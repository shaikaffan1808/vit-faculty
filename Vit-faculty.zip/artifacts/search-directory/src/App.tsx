import { useEffect, useMemo, useRef, useState } from 'react';
import { Mail, MapPin, Moon, Search, Sun, X } from 'lucide-react';
import { faculty, type Faculty } from '@/data/faculty';

type Theme = 'day' | 'night';

const avatarColors = ['avatar-coral', 'avatar-sage', 'avatar-gold', 'avatar-blue'] as const;

function getInitials(name: string) {
  return name
    .split(' ')
    .filter(Boolean)
    .map((part) => part[0])
    .slice(0, 2)
    .join('');
}

function getAvatarTone(id: string) {
  const total = [...id].reduce((sum, character) => sum + character.charCodeAt(0), 0);
  return avatarColors[total % avatarColors.length];
}

function displayValue(value: string | null | undefined) {
  return value?.trim() || 'Not listed';
}

function FacultyCard({
  member,
  index,
  onSelect,
}: {
  member: Faculty;
  index: number;
  onSelect: (member: Faculty) => void;
}) {
  const [imageFailed, setImageFailed] = useState(false);

  return (
    <article
      className="faculty-card animate-rise"
      style={{ animationDelay: `${Math.min(index, 14) * 28}ms` }}
      tabIndex={0}
      role="button"
      aria-label={`Open profile for ${member.name}`}
      onClick={(event) => {
        if (event.target instanceof HTMLElement && event.target.closest('a')) return;
        onSelect(member);
      }}
      onKeyDown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          onSelect(member);
        }
      }}
      data-testid={`card-faculty-${member.id}`}
    >
      <div className={`faculty-photo ${getAvatarTone(member.id)}`} aria-label={`${member.name} photo`}>
        {member.photoUrl && !imageFailed ? (
          <img
            src={member.photoUrl}
            alt={`${member.name}`}
            loading="lazy"
            onError={() => setImageFailed(true)}
          />
        ) : (
          <span>{getInitials(member.name)}</span>
        )}
      </div>

      <div className="faculty-card-content">
        <div className="faculty-card-heading">
          <div>
            <h2 data-testid={`text-faculty-name-${member.id}`}>{member.name}</h2>
            <p>{displayValue(member.designation)}</p>
          </div>
          <span className="school-pill">{displayValue(member.department)}</span>
        </div>

        <div className="faculty-card-meta">
          <span className="cabin-detail">
            <MapPin size={14} strokeWidth={1.8} aria-hidden="true" />
            <span className="cabin-label">Cabin</span>
            <strong className="cabin-number">{displayValue(member.office)}</strong>
          </span>
          {member.email ? (
            <a href={`mailto:${member.email}`}>
              <Mail size={14} strokeWidth={1.8} aria-hidden="true" />
              {member.email}
            </a>
          ) : (
            <span className="muted-meta">
              <Mail size={14} strokeWidth={1.8} aria-hidden="true" />
              Email not listed
            </span>
          )}
        </div>
      </div>
    </article>
  );
}

function FacultyProfile({ member, onClose }: { member: Faculty; onClose: () => void }) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const [imageFailed, setImageFailed] = useState(false);
  const [isClosing, setIsClosing] = useState(false);

  const requestClose = () => {
    if (!isClosing) setIsClosing(true);
  };

  useEffect(() => {
    dialogRef.current?.focus();
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setIsClosing(true);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
    <div
      className={`profile-modal-backdrop ${isClosing ? 'is-closing' : ''}`}
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) requestClose();
      }}
      onAnimationEnd={(event) => {
        if (isClosing && event.target === event.currentTarget) onClose();
      }}
    >
      <div
        ref={dialogRef}
        className={`profile-modal ${isClosing ? 'is-closing' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="faculty-profile-title"
        tabIndex={-1}
      >
        <div className="profile-modal-heading">
          <div>
            <span className="section-kicker">Faculty profile</span>
            <h2 id="faculty-profile-title">{member.name}</h2>
            <p>{displayValue(member.designation)}</p>
          </div>
          <button type="button" className="profile-close" onClick={requestClose} aria-label="Close faculty profile">
            <X size={18} strokeWidth={2} aria-hidden="true" />
          </button>
        </div>

        <div className="profile-modal-grid">
          <div className={`profile-photo ${getAvatarTone(member.id)}`}>
            {member.photoUrl && !imageFailed ? (
              <img src={member.photoUrl} alt={member.name} onError={() => setImageFailed(true)} />
            ) : (
              <span>{getInitials(member.name)}</span>
            )}
          </div>

          <div className="profile-info">
            <div className="profile-info-grid">
              <div>
                <span>School</span>
                <strong>{displayValue(member.department)}</strong>
              </div>
              <div>
                <span>Cabin / office</span>
                <strong className="profile-cabin-number">{displayValue(member.office)}</strong>
              </div>
              <div>
                <span>Email</span>
                {member.email ? <a href={`mailto:${member.email}`}>{member.email}</a> : <strong>Not listed</strong>}
              </div>
              <div>
                <span>Contact</span>
                <strong>{displayValue(member.phone)}</strong>
              </div>
            </div>

            {member.researchArea ? (
              <div className="profile-research">
                <span>Research area</span>
                <p>{member.researchArea}</p>
              </div>
            ) : null}

          </div>
        </div>
      </div>
    </div>
  );
}

function ThemeToggle({ theme, onChange }: { theme: Theme; onChange: (theme: Theme) => void }) {
  return (
    <div className="theme-toggle" aria-label="Choose page theme">
      <button
        type="button"
        className={theme === 'day' ? 'theme-option is-active' : 'theme-option'}
        aria-pressed={theme === 'day'}
        onClick={() => onChange('day')}
      >
        <Sun size={14} strokeWidth={1.8} aria-hidden="true" />
        Day
      </button>
      <button
        type="button"
        className={theme === 'night' ? 'theme-option is-active' : 'theme-option'}
        aria-pressed={theme === 'night'}
        onClick={() => onChange('night')}
      >
        <Moon size={14} strokeWidth={1.8} aria-hidden="true" />
        Night
      </button>
    </div>
  );
}

function getInitialTheme(): Theme {
  if (typeof window === 'undefined') return 'day';
  const saved = window.localStorage.getItem('vitap-directory-theme');
  if (saved === 'day' || saved === 'night') return saved;
  return 'day';
}

function Home() {
  const [query, setQuery] = useState('');
  const [theme, setTheme] = useState<Theme>(getInitialTheme);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedFaculty, setSelectedFaculty] = useState<Faculty | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    window.localStorage.setItem('vitap-directory-theme', theme);
  }, [theme]);

  useEffect(() => {
    const timer = window.setTimeout(() => setIsLoading(false), 380);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const handleShortcut = (event: KeyboardEvent) => {
      if (event.key === '/' && document.activeElement?.tagName !== 'INPUT') {
        event.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleShortcut);
    return () => window.removeEventListener('keydown', handleShortcut);
  }, []);

  const filteredFaculty = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase().replace(/\s+/g, ' ');
    if (!normalizedQuery) return faculty;

    return faculty.filter((member) => {
      const searchableText = [
        member.name,
        member.designation,
        member.department,
        member.subDepartment,
        member.office,
        member.email,
      ]
        .filter(Boolean)
        .join(' ')
        .toLocaleLowerCase();
      return searchableText.includes(normalizedQuery);
    });
  }, [query]);

  const clearSearch = () => {
    setQuery('');
    setSelectedFaculty(null);
    inputRef.current?.focus();
  };

  return (
    <main className="directory-shell grain">
      <header className="site-header">
        <div className="header-actions">
          <ThemeToggle theme={theme} onChange={setTheme} />
        </div>
      </header>

      <div className="directory-container">
        <section className="hero-section" aria-labelledby="page-title">
          <div className="hero-brand" aria-label="VIT-AP University">
            <strong>VIT-AP</strong>
            <span>UNIVERSITY</span>
          </div>
          <h1 id="page-title">Find your faculty</h1>
        </section>

        <section className="search-panel" aria-label="Search faculty">
          <div className="search-label-row">
            <label htmlFor="faculty-search">Search the faculty directory</label>
          </div>
          <div className={`search-field ${query ? 'has-query' : ''}`}>
            <Search size={20} strokeWidth={1.8} aria-hidden="true" />
            <input
              ref={inputRef}
              id="faculty-search"
              type="search"
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setSelectedFaculty(null);
              }}
              placeholder="Type a faculty name, e.g. Srinivas"
              autoComplete="off"
              spellCheck="false"
              data-testid="input-faculty-search"
            />
            {query ? (
              <button type="button" className="clear-button" onClick={clearSearch} aria-label="Clear search">
                <X size={17} strokeWidth={2} aria-hidden="true" />
              </button>
            ) : null}
          </div>
          <div className="search-footer">
            <span><i className="scope-marker" aria-hidden="true" />Names, schools, cabins, and emails</span>
            <strong data-testid="text-result-count">
              {isLoading ? 'Loading…' : `${filteredFaculty.length} ${filteredFaculty.length === 1 ? 'match' : 'matches'}`}
            </strong>
          </div>
        </section>

        <section className="results-section" aria-labelledby="results-title">
          <div className="results-heading">
            <div>
              <span className="section-kicker">VIT-AP faculty</span>
              <h2 id="results-title">{query ? 'Matching faculty' : 'All faculty'}</h2>
            </div>
            <span className="results-total">{isLoading ? '—' : filteredFaculty.length}</span>
          </div>

          {isLoading ? (
            <div className="results-list" aria-label="Loading faculty">
              {[1, 2, 3].map((item) => <div className="skeleton-card" key={item} />)}
            </div>
          ) : filteredFaculty.length ? (
            <div className="results-list" data-testid="list-faculty-results">
              {filteredFaculty.map((member, index) => (
                <FacultyCard
                  key={member.id}
                  member={member}
                  index={index}
                  onSelect={setSelectedFaculty}
                />
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <Search size={22} strokeWidth={1.7} aria-hidden="true" />
              <div>
                <h3>No faculty match found</h3>
                <p>Try a shorter name, school, or cabin number.</p>
                <button type="button" onClick={clearSearch}>Clear search</button>
              </div>
            </div>
          )}
        </section>

        <footer className="directory-footer">
          <span>VIT-AP University</span>
          <span className="footer-credit">by SHAIK.A</span>
        </footer>
      </div>
      {selectedFaculty ? <FacultyProfile member={selectedFaculty} onClose={() => setSelectedFaculty(null)} /> : null}
    </main>
  );
}

export default Home;