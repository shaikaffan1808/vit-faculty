import { access, mkdir, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const SOURCE_PAGE = 'https://vitap.ac.in/allfaculty';
const CMS_API = 'https://cms.vitap.ac.in/api/faculty-profiles';
const outputPath = fileURLToPath(new URL('../src/data/faculty.ts', import.meta.url));

const cleanText = (value) => {
  if (typeof value !== 'string') return null;
  const cleaned = value.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  return cleaned || null;
};

const valueFrom = (value, keys) => {
  if (typeof value === 'string') return cleanText(value);
  if (!value || typeof value !== 'object') return null;
  return keys.map((key) => cleanText(value[key])).find(Boolean) ?? null;
};

const listFrom = (value, keys) => {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.map((entry) => valueFrom(entry, keys)).filter(Boolean))];
};

const photoUrlFrom = (photo) =>
  cleanText(photo?.data?.attributes?.url) ?? cleanText(photo?.url);

const normalize = (record, index, source) => {
  const attributes = record.attributes ?? record;
  const employeeId =
    attributes.Employee_Id === null || attributes.Employee_Id === undefined
      ? null
      : String(attributes.Employee_Id);
  const membership = cleanText(attributes.Professonal_Membership);
  const linkFields = [
    ['linkedin', 'LinkedIn'],
    ['website', 'Website'],
    ['dblp', 'Research_DBLP'],
    ['researchGate', 'Research_Research_Gate'],
    ['googleScholar', 'Research_google_schloar'],
    ['orcid', 'Research_orchid'],
    ['scopus', 'Research_Scopus_Id'],
    ['vidwan', 'Research_vidwan'],
  ];
  const links = Object.fromEntries(
    linkFields
      .map(([key, sourceKey]) => [key, cleanText(attributes[sourceKey])])
      .filter(([, value]) => value),
  );
  const sourceId = record.id ?? employeeId ?? index;

  return {
    id: `vitap-${String(sourceId).replace(/[^a-zA-Z0-9]+/g, '-')}-${source}`,
    name: cleanText(attributes.Name) ?? 'Unnamed faculty member',
    employeeId,
    designation: cleanText(attributes.Designation),
    department: cleanText(attributes.Department),
    subDepartment: cleanText(attributes.sub_department),
    office: cleanText(attributes.Office_Address),
    email: cleanText(attributes.EMAIL),
    phone: cleanText(attributes.Contact_No),
    photoUrl: photoUrlFrom(attributes.Photo),
    education: [
      attributes.Education_UG,
      attributes.Education_PG,
      attributes.Education_PHD,
      attributes.Education_other,
    ]
      .map(cleanText)
      .filter(Boolean),
    researchArea: cleanText(attributes.Research_area_of_specialization),
    memberships: membership ? [membership] : [],
    projects: listFrom(attributes.Projects, ['project', 'Project', 'title', 'Title']),
    patents: listFrom(attributes.Patents, ['patent', 'Patent', 'title', 'Title']),
    awards: listFrom(attributes.Awards_and_Recognitions, [
      'award_or_recognition_name',
      'award',
      'name',
      'title',
    ]),
    links,
  };
};

const findBalancedArray = (source, start) => {
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let index = start; index < source.length; index += 1) {
    const character = source[index];
    if (quote) {
      if (escaped) escaped = false;
      else if (character === '\\') escaped = true;
      else if (character === quote) quote = null;
      continue;
    }
    if (character === '"' || character === "'") {
      quote = character;
      continue;
    }
    if (character === '[') depth += 1;
    if (character === ']') {
      depth -= 1;
      if (depth === 0) return source.slice(start, index + 1);
    }
  }
  throw new Error('Could not find the embedded SBST faculty array.');
};

class OfficialSourceUnavailable extends Error {}

const fetchResponse = async (url, options) => {
  let response;
  try {
    response = await fetch(url, {
      ...options,
      signal: options?.signal ?? AbortSignal.timeout(15000),
    });
  } catch (error) {
    throw new OfficialSourceUnavailable(`Could not reach ${url}: ${error.message}`);
  }
  if (!response.ok) {
    throw new OfficialSourceUnavailable(`Request failed (${response.status}) for ${url}`);
  }
  return response;
};

const fetchText = async (url, options) => {
  const response = await fetchResponse(url, options);
  try {
    return await response.text();
  } catch (error) {
    throw new OfficialSourceUnavailable(`Could not read ${url}: ${error.message}`);
  }
};

const fetchJson = async (url, options) => {
  const response = await fetchResponse(url, options);
  let text;
  try {
    text = await response.text();
  } catch (error) {
    throw new OfficialSourceUnavailable(`Could not read ${url}: ${error.message}`);
  }
  try {
    return JSON.parse(text);
  } catch (error) {
    throw new Error(`Invalid JSON response from ${url}: ${error.message}`);
  }
};

const refreshFaculty = async () => {
const pageHtml = await fetchText(SOURCE_PAGE);
const chunkPath = pageHtml.match(
  /src="([^"]*\/_next\/static\/chunks\/app\/(?:%28academics%29|\(academics\))\/allfaculty\/page-[^"]+\.js)"/,
)?.[1];
if (!chunkPath) throw new Error('Could not locate the VIT-AP faculty page bundle.');

const chunkUrl = new URL(chunkPath.replaceAll('&amp;', '&'), SOURCE_PAGE).href;
const chunk = await fetchText(chunkUrl);
const token = chunk.match(/Authorization:"Bearer "\.concat\("([^"]+)"\)/)?.[1];
if (!token) throw new Error('Could not locate the CMS authorization token in the faculty bundle.');

const cmsRecords = [];
for (let page = 1; page <= 100; page += 1) {
  const url = new URL(CMS_API);
  url.searchParams.set('populate', '*');
  url.searchParams.set('sort', 'Employee_Id:ASC');
  url.searchParams.set('pagination[page]', String(page));
  url.searchParams.set('pagination[pageSize]', '100');
  const response = await fetchJson(url, {
    headers: { Authorization: `Bearer ${token}` },
  });
  cmsRecords.push(...(response.data ?? []));
  const pagination = response.meta?.pagination;
  if (!pagination || page >= pagination.pageCount) break;
}

const arrayStart = chunk.indexOf('r=[{id:1,attributes:');
if (arrayStart < 0) throw new Error('Could not locate the embedded SBST faculty records.');
const embeddedExpression = findBalancedArray(chunk, arrayStart + 2);
const embeddedRecords = Function(`"use strict"; return (${embeddedExpression});`)();
const records = [
  ...cmsRecords.map((record, index) => normalize(record, index, 'cms')),
  ...embeddedRecords.map((record, index) => normalize(record, index, 'sbst')),
];

const seenNames = new Set();
const faculty = records.filter((record) => {
  const key = record.name.toLocaleLowerCase().replace(/\s+/g, ' ').trim();
  if (seenNames.has(key)) return false;
  seenNames.add(key);
  return true;
});

const generatedAt = new Date().toISOString();
const output = `/* Generated from ${SOURCE_PAGE} on ${generatedAt}. Run the faculty ingestion script to refresh. */\n\nexport type FacultyLinkKey = 'linkedin' | 'website' | 'dblp' | 'researchGate' | 'googleScholar' | 'orcid' | 'scopus' | 'vidwan';\n\nexport type Faculty = {\n  id: string;\n  name: string;\n  employeeId: string | null;\n  designation: string | null;\n  department: string | null;\n  subDepartment: string | null;\n  office: string | null;\n  email: string | null;\n  phone: string | null;\n  photoUrl: string | null;\n  education: string[];\n  researchArea: string | null;\n  memberships: string[];\n  projects: string[];\n  patents: string[];\n  awards: string[];\n  links: Partial<Record<FacultyLinkKey, string>>;\n};\n\nexport const facultySource = {\n  pageUrl: ${JSON.stringify(SOURCE_PAGE)},\n  cmsApi: ${JSON.stringify(CMS_API)},\n  refreshedAt: ${JSON.stringify(generatedAt)},\n  cmsRecords: ${cmsRecords.length},\n  embeddedRecords: ${embeddedRecords.length},\n  recordCount: ${faculty.length},\n} as const;\n\nexport const faculty: Faculty[] = ${JSON.stringify(faculty, null, 2)};\n`;

await mkdir(dirname(outputPath), { recursive: true });
await writeFile(outputPath, output);
const mobileFacultyPath = fileURLToPath(new URL('../../faculty-mobile/src/data/faculty.ts', import.meta.url));
try {
  await access(dirname(mobileFacultyPath));
  await writeFile(mobileFacultyPath, output);
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
}
console.log(
  `Ingested ${faculty.length} faculty records (${cmsRecords.length} CMS + ${embeddedRecords.length} embedded; ${records.length - faculty.length} duplicate omitted).`,
);
};

try {
  await refreshFaculty();
} catch (error) {
  if (!(error instanceof OfficialSourceUnavailable)) throw error;
  try {
    await access(outputPath);
  } catch {
    throw error;
  }
  console.warn(
    `Official faculty refresh unavailable; keeping the bundled snapshot. ${error.message}`,
  );
}