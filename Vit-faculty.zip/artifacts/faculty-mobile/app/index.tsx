import { useEffect, useMemo, useState } from 'react';
import {
  FlatList,
  ImageBackground,
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import * as Haptics from 'expo-haptics';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { faculty, type Faculty } from '@/src/data/faculty';
import { useColors } from '@/hooks/useColors';
import { FacultyCard } from '@/components/FacultyCard';
import { FacultyProfileModal } from '@/components/FacultyProfileModal';

type Theme = 'day' | 'night';

const THEME_STORAGE_KEY = 'vitap-directory-theme';

function getSearchableText(member: Faculty) {
  return [
    member.name,
    member.designation,
    member.department,
    member.subDepartment,
    member.office,
    member.email,
  ]
    .filter(Boolean)
    .join(' ')
    .toLocaleLowerCase();
}

export default function FacultyDirectoryScreen() {
  const insets = useSafeAreaInsets();
  const [theme, setTheme] = useState<Theme>('day');
  const [query, setQuery] = useState('');
  const [selectedFaculty, setSelectedFaculty] = useState<Faculty | null>(null);
  const colors = useColors(theme === 'day' ? 'light' : 'dark');

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(THEME_STORAGE_KEY)
      .then((savedTheme) => {
        if (active && (savedTheme === 'day' || savedTheme === 'night')) {
          setTheme(savedTheme);
        }
      })
      .catch((error) => console.warn('Could not restore theme preference:', error));
    return () => {
      active = false;
    };
  }, []);

  const filteredFaculty = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase().replace(/\s+/g, ' ');
    if (!normalizedQuery) return faculty;
    return faculty.filter((member) => getSearchableText(member).includes(normalizedQuery));
  }, [query]);

  const changeTheme = (nextTheme: Theme) => {
    setTheme(nextTheme);
    void Haptics.selectionAsync().catch(() => undefined);
    AsyncStorage.setItem(THEME_STORAGE_KEY, nextTheme).catch((error) => {
      console.warn('Could not save theme preference:', error);
    });
  };

  const openProfile = (member: Faculty) => {
    Keyboard.dismiss();
    void Haptics.selectionAsync().catch(() => undefined);
    setSelectedFaculty(member);
  };

  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? Math.max(insets.bottom, 34) : insets.bottom;

  const listHeader = (
    <View>
      <View style={styles.topBar}>
        <View>
          <Text style={[styles.brand, { color: colors.primary }]}>VIT-AP</Text>
          <Text style={[styles.brandSub, { color: colors.primary }]}>UNIVERSITY</Text>
        </View>
        <View style={[styles.themeToggle, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Use Day theme"
            accessibilityState={{ selected: theme === 'day' }}
            onPress={() => changeTheme('day')}
            style={[styles.themeOption, theme === 'day' && { backgroundColor: colors.accent }]}
            testID="theme-day"
          >
            <Ionicons name="sunny-outline" size={15} color={theme === 'day' ? colors.primary : colors.mutedForeground} />
            <Text style={[styles.themeText, { color: theme === 'day' ? colors.primary : colors.mutedForeground }]}>Day</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Use Night theme"
            accessibilityState={{ selected: theme === 'night' }}
            onPress={() => changeTheme('night')}
            style={[styles.themeOption, theme === 'night' && { backgroundColor: colors.accent }]}
            testID="theme-night"
          >
            <Ionicons name="moon-outline" size={15} color={theme === 'night' ? colors.primary : colors.mutedForeground} />
            <Text style={[styles.themeText, { color: theme === 'night' ? colors.primary : colors.mutedForeground }]}>Night</Text>
          </Pressable>
        </View>
      </View>

      <Text style={[styles.heroTitle, { color: colors.heading }]}>
        Find your faculty
      </Text>
      <View
        style={[
          styles.searchPanel,
          { backgroundColor: colors.card, borderColor: colors.border, shadowColor: colors.shadow },
        ]}
      >
        <Text style={[styles.searchLabel, { color: colors.foreground }]}>Search the faculty directory</Text>
        <View style={[styles.searchField, { backgroundColor: colors.background, borderColor: colors.input }]}>
          <Ionicons name="search-outline" size={19} color={colors.mutedForeground} />
          <TextInput
            accessibilityLabel="Search the faculty directory"
            autoCapitalize="none"
            autoCorrect={false}
            clearButtonMode="never"
            onChangeText={setQuery}
            placeholder="Name, school, cabin, or email"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="search"
            style={[styles.searchInput, { color: colors.foreground }]}
            value={query}
            testID="input-faculty-search"
          />
          {query.length > 0 ? (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Clear search"
              hitSlop={10}
              onPress={() => setQuery('')}
              testID="clear-search"
            >
              <Ionicons name="close-circle" size={20} color={colors.mutedForeground} />
            </Pressable>
          ) : null}
        </View>
        <View style={styles.searchFooter}>
          <Text style={[styles.offlineLabel, { color: colors.mutedForeground }]}>
            <Ionicons name="cloud-offline-outline" size={13} color={colors.primary} /> Offline directory
          </Text>
          <Text style={[styles.matchCount, { color: colors.primary }]}>
            {filteredFaculty.length} {filteredFaculty.length === 1 ? 'match' : 'matches'}
          </Text>
        </View>
      </View>

      <View style={[styles.resultsHeading, { borderBottomColor: colors.border }]}>
        <View>
          <Text style={[styles.sectionKicker, { color: colors.heading }]}>
            VIT-AP FACULTY
          </Text>
          <Text style={[styles.resultsTitle, { color: colors.foreground }]}>
            {query ? 'Matching faculty' : 'All faculty'}
          </Text>
        </View>
        <Text style={[styles.resultsTotal, { color: colors.primary }]}>{filteredFaculty.length}</Text>
      </View>
    </View>
  );

  return (
    <ImageBackground
      source={require('../assets/images/campus-background.png')}
      resizeMode="cover"
      style={styles.background}
      imageStyle={styles.backgroundImage}
    >
      <View style={[styles.tint, { backgroundColor: colors.backgroundOverlay }]}>
        <StatusBar style={theme === 'day' ? 'dark' : 'light'} />
        <KeyboardAvoidingView
          behavior={Platform.OS === 'web' ? undefined : 'padding'}
          keyboardVerticalOffset={0}
          style={styles.flex}
        >
          <FlatList
            contentContainerStyle={[
              styles.listContent,
              { paddingTop: topInset + 14, paddingBottom: bottomInset + 24 },
            ]}
            data={filteredFaculty}
            keyExtractor={(member) => member.id}
            keyboardDismissMode={Platform.OS === 'ios' ? 'interactive' : 'on-drag'}
            keyboardShouldPersistTaps="handled"
            ListEmptyComponent={
              <View style={[styles.emptyState, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Ionicons name="search-outline" size={26} color={colors.primary} />
                <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No faculty found</Text>
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                  Try a shorter name, school, cabin, or email.
                </Text>
                <Pressable
                  accessibilityRole="button"
                  onPress={() => setQuery('')}
                  style={[styles.clearSearchButton, { backgroundColor: colors.primary }]}
                >
                  <Text style={[styles.clearSearchText, { color: colors.primaryForeground }]}>Clear search</Text>
                </Pressable>
              </View>
            }
            ListFooterComponent={
              <Text style={[styles.footerText, { color: colors.mutedForeground }]}>
                Faculty data is bundled on this device.
              </Text>
            }
            ListHeaderComponent={listHeader}
            renderItem={({ item }) => (
              <FacultyCard member={item} colors={colors} onPress={openProfile} />
            )}
            scrollEnabled={filteredFaculty.length > 0}
            showsVerticalScrollIndicator={false}
            style={styles.flex}
          />
        </KeyboardAvoidingView>
      </View>
      <FacultyProfileModal
        key={selectedFaculty?.id ?? 'closed'}
        colors={colors}
        member={selectedFaculty}
        onClose={() => setSelectedFaculty(null)}
      />
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  background: { flex: 1 },
  backgroundImage: { opacity: 1 },
  tint: { flex: 1 },
  listContent: { paddingHorizontal: 18 },
  topBar: {
    minHeight: 52,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 12,
  },
  brand: {
    fontSize: 27,
    lineHeight: 29,
    fontWeight: '800',
    letterSpacing: -1.4,
  },
  brandSub: {
    marginTop: 1,
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 3.5,
  },
  themeToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 3,
    borderWidth: 1,
    borderRadius: 10,
  },
  themeOption: {
    minHeight: 34,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    paddingHorizontal: 9,
    borderRadius: 7,
  },
  themeText: { fontSize: 11, fontWeight: '700' },
  heroTitle: {
    marginTop: 24,
    marginBottom: 21,
    fontSize: 34,
    lineHeight: 39,
    fontWeight: '700',
    letterSpacing: -1.4,
  },
  searchPanel: {
    padding: 16,
    borderWidth: 1,
    borderRadius: 16,
    shadowOpacity: 0.1,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 7 },
    elevation: 4,
  },
  searchLabel: { marginBottom: 10, fontSize: 13, fontWeight: '700' },
  searchField: {
    minHeight: 49,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderRadius: 10,
  },
  searchInput: { flex: 1, minWidth: 0, paddingVertical: 10, fontSize: 14 },
  searchFooter: {
    marginTop: 11,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 10,
  },
  offlineLabel: { fontSize: 10, fontWeight: '600' },
  matchCount: { fontSize: 11, fontWeight: '800' },
  resultsHeading: {
    marginTop: 35,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  sectionKicker: { fontSize: 9, fontWeight: '800', letterSpacing: 1.5 },
  resultsTitle: { marginTop: 5, fontSize: 21, fontWeight: '700', letterSpacing: -0.5 },
  resultsTotal: { fontSize: 13, fontWeight: '800' },
  emptyState: {
    alignItems: 'center',
    padding: 25,
    borderWidth: 1,
    borderRadius: 14,
  },
  emptyTitle: { marginTop: 10, fontSize: 17, fontWeight: '700' },
  emptyText: { marginTop: 5, fontSize: 13, textAlign: 'center', lineHeight: 19 },
  clearSearchButton: { marginTop: 14, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 9 },
  clearSearchText: { fontSize: 12, fontWeight: '700' },
  footerText: { marginTop: 19, textAlign: 'center', fontSize: 10 },
});
