import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import type { Faculty } from '@/src/data/faculty';

type Palette = ReturnType<typeof import('@/hooks/useColors').useColors>;

function getInitials(name: string) {
  return name.split(/\s+/).filter(Boolean).map((part) => part[0]).slice(0, 2).join('');
}

function displayValue(value: string | null | undefined) {
  return value?.trim() || 'Not listed';
}

export function FacultyCard({
  member,
  colors,
  onPress,
}: {
  member: Faculty;
  colors: Palette;
  onPress: (member: Faculty) => void;
}) {
  const [imageFailed, setImageFailed] = useState(false);

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Open profile for ${member.name}`}
      onPress={() => onPress(member)}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: pressed ? colors.primary : colors.border,
          opacity: pressed ? 0.92 : 1,
        },
      ]}
      testID={`card-faculty-${member.id}`}
    >
      <View style={[styles.photo, { backgroundColor: colors.accent }]}>
        {member.photoUrl && !imageFailed ? (
          <Image
            source={{ uri: member.photoUrl }}
            style={StyleSheet.absoluteFill}
            contentFit="cover"
            cachePolicy="memory-disk"
            transition={150}
            onError={() => setImageFailed(true)}
            accessibilityLabel={`${member.name} portrait`}
          />
        ) : (
          <Text style={[styles.initials, { color: colors.primary }]}>{getInitials(member.name)}</Text>
        )}
      </View>
      <View style={styles.content}>
        <View style={styles.headingRow}>
          <Text style={[styles.name, { color: colors.foreground }]} numberOfLines={2}>
            {member.name}
          </Text>
          <Text style={[styles.schoolPill, { color: colors.primary, backgroundColor: colors.accent }]}>
            {displayValue(member.department)}
          </Text>
        </View>
        <Text style={[styles.designation, { color: colors.primary }]} numberOfLines={2}>
          {displayValue(member.designation)}
        </Text>
        <View style={styles.metaRow}>
          <Ionicons name="location-outline" size={14} color={colors.mutedForeground} />
          <Text style={[styles.cabinLabel, { color: colors.mutedForeground }]}>Cabin</Text>
          <Text style={[styles.cabinValue, { color: colors.primary }]} numberOfLines={2}>
            {displayValue(member.office)}
          </Text>
        </View>
        <View style={styles.metaRow}>
          <Ionicons name="mail-outline" size={14} color={colors.mutedForeground} />
          <Text style={[styles.email, { color: colors.mutedForeground }]} numberOfLines={1}>
            {displayValue(member.email)}
          </Text>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    width: '100%',
    minHeight: 135,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 10,
    padding: 12,
    borderWidth: 1,
    borderRadius: 13,
  },
  photo: {
    width: 68,
    height: 84,
    flexShrink: 0,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 9,
  },
  initials: { fontSize: 16, fontWeight: '800' },
  content: { flex: 1, minWidth: 0, paddingTop: 1 },
  headingRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 7 },
  name: { flex: 1, minWidth: 0, fontSize: 15, lineHeight: 19, fontWeight: '800' },
  schoolPill: {
    maxWidth: '44%',
    overflow: 'hidden',
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 5,
    fontSize: 8,
    lineHeight: 11,
    fontWeight: '700',
  },
  designation: { marginTop: 4, fontSize: 12, lineHeight: 16, fontWeight: '600' },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 7, minWidth: 0 },
  cabinLabel: { fontSize: 11, fontWeight: '600' },
  cabinValue: { flex: 1, minWidth: 0, fontSize: 12, lineHeight: 16, fontWeight: '800' },
  email: { flex: 1, minWidth: 0, fontSize: 11, lineHeight: 15 },
});
