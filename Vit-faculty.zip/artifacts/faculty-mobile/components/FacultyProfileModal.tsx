import { useState } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { Faculty } from '@/src/data/faculty';

type Palette = ReturnType<typeof import('@/hooks/useColors').useColors>;

function displayValue(value: string | null | undefined) {
  return value?.trim() || 'Not listed';
}

function getInitials(name: string) {
  return name.split(/\s+/).filter(Boolean).map((part) => part[0]).slice(0, 2).join('');
}

function ProfileField({
  label,
  value,
  colors,
  highlighted = false,
}: {
  label: string;
  value: string;
  colors: Palette;
  highlighted?: boolean;
}) {
  return (
    <View style={styles.field}>
      <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.fieldValue, { color: highlighted ? colors.primary : colors.foreground }]}>
        {value}
      </Text>
    </View>
  );
}

export function FacultyProfileModal({
  member,
  colors,
  onClose,
}: {
  member: Faculty | null;
  colors: Palette;
  onClose: () => void;
}) {
  const { width, height } = useWindowDimensions();
  const [imageFailed, setImageFailed] = useState(false);
  const modalWidth = Math.min(width - 28, 560);

  return (
    <Modal
      visible={member !== null}
      transparent
      animationType="fade"
      statusBarTranslucent
      onRequestClose={onClose}
    >
      <View style={[styles.backdrop, { backgroundColor: colors.modalBackdrop }]}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Close faculty profile"
          onPress={onClose}
          style={StyleSheet.absoluteFill}
        />
        {member ? (
          <View
            style={[
              styles.modalCard,
              {
                width: modalWidth,
                maxHeight: Math.min(height - 28, 760),
                backgroundColor: colors.card,
                borderColor: colors.border,
                shadowColor: colors.shadow,
              },
            ]}
          >
            <View style={[styles.modalHeading, { borderBottomColor: colors.border }]}>
              <View style={styles.headingText}>
                <Text style={[styles.kicker, { color: colors.primary }]}>FACULTY PROFILE</Text>
                <Text style={[styles.profileName, { color: colors.foreground }]}>{member.name}</Text>
                <Text style={[styles.profileDesignation, { color: colors.primary }]}>
                  {displayValue(member.designation)}
                </Text>
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Close faculty profile"
                hitSlop={10}
                onPress={onClose}
                style={[styles.closeButton, { backgroundColor: colors.muted }]}
                testID="close-faculty-profile"
              >
                <Ionicons name="close" size={20} color={colors.foreground} />
              </Pressable>
            </View>
            <ScrollView
              contentContainerStyle={styles.profileBody}
              showsVerticalScrollIndicator={false}
            >
              <View style={[styles.profilePhoto, { backgroundColor: colors.accent }]}>
                {member.photoUrl && !imageFailed ? (
                  <Image
                    source={{ uri: member.photoUrl }}
                    style={StyleSheet.absoluteFill}
                    contentFit="cover"
                    cachePolicy="memory-disk"
                    onError={() => setImageFailed(true)}
                    accessibilityLabel={`${member.name} portrait`}
                  />
                ) : (
                  <Text style={[styles.profileInitials, { color: colors.primary }]}>
                    {getInitials(member.name)}
                  </Text>
                )}
              </View>
              <View style={styles.fieldsGrid}>
                <ProfileField label="School" value={displayValue(member.department)} colors={colors} />
                <ProfileField label="Department area" value={displayValue(member.subDepartment)} colors={colors} />
                <ProfileField label="Cabin / office" value={displayValue(member.office)} colors={colors} highlighted />
                <ProfileField label="Email" value={displayValue(member.email)} colors={colors} />
                <ProfileField label="Contact" value={displayValue(member.phone)} colors={colors} />
              </View>
              {member.researchArea ? (
                <View style={[styles.researchBlock, { borderTopColor: colors.border }]}>
                  <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>RESEARCH AREA</Text>
                  <Text style={[styles.researchText, { color: colors.foreground }]}>{member.researchArea}</Text>
                </View>
              ) : null}
              {member.education.length > 0 ? (
                <View style={[styles.researchBlock, { borderTopColor: colors.border }]}>
                  <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>EDUCATION</Text>
                  {member.education.map((item, index) => (
                    <Text key={`${member.id}-education-${index}`} style={[styles.researchText, { color: colors.foreground }]}>
                      {item}
                    </Text>
                  ))}
                </View>
              ) : null}
            </ScrollView>
          </View>
        ) : null}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 14 },
  modalCard: {
    overflow: 'hidden',
    borderWidth: 1,
    borderRadius: 20,
    shadowOpacity: 0.25,
    shadowRadius: 28,
    shadowOffset: { width: 0, height: 12 },
    elevation: 12,
  },
  modalHeading: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 10,
    padding: 18,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  headingText: { flex: 1, minWidth: 0 },
  kicker: { fontSize: 9, fontWeight: '800', letterSpacing: 1.3 },
  profileName: { marginTop: 7, fontSize: 23, lineHeight: 28, fontWeight: '800', letterSpacing: -0.5 },
  profileDesignation: { marginTop: 6, fontSize: 13, lineHeight: 18, fontWeight: '600' },
  closeButton: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center', borderRadius: 17 },
  profileBody: { paddingHorizontal: 18, paddingTop: 17, paddingBottom: 22 },
  profilePhoto: {
    width: 110,
    height: 132,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    borderRadius: 12,
    marginBottom: 18,
  },
  profileInitials: { fontSize: 22, fontWeight: '800' },
  fieldsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 14 },
  field: { width: '47%', minWidth: 120, gap: 4 },
  fieldLabel: { fontSize: 9, fontWeight: '800', letterSpacing: 0.8, textTransform: 'uppercase' },
  fieldValue: { fontSize: 13, lineHeight: 18, fontWeight: '600', overflow: 'hidden' },
  researchBlock: { marginTop: 18, paddingTop: 15, borderTopWidth: StyleSheet.hairlineWidth, gap: 6 },
  researchText: { fontSize: 13, lineHeight: 19 },
});
