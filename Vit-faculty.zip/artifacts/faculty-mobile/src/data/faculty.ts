/* Generated from https://vitap.ac.in/allfaculty on 2026-10-15T18:15:47.572Z. Run the faculty ingestion script to refresh. */

export type FacultyLinkKey = 'linkedin' | 'website' | 'dblp' | 'researchGate' | 'googleScholar' | 'orcid' | 'scopus' | 'vidwan';

export type Faculty = {
  id: string;
  name: string;
  employeeId: string | null;
  designation: string | null;
  department: string | null;
  subDepartment: string | null;
  office: string | null;
  email: string | null;
  phone: string | null;
  photoUrl: string | null;
  education: string[];
  researchArea: string | null;
  memberships: string[];
  projects: string[];
  patents: string[];
  awards: string[];
  links: Partial<Record<FacultyLinkKey, string>>;
};

export const facultySource = {
  pageUrl: "https://vitap.ac.in/allfaculty",
  cmsApi: "https://cms.vitap.ac.in/api/faculty-profiles",
  refreshedAt: "2026-10-15T18:15:47.572Z",
  cmsRecords: 602,
  embeddedRecords: 7,
  recordCount: 609,
} as const;

export const faculty: Faculty[] = [
  {
    "id": "vitap-1285-cms",
    "name": "Dr. Srinivas S",
    "employeeId": "1.70004",
    "designation": "Dean, SAS, Professor HAG",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G23-A, AB-2",
    "email": "srinivas.s@vitap.ac.in",
    "phone": "5331",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Srinivas_S_70004_0497_2c281fd932.avif",
    "education": [
      "B.Sc , Kaktiya Degree College (Kakatiya University) Warangal",
      "M.Sc Applied Mathematics, NIT Warangal",
      "NIT Warangal (Formerly REC Warangal)"
    ],
    "researchArea": "Differential Equations, PDEs, Non-Newtonian fluid flows, Heat and Mass transfer",
    "memberships": [
      "ISTAM, ISTE, IMS, ASTFE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/srinivas-suripeddi-33096aa6/",
      "researchGate": "A-6181-2010",
      "googleScholar": "https://scholar.google.co.in/citations?user=j-Bu7pwAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=23135736100",
      "vidwan": "https://vitap.irins.org/profile/259967"
    }
  },
  {
    "id": "vitap-1186-cms",
    "name": "Dr. Dilipkumar Mohanty",
    "employeeId": "1.70016",
    "designation": "Dean, SMEC, Professor Grade 2",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "310-H, AB-1",
    "email": "mohanty.dk@vitap.ac.in",
    "phone": "5147",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Dilipkumar_Mohanty_70016_IMG_2317_SMEC_0951702ac8.avif",
    "education": [
      "Utkal University, Bhubaneswar",
      "IIT Delhi, New Delhi",
      "BITS Pilani, Rajasthan"
    ],
    "researchArea": "Thermal Engineering, Experimental Heat Transfer, IC Engines, Biofuels",
    "memberships": [
      "SAE, International Association of Engineers"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "orcid": "0000-0002-8275-0627",
      "scopus": "37011129800"
    }
  },
  {
    "id": "vitap-1152-cms",
    "name": "Dr. Y. V. Pavan Kumar",
    "employeeId": "1.70049",
    "designation": "Dean SENSE, Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "422-G, AB-1",
    "email": "pavankumar.yv@vitap.ac.in",
    "phone": "5364",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pavan_Kumar_Y_V_SENSE_70049_108b6122b4.avif",
    "education": [
      "Bachelor of Technology (B.Tech.), Department of Electrical and Electronics Engineering, Jawaharlal Nehru Technological University (JNTU), Hyderabad",
      "Master of Technology (M.Tech.), Instrumentation and Control Systems, Department of ECE, University College of Engineering, Jawaharlal Nehru Technological University Kakinada (JNTUK), Andhra Pradesh, India",
      "Doctor of Philosophy (PhD), Department of Electrical Engineering, Indian Institute of Technology Hyderabad (IITH), Telangana, India"
    ],
    "researchArea": "Microgrids, Smart Grids, Classical & Modern Control, Power Quality, Power Converters, Hybrid Electric Vehicles, Data Analytics, Artificial Intelligence",
    "memberships": [
      "1. IEEE Senior Member (ID: 92950639), 2. Nominated Member - Bureau of Indian Standards (BIS)"
    ],
    "projects": [
      "1. Enhancement of Transient Performance in Voltage Source Inverter Based Microgrids Using Virtual Inertia Mechanism, Funding Agency / Sponsor - International Research Experience (SIRE) Grant, Science and Engineering Research Board (SERB), Project ID / Reference Number - SIR/2022/000760, Sanctioned Amount (INR) - 16,25,636, Project End Date - 13-Apr-2023, Current Status - Completed",
      "2. Investigation on Methods to Improve Transient Response of Microgrids Using Virtual Inertia Mechanisms for Seamless Synchronization with Utility Grid, Funding Agency / Sponsor - Start-up Research Grant (SRG), Science and Engineering Research Board (SERB), Project ID / Reference Number - SRG/2019/000648, Sanctioned Amount (INR) - 32,82,400, Project End Date - 20-May-2022, Current Status - Completed",
      "3. Study of Lithium Ferro Phosphate Battery Bank for Household Inverters, Funding Agency / Sponsor - Research Grant in Engineering, Management, and Sciences (RGEMS), Project ID / Reference Number - VIT-AP/SpoRIC/RGEMS/2023-24/005, Sanctioned Amount (INR) - 1,68,707, Project End Date - 11-Oct- 2024, Current Status - Completed",
      "4. Virtual Inertia Controller for Voltage Source Inverter Based Microgrids, Funding Agency / Sponsor - Research Grant in Engineering, Management, and Sciences (RGEMS), Project ID / Reference Number - VIT-AP/SpoRIC/RGEMS/2023-24/002, Sanctioned Amount (INR) - 1,90,000, Project End Date - 30- June-2024, Current Status - Completed",
      "5. Design of Power Conversion Loop for Microgrids Research, Funding Agency / Sponsor - Research Grant in Engineering, Management, and Sciences (RGEMS), Project ID / Reference Number - VIT-AP/2018/VC/RGEMS/4/7, Sanctioned Amount (INR) - 60,000, Pro ject End Date - 31-Aug-2019 , Current Status – Completed"
    ],
    "patents": [
      "1. Boost converter to obtain constant output from a Solar PV , Patent Publication Number – 202341018275, Patent Grant Number – 567497, Date of Grant - 17/06/2025",
      "2. Safety Hook for Ceiling Fan, Patent Publication Number – 382152-001, Patent Grant Number – 382152-001, Date of Grant - 24/05/2023",
      "3. A system and method for providing harmonics free power distribution to electrical vehicle charging station, Patent Publication Number – 202341070174, Date of Publication - 24/11/2023",
      "4. Smart Universal Power Adaptor, Patent Publication Number – 202341047453, Date of Publication - 01/09/2023"
    ],
    "awards": [
      "Academic Excellence Award 2025-26, in recognition of outstanding contributions in Curriculum Development, Teaching Learning process and Innovation Activities for the academic year 2025-26.",
      "Academic Research Excellence Award 2025-26, in recognition of outstanding contributions and exemplary achievements in Publications and Patents related to Engineering and Advanced Sciences for the academic year 2025-26."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-y-v-pavan-kumar-aaa803254/",
      "researchGate": "https://www.researchgate.net/profile/Y-V-Pavan-Kumar",
      "googleScholar": "https://scholar.google.com/citations?user=ftiD54UAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-9048-5157",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=54395950000",
      "vidwan": "https://vitap.irins.org/profile/315712"
    }
  },
  {
    "id": "vitap-1146-cms",
    "name": "Dr. Sudhakar Ilango",
    "employeeId": "1.70087",
    "designation": "Dean, SCOPE, Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": null,
    "email": "sudhakar.ilango@vitap.ac.in",
    "phone": "5459",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sudhakar_Ilango_70087_IMG_4727_SCOPE_68f8caba72.avif",
    "education": [
      "B.E CSE, Bharathiar University",
      "M.E CSE, Anna University",
      "Anna University"
    ],
    "researchArea": "Artificial Intelligence, Machine Learning, Deep Learning, Operating Systems, Theory of Computation",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/schhp?hl=en",
      "orcid": "https://orcid.org/0000-0002-7887-9081",
      "scopus": "https://www.scopus.com/sources.uri?zone=TopNavBar&origin=userDashboard#"
    }
  },
  {
    "id": "vitap-1223-cms",
    "name": "Dr. Benarji Chakka",
    "employeeId": "1.70169",
    "designation": "Dean, VSL, Professor HAG",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "416-A, AB-2",
    "email": "benarji.chakka@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70169_Dr_Benarji_Chakka_VSL_1383_213e2b1f4a.avif",
    "education": [
      "Andhra University",
      "School of Oriental and African Studies (SOAS) University of London",
      "Jawaharlal Nehru University"
    ],
    "researchArea": "International Law; Aviation and Space Law; International Humanitarian Law; International Refugee Law and International Criminal Law; Anti Money Laundering",
    "memberships": [
      "Executive Council Member, Indian Soceity of International Law; Life Member Indian Soceity of International Law; Life Member Indian Law Institute; Member Asian Soceity of Internatinal Law. Member European Soceity of International Law"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/feed/",
      "googleScholar": "https://scholar.google.com/scholar?hl=en&as_sdt=0%2C5&q=benarji+chakka+&oq=",
      "orcid": "0000-0001-5520-5343",
      "scopus": "https://www.scopus.com/feedback/author/reviewAuthorProfile.uri?authorIds=57703681400"
    }
  },
  {
    "id": "vitap-1274-cms",
    "name": "Dr. Priyanka Ghosh",
    "employeeId": "1.70342",
    "designation": "Dean In-Charge, VISH, Associate Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "224-A, AB-2",
    "email": "dean.vish@vitap.ac.in",
    "phone": "5133",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Priyanka_Ghosh_VISH_1463_b08f244c8b.avif",
    "education": [
      "B.Sc. Geography, Presidency College, Kolkata",
      "M.Sc. Geography, University of Calcutta, Kolkata",
      "University of Kentucky, Lexington, USA",
      "Postdoc Research Scholar, University of Kentucky, Lexington, USA"
    ],
    "researchArea": "Environmental Geography, Political Ecology, Biodiversity Conservation, Climate Change Adaptation, Tourism/Ecotourism",
    "memberships": [
      "American Association of Geographers (AAG); Lifetime Member, The Geographical Society of India"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/priyanka-ghosh-0335807/",
      "website": "https://sites.google.com/view/pghosh22/home?pli=1",
      "googleScholar": "https://scholar.google.com/citations?user=FqmcsIsAAAAJ&hl=hi",
      "orcid": "0000-0002-4768-7044",
      "scopus": "56846311700"
    }
  },
  {
    "id": "vitap-1355-cms",
    "name": "Dr. M Venkata Rajanikanth",
    "employeeId": "1.70383",
    "designation": "Dean Academic Research, Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "313-A, AB-1",
    "email": "rajanikanth.machavaram@vitap.ac.in",
    "phone": "5906",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Venkata_Rajanikanth_IMG_6740_SASPHY_988d5487c2.avif",
    "education": [
      "BSc, Andhra Loyola College, Nagarjuna University",
      "MSc (Physics), University of Hyderabad",
      "1. PhD, Royal Military College of Science, Cranfield University, UK; 2. Research Fellow, Metallurgy and Materials, University of Birmingham, UK",
      "Research Fellow, Metallurgy and Materials, University of Birmingham, UK"
    ],
    "researchArea": "Excimer laser microfabrication, Fibre sensors, Fibre reinforced composites, Instrumentation",
    "memberships": [],
    "projects": [
      "EPSRC Oxford University Programme Grant - Transpiration Cooling Systems for Jet Engine Turbines and Hypersonic Flight. Funding Agency : EPSRC. COMPLETED, RESEARCH FELLOW, INR 706053988.16, 2016 - 2022",
      "Optimised Lightweight Bogie with integrated suspension and steering. Funding Agency : ELG CARBON FIBRE LTD. COMPLETED, RESEARCH FELLOW, INR 4650000, 2017 - 2021",
      "Novel Multi-Measurand Optical Fibre Sensor. Funding Agency : BAE SYSTEMS (OPERATIONS) LTD, EPSRC. COMPLETED, RESEARCH FELLOW, INR 4650000, 2017 - 2021",
      "High Value Manufacturing - Next Generation Filament Winding. Funding Agency : TSB UK, CTM EQUIPMENT LTD. COMPLETED, RESEARCH FELLOW, INR 13950000, 2010 - 2013",
      "Environmentally friendly and energy efficient pultrusion (TS/G000387/1). Funding Agency : TECHNOLOGY STRATEGY BOARD, UK. COMPLETED, RESEARCH FELLOW, INR 38301213, 2008 - 2012",
      "Clean and efficient processing of fibre reinforced composites: Processing of thermosets. Funding Agency : TECHNOLOGY STRATEGY BOARD, UK. COMPLETED, RESEARCH FELLOW, INR 9852513, 2005 - 2007",
      "Novel production techniques for fibre optic sensors. Funding Agency : ROLLS ROYCE PLC. COMPLETED, RESEARCH STUDENT, INR 23250000, 2002 - 2006"
    ],
    "patents": [
      "Fibre spreading Inventors: Gerard Fernando, Venkata Machavaram."
    ],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=RS0HjHQAAAAJ&hl=en",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/302512"
    }
  },
  {
    "id": "vitap-1443-cms",
    "name": "Dr.Arunkumar Sivakumar",
    "employeeId": "1.70429",
    "designation": "Dean –In Charge, VSB, Professor Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "410, AB-1",
    "email": "arunkumar.sivakumar@vitap.ac.in",
    "phone": "5847",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Arunkumar_Sivakumar_VSB_ca331d8994.avif",
    "education": [
      "Bachelor of Science-The Bishop Heber College-Affiliated to Bharadhidasan University,Tiruchirappalli-India",
      "1.Master of Business Administration -Specialisation in Marketing.The American College-Affiliated to Madurai Kamarai University-1997. 2.M-Phil in Management, Vinayaga Mission University, Tamil Nadu, India-2009. 3.MBA -Specialization in Human Resource Management Dr Sir C.V.Raman University, Bilaspur, Chattisgarh, India 2014. 4.M.B.A.in Human Resources , Manonmaniam Sundaranar University, Tirunelveli TN, India.2016",
      "Ph.D. in Management from Gandhigram Rural University, Govt. of India; SMFI Certification from IIM Bangalore, Calcutta & Lucknow; ADTHE from Nottingham Trent University, UK.",
      "1) ADTHE-Advance Diploma in Teaching Higher Education,2004, The Nottingham Trent University, UK. 2) SMF-Strategic Management Proficiency Certification Course,2008-2011, Sponsored by - All India Council for Technical Education-AICTE and Strategic Management Forum (An Association of Strategic Management Professionals from Industry, Academia, and Public Administration Fields, to propagate the concept and practice of strategic management in the country)-Facilitated in IIM-Bangalore, IIM-Kozhikode, IIM-Lucknow, BIMTECH, Indian Institute of Foreign Trade."
    ],
    "researchArea": "Digital and Social Media Marketing ,Retail Marketing ,Services Marketing,Consumer Behaviour,Training and Development,Human Resource Management ,Organisation Behaviour, Entrepreneurship and Educational Reasearch .",
    "memberships": [],
    "projects": [
      "Funded Research Project-Project funded by ICSSR under IMPRESS Scheme by Ministry of Human Resource Development -Integrating Flipped Classroom with Bloom’s Modified Taxonomy Model as a New Paradigm for Management Education: An Exploratory Study-https://icssr.org/impress"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-arunkumar-sivakumar-9ab58429/",
      "researchGate": "https://www.researchgate.net/profile/Arunkumar-Sivakumar-2",
      "googleScholar": "https://scholar.google.com/citations?user=TIIg1moAAAAJ&hl=en&authuser=2",
      "orcid": "https://orcid.org/0000-0001-9886-033X",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57197711847",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/302005"
    }
  },
  {
    "id": "vitap-1150-cms",
    "name": "Dr. Jagadish Chandra Mudiganti",
    "employeeId": "2.70014",
    "designation": "Registrar, Professor HAG",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "705, CB",
    "email": "mudiganti.jc@vitap.ac.in",
    "phone": "5157",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/4_Dr_Jagadish_Chandra_Mudiganti_SENSE_70014_03cc80fda8.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1669-cms",
    "name": "Dr. P Arulmozhivarman",
    "employeeId": "2.70806",
    "designation": "Vice Chancellor (I/c)",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "CB G08",
    "email": "vc@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_P_Arulmozhivarman_VC_3e6b8e2db2.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1135-cms",
    "name": "Dr. Saroj Kumar Panigrahy",
    "employeeId": "3.70051",
    "designation": "Associate-Dean, SCOPE, Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "705, CB",
    "email": "saroj.panigrahy@vitap.ac.in",
    "phone": "5360",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Saroj_Kumar_Panigrahy_70051_IMG_4724_SCOPE_877760db9f.avif",
    "education": [
      "B.Tech (CSE), Berhampur University, Odisha",
      "M.Tech (CSE), NIT Rourkela",
      "CSE, NIT Rourkela"
    ],
    "researchArea": "Wireless Body Area Networks, Wireless Sensor Networks, Internet of Vehicles, Cryptography, Network Security",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "dblp": "https://dblp.org/pid/92/2.html",
      "researchGate": "https://www.researchgate.net/profile/Saroj-Panigrahy",
      "googleScholar": "https://scholar.google.com/citations?user=XM-M5ggAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-5285-3609",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=24829835500"
    }
  },
  {
    "id": "vitap-1461-cms",
    "name": "Dr. Usha Seshadri",
    "employeeId": "3.70114",
    "designation": "Associate Dean, VSB, Associate Professor Grade 2",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "410, AB-1",
    "email": "usha.seshadri@vitap.ac.in",
    "phone": "5410",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70114_Dr_Usha_Seshadri_VSB_1192_e750b5fc3c.avif",
    "education": [
      "B.Sc (Chemistry)- Pondicherry University",
      "Masters in International Management- Pondicherry University",
      "PhD in Management - Pondicherry University"
    ],
    "researchArea": "Consumer Behaviour, Services Marketing,Sustainable Marketing, Rural Marketing and Digital Marketing.",
    "memberships": [
      "American Marketing Association."
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/drushaseshadri",
      "researchGate": "https://www.researchgate.net/profile/Usha-Seshadri-2",
      "googleScholar": "https://scholar.google.com/citations?user=4Xw5_hYAAAAJ&hl=en&oi=sra",
      "orcid": "https://orcid.org/0000-0003-1301-1238",
      "scopus": "57219218919"
    }
  },
  {
    "id": "vitap-1236-cms",
    "name": "Dr. Ananthu S Hari",
    "employeeId": "3.70541",
    "designation": "Assistant Dean VSL, Assistant Professor Senior Grade 2",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "416-D, AB-2",
    "email": "ananthu.s.hari@vitap.ac.in",
    "phone": "5919",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70541_Dr_Ananthu_S_Hari_VSL_1109_ac7d036a78.avif",
    "education": [
      "BBA LL.B (Hons) - Mahatma Gandhi University, Kerala",
      "LL.M (Intellectual Property Law) - IIT Kharagpur",
      "Ph.D (Intellectual Property Law) - IIT Kharagpur"
    ],
    "researchArea": "Intellectual Property Law",
    "memberships": [
      "AsianSil"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ananthu-s-hari-32922a110/",
      "googleScholar": "https://scholar.google.com/citations?user=yfw0IwgAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/dashboard.uri?origin=&zone=TopNavBar"
    }
  },
  {
    "id": "vitap-1287-cms",
    "name": "Dr. Vemula Ramakrishna Reddy",
    "employeeId": "4.70098",
    "designation": "Head, Dept. of Mathematics, Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G23-I, AB-2",
    "email": "ramakrishna.reddy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vemula_Ramakrishna_Reddy_SAS_MAT_1925_069bd98a76.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1148-cms",
    "name": "Dr. Nagaraju Devarakonda",
    "employeeId": "4.70104",
    "designation": "Head, Dept. of Software and System Engineering, Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "707 - H, CB",
    "email": "nagaraju.devarakonda@vitap.ac.in",
    "phone": "5352",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Nagaraju_Devarakonda_70104_IMG_4890_SCOPE_6ce8e6103a.avif",
    "education": [
      "B.Tech, Sri Venkateswara University",
      "M.Tech, Jawaharlal Nehru University, New Delhi",
      "Computer Science and Engineering, Jawaharlal Nehru Technological University Hyderabad"
    ],
    "researchArea": "Data Mining, Machine Learning, Soft Computing",
    "memberships": [
      "Computer Society of India, IEEE, ACM, IAENG, https://drive.google.com/open?id=1vQD2SlDMBQ6BJQKsFiV9P83HsUIMJzXw"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-nagaraju-devarakonda-5a635a87/?originalSubdomain=in",
      "dblp": "https://dblp.org/pid/209/5819.html",
      "researchGate": "https://www.researchgate.net/profile/Nagaraju-Devarakonda",
      "googleScholar": "https://scholar.google.com/citations?user=53xGgtMAAAAJ&hl=en&oi=ao",
      "orcid": "https://orcid.org/0000-0003-4864-8482",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=54999915100"
    }
  },
  {
    "id": "vitap-1202-cms",
    "name": "Dr. Gurumurthy Komanapalli",
    "employeeId": "4.7018",
    "designation": "Head, Dept. of Micro and Nano Electronics, Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "422-B, AB-1",
    "email": "gurumurthy.k@vitap.ac.in",
    "phone": "5707",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Gurumurthy_Komanapalli_70180_IMG_5134_SENSE_61560a4248.avif",
    "education": [
      "BTECH, JNTU-KAKINADA",
      "VLSI, Delhi Technological University",
      "Delhi Technological University"
    ],
    "researchArea": "Analog VLSI",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [
      "1. Title of the Invention: Dielectric Modulated Step Channel Junction Less Tunnel Field Effect (DMSC- JLTFET) for Detecting Cancer Cells, Patent Status: Granted, Patent Grant Number: 595781, Date of Grant: 17/07/2026.",
      "2. Title of the Invention: Seeding Robot, Patent Status: Granted, Patent Grant Number: 603106, Date of Grant: 18/09/2026.",
      "3. Title of the Invention: VDBA Based First Order all Pass Filter and its Applications, Patent Status: Published, Patent Application Number: 202141028084 A, Date of Publication: 02/07/2021.",
      "4. Title of the Invention: SANISHIELD (Automatic Sanitizer Dispenser with Battery Backup), Patent Status: Published, Patent Application Number: 202141029303 A, Date of Publication: 09/07/2021.",
      "5. Title of the Invention: VOLTAICON - Break Free Backup Power System, Patent Status: Published, Patent Application Number: 202141037214 A, Date of Publication: 27/08/2021."
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/gurumurthy-k-04486457/?isSelfProfile=true",
      "dblp": "https://dblp.org/pid/243/2145",
      "researchGate": "https://www.researchgate.net/profile/Gurumurthy-Komanapalli",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=cOtPdXoAAAAJ&view_op=list_works&sortby=pubdate",
      "orcid": "0000-0001-8067-7254",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56964314500"
    }
  },
  {
    "id": "vitap-1208-cms",
    "name": "Dr. Subhasish Mahapatra",
    "employeeId": "4.70183",
    "designation": "Head, Dept. of Embedded Systems, Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "422-C, AB-1",
    "email": "subhasish.m@vitap.ac.in",
    "phone": "5711",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Subhasish_Mahapatra_70183_IMG_2589_SENSE_ffbbcc5c69.avif",
    "education": [
      "Biju Patnaik University of Technology, Rourkela",
      "Anna University Chennai",
      "Ph.D, National Institute of Technology Rourkela"
    ],
    "researchArea": "Instrumentation & Control, Nonlinear Control, Autonomous Underwater Vehicles, Robotics, Process Control Instrumentation",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Subhasish-Mahapatra",
      "googleScholar": "wTFkdAEAAAAJ",
      "orcid": "0000-0003-3717-2634",
      "scopus": "57189689760"
    }
  },
  {
    "id": "vitap-1209-cms",
    "name": "Dr. Khairnar Vikas Vishnu",
    "employeeId": "4.70193",
    "designation": "Head, Dept. of Communications and Signal Processing, Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "422-A, AB-1",
    "email": "vikas.vishnu@vitap.ac.in",
    "phone": "5303",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Khairnar_Vikas_Vishnu_IMG_6625_SENSE_ec891457ef.avif",
    "education": [
      "BE Electronics & Telecommunication Engineering (E&TC), Savitribai Phule Pune University, Pune",
      "ME Communication Engineering, Dr. Babasaheb Ambedkar Marathwada (BAMU) University, Aurangabad",
      "PhD Birla Institute of Technology And Science (BITS) Pilani"
    ],
    "researchArea": "RF & Microwave Engineering, Metasurface based Antennas, Reconfigurable Antennas",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/vikas-khairnar-b43b6471",
      "researchGate": "https://www.researchgate.net/profile/Vikas-Khairnar",
      "googleScholar": "https://scholar.google.com/citations?hl=en&authuser=1&user=ta0YmdIAAAAJ",
      "orcid": "0000-0001-9757-2088",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57192304967",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/301703"
    }
  },
  {
    "id": "vitap-1200-cms",
    "name": "Dr. Reeja S R",
    "employeeId": "4.70306",
    "designation": "Head, Dept. of Artificial Intelligence and Machine Learning. Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "706-D, CB",
    "email": "reeja.sr@vitap.ac.in",
    "phone": "5967",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Reeja_S_R_70306_0211_c3768ccf86.avif",
    "education": [
      "B.Tech, M G university, Kerala",
      "M.Tech, VTU, Govt. of Karnataka",
      "CSE, VTU, Govt. of Karnataka"
    ],
    "researchArea": "High Performance Computing, Machine Learning, Artificial Intelligence, Computer Vision, Data Analytics",
    "memberships": [
      "CSI"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?hl=en&user=EbRHmzQAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=59318563300"
    }
  },
  {
    "id": "vitap-1203-cms",
    "name": "Dr. G.Muneeswari",
    "employeeId": "4.70307",
    "designation": "Head, Dept. of Data Science and Engineering, Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "104-F, CB",
    "email": "muneeswari.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_G_Muneeswari_SCOPE_1458_c89f0d19e0.avif",
    "education": [
      "B.E, Madras University",
      "M.E, Anna University",
      "I&CE, Anna University"
    ],
    "researchArea": "Distributed Systems, Artificial intelligence, Machine learning, parallel architecture, computer security",
    "memberships": [
      "ISTE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=fXSyeiYAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=37102404900"
    }
  },
  {
    "id": "vitap-1353-cms",
    "name": "Dr. Nagarjuna Neella",
    "employeeId": "4.70359",
    "designation": "Head, Dept. of Physics, Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "225-C, AB-2",
    "email": "nagarjuna.neela@vitap.ac.in",
    "phone": "5730",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Nagarjuna_Neella_70359_0499_a199913312.avif",
    "education": [
      "BSc MPCs, Sri Venkateshwara University, Tirupati",
      "MSc Physics, Sri Venkateshwara University, Tirupati, MSc. Engg., Indian Institute of Science Bangalore",
      "PhD, Indian Institute of Science, Bangalore",
      "Indian Institute of Science, Bangalore and Kagawa University, Japan"
    ],
    "researchArea": "1D & 2D Materials, Functional Nanocomposites, Thin films Technology, Solution-Processed Electronic Devices, Next-generation Flexible Smart Sensors and Wearable Body",
    "memberships": [
      "IEEE, Instrument Society Of India (ISOI)"
    ],
    "projects": [
      "1. MXene based Functional Nanocomposite Nasal Sensor for the Identification of Possible Diseases/Abnormalities, Internal SEED Grant: VIT AP/SPORIC/RGEMS/ 22-23/016(Ongoing)",
      "2. Fabrication and Characterization of Solution Processed Nanosheets and Nanocomposites based Resistive thin Films for Heating elements as well as Sensing elements applications (Smart Temperature, Strain, Tactile, Pressure, Force, Capacitive, Robotics, Wearable Body Warmers etc.)."
    ],
    "patents": [
      "1. Nagarjuna Neella, Venkateswarlu Gaddam, M. M. Nayak, N. S. Dinesh and K. Rajanna, “Reduced Graphene Oxide-Silver Nanocomposite Films for Temperature Sensor Application”, USA Patent Filed, File No: USA 16/090/737, International Patent–PCT Filed, File No: PCT/IB2017/052017 and Indian Patent Filed, File No: 201641012543.",
      "2. Vaishakh Kedambaimoole, Pavithra B Jain, Manasa, Nagarjuna Neella, M. M. Nayak, K. Rajanna and N. S. Dinesh, “Highly Sensitive Reduced Graphene Oxide-Nickel Composite based Cryogenic Temperature Sensor” USA Patent Filed, File No: USA 16/520/449 and Indian Patent Filed, File No: 201841027819.",
      "3. Nagarjuna Neella, Vaishakh Kedambaimoole, M. M. Nayak, N. S. Dinesh and K. Rajanna, “Reduced Graphene Oxide Nanomaterial Coated Cotton Fabric as a Heater Device and Method Therefore”, International Patent–PCT Filed, File No: PCT/IB2018/050721 and Indian patent Filed, File No: 201741004725.",
      "4. Nagarjuna Neella, Venkateswarlu Gaddam, Veera Pandi N, K. Rajanna, M. M. Nayak, N. S. Dinesh, “Graphene Oxide–Platinum Nanocomposite for Sensor Applications”, Indian Patent Filed, File No: 201641031595.",
      "5. Nagarjuna Neella, Manjunath. M.S, M. M. Nayak and K. Rajanna, “Reduced Graphene Oxide Nanosheets based Strain Gauges for Pressure Transducers and Method Therefore”, Indian Patent Filed, File No: 201741007404.",
      "6. Vijay Shirhatti, Vaishakh Kedambaimoole, Suresh Nuthalapati, Nagarjuna Neella, M. M. Nayak and K. Rajanna, “Capacitive Sensor and Process of Preparation Thereof”, Indian Patent Filed, File No: 201841013832.\""
    ],
    "awards": [
      "Received Gandhian Young Technological Innovation Awards 2018 (GYTI Awards 2018) for the project entitled: “Development of Graphene Coated Conductive Fabrics based Smart Wearable Body Warmers for Defense and Medical Applications”, from The President of India, Rashtrapati Bhavan, New Delhi, 2018 during 19-23rd March 2018, Festival of Innovations and Entrepreneurship 2018 (FINE 2018), India.",
      "Received RULA International awards 2019 (RULA Awards 2019) for the project entitled: “Al:ZnO Nanosheets on Flexible Stainless Steel Substrate as Impact Sensor”, from The Director, IJRULA and RULA Awards, World Research Council and United Medical Council, 26th February 2019 at Grandeur Hall, Breeze Residency, Trichy, Tamilnadu, India."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-nagarjuna-neella-29937571",
      "researchGate": "https://www.researchgate.net/profile/Nagarjuna-Neella",
      "googleScholar": "https://scholar.google.com/citations?user=zGdD8SEAAAAJ&hl=en&oi=ao",
      "scopus": "https://orcid.org/0000-0001-9423-0410 View this author’s ORCID profile",
      "vidwan": "https://vitap.irins.org/profile/301729"
    }
  },
  {
    "id": "vitap-1357-cms",
    "name": "Dr. Illa Ramakanth",
    "employeeId": "4.7044",
    "designation": "Head, Dept. of Chemistry, Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "204-A, CB",
    "email": "ramakanth.illa@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Illa_Ramakanth_SAS_0813_9c031a5f24.avif",
    "education": [
      "BSc & Andhra University",
      "MSc (Analytical Chemistry) & Andhra University",
      "PhD (Chemistry) & IIT Madras",
      "Postdoctoral Fellow & Technical University of Ostrava, Czech Republic and University of Calgary, Canada"
    ],
    "researchArea": "Analytical Chemistry, Physical Chemistry, Colloids & Interface Chemistry, Energy Materials, Soft Materials, Supramolecular Gels, Nanomaterials, Thin Films",
    "memberships": [
      "1) APAS - Associate Fellow of AP Akademi of Sciences, Amaravati, Andhra Pradesh, India 2) RSC - Member of the Royal Society of Chemistry, London, U.K. 3) IAAM - Member of the International Association of Advanced Materials, Sweden, Europe 4) ISCA - Life Member, Indian Science Congress Association, Kolkata, India"
    ],
    "projects": [
      "1. Detection of bio/chemical analyte using novel piezo resistive polymeric cantilever beams, MHRD, New Delhi",
      "2. Erasmus+ World project-cum-mobility programme, European Commission, Brussels through SUA, Nitra, Slovakia;",
      "3. Synthesis of photo-active nanoparticles via green chemistry approach to enhance crop production for sustainable agriculture: Mechanism and structural investigation, RGEMS, VIT-AP University, Amaravati, AP, India;",
      "4. Erasmus+ World project-cum-mobility programme, European Commission, Brussels through SUA, Nitra, Slovakia."
    ],
    "patents": [],
    "awards": [
      "Chaired the session (Invited) for International Conference on Materials, Mechanical and Energy Engineering (ICMMEE-2021) organized by the Department of Mechanical Engineering, Bapatla Engineering College, Bapatla, India, during 7 – 8, May 2021",
      "Keynote speaker and Chaired the session (Invited) for the International Conference on Emanate & Innovative Trends in Engineering, Management and Sciences (ICEITEMS-2019), held at Malla Reddy Institute of Technology (MRIT), Secunderabad, India, on November 8 – 9, 2019",
      "Received Best Presentation Award (Oral) during the International Conference on Recent Advances in Chemical, Pharmaceutical and Life Processes (RACPL-2019), held at Andhra University, Visakhapatnam, India, July 13 – 15, 2019",
      "Secured 3rd Best Prize / Performance Award in Ph.D. Comprehensive Examination (Written & Oral) at Department of Chemistry, IIT Madras, Chennai, India (08/02/2005)",
      "Qualified CSIR/UGC-NET (Council of Scientific and Industrial Research/ University Grants Commission - National Eligibility Test) in Chemical Sciences (June 2003)",
      "Qualified GATE (Graduate Aptitude Test in Engineering) in Chemistry (2002), All India Rank : 448",
      "Qualified DRDO SET (Defence Research & Development Organization Scientist Entry Test) in Chemistry (2004)",
      "DST & CSIR, New Delhi and IITMAANA, IIT Madras Travel Grant Support for Scientific Presentation abroad, New York, USA (2009)",
      "RGUKT, Hyderabad & CSIR, New Delhi Travel Grant Support for Scientific Presentation abroad, Singapore, Asia (2013)",
      "Secured 24th Rank in Andhra University Common Entrance Test (AUCET-1997) in Chemistry conducted by Andhra University, Visakhapatnam",
      "Nominated as Executive Committee Member, Royal Society of Chemistry (UK) – Local Section Deccan (RSC-LSD), Hyderabad, India",
      "Awarded Erasmus+ Mobility Project and Program for Teaching and Research of European Commission: Visiting Faculty Fellowship for International Mobility Program for Faculty Exchange to do research and teaching at Slovak University of Agriculture, Nitra, Slovakia, Europe (November 4 – 17, 2021)",
      "Awarded Visiting Research Fellowship: Invited as Visiting Researcher by the Department of Chemistry, University of Pretoria, South Africa for a period of 6 weeks from September 14th to October 27th, 2018 on a “Staff Exchange Bursary Programme” to do Research and Deliver Lectures",
      "Awarded Erasmus+ Visiting Faculty Fellowship for International Mobility Program for Faculty Exchange to do research and teaching at Slovak University of Agriculture, Nitra, Slovakia, Europe, through Erasmus+ Mobility Project and Program for Teaching and Research of European Commission (November 5 – 13, 2017)",
      "Awarded Visiting Research Fellowship: Invited as a Visiting Researcher by the Department of Chemistry, University of Pretoria, South Africa for a period of 2 months from September 23rd to November 24th, 2016 on a “Staff Exchange Bursary Programme” to do Research and Deliver Lectures",
      "Awarded CSIR Fellowship: Senior Research Fellow (October 2008 - June 2010)",
      "IIT Madras HTRA Fellowship: Senior Research Fellow (September 2005 - June 2008)",
      "DRDO Fellowship: Junior Research Fellow (August 2003 - August 2005)"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ramakanth-illa-078101115/?original_referer=https%3A%2F%2Fwww%2Egoogle%2Ecom%2F&originalSubdomain=in",
      "researchGate": "https://www.researchgate.net/profile/Ramakanth-Illa",
      "googleScholar": "https://scholar.google.co.in/citations?user=ewAbORMAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=23969482200",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/299942"
    }
  },
  {
    "id": "vitap-1276-cms",
    "name": "Dr. Anil Vitthalrao Turukmane",
    "employeeId": "4.70487",
    "designation": "Head, Dept. of Networking and Security, Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "620-O, CB",
    "email": "anil.turukmane@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Anil_Vitthalrao_Turukmane_70487_0162_9c8d31f279.avif",
    "education": [
      "BE IT, Dr.Babsaheb Ambedkar Marathwada University, Auranagbad",
      "MECSE, Dr.Babsaheb Ambedkar Marathwada University",
      "Phd(CSE), POSTDOC (CSE) Lincoln University Malaysia."
    ],
    "researchArea": "Network Security, Cyber Security, Machine Learning, Artificial Intelligence, Security",
    "memberships": [
      "Life time Member of Indian Society for Technical Education(LMISTE), Life time Member of International Society For Research And Development (ISRD), Life Time Member of International Economics Development Research Center (IEDRC), The Institute of Engineers India(IEI)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=MwfpFooAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0003-4284-7464",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55595737600"
    }
  },
  {
    "id": "vitap-1288-cms",
    "name": "Dr. Ch. Naresh",
    "employeeId": "4.70492",
    "designation": "Head, Dept. of Electrical Engineering, Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "422-D, AB-1",
    "email": "naresh.ch@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70492_Dr_Ch_Naresh_SENSE_1136_3cff4fb0a0.avif",
    "education": [
      "B.Tech., Anurag University, Hyderabada",
      "M.Tech., NIT Kurukshetra",
      "Ph.D, IIT Madras"
    ],
    "researchArea": "Automation through PLC controllers, Nanoparticle synthesis and Chracterisation, diagnosis of electrical insulation systems, surface and bulk charge trap behaviour of nanocomposite materials, identification and classification of material degradation through machine learning algorithms",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "website": "https://sites.google.com/smail.iitm.ac.in/nareshchillu",
      "researchGate": "https://www.researchgate.net/profile/Chillu-Naresh",
      "googleScholar": "GczCr7wAAAAJ",
      "orcid": "0000-0003-4024-9989",
      "scopus": "57211791130"
    }
  },
  {
    "id": "vitap-1393-cms",
    "name": "Dr. Deepanjan. K",
    "employeeId": "4.70582",
    "designation": "Head, Dept. of Social Sciences, Assistant Professor Senior Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "1017-E, CB",
    "email": "deepanjan.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Deepanjan_K_70582_IMG_4773_VISH_eca95adf73.avif",
    "education": [
      "History, Loyola College, Chennai",
      "History, University of Hyderabad",
      "Social Exclusion and Inclusive Policy, Jawaharlal Nehru University"
    ],
    "researchArea": "Intellectual History of Modern India",
    "memberships": [
      "European Association of South Asian Studies, Indian History Congress, South Indian History Congress"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/deepanjan-k-a4682a1ba/"
    }
  },
  {
    "id": "vitap-1398-cms",
    "name": "Dr. Sanziou Boro",
    "employeeId": "4.70583",
    "designation": "Head, Dept. of Humanities, Associate Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "723 - J, CB",
    "email": "sanziou.b@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70583_Dr_Sanziou_Boro_VISH_1356_2960f8813f.avif",
    "education": [
      "St. Edmund's College, Shillong",
      "E.F.L.U. Hyderabad",
      "E.F.L.U. Hyderabad"
    ],
    "researchArea": "Translation Studies",
    "memberships": [
      "National Translation Mission"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "orcid": "https://orcid.org/0009-0003-6396-9783",
      "vidwan": "351814"
    }
  },
  {
    "id": "vitap-1396-cms",
    "name": "Dr. V R K Murty",
    "employeeId": "5.70048",
    "designation": "Emeritus professor",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "130, AB-1",
    "email": "vrkm@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70048_Dr_V_R_K_Murty_IMG_0994_SAS_689c0ba4f2.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1334-cms",
    "name": "Dr. Mary Chandini Stephens",
    "employeeId": "5.70456",
    "designation": "Emeritus Professor",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "202-F , AB-2",
    "email": "marychandini.y@vit.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Mary_Chandini_Stephens_VISH_1566_517a2cb19d.avif",
    "education": [
      "Bachelor of Arts, Madras University",
      "Madras Christian College (Autonomous) Madra University.",
      "Ph.D. VIT University, Vellore."
    ],
    "researchArea": "English literature, Indian Writing In English",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1132-cms",
    "name": "Dr. Hari Seetha",
    "employeeId": "6.70003",
    "designation": "Professor HAG",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "707 - E, CB",
    "email": "seetha.hari@vitap.ac.in",
    "phone": "5131",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Hari_Seetha_SCOPE_0741_2b647e6904.avif",
    "education": [
      "B.Sc,Nagarjuna University",
      "M.Sc(Tech) ,R.E.C Warangal",
      "Ph.D ,VIT University Vellore"
    ],
    "researchArea": "Large Data Classification,Intrusion Detection,Text Mining,Machine Learning,Deep Learning",
    "memberships": [
      "IEEE,ACM"
    ],
    "projects": [
      "DST sponsored project on Information Retrieval was completed as Co-PI"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/seetha-hari-64330215a/?originalSubdomain=in",
      "researchGate": "https://www.researchgate.net/profile/Seetha-Hari/2",
      "googleScholar": "https://scholar.google.com/citations?user=U0AJVTUAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=50361991400",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/262434"
    }
  },
  {
    "id": "vitap-1375-cms",
    "name": "Dr. N Madhusudhana Rao",
    "employeeId": "6.70005",
    "designation": "Dean, Academics, Professor HAG",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "G-36, AB-1",
    "email": "madhusudhana.n@vitap.ac.in",
    "phone": "5157",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70005_Dr_N_Madhusudhana_Rao_PHY_1360_73381f87c1.avif",
    "education": [
      "B.Sc., Sri Venkateswara University",
      "M.Sc Physics, Sri Venkateswara University",
      "Ph.D., Sri Venkateswara University"
    ],
    "researchArea": "Semiconductors and Nano Materials",
    "memberships": [],
    "projects": [
      "1. Investigations on Cr and Co doped CdTe Diluted Magnetic Semiconductors for Room Temperature Ferromagnetism Funded by DRDO.",
      "2. Investigations for Room temperature ferromagnetism in Cr, Fe, Ni and Cu-doped In2O3 thin films for spintronic applications funded by UGC-DAE-CSR Kalpakam Node.",
      "3. Development of Room Temperature Ferromagnetic, Transparent, Conducting Mn, Fe doped ITO thinfilms funded by UGC-DAE-CSR Kalpakam Node."
    ],
    "patents": [
      "1. Appl. No. .202141029302 A- A METHOD FOR SYNTHESIS OF STOICHIOMETRIC CUINO2 NANO CRYSTALLINE POWDER",
      "2. Appl. No. 202241001421A - PATOSAP- Photon Assisted Therapeutic Operative Sole for Alleviating Psoriasis"
    ],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=k1sjCPUAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=6505971371"
    }
  },
  {
    "id": "vitap-1176-cms",
    "name": "Dr. Pankaj Balkrishna Tambe",
    "employeeId": "6.70009",
    "designation": "Professor HAG",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "145, AB-1",
    "email": "pankaj.tambe@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pankaj_Balkrishna_Tambe_70009_IMG_2621_SMEC_2f648dd89a.avif",
    "education": [
      "BE, Nagpur University",
      "M.Tech, MNNIT Allahabad",
      "Ph.D, IIT Bombay, Mumbai"
    ],
    "researchArea": "Polymer processing, Polymer Nanocomposites, Polymer Blends, Nanofluids, Metal Matrix Nanocomposites",
    "memberships": [
      "ASME"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=OryAJsoAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1184-cms",
    "name": "Dr. P S Rama Sreekanth",
    "employeeId": "6.7002",
    "designation": "Professor HAG",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "129, AB-1",
    "email": "sreekanth.p@vitap.ac.in",
    "phone": "5148",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_P_S_Rama_Sreekanth_70020_IMG_4723_SMEC_8e23baaadb.avif",
    "education": [
      "Mechanical Engineering, JNT University, Hyderabad",
      "Machine Design, Andhra University",
      "Mechanical Engineering, Indian Institute of Technology- Guwahati"
    ],
    "researchArea": "Graphene generation, Energy harvesting- Tribo & Piezoelectric nanogenerators, Water purification, Coatings, Nanocomposites, Bio composites, Honeycomb Sandwich structures.",
    "memberships": [
      "ASME, SBOAI, MRSI, SAE, ISTE,"
    ],
    "projects": [
      "1. Design & Fabrication of Low cost, Effort Assistive Pneumatic Prosthesis for above Knee Amputees Rs. 15,00,000, MInistry of Micro Small and Medium Entreprises, GoI. Ongoing",
      "2. Development of Regenerative Effort Assistive Pylon with Novel Pneumatic Knee Mechanism for Youth and Elderly. BUIMERC India Foundation Rs. 52,00,000 3 year, Ongoing",
      "3. 4D Printing enable development of low-cost, optimized blended and combination patterned ‘shape memory - conventional’ polymer nanocomposite sandwich structures Rs. 18,96,400.00 ANRF, 3 Years. Completed",
      "4. Recycled plastics based Composite tiles with bovine waste and phase change material for thermal & radiation management, Rs. 10,00,000.00, Dassaults Systemes. Completed",
      "5. Regeneration of Fuel from MSW and Biomass using Pyrolysis - Reforming process Rs. 4,62,200.00, V-Launch. Completed",
      "6. Fabrication, characterization and evaluation of design parameter variability of polymer nanocomposite sandwich beams with gradient cell size honeycomb core for obtaining graded beam properties. Rs. 28,00,000.00, DST-SERB, 2016-2019. Completed",
      "7. Fabrication of Teflon fabric-reinforced Nafion based Wearable Exoskeleton Actuator for rehabilitation training. Rs. 2,59,773.00, RGEMS. Completed",
      "8. Fabrication and Characterization of UHMWPE/MWCNT nano-composites Rs. 2,27,000.00, Consultant support for AICTE sponsired project to RVR& JC college of Engineering, 2022-23. Completed",
      "9. Composition and property testing of Thermostatic lite cellular Bricks Rs. 2,00,000.00, M/s Sea Associates, Berhampur. Completed",
      "10. Deposition orientation in fused deposition modelling based 3D printing with varying/gradient fill densities for nanocomposite based filament Rs. 90,000.00, Ms Additive Manufacturing Pvt. Ltd. Completed",
      "11. Investigation of the Role of Multidimensional Carbon Based Nanofillers and ceramic nanofillers in Restricting Radiation Damage and Thermal Cycling Effects of Epoxy Carbon Fibre Reinforced Composites for Space Application. Rs. 66,000.00, RGEMS, VIT-AP. Completed",
      "12. Shape memory polymer and its nanocomposites. Optimizing the Injection Molding parameters for Diaplex based virgin Polyurethane (PU) shape memory Rs. 60,000.00, Deesha Impex. Completed"
    ],
    "patents": [
      "1. A Metal-Coated Polymer Ion-Exchange Membrane, A Method Of Fabrication Thereof, And Applications Therof , Application No. : 202341053185 Venkata Dinesh Avvari, Vit-Ap University, P.S. Rama Sreekanth, Vit-Ap University- Granted",
      "2. A Method Of Fabricating A Multilayer Ultra-High Molecular Weight Polyethylene Nanocomposite, Application No. 202341029897 Dr. P.S.Rama Sreekanth, Vit-Ap University Mr. Sri Ram Murthy Paladugu, Vit-Ap University - Granted",
      "3. Fabrication Of Spatially Varied Functional Graded Plate Using A Reusable Die-Mat, Application No. 202341029286 Dr. Vasavi Boggarapu, Vit-Ap University, Dr. P.S. Rama Sreekanth, Vit-Ap University",
      "4. Single Axis Rotating Tool Holder With Size Adjustable Mount. File No. 202141055122 (Published) Publication Date : 10.12.2021 Mr. Ankan Narayan Biswas, Vit-Ap University, Mr. Shayaan Ahmed, Vit-Ap University, Dr. P. S. Rama Sreekanth, Vit-Ap University",
      "5. Design And Development Of Autonomous Underwater Vehicle (Auv) With Light Weight Material And Using. File No. 202141057221 (Published), Published Date : 04.02.2022 Ch. Sridhar Yesaswi, Vit-Ap University, Dr. P. S. Rama Sreekanth, Vit-Ap University",
      "6. Hybrid Auxetics Incorporated Non-Pneumatic Wheel, File No. 202141041160, Published Date : 29.10.2021 Mr. Ankan Narayan Biswas, Vit-Ap University, Dr. P. S. Rama Sreekanth, Vit-Ap University",
      "7. Automatic Protection Guards For Bike File No: 202141017961 A (Published) Published Date : 30.04.2021 Nunna Mahesh, P S Rama Sreekanth",
      "8. Thickness Wise Gradient Honeycomb Cushioning Structure (Design Innovation) Published . File No:321869-001, Published Date : P S Rama Sreekanth, Santosh Sahu, Niteshdhar Badgayan - Granted",
      "9. Hybrid Honeycomb Support Structures (Design Innovation) Published, File No:321871-001, Published Date : P S Rama Sreekanth, Santosh Sahu, Niteshdhar Badgayan- Granted",
      "10. Development Of Recycled Plastics Based Composite Roof Tiles With Used Face Mask, Phase Change Material And Bovine Waste (Utility Patent) Published. File No: 202141029299, Published Date : 09.07.2021 S. Krishna Satya, P S Rama Sreekanth",
      "11. Sandwich Nanocomposite Preparation Technique For Orthopaedic Application (Utility Patent) Published. File No: 202141029308, Published Date : 16.07.2021 Nilesh Dalai, P S Rama Sreekanth",
      "12. Design, Simulation And Fabrication Of Convergent Lpg Burner With Diffuser (Utility Patent) Published. File No: 202141032538, Published Date : 30.07.2021 Jangala Sai Sri Laxman, P S Rama Sreekanth, Peri Shanmukh Ram, Kakumani Venkata Siva Prasad",
      "13. A Novel Hybrid Woven Fabric With Carbon (Weft) And Kevlar (Wrap) With Nanofillers For High Strength And Load Bearing Applications, File No. 202241029727 Published Date : 30.06.2022 Mr. Madarvoni Srivatsava, Vit-Ap University, Dr. P. S. Rama Sreekanth, Vit-Ap University"
    ],
    "awards": [
      "Research Award – Projects, Publications – AY 2025-26",
      "Research Award – Projects, Publications – AY 2024-25",
      "Research Award - Patents - AY 2023-24",
      "Research Award - Sponsored Research Projects- AY 2023-24",
      "Research Award - Patents - AY 2022-23",
      "Research Award - Sponsored Research Projects- AY 2022-23",
      "Star Performer – Letter of Appreciation received from Vice-Chancellor’ 2021",
      "Research Award - Consultancy Projects for the academic year 2021-22.",
      "Research Award - Sponsored Projects for the academic year 2021-22.",
      "Research Award - Publications (Engineering & Advanced Sciences) for the academic year 2021-22.",
      "Research Award - Patents (Engineering & Advanced Sciences) for the academic year 2021-22.",
      "Above & Beyond Award of overall contribution to the VIT-AP university, 2021.",
      "Dean, School of Mechanical Engineering, 2021.",
      "Best Researcher Award – under all 3 Categories – Publications, Patents and Sponsored Research – University Awards – 2020",
      "Above & Beyond Award for overall performance & contribution to VIT-AP University- University Awards- 2020",
      "Best Researcher Award (Sponsored Research) on VIT-AP University day celebrations, 2018",
      "Above & Beyond Award of overall contribution to the VIT-AP university, 2018",
      "Best Oral Presentation Award during ICMSET-2017, 20-22nd Oct-2017, Republic of South Korea.",
      "Young scientist travel award by DST-SERB to Visit South Korea for ICMSET, 2017.",
      "Odisha Youth Innovation Award received from Chief Minister of Odisha for our Group work, 2017",
      "Member Technical Committee of 6th International Conference on Materials Science and Engineering Technology. Seoul, Republic of Korea, 2017.",
      "Member of scientific committee of International Conference on Applied Mechanics and Mechatronics Engineering, 2015, Bangkok, Thailand.",
      "Obtained Best Paper award at International conference on advances in mechanical sciences, Hyderabad, 2014.",
      "Member of technology program committee of the International Conference on Biomedical Engineering and Biotechnology, Beijing, China, 2014.",
      "Scholarship Award by MHRD during Ph. D",
      "Young scientist travel award by Science and engineering research board, Department of science and technology, 2012.",
      "Council of Scientific and Industrial Research foreign travel award for Bright Young Indian Scientist working in an academic or research institution in India to participate in an International conferences, 2012.",
      "Reviewer of nanocomposites section in 2nd International Conference on Biomedical Engineering and Biotechnology, Wuhan, China, on October 11-13, 2013"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/p-s-rama-sreekanth-96867453/",
      "googleScholar": "https://scholar.google.com/citations?user=oyrgR4QAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0001-6444-0345",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=54684960000"
    }
  },
  {
    "id": "vitap-1154-cms",
    "name": "Dr. Ravindra Dhuli",
    "employeeId": "6.70053",
    "designation": "Professor HAG",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "144, AB-1",
    "email": "ravindra.d@vitap.ac.in",
    "phone": "5363",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ravindra_Dhuli_70053_IMG_4932_SENSE_00908717ad.avif",
    "education": [
      "B. Tech ECE, Acharya Nagarjuna University",
      "PHD Signal Processing, IIT Delhi"
    ],
    "researchArea": "Signal Processing, Image processing, Communication Systems, Multi rate systems",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=guZR8v4AAAAJ&hl=en",
      "scopus": "35306380700",
      "vidwan": "https://vitap.irins.org/profile/257204"
    }
  },
  {
    "id": "vitap-1407-cms",
    "name": "Dr. K Senthil",
    "employeeId": "6.704",
    "designation": "Professor HAG",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "707 - B, CB",
    "email": "senthil.k@vitap.ac.in",
    "phone": "5818",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70400_Dr_K_Senthil_1055_110b0a68fe.avif",
    "education": [
      "B.Sc. (Physics) & Bharathiar University",
      "M.Sc. (Physics) & Madurai Kamaraj University",
      "Ph.D. (Physics) & Bharathiar University",
      "Tohoku University (Japan), POSTECH (South Korea)"
    ],
    "researchArea": "Nanomaterials for energy and environmental applications",
    "memberships": [],
    "projects": [
      "1. Development of Advanced Materials based on MXene / Metal Oxide Nanocomposites for Energy and Environmental Applications & UGC-DAE-CSR( Ongoing)",
      "2. Surface modification of one-dimensional metal oxide nanostructures by ion implantation for spintronics and gas sensing applications & UGC-DAE-CSR"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "C-9738-2011",
      "googleScholar": "https://scholar.google.com/citations?user=jfSZ_aMAAAAJ&hl=en",
      "orcid": "0000-0002-0997-0607",
      "scopus": "6701861455",
      "vidwan": "302598"
    }
  },
  {
    "id": "vitap-1304-cms",
    "name": "Dr. Sumesh E. P",
    "employeeId": "6.7051",
    "designation": "Professor HAG",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": null,
    "email": "sumesh.ep@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70510_Dr_Sumesh_E_P_SENSE_1148_b90cc8bdd9.avif",
    "education": [
      "BTech in Electronics and Communication Engineering, University of Calicut",
      "MTech - Opto Electronics and Laser Technology, Cochin University of Science and Technology",
      "PhD in Electronics and Communication Engineering, NIT Calicut",
      "Post Doc in Elctronics and Communication Engineering - Aalto University, Finland"
    ],
    "researchArea": "Artificial Intelligence, Signal Processing, Communication Engineering and Embedded systems",
    "memberships": [
      "Sr. Member IEEE, Member ISTE"
    ],
    "projects": [
      "1. Design of wearable IoT device supported by Deep learning for Smart Covid-19 Monitoring and Alerting System, funded by The Research Council (TRC) of Oman",
      "2. Non-Invasive technique for screening diabetic retinopathy towards the prevention of blindness using the Deep Learning algorithms for smart heath system in Oman, funded by The Research Council (TRC) of Oman under smart city platform",
      "3. Smart suitcase with security system and automatic weight management, Funded by The Research Council of Oman- Furap Call 5.",
      "4. Automatic daily activity management system for the elderly person, funded by The Research Council of Oman- Furap Call 4."
    ],
    "patents": [],
    "awards": [
      "National Award - Best project in the Health and Social service sector, The research Council of Oman ( Government organization promoting research in Oman), 2017"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sumesh-parameswaran-b76a3626/",
      "googleScholar": "xDoHPLEAAAAJ",
      "orcid": "0000-0001-6401-8830",
      "scopus": "26423295900",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/300210"
    }
  },
  {
    "id": "vitap-1550-cms",
    "name": "Dr. Edara Sreenivasa Reddy",
    "employeeId": "6.70685",
    "designation": "Professor HAG",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "103 - G, CB",
    "email": "sreenivasareddy.e@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Edara_Sreenivasa_Reddy_SCOPE_IMG_2139_cb903a1d75.avif",
    "education": [
      "B.Tech, Acharya Nagarjuna University",
      "M.Tech, Visveswaraya Technological University",
      "Ph.D, Acharya Nagarjuna university"
    ],
    "researchArea": "Machine Learning, Deep Learning, Image processing, Pattern recognition",
    "memberships": [
      "SMIEEE,CHAIR-IEEE,GUNTUR SUBSECTION,LMISTE,IAENG"
    ],
    "projects": [
      "Prediction of Cerebral ataxia based on gait analysis : A deep learning approach ,ANU"
    ],
    "patents": [
      "1. Forensic Tool for the Semantic-Based Image Retrieval System, Australian Govt Patent number: 2021103865",
      "2. IMAGE PROCESSING BASED MODEL DEVICE FOR MELANOMA DETECTION,UK Patent Design number: 6392823",
      "3. AI based wireless ECG monitoring Device, UK Patent Design number: 6388108",
      "4. Equipment to mitigate performance issues in mobile cloud computing, UK Patent Design number: 6386900",
      "5. METHOD OF DETECTING EPILEPSY USING MACHINE LEARNING (ML) AND OPTIMIZATION TECHNIQUES, Application No.202241022858 A",
      "6. METHOD AND SYSTEM FOR IMPLEMENTING IMPROVED GENERALIZED FUZZY PEER GROUP WITH MODIFIED TRILATERAL FILTER TO REMOVE MIXED IMPULSE AND ADAPTIVE WHITE GAUSSIAN NOISE FROM COLOR IMAGES, Application No.202241007620 A",
      "7. IMOD- VIDEO SURVEILLANCE SYSTEMS: INTELLIGENT MOVING OBJECT DETECTION MODEL IN VIDEO SURVEILLANCE SYSTEMS, Application No.202041035254 A",
      "8. NAPR-VIDEO SURVEILLANCE SYSTEMS: A NOVEL APPROACH FOR PRIVACY PRESERVING IN REAL TIME VIDEO SURVEILLANCE SYSTEMS, Application No.202041038132 A",
      "9. METHOD AND SYSTEM FOR DETECTING IMPORTANT EPISODES OF ECG BASED ON DEEP LEARNING TECHNIQUES Application No.202241011732",
      "10. Longitudinal Slots Array Etched Substrate Integrated Waveguide Antenna with Sector Beam Pattern for 5G Applications, Application No.202241065809 A",
      "11. DESIGN OF ANISOTROPIC METASURFACE FOR CONTROLLING ELECTROMAGNETIC WAVE POLARIZATION, Application No.202141034149 A",
      "12. Mutual Coupling reduction using Dielectric resonator in twinned element MIMO antenna, Application No.202141041426 A"
    ],
    "awards": [
      "BEST COMPUTER SCIENCE TEACHER AWARD BY ISTE-2021,BEST RESEARCHER AWARD BY ANU-2023"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/edara-sreenivasa-reddy-04ba2a336/",
      "researchGate": "https://www.researchgate.net/profile/Edara-Reddy",
      "googleScholar": "https://scholar.google.com/citations?user=RA3tR7UAAAAJ&hl=en&authuser=1",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=53867218700",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/448088"
    }
  },
  {
    "id": "vitap-1147-cms",
    "name": "Dr. Aravapalli Rama Satish",
    "employeeId": "7.70103",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "615-H, CB",
    "email": "rama.satish@vitap.ac.in",
    "phone": "5353",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Aravapalli_Rama_Satish_IMG_1837_SCOPE_8db829393d.avif",
    "education": [
      "B.E., University of Madras",
      "M.Tech, JNTUK, Kakinada",
      "Computer Science & Engineering, Acharya Nagarjuna University"
    ],
    "researchArea": "Data Mining, Machine Learning, Big Data, Deep Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/ramsatpm/",
      "googleScholar": "https://scholar.google.com/citations?user=tMYlX6QAAAAJ&hl=en",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0002-4323-8073",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57519872900"
    }
  },
  {
    "id": "vitap-1386-cms",
    "name": "Dr. Paramasivam R",
    "employeeId": "7.70106",
    "designation": "Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "125-E, AB-2",
    "email": "paramasivam.r@vitap.ac.in",
    "phone": "5694",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Paramasivam_R_70106_IMG_2564_SAS_CHY_828bbdfac1.avif",
    "education": [
      "B.Sc. Chemistry, Madras University, Chennai",
      "M.Sc. (Applied Chemistry in the Faculty of Engg.), Bharathiar University, Coimbatore",
      "Ph. D. (Chemical Engineering), IIT Madras, Chennai"
    ],
    "researchArea": null,
    "memberships": [
      "ISTE Life Member (LM 64420), ISRD Life Member (Fellow Membership ID: F3140900691)."
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?hl=en&user=cddBXtIAAAAJ",
      "scopus": "www.scopus.com/authid/detail.uri?authorId=36916454600"
    }
  },
  {
    "id": "vitap-1153-cms",
    "name": "Dr. Harikiran Jonnadula",
    "employeeId": "7.7011",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "812 - N, CB",
    "email": "harikiran.j@vitap.ac.in",
    "phone": "5166",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Harikiran_Jonnadula_70110_IMG_4751_SCOPE_adcc11a534.avif",
    "education": [
      "B.Tech - JNTU Hyderabad",
      "M.Tech- Andhra University",
      "Ph.D.- JNTU Kakinada"
    ],
    "researchArea": "Image Processing",
    "memberships": [],
    "projects": [
      "1. “Automated System for Microarray Image Analysis”, UGC MAJOR RESEARCH PROJECT, UGC Reference No: 42-147/2013 (SR) , VALUE: Rs. 7,43,000, Duration April 2013 to March 2016.",
      "2. “Human Activity Recognition for Abnormal Event Detection In Enhancing Security of Automated Teller Machines Using Machine Learning Techniques”, File No : R.4/2/UG/2018- 19/RDUG2018036 [Permanent ID: UG2019033] Rs.20000 The Institution of Engineers (IEI) R & D Project. August 2018 to June 2019.",
      "3. “Human Detection and Motion Analysis from a Unmanned Arial Vehicle (Uav) using Machine Learning Techniques”, RGEMS (Research Grant in Engineering Management and Science) grant from VIT-AP University Rs. 68000. August 2020 .",
      "4. “Computer Aided Diagnosis (Cad) System for Ovarian Classification”, Consultancy work from Sreyas Hospital and IVF center , Rs.59000"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=8Rn0jyMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=37050839700"
    }
  },
  {
    "id": "vitap-1156-cms",
    "name": "Dr. Prabha Selvaraj",
    "employeeId": "7.70123",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "706 - E, CB",
    "email": "prabha.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Prabha_Selvaraj_SCOPE_IMG_7108_b396b325ac.avif",
    "education": [
      "B.E CSE & Bharathiyar University",
      "M.E CSE & Anna University",
      "PhD CSE & Anna University"
    ],
    "researchArea": "Machine Learning and DEEP Learning, Recommendation System, Image Processing, IoT, Security, Block Chain",
    "memberships": [
      "ISTE, CSI"
    ],
    "projects": [
      "Computerized data Sharing and collection & Dr.Kavitha Shankar, Chairman, Rasipuram"
    ],
    "patents": [
      "1.TITLE OF THE INVENTION: System to Facilitate Visually Impaired Person to Identify Person Present in Surrounding. Application No.: 201941050087",
      "2.TITLE OF THE INVENTION: Voice Assisted Neuro-Fuzzy Deep Learning Technique to Elderly and Disabled for Flexible and Secure Navigation.",
      "3.TITLE OF THE INVENTION: An IoT Based Automatic Fatigue and Health Monitoring System During Travel Application No.: 202041043131",
      "4.TITLE OF THE INVENTION: An Innovative IoT Based NHS Wheelchair that Automatically Provides Pills for The Cerebrovascular Disease Patients Application No.: 202041049419",
      "5.TITLE OF THE INVENTION: Dynamic Smart Alarm Based On Quality of Sleep (QOS) Application No.: 202141026728 A",
      "6. TITLE OF THE INVENTION: Multipurpose Smart Bottle with Hydro Pattern Analyser and Advisory System. Application No.: 202141037211 A",
      "7. TITLE OF THE INVENTION: Portable Umbrella with Tissue Dispenser and Sanitizer. Application No.: No.202141055125 A",
      "8. TITLE OF THE INVENTION: IoT Based Borewell Rescue Robot System Using Computer Vision and Imitation Learning Application No.: No. 202241020233",
      "9. TITLE OF THE INVENTION: Artificial Intelligence Driven Smart TV Recommendation System using Computer Vision Application No.:202241047426",
      "10. TITLE OF THE INVENTION: Establishing Trust and Transparency in Supply Chain Management Using Blockchain Technology Application No.:202241047426",
      "11. TITLE OF THE INVENTION: Flexible Plug in-Plug Out Single Pole Single Throw Switch Application No.: 202341062426"
    ],
    "awards": [
      "Distinguished Leader in Engineering Discipline 2019 by Higher Education Leadership Awards (HELA).",
      "Global Teacher Awards 2019 by AKS EDUCATION AWARDS in Education Industry GLOBAL TEACHER CONCLAVE AND AWARDS 2019, Gurukul Academic Award 2022 for Best faculty"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/prabha-selvaraj-649448177/",
      "researchGate": "https://www.researchgate.net/profile/Prabha_Selvaraj2",
      "googleScholar": "https://scholar.google.co.in/citations?user=vSge6KcAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57209479255"
    }
  },
  {
    "id": "vitap-1179-cms",
    "name": "Dr. P. Kuppusamy",
    "employeeId": "7.70282",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "812 - D, CB",
    "email": "kuppusamy.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_P_Kuppusamy_70282_0158_80b87944be.avif",
    "education": [
      "B.E CSE, Madras University",
      "ME CSE, Anna University Chennai",
      "CSE, Anna University Chennai"
    ],
    "researchArea": "Machine Learning, Deep Learning, IoT",
    "memberships": [
      "IEEE, ISTE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-kuppusamy-p-2499b0b4",
      "googleScholar": "https://scholar.google.com/citations?user=jVwmhooAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0001-5369-8121",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55574186541"
    }
  },
  {
    "id": "vitap-1446-cms",
    "name": "Dr. Raghavendra",
    "employeeId": "7.70292",
    "designation": "Professor Grade 2",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "410, AB-1",
    "email": "raghavendra@vitap.ac.in",
    "phone": "5412",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70292_Dr_Raghavendra_VSB_1186_f1a8884d65.avif",
    "education": [
      "BBA (Mangalore University)",
      "MBA (Mangalore University)",
      "PhD (University of Mysore)"
    ],
    "researchArea": "Security Analysis and Portfolio Management, Financial Derivatives, Capital Market, Fintech Applications",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Raghavendra-Acharya-2",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=0dKf4xcAAAAJ",
      "orcid": "0000-0002-5798-6363",
      "scopus": "57760316100"
    }
  },
  {
    "id": "vitap-1204-cms",
    "name": "Dr. Dasari Venkata Lakshmi",
    "employeeId": "7.70308",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "103 - F, CB",
    "email": "venkatalakshmi.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Dasari_Venkata_Lakshmi_SCOPE_0724_67dcd708c3.avif",
    "education": [
      "B.Sc (M.P.C), Acharya Nagarjuna University",
      "M.Sc (Pure Mathematics), Central University of Hyderabad",
      "Ph.D Mathematics, Central University of Hyderabad"
    ],
    "researchArea": "Computing Models , Artificial Intelligence, Machine Learning, Natural Language Processing, Data Analytics.",
    "memberships": [
      "International Association of Engineers (IAENG), IFERP Institute For Engineering Research and Publication"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/drdvlakshmi",
      "googleScholar": "https://scholar.google.com/citations?user=w_eUoBoAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0003-2020-314X",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57220588780"
    }
  },
  {
    "id": "vitap-1226-cms",
    "name": "Dr. Eswaraiah Rayachoti",
    "employeeId": "7.70391",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "620-H, CB",
    "email": "eswaraiah.rayachoti@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Eswaraiah_Rayachoti_70391_IMG_4691_SCOPE_d854f7b1d3.avif",
    "education": [
      "B.Tech, Sri Venkateswara University",
      "M.Tech, Jawaharlal Nehru Technological University Hyderabad",
      "Acharya Nagarjuna University"
    ],
    "researchArea": "Deep Learning, Data Science",
    "memberships": [
      "Indian Society for Technical Education (ISTE), International Association of Engineers (IAENG), The Society of Digital Information and Wireless Communications (SDIWC)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "dblp": "https://dblp.uni-trier.de/pid/155/9804.html",
      "orcid": "https://orcid.org/0000-0001-8605-0794",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56208749400"
    }
  },
  {
    "id": "vitap-1244-cms",
    "name": "Dr. Naga Jagadesh Bommagani",
    "employeeId": "7.70436",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "707 - F, CB",
    "email": "nagajagadesh.bommagani@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Naga_Jagadesh_Bommagani_SCOPE_1881_f7e99e75d7.avif",
    "education": [
      "B.Tech, JNTU",
      "M.Tech, JNTU, Hyderabad",
      "Computer Science & Engineering, Jawaharlal Nehru Technological University Kakinada"
    ],
    "researchArea": "Digital Image Processing, Medical Imaging, Machine Learning, Soft Computing, Data Analytics",
    "memberships": [
      "CSI, ISTE, IEEE, Institute of Engineers"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-b-n-jagadesh-86898022/",
      "googleScholar": "https://scholar.google.com/citations?user=97eyYhQAAAAJhttps://www.scopus.com/authid/detail.uri?authorId=57191666358",
      "orcid": "https://orcid.org/0000-0003-3402-146X"
    }
  },
  {
    "id": "vitap-1317-cms",
    "name": "Dr Sachi Nandan Mohanty",
    "employeeId": "7.70455",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "104-I, CB",
    "email": "sachinandan.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sachi_Nandan_Mohanty_SCOPE_1551_ec578c759f.avif",
    "education": [
      "BSc,Berhampur University",
      "MTech (Computer Science & Engineering), KIIT University",
      "Computer Science, Indian Institute of Technology Kharagpur , WB, India",
      "Post Doctoral, Indian Institute of Technology Kanpur, UP, India"
    ],
    "researchArea": "Fuzzy Decision making, Emotion, Cognition, Machine learning in Health care, Social Network analysis, MCDM, Brain Computer Interface",
    "memberships": [
      "\"IEEE, IE(India), ACM, CSI https://drive.google.com/open?id=1ryu6KLGxkKf4aFPk85DAoTcDK_xFRwLe\""
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-sachinandan-mohanty-61061815/?originalSubdomain=in",
      "dblp": "https://dblp.org/pid/210/7286.html",
      "researchGate": "https://www.researchgate.net/scientific-contributions/Sachi-Nandan-Mohanty-2180912778",
      "googleScholar": "https://scholar.google.co.in/citations?user=166bepcAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-4939-0797",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=36170793300"
    }
  },
  {
    "id": "vitap-1255-cms",
    "name": "Dr. Y Narasimha Rao",
    "employeeId": "7.70465",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "626 - A, CB",
    "email": "y.narasimharao@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Y_Narasimha_Rao_70465_IMG_4699_SCOPE_137431ee92.avif",
    "education": [
      "B.Tech(CSE)-JNTU Hyderabad",
      "M.Tech(CSE)-Acharya Nagarjuna University",
      "Ph.D(CS&SE)-Andhra University"
    ],
    "researchArea": "IOT,ML,DL,Security,Communications",
    "memberships": [
      "CSI"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/publication/371138739_A_Study_on_Imbalanced_Data_Classification_for_Various_Applications/stats",
      "googleScholar": "https://scholar.google.co.in/citations?user=mb2s8asAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-1560-8719",
      "vidwan": "https://vidwan.inflibnet.ac.in/login/reset/169994/10171dc8462df5d2a7b0598e4abe0b90"
    }
  },
  {
    "id": "vitap-1297-cms",
    "name": "Dr. Bharathi V C",
    "employeeId": "7.70466",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "707 - C, CB",
    "email": "bharathi.vc@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70466_Dr_Bharathi_V_C_SCOPE_1227_884cfa7b99.avif",
    "education": [
      "B.Tech, Madras university",
      "M.E, Anna Universtiy",
      "Computer Science, Annamalai University"
    ],
    "researchArea": "Image and video processing, Pattern recognition, Document handling, Document retrieval, and Machine learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/feed/",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=DYWwcDoAAAAJ",
      "orcid": "https://orcid.org/0000-0003-2097-4577",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55583621300",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/302799"
    }
  },
  {
    "id": "vitap-1333-cms",
    "name": "Dr. Hemant Kumar Reddy",
    "employeeId": "7.70493",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "706 - B, CB",
    "email": "hemanth.reddy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Hemant_Kumar_Reddy_70493_IMG_4765_SCOPE_5a07de8e26.avif",
    "education": [
      "B.Sc, Berhampur University",
      "M.Tech(Computer Science), Berhampur University",
      "Ph.D(Computer Science & Engineering), NIT AP"
    ],
    "researchArea": "Distributed System ( Cloud, Fog, IoT), Blockchain Technology",
    "memberships": [
      "CSI: I1504527"
    ],
    "projects": [
      "A Machine Learning Framework for deploying mobile edge clouds for real time analytics on IoT data over 5G”, MeitY, New Delhi, 35.00 Lakhs for three years.(Role: Co-PI)"
    ],
    "patents": [],
    "awards": [
      "Received Best Researcher Award from Biju Patnaik University of Technology, Odisha for year 2020"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/k-hemant-reddy-566990251/",
      "researchGate": "https://www.researchgate.net/profile/Hk-Reddy?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=mYFhm4YAAAAJ&hl=en",
      "orcid": "http://orcid.org/0000-0003-2492-3312",
      "scopus": "https://www.scopus.com/feedback/author/reviewAuthorProfile.uri?authorIds=55420301000,55027479400",
      "vidwan": "https://vidwan.inflibnet.ac.in/myprofile"
    }
  },
  {
    "id": "vitap-1289-cms",
    "name": "Dr. Srinivasa Reddy Konda",
    "employeeId": "7.70517",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "312, CB",
    "email": "srinivasareddy.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70517_Dr_Srinivasa_Reddy_Konda_SCOPE_1251_c51ac3591e.avif",
    "education": [
      "B.Tech. in Computer Science & Engineering, Jawaharlal Nehru Technological University, Hyderabad",
      "M.Tech. in Computer Science & Engineering, SRM Institute of Science and Technology, Chennai",
      "Faculty of Computer Science & Engineering, Jawaharlal Nehru Technological University Anantapur, Ananthapuramu"
    ],
    "researchArea": "Data Structures, Design and Analysis of Algorithms, Image Processing & Computer Vision, Machine Learning, Data Analytics",
    "memberships": [
      "CSI, ISTE, IAENG"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-srinivasa-reddy-k-326ab615/",
      "googleScholar": "https://scholar.google.com/citations?user=wULNGtMAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-4371-2169",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57202347382"
    }
  },
  {
    "id": "vitap-1362-cms",
    "name": "Dr. Kalapraveen Bagadi",
    "employeeId": "7.70567",
    "designation": "Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "126, AB-1",
    "email": "kalapraveen.b@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kalapraveen_Bagadi_SENSE_1923_3c237f7b88.avif",
    "education": [
      "B.E., Andhra University",
      "M.Tech, NIT Rourkela",
      "Ph.D., NIT Rourkela"
    ],
    "researchArea": "Application of AI for Wireless Communication",
    "memberships": [
      "IEEE, Indian Science Congress"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "k4-CN2kAAAAJ",
      "orcid": "0000-0003-1082-1972",
      "scopus": "41661042600"
    }
  },
  {
    "id": "vitap-1690-cms",
    "name": "Dr. Vasavi Sanikommu",
    "employeeId": "7.70827",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "706 - A, CB",
    "email": "vasavi.sanikommu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vasavi_Sanikommu_SCOPE_a3da3c9f68.avif",
    "education": [
      "BSc (Computer Science), Acharya Nagarjuna University",
      "MS(Software Systems), BITS Pilani",
      "PhD(CSE), Acharya Nagarjuna University, Pursuing Postdoc at Technological University Baja California (UABC)",
      "Pursuing Postdoc at Technological University Baja California (UABC)"
    ],
    "researchArea": "Edge AI, Crowd video Analytics, Predictive Analytics for Remotely Sensed Data",
    "memberships": [
      "i. Senior Member IEEE , & Member Women in Engineering(WIE) , IEEE GRSS member: 94173153 ii. Life Member of CSI Member ID: I0136476 iii. Member Machine Intelligence Research Labs , Washington, USA iv. Life Member (Senior) of ACEEE Member ID:1174"
    ],
    "projects": [
      "1. Ongoing research work on Development of Techniques for Scalloping and Banding removal in Scan-SAR with Space Applications Center (SAC) ,Ahmedabad, ISRO and Mentor for MSME project",
      "2. Development of Edge Computing Framework for Multi-Object detection based on Deep-learning Techniques and Analysis for Satellite In-Orbit processing, Funding Agency: Advanced Data Research Institute (ADRIN), Department of Space, ISRO, February 14th 2024, Completed With 11 publications",
      "3. Development of Infra-red camera based Crowd Video Surveillance using Hybrid Deep Learning Model, Funding Agency: Advanced Data Research Institute (ADRIN), Department of Space, ISRO, February 14th 2024, Completed With 4 publications",
      "4. Impact of Climate Change on Offshore Wind and Wave Power Potential in the India EEZ Region, Indian Institute of Technology Kharagpur under the aegis of the National Mission on Interdisciplinary Cyber-Physical Systems (NM-ICPS), DST, Government of India, October 20th 2023, Completed With 1 patent and 2 publications",
      "5. Artificial Intelligence In Remote Sensing Applications, IEEE GRSS, September 2023, Conducted Seasonal School Programmes during 2023, 2024,2025",
      "6. Updating of Very Large Scale Urban GIS Maps with Latest Very High Resolution Satellite Data Using Deep Learning Techniques, National Remote Sensing Center (NRSC), ISRO, October 10th 2022, Completed With 14 publications",
      "7. A Visual Analytics Tool that creates a dashboard for hidden patterns within Road accidents dataset using Machine learning techniques, University Grants Commission (UGC), ay 2014, Completed With 2 patents and 2 publications",
      "8. Robust Video Analytics (Image Classification module), Funding Agency: Advanced Data Research Institute (ADRIN), Department of Space, ISRO, May 2014, Completed With 7 publications",
      "9. Image processing and classification techniques for detection and tracking of whales using space-borne remote sensing data, IEEE GRSS, January 2024, Completed With 7 publications",
      "10. UGC Travel Grant of Rs 1,72,450/- to present research paper “Metadata based Object Detection and Classification using Key Frame Extraction Method” at 2nd International conference on Optoelectronics and Image Processing (ICOIP 2015), at Chicago, U.S.A, during 2nd July to 3rd July 2015."
    ],
    "patents": [
      "1. Method and System for Coastal Zone Risk Prediction using Meteorological GeoSpatial data Ref No: 201941046407, Granted on 7-11-2023",
      "2. Method and system for Accident risk prediction using real world road transportation data Ref No: 201641025927, Granted on 09/02/2024",
      "3. PORTABLE SOLAR FISH DRYER, UK design patent, , Number: 6303822, Granted on 30/08/2023",
      "4. An Automated Board Cleaning System and Method Employed Thereof, application number: 202441023379, Filed: 25/03/2024, Published: 26/09/2025",
      "5. DEVICE FOR DETECTING DISEASED LEAVES IN PLANT BY IMAGE PROCESSING, application number: 202341055621, Filed: 18/08/2023, published: 30-09-2023",
      "6. Under Water Drone Design Patent, Ref No: 371375-001 Published: 23/09/2022",
      "7. Solar Power Generation Forecasting Using Ensemble Approach Based On Deep Learning And Statistical Methods, Ref No: 202241054828, Published : 24/09/2022",
      "8. Method and system for receiving a complaint Ref No: 201641003379, filed: January 29th 2016 Published: August 2017,FER requested in 2020",
      "9. System And Method For Contactless Temperature Monitoring Using Smart Thermometer, application number: 202441046517, filed: 17/06/2024",
      "10. A System For Automated Bail Dislodgement Detection, Patent Ref number: 202541076448, Filed::11/08/2025"
    ],
    "awards": [
      "Guest Lecturer at India Space Academy, Department of Space Education, New Delhi since November 2025",
      "University Research Council member in Audisankara (Deemed to be University) since August 2025",
      "Board of Studies member and Faculty Ratification member (JNTUK) for Andhra Loyola Engineering College",
      "One among 81 invitees from ISRO to participate in ISRO academia day for the release of RESPOND basket 2024",
      "Key person in bringing MOUs with various ISRO centers such as Space application center (SAC) Ahmadabad, Advanced Data Research Institute (ADRIN), CR Rao AIMSCS, LDU Business Analytics Dubai, Data Stride Analytics, APSAC.",
      "Received Indian women Achievers Award (IWAA) under the category of Excellence in STEM in 2024",
      "Senior Member IEEE, Member WIE, Member IEEE GRSS, Member MIR Labs, Life Member CSI",
      "Volunteer for Elevation to Senior Member grade of IEEE members",
      "Ongoing Collaborative Research work with scientists of National Remote Sensing Center (NRSC) on Change detection modeling from High resolution images for Urban areas since 2019 with an outcome of SCI and Scopus publications",
      "Ongoing Collaborative Research work with Professor of Autonomous University of Baja California, Mexico, USA in Drone Based Video Processing (Since 2021)",
      "Ongoing Collaborative Research work with Andhra Pradesh State Disaster Management in solving societal problems since 2019 with an outcome of App development, Scopus indexed publications and Patent filing is pending",
      "Ongoing Collaborative Research work with Andhra Pradesh Space Applications Center (APSAC) in solving societal problems since 2021",
      "Completed Collaborative Research work with Professor of Illinois State University in Geospatial Analysis Framework using Cassandra-Hadoop, Spark-MongoDB, Spark-Redis (2015-2018) with an outcome of Scopus publications",
      "Completed Collaborative Research work with Professor of Illinois State University in Cloud data Analytics using Genetic algorithms (2021-22) with an outcome of Scopus publications",
      "Completed Collaborative Research work with Professor of National University of Singapore in Thermal Image Analysis for classifying Geriatric Patients.(2016-2018) with an outcome of ACM and Scopus publication, best paper award",
      "Completed Collaborative Research work with Professor of Michigan State University in Fundus Image Analysis for classifying Diabetic Retinopathy (2017-2019) with an outcome of Scopus publications",
      "Completed Collaborative Research work with Indian National Centre for Ocean Information Services(INCOIS) for Coastal Zone Data Modelling (2018-2019) with an outcome of patent filing",
      "Completed Collaborative Research work with Advanced Data Research Institute (ADRIN) for Identification of Soft Biometrics of Human beings with Deep Learning Techniques (2018-2020) and submitted two SCI Q1 journals.",
      "Completed Collaborative Research work with Space Application Center (SAC) Ahmadabad, for Internal Wave Prediction (2019- 2022) with an outcome of IEEE Conference and Science Direct Publication",
      "Completed Collaborative Research work with Andhra Pradesh State Disaster Management in solving societal problems (2019-2020) with an outcome of App development and Patent filing is pending",
      "Session chair at IEEE conference ICFSP 2024 conducted at Paris- France, Keynote speaker for IEEE Conference ICOIP 2017 conducted at Singapore, July 2017 and Session chair for ICEIEE 2019 conference conducted at Malaysia",
      "Delivered Guest Lecture at UTM Malaysia on Innovative research ideas and possible collaboration, Applied ASEAN project with Co-Investigators from Singapore and Malaysia",
      "Received Best Paper award at 9th IEEE Annual Information Technology, Electronics, and Mobile Communication Conference (IEMCON 2018) held at University of British Columbia, Canada during 1-3rd November 2018",
      "Received Best Paper award at International Conference On Adaptive Computational Intelligence (ICACI-2020) 15th & 16th December 2020, Mysore",
      "Collaborative research work publications with research organization/industry: 31 and with international authors: 14",
      "Received Indian Women Achievers Award (IWAA) 2024 under the category of Excellence in STEM towards remarkable journey and contributions for science technology engineering and mathematics",
      "Best Teacher Award Received Best Teacher Award, Vishitta Mahila Award, Conferred Outstanding Women in Engineering Award, Best Faculty in Rural Institution award , Good standing Through from IEEE, Academic Titan Achievement Award",
      "Recognized as an honorary Rosalind Member of London Journals Press with Membership ID, #RS56761 for the research paper entitled “Web Based Geo Processing Workbench” On 26th April 2021",
      "Visited Reputed Universities in U.S.A, Thailand, Singapore, Canada Malaysia and France",
      "Visited National Argonne Laboratory A multidisciplinary Science and Engineering Research Centre that address vital national challenges in Clean Energy, Environment, Technology and National Security",
      "Organizing and technical committee member for various conferences conducted at India, U.S.A, Singapore, China",
      "Motivated students to present their research work at various national project expos, Smart India Hackathon, conducted by industry and academic institutes"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-vasavi-s-b9598354/",
      "researchGate": "https://www.researchgate.net/profile/Sanikommu_Vasavi",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=sEQYEScAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=23986854500",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/680552"
    }
  },
  {
    "id": "vitap-1704-cms",
    "name": "Dr. Syamala Murali Krishna",
    "employeeId": "7.70843",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "706 - I, CB",
    "email": "muralikrishna.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_SYAMALA_MURALI_KRISHNA_SCOPE_4253667735.avif",
    "education": [
      "B.Tech -SV University",
      "M.Tech -JNTUCEH-Hyderabad",
      "Ph.D -JNTUA -Anantapurum"
    ],
    "researchArea": "Text mining , Data Analytics, NLP and Machine Learning",
    "memberships": [
      "CSI"
    ],
    "projects": [
      "1. A grant of 6 Lakhs from DST to words conduction of Big data work shop in the year 2014 No BDID/01/22/2014 Government of India Department of Science & Technology –Big Data Initiatives division Rs. 6,00,000/-",
      "2. A grant of 40k ICMR Sponsored National Level Seminar on Data Mining Applications to Health care ICMR letter No. 7/1190/17-Seminars (HRD) dated 06/02/2018 Rs 40,000/-",
      "3. MODROBS scheme titled “Advanced Computer Analytics Lab” the sanctioned grant of Rs 11,01,000/ F.No.9-192/RIFD/MOD/POLICY-1/2018-19 Date: 04.12-2019.",
      "4. Research project entitled “EXPLORING THE DETERMINANTS OF ANAEMIA IN YOUNG ADULT WOMEN: THE ROLE OF AI BASED INTERVENTION”, R.O.C. No. SPMVV/UGC/F1/PM-USHA/2024; Approved Budgetary: Rs. 7,90,900/- Date 31-12-2024"
    ],
    "patents": [
      "1. Dr. S. Murali Krishna, Professor published a patent on, “AI-DRIVEN SMART ELECTRIC WHEEL CHAIR” with patent number: 202441017564 A, Date of Filing: 12/03/2024; Publication Date: 22/03/2024",
      "2. Dr. S. Murali Krishna, Professor published a patent on, “ AI-DRIVEN ELECTRIC VEHICLE CHARGING SYSTEM” with patent number: 202341071602 , Date of Filing: 01/12/2023; Publication Date: 19/10/2023"
    ],
    "awards": [
      "University Innovation Fellowship -Faculty Champion -d.school at Stanford University"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/murali-krishna-syamala-634046408/",
      "researchGate": "https://orcid.org/my-orcid?orcid=0000-0001-7154-1881",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=xmOYsbwAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57195221519",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/627698"
    }
  },
  {
    "id": "vitap-1736-cms",
    "name": "Dr. Rupa Chiramdasu",
    "employeeId": "7.70871",
    "designation": "Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "103 - A, CB",
    "email": "rupa.chiramadasu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_RUPA_CHIRAMADASU_SCOPE_fb15d93de6.avif",
    "education": [
      "B.Tech (CSIT), JNTU Hyderabad",
      "M.Tech(CSIT), Andhra University",
      "Ph.D (Data Security), Andhra University, PDF ( Data Security), Lincoln University",
      "PDF ( Data Security), Lincoln University"
    ],
    "researchArea": "AI Security, Cryptography, Watermarking",
    "memberships": [
      "1. Senior Member of INAE : IndM/2025/C1/145, 2. Senior Member of IEEE: 93308121, 3. Life Member in Institute of Engineers of India IE (I) :AM0995951, 4. Life Member in Indian Society for Technical Education (ISTE) : LM54318, 5. Life Member in Computer Society of India (CSI) : 00157372, 6. Life Member in International Association of Engineers (IAENG): 100591, 7. Senior Member of International Association of Computer Science and Information Technology (IACSIT) – 80344892, 8. CSTA (acm) computer society teachers association: 3991581, 9. Life member in CRSI : L/0675, 10. Life Member: IETE :M 500594"
    ],
    "projects": [
      "1. “Design and Development of Robust Authentication Protocol for under water vehicle secure communication System”, National Program for Research, Development, and Innovation (RDI) in Cyber Security, Saudi Arabia, 2025-26",
      "2. “Blockchain based Medical Digital Assets Protection Against Frauds”, AICTE-AURA, 2025-26",
      "3. “Design and Development of Ornithopter”, SAGTE, 2-22-24",
      "4. “Ratinale for the presence of Moral values, Ethics and Behavioural sciences on Attitude development in the technical education”, AICTE – AQIS, 2019-21",
      "5. “Development of an Application System for Encoding Schemes in real time system”, DST-SERB, 2014-17"
    ],
    "patents": [
      "1. Ref. No: IPR1408202670871, “QuantumShield-IoT”",
      "2. Ref No: 202541125507, “A Footwear System For Obstacle Detection And Health Monitoring”, Filed",
      "3. Ref. No. 202541043150, “A Neck Band Embedded With Secure Communication For Posture Monitoring And Correction”, Granted",
      "4. Ref. No. 398614-001, “Ornithopter”, Granted",
      "5. Ref. No. 202241056359, G.No: 496889, “A Device For Protection Against Pedophiles”, Granted",
      "6. Ref. No. 202041049462, G. No: 415216, “Smart Power Controlling Device switching Using IoT”, Granted",
      "7. Ref. No. 2934/CHE/2014, G. No: 405844, “A method of encoding and decoding for secure message transmission based on keyless rotational (carpet) shift approach”, Granted",
      "8. Ref. No. 2020103943, Australia- International Patent on “A System And A Method For Preventing Theft Using Blockchain Technology “, Granted",
      "9. Ref. No. 201641015449, G. No.: 530344, “Method and system for Secure Information Framework with APRQ Properties”, Granted",
      "10. Ref. No: 14694/2019-CO/L, “Controlling of security Risks using cheating Text“ , Published",
      "11. Ref. No: 202441052952, “An Augmented Reality-Based Method For Exploring And Preserving The Weaving Heritage Of Sarees”, Published",
      "12. Ref. No: 202341053778, “Ornithopter Unmanned Remote Control Aerial Vehicle For Intruder Detection And Data Preservation”, Published",
      "13. Ref. No: PCT/IB2023/062763, “Ornithopter Unmanned Remote Control Aerial Vehicle For Intruder Detection”, Published",
      "14. Ref: 202141042413, “Method, System And Device For Crop Detection Blockchain Based”, Published",
      "15. Ref: 202041010236, “Method and system for identifying integrity of physical currency”, Published",
      "16. Ref. No: 201841029508, “Method, System And Device For Protecting The Privacy Of Data”, Published"
    ],
    "awards": [
      "2026 – National: Evaluation Jury Member, IETE- Technomedia Award for Young Women in Engineering, India",
      "2026 – International: Session Chair, IEEE International Conference, ANITS (A), Vizag.",
      "2026 – International: Utthama Adhyapika, Braino Vision Pvt. Ltd. (AICTE Recognized).",
      "2025 – National: Appreciation Award, JNTU Kakinada.",
      "2025 – International: Global Top 2% Scientist, Elsevier & Stanford University, USA.",
      "2025 – International: Excellence in Research Contribution, Council for Skills and Competencies (CSC), MSME, India.",
      "2024 – International: Global Top 2% Scientist, Elsevier & Stanford University, USA.",
      "2025 – National: Evaluation Jury Member, IETE- Technomedia Award for Young Women in Engineering, India",
      "2024 – International: Best Paper Award – Ornithopter, NIT Uttarakhand.",
      "2024 – International: Best Paper Award – Privacy of Army Vehicle, Springer, Kolkata.",
      "2024 – International: Session Chair, IEEE International Conference, University of Malaya & VIT Vellore (QS Rank #65).",
      "2023 – International: Best Paper Award – Meaningful Cipher, Sharnabava University.",
      "2023 – International: Global Top 2% Scientist, Elsevier & Stanford University, USA.",
      "2023 – International: Technomedia Young Women in Engineering, IETE, HQ, New Delhi.",
      "2022 – National: Coordinator & IIC-Ambassador, NIPAM, IP India.",
      "2020-21 – International: Certificate of Continuing Education, Cybrary, Maryland, USA.",
      "2017–18 – National: Computer Discipline Award, IEI, Kolkata.",
      "2017–18 – International: Certificate of Continuing Education, Cybrary, Maryland, USA.",
      "2017 – National: IETE Brig. M. L. Anand Award, IETE, Kochi.",
      "2016 – International: Senior Member, IEEE.",
      "2013-14 – National: Computer Discipline Award, Indian Engineering Congress.",
      "2013–14 – National: One of the Top 25 Women Engineers, IEI, Kolkata.",
      "2013–14 – National: Best University Teacher, JNTUK.",
      "2012–13 – State: Young Engineer Award, Government of Andhra Pradesh and IEI.",
      "2011–12 – National: Young Engineer Award, IEI, Kolkata.",
      "2010–11 – State: Young Engineer Award, JNTUK, Andhra Pradesh.",
      "2009–10 – International: Best Paper Award, Pentagram Research Centre, Government of Andhra Pradesh."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-rupa-ch-72966528",
      "researchGate": "https://www.researchgate.net/profile/Ch-Rupa?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=d9onLuYAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56456742200",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/512794"
    }
  },
  {
    "id": "vitap-1140-cms",
    "name": "Dr. John Pradeep D",
    "employeeId": "8.70007",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "G-31, AB-1",
    "email": "john.darsy@vitap.ac.in",
    "phone": "5444",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_John_Pradeep_D_70007_IMG_4713_SENSE_9d6a075b3b.avif",
    "education": [
      "B.Tech, JNTU Anantapur",
      "IIT-Guwahati",
      "Ph.D, VIT University, Vellore"
    ],
    "researchArea": "Nonlinear Control, Machine learning, Reinforcement learning, SAW sensors",
    "memberships": [
      "Member IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/John-Darsy",
      "googleScholar": "https://scholar.google.co.in/citations?user=CUw4IV4AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1384-cms",
    "name": "Dr. Khadheer Pasha Sk",
    "employeeId": "8.70012",
    "designation": "Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "125, AB-1",
    "email": "khadheerpasha.sk@vitap.ac.in",
    "phone": "5125",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Khadheer_Pasha_Sk_IMG_9445_A_SASPHY_21a18e2791.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1149-cms",
    "name": "Dr. Nalluri Purnachand",
    "employeeId": "8.70027",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "128, AB-1",
    "email": "purnachand.n@vitap.ac.in",
    "phone": "5160",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Nalluri_Purnachand_70027_IMG_5128_SENSE_1c9b26e785.avif",
    "education": [
      "B.Tech, Acharya Nagarjuna University",
      "M.Tech & VIT Univerity, Vellore",
      "PhD, Univeristy of Aveiro - Portugal"
    ],
    "researchArea": "FPGA and ASIC architectures of image & video processing, Hardware accelerators of convolution neural networks, Video Processing Algorithms",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Purnachand-Nalluri",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=JwVT_dMAAAAJ"
    }
  },
  {
    "id": "vitap-1310-cms",
    "name": "Dr. Santanu Mandal",
    "employeeId": "8.7003",
    "designation": "Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "320-B, AB-2",
    "email": "santanu.mandal@vitap.ac.in",
    "phone": "5566",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Santanu_Mandal_70030_IMG_4872_SAS_MAT_2f47fe5831.avif",
    "education": [
      "B.Sc(Hons.)., Jadavpur University",
      "M.Sc., Jadavpur University",
      "Ph.D.(Neural Networks), Jadavpur University"
    ],
    "researchArea": "Control Systems, Nonlinear Dynamics, Neural Networks, Robotics, Image Encryption",
    "memberships": [
      "Bio-Mathematical Society of India (Life Member)"
    ],
    "projects": [
      "1. Real Time Intelligent Glasses for Visually Impaired Using Machine Vision and Voice Assistance (funded by V-LAUNCH, VIT-AP University)",
      "2. Autonomous Weed Removal and Collector Robot (funded by V-LAUNCH, VIT-AP University)",
      "3. New image encryption method for satellite/geographical images using memristor-based hyper-chaotic system for secure communication and protection of data. (funded by RGEMS, VIT-AP University)",
      "4. Automotive Drone-based Multitasking Device with Intelligent Tracking System for Agricultural and Plantation (funded by V-LAUNCH, VIT-AP University)",
      "5. Memristor based neuromorphic architecture for image processing, (funded by RGEMS, VIT-AP University)",
      "6. Py-Digital Writing Pad – (Python Based Motion Sensing Digital Writing Pad (funded by V-LAUNCH, VIT-AP University)"
    ],
    "patents": [
      "1. Patent No.: 553628 (Granted), Automotive Drone-based Multitasking Device with Intelligent Tracking System For Agriculture and Plantation",
      "2. Patent No: 452885 (Granted), Smart Glass for Assisting Visually Impaired Users with Voice Assistance and Method Thereof",
      "3. Application No.: 202341062911, Robotic Means to Remove Weed From a Fieldrobotic Means to Remove Weed from a Field",
      "4. Application No.: 202141026740, Py-Digital Writing Pad (Python Based Motion Sensing Digital Writing Pad)",
      "5. Application No.: 202441024597, Roadside Electric Vehicle Charging Unit Using Wind Energy",
      "6. Application No.: 202441029516, A system for Enabling Encryption and Decryption of One or More Images for Attaining Secured Transmission",
      "7. Application No.: 202141057233, A Novel Circuit-Based Synaptic Memristor for Neuromorphic Computing",
      "8. Application No: 202341051513, A Floating Vessel-Mounted System to Convert Water Wave Energy into Electrical Energy",
      "9. Application: 202441047930, A Smart Bin Facilitating Recycling of Non-biodegradable Substances, and Method Thereof",
      "10. Application No.: 202341009050, System and Method for Automated Touchless Ticket Booking Based on Finger Patterns"
    ],
    "awards": [
      "2nd Prize (National Level INNOVATION AWARDS '24 - \"SEEDBRAINS 3.0\"), Cambrian House of Student Startup in association with MSME CoE, DESE, IISc; NRDC: Bengaluru, Karnataka, IN, 2024",
      "Best Paper Award (IC-JSPMNTC 2024), JSPM NARHE TECHNICAL CAMPUS, NARHE, PUNE, India, 2024",
      "National Award Hackathon 3.0 award, Indian Council of Agricultural Research- National Agricultural Higher Education Project (ICAR-NAHEP), Govt. India, 2023",
      "'GOLD AWARD' FOR THE INNOVATION 'AUTOMOTIVE DRONE-BASED MULTITASKING DEVICE WITH INTELLIGENT TRACKING SYSTEM FOR AGRICULTURE AND PLANTATION', Goa State Innovation Council & INEX India, 2022",
      "'GOLD AWARD' FOR THE INNOVATION 'PY-DIGITAL WRITING PAD (PYTHON BASED MOTION SENSING DIGITAL WRITING PAD)', Goa State Innovation Council & INEX India, 2022"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/santanu-mandal-ph-d-247a64115/",
      "website": "vitap.irins.org/profile/302822",
      "researchGate": "https://www.researchgate.net/profile/Santanu-Mandal-7?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=7FPLT3QAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0003-1349-7717",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57210516903",
      "vidwan": "https://vitap.irins.org/profile/302822"
    }
  },
  {
    "id": "vitap-1366-cms",
    "name": "Dr. Roopas Kiran Sirugudu",
    "employeeId": "8.70031",
    "designation": "Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "G-36, AB-1",
    "email": "roopaskiran.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70031_Dr_Roopas_Kiran_Sirugudu_Physics_1101_51b282850f.avif",
    "education": [
      "B.Sc., Nagarjuna University",
      "M.Sc., Indian Institute of Technology Madras",
      "Ph.D., Indian Institute of Technology Madras, Postdoctoral Fellow, University of Padova, Italy",
      "Postdoctoral Fellow, University of Padova, Italy"
    ],
    "researchArea": "Dielectric Materials - Ferroelectrics, Piezoelectrics, microwave dielectrics, Multiferroics, Structure-Property correlation, X-ray diffraction, Raman Spectroscopy",
    "memberships": [
      "MRSI, India"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Roopas-Sirugudu?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=QJdzDQYAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=36147575600",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/304364"
    }
  },
  {
    "id": "vitap-1139-cms",
    "name": "Dr. Hussain Syed",
    "employeeId": "8.70032",
    "designation": "Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "623-A, CB",
    "email": "hussain.syed@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Hussain_Syed_70032_IMG_4953_SCOPE_d31f2b1b37.avif",
    "education": [
      "B.E, ANNA UNIVERSITY",
      "M.Tech (Database Systems), SRM University",
      "1. Ph.D (CSE), Sri Satya Sai University of Technology and Medical Sciences, Sehore, 2. Post Doctoral Fellowship at SR University, Warangal",
      "Post Doctoral Fellowship at SR University, Warangal"
    ],
    "researchArea": "Software Engineering,Human-Interaction Design, Software Project management,Data Analytics,Business Intelligence, Data warehousing & Data-Mining.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-hussain-syed-2a294315/",
      "googleScholar": "https://scholar.google.com/citations?user=uPgeplgAAAAJ&hl=en",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0002-8860-4196",
      "scopus": "https://www.scopus.com/dashboard.uri?origin=sbrowse&zone=TopNavBar"
    }
  },
  {
    "id": "vitap-1372-cms",
    "name": "Dr. J Sudagar",
    "employeeId": "8.70033",
    "designation": "Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "214, AB-1",
    "email": "sudagar.jothi@vitap.ac.in",
    "phone": "5153",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Sudagar_IMG_6746_SASPHY_4a01516fb6.avif",
    "education": [
      "B.Sc (Physics) & Pondicherry University",
      "M.Sc (Materials Science & Tech) & Pondicherry University",
      "PhD (Materials Science and Engg) & Jilin University",
      "PDF (Materials Science and Engg) & IIT Madras"
    ],
    "researchArea": "High-Entropy materials; Eco-friendly Coatings; Corrosion science of engineering materials; Photovoltaics; Nanomaterials synthesis, and Nanocomposites.",
    "memberships": [
      "1. Life Membership (LM-50579) in â€˜Indian Institute of Metals (IIM)â€™, Chennai Chapter, India 2. Life Active Member (LF201401084) in â€˜The Society for Advancement of Electrochemical Science and Technology (SAEST)â€™, CSIR-CECRI Campus, Tamilnadu, India 3. IEEE professional member (94997943) in Hyderabad section 2018-2019, 2019-2020. 4. Life Member in â€˜Indian Red Cross societyâ€™, National Social Service and Yoga activities 5. Life Membership (LMB 2978) in â€˜Materials Research Society of India (MRSI)â€™, Hyderabad Chapter, India 6. Life member â€˜The Indian Science Congress and Associationâ€™, Kolkata, India"
    ],
    "projects": [
      "1.PI: Dr. J. Sudagar, Title: CuO/SnO2 Hetero Junction Nanoarrays for Selective Detection of CO2 Gas, VIT-AP V-LANCH funded for the year 2022-2023 (Ongoing)",
      "2. Co-PI: Dr. J. Sudagar, Title: Solar and Battery Powered Autonomous (Autopilot) Campus Vehicle for Visitors, VIT-AP V-LANCH funded for the year 2022-2023 (Ongoing)",
      "3. PI: Dr. J. Sudagar, Title: Corrosion Behavior of Ceramic Materials under Extreme Environment Conditions, VIT-AP RGMES funded for the year 2021-2022",
      "4. PI: Dr. J. Sudagar, Title: Extended Life of Components through High Entropy Alloy Coatings for Engineering Applications, VIT-AP RGMES funded for the year 2017-2018"
    ],
    "patents": [
      "1. Indian Patent filed ‘Chromium free conversion coating of Aluminium alloy’ submitted in Industrial metal finishing domain, 2023, IP India App. No. 202341031096 (published)",
      "2. Indian Patent filed ‘Chromium free conversion coating of Magnesium alloy’ submitted in Industrial metal finishing domain, 2023, IP India App. No. 202341032533 (published)",
      "3. Indian Patent filed ‘Multipurpose Solar Umbrella with Fan, LED, Water Sprinkler and Temperature Sensor’ submitted in Smart gadgets domain, 2023, IP India App. No. 202341026347 (published)"
    ],
    "awards": [
      "2023-PK Das Memorial Best Faculty award (Junior) with Rs.10000/- Cash prize by Nehru Group of Institution, Coimbatore, India.",
      "2023-Partial Travel Assistance by CSIR to attend The International Conference on PROCESSING & MANUFACTURING OF ADVANCED MATERIALS Processing, Fabrication, Properties, Applications (THERMEC-2023), Vienna, Austria.",
      "2018-Best Academic Researcher - 2017 by Dr. Kalam Educational Trust, Chennai, India.",
      "2017-Outstanding Reviewer for Materials Science and Engineering B by Elsevier, Amsterdam, The Netherlands.",
      "2014-Centre for International Co-operation in Science (CICS) & IITM alumni Travel Award to attend 13th International Ceramic Congress (ICC-2014), Montecatini terme, Italy.",
      "2013-Best Poster award in the International Union of Materials Research Society -International Conference in Asia (IUMRS-ICA), IISc, Bangalore, India.",
      "2013-Institute Post-Doctoral Fellowship (IPDF) by the Indian Institute of Technology Madras, Chennai, India.",
      "2011-ICC Young Researcher Travel Award by the International Corrosion Council (ICC-2011) to attend 18th International Corrosion Congress at Perth, Australia.",
      "2008-PhD fellowship provided by Chinese Government Scholarship, China & India-China Cultural Exchange Scholarship by the Ministry of Human Resource Development (MHRD), India and Ministry of Education (MOE), China.",
      "2006-CSIR Diamond Jubilee Research Internship by the Council of Scientific and Industrial Research (CSIR), India"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-jothi-sudagar-807a2224/",
      "website": "https://sites.google.com/vitap.ac.in/prof-sudagar-jothi/bio",
      "researchGate": "https://www.researchgate.net/profile/Sudagar-Jothi",
      "googleScholar": "XuDokAmoPtMC",
      "orcid": "0000-0002-7670-4843",
      "scopus": "35073061100",
      "vidwan": "300860"
    }
  },
  {
    "id": "vitap-1503-cms",
    "name": "Dr. Umakanta Nanda",
    "employeeId": "8.70055",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "326-E, AB-1",
    "email": "umakanta.n@vitap.ac.in",
    "phone": "5362",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Umakanta_Nanda_SENSE_1828_1_804cdb609d.avif",
    "education": [
      "BPUT, Odisha",
      "MTech, NIT Rourkela",
      "PhD, NIT Rourkela"
    ],
    "researchArea": "Microelectronics, Semiconductor Devices and Circuits, Mixed Signal VLSI Design, Solar Cells",
    "memberships": [
      "Senior Member - IEEE, Life Member - ISTE"
    ],
    "projects": [
      "1. Chief Investigator, Chips to Startup (C2S) Program, Ministry of Electronics & Information Technology (MeitY), where VIT-AP is supported by the ChipIN Centre for EDA tools access"
    ],
    "patents": [
      "1. ⁠U Nanda, A K Tripathy, N K Mucheli, J Kumar, “IOT based power theft detection system”, 201941048016, Indian patent, 6th Dec 2019, status: Published.",
      "2. U Nanda, A Biswas, S Chattergee, A K Pradhan, S Saxena, D K Yadav, A Jamshed, G K Rajput, “Cybernetic Plant”, Indian Patent Filed on 5th March 2020, Application number: 202041009615, status: Published.",
      "3. A K Tripathy, U Nanda, T Mehrotra, A K Mishra, A K Pradhan, S Saxena, S Gupta, J Kumar, “An IOT based intelligent food storage system”, 202041018273, Indian patent, 6th June 2020, status: Published.",
      "4. B Baral, U Nanda, K Potnuru, A Mishra, S M Biswal, Sachin, “Smart Management of Food Storage and Waste Reduction using Blockchain Technology”, 202141026736, Indian patent, 25th June, 2021, status: Published.",
      "5. Umakanta Nanda, Srikurmum Hari Chandana, Samineni Peddakrishna, “Smart Power Saving Refrigerator with Individual Shelf Closing Doors”, 202141038645, Indian patent, 10th September, 2021, status: Published.",
      "6. C Neelesh, A D Sai Teja, M. S S Sai Manoj, M. Naresh, S Peddakrishna, U Nanda, A Side Mirror Water Droplet Removal System Using Controlled Pressure Regulator, 202141057902, Indian patent, 24th December, 2021, status: Published."
    ],
    "awards": [
      "Editor of Distinction award by Springer Nature recognising the careful evaluation of submissions and strong stewardship of the peer review process, time to first decision, reflecting the commitment to delivering an efficient, constructive, and fair experience for authors."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/umakanta-nanda-05946821/",
      "website": "https://sites.google.com/vitap.ac.in/umakantananda/home",
      "researchGate": "https://www.researchgate.net/profile/Umakanta-Nanda",
      "googleScholar": "https://scholar.google.com/citations?user=V8HuVjIAAAAJ&hl=en&oi=ao",
      "orcid": "https://orcid.org/0000-0003-4746-5297",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=36621876000",
      "vidwan": "https://vitap.irins.org/profile/213563"
    }
  },
  {
    "id": "vitap-1399-cms",
    "name": "Dr. Debajit Goswami",
    "employeeId": "8.70058",
    "designation": "Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "214, AB-1",
    "email": "debajit.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Debajit_Goswami_SASPHY_2bb166cd6f.avif",
    "education": [
      "B.Sc. (Physics Hons.), University of Calcutta",
      "M. Sc. Physics, Jawaharlal Nehru University",
      "1) Ph. D. Physics, University of Florida, USA, 2) Saarland University, Germany, 3) International Centre for Theoretical Sciences - Tata Institute of Fundamental Research, Bengaluru, India",
      "1. Saarland University, Germany 2. International Centre for Theoretical Sciences - Tata Institute of Fundamental Research, Bengaluru, India"
    ],
    "researchArea": "Theoretical Biophysics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/debajit-goswami-8826b426/",
      "researchGate": "https://www.researchgate.net/profile/Debajit-Goswami?ev=hdr_xprf"
    }
  },
  {
    "id": "vitap-1157-cms",
    "name": "Dr. Deepak Ch",
    "employeeId": "8.70059",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "329-I, AB-1",
    "email": "deepak.ch@vitap.ac.in",
    "phone": "5367",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Deepak_Ch_70059_IMG_2637_SENSE_18c600cdbe.avif",
    "education": [
      "B.Tech from JNTU Hyderabad",
      "M.Tech from JNTU Anantapur, Andhra Pradesh",
      "Ph. D, from Homi Bhabha National Institute (HBNI), Mumbai, Maharashtra"
    ],
    "researchArea": "Digital Systems, VLSI Circuits, FPGA, ASIC Designs, Internet of Things",
    "memberships": [
      "IEEE"
    ],
    "projects": [
      "1. Social distance monitoring and face mask detection system, Project ID / Reference Number - VLAUNCH/2021/17, Project End Date - 31-08-2022, Current Status - Completed",
      "2. IoT platform for wireless monitoring of industrial motor, Project ID / Reference Number - VIT-AP/IIEC/VLAUNCH/2024-25/001, Project Start Date - 13-12-2024, Current Status - Ongoing"
    ],
    "patents": [
      "1. Social distance monitoring and face mask Detection equipment, Patent Publication Number - A62B18/02, Date of Publication - 25/09/2020, Patent Status - Published",
      "2. Dynamic Digital Twin System and a Method af Operating, Patent Grant Number - AU-A-2020103853, Date of Grant - 11-02-2021, Patent Status - Granted",
      "3. IoT Based Industrial System for Smart Monitoring of Motor Using Synchro, Patent Application Number - 202141055123A, Date of Publication - 10/12/2021, Patent Status - Published",
      "4. Bluetooth Connected Earbud, Patent Grant Number - 406297-001, Date of Grant - 08/04/2024, Patent Status - Granted",
      "5. Automated Drone with Pesticide and Fertilizer Sprayer, Patent Publication Number - C05G 3/00, Date of Publication- 24/09/2021, Patent Status - Published"
    ],
    "awards": [],
    "links": {
      "orcid": "0000-0002-7255-549X",
      "scopus": "57060574000"
    }
  },
  {
    "id": "vitap-1158-cms",
    "name": "Dr. Anoop Kumar Mishra",
    "employeeId": "8.7006",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "328-A, AB-1",
    "email": "anoop.m@vitap.ac.in",
    "phone": "5349",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Anoop_Kumar_Mishra_70060_IMG_2645_SENSE_75a3f451e8.avif",
    "education": [
      "B.E. from RGPV Bhopal",
      "--",
      "PhD, NIT Rourkela, Odisha"
    ],
    "researchArea": "Cooperative Transmission over Fading Channels, Physical layer security and privacy, Cognitive Multi-hop Networks, Computational Offloading for MEC System, and NOMA-aided MEC system.",
    "memberships": [
      "IEEE"
    ],
    "projects": [
      "Brain activity monitoring, Project ID / Reference Number - IDEAAP 023114, Project End Date - 4th November 2025, Current Status, Ongoing"
    ],
    "patents": [
      "1. System and Method for Detecting Variations in a Landscape Area using Remote Sensing Images, Patent Grant Number - 577907, Date of Grant - 12 January 2026, Patent Status - Granted",
      "2. IoT based Patient Health Monitoring System, Patent Grant Number - 570059, Date of Grant - 26 August 2025, Patent Status - Granted",
      "3. Automated Radiation Mapper Using Drone, Patent Application Number- 202341034186, Date of Publication - 16 June 2023, Patent Status - Published",
      "4. Wireless Robot for Surveillance & Fire Detection, Patent Application Number - 202441002221, Date of Publication - 16 February 2024, Patent Status - Published",
      "5. E-DOC: A Tele- Health Kiosk, Patent Application Number - 202141026722, Date of Publication - 2 July 2021 ,Patent Status - Published",
      "6. A Surveillance- Based Device Control System and Method Thereof, Patent Application Number - 202341086918, Date of Publication - 12 January 2024, Patent Status - Published"
    ],
    "awards": [],
    "links": {
      "website": "https://sites.google.com/view/akm16/home?authuser=0",
      "dblp": "https://dblp.org/pid/131/4404.html",
      "researchGate": "https://www.researchgate.net/profile/Anoop-Mishra-8",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=0GPPb2UAAAAJ",
      "orcid": "0000-0003-4595-7394",
      "scopus": "57191228109"
    }
  },
  {
    "id": "vitap-1159-cms",
    "name": "Dr. Sameeulla Khan Md",
    "employeeId": "8.70061",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "G-36, AB-1",
    "email": "sameeulla.k@vitap.ac.in",
    "phone": "5368",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sameeulla_Khan_Md_70061_IMG_2610_SENSE_9451c395f5.avif",
    "education": [
      "B.Tech, Acharya Nagarjuna University",
      "M.Tech, Acharya Nagarjuna University",
      "Ph.D, Indian Institute of Technology hyderabad"
    ],
    "researchArea": "Image and Video processing, Signal Processing, Information Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "orcid": "0000-0002-0520-9634",
      "scopus": "57145513900"
    }
  },
  {
    "id": "vitap-1189-cms",
    "name": "Dr. Ambuj Sharma",
    "employeeId": "8.70069",
    "designation": "Professor Grade 1",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "328-I , AB-1",
    "email": "sharma.ambuj@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ambuj_Sharma_IMG_2320_70069_SMEC_9078d3cd6b.avif",
    "education": [
      "B.TECH, RGPV BHOPAL",
      "M.TECH, MNNIT ALLAHABAD",
      "IIT(BHU), Varanasi"
    ],
    "researchArea": "Computational Mechanics, Wavelet Analysis, Nanocomposite, Numerical Modelling, Friction Stir Additive Manufacturing",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/ambuj-sharma-6aa5a6146/",
      "orcid": "0000-0002-2993-7118"
    }
  },
  {
    "id": "vitap-1161-cms",
    "name": "Dr. Jayendra Kumar",
    "employeeId": "8.70077",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "326-D, AB-1",
    "email": "kumar.jayendra@vitap.ac.in",
    "phone": "5347",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Jayendra_Kumar_70077_IMG_4911_SENSE_3409ac7d14.avif",
    "education": [
      "Solapur University",
      "Solapur University",
      "Ph.D, National Institute of Technology Silchar"
    ],
    "researchArea": "Microstrip and Graphene-based Antennas, 5G Antennas, Metamaterial, Reconfigurable Antennas, Machine and Deep Learning",
    "memberships": [
      "IEEE Senior Member, ISTE Life member (No. LM-82796), IAE Member (No. 197102), IACSIT Member (80351248), UACEE Senior Member"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Jayendra-Kumar",
      "googleScholar": "https://scholar.google.com/citations?user=lS_56_MAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-3381-2764",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56542511500",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/301783"
    }
  },
  {
    "id": "vitap-1165-cms",
    "name": "Dr. Sudha Ellison Mathe",
    "employeeId": "8.70078",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "206, CB",
    "email": "ellison.mathe@vitap.ac.in",
    "phone": "5348",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sudha_Ellison_Mathe_70078_IMG_5140_SENSE_e65e618ff3.avif",
    "education": [
      "B.Tech & KLCE, Vaddeswaram (affiliated to ANU, Guntur)",
      "M.E & BITS Pilani",
      "Ph.D & NIT Warangal"
    ],
    "researchArea": "IoT, PQC, VLSI Architectures, ASIC and FPGA implementations, AI/ML/DL",
    "memberships": [
      "IEEE, IEICE"
    ],
    "projects": [
      "1. PrayanaElectric - An AI/IoT based e-Bike for smart transport solutions - VIT-AP University",
      "2. Universal Appliance Controller - VIT-AP University",
      "3. Smart Bike for Intra-University transportation - VIT-AP University"
    ],
    "patents": [
      "1. 202341055973-Unmasking the Masked: Deep learning-based approach for reconstructing and recognizing masked faces",
      "2. 202341036606-MONITORING AND CONTROL OF IOT BASED E-BIKE CAMPUS TRANSPORTATION SYSTEM",
      "3. 202341053714-A smart BMS for Electric Vehicles",
      "4. 202341053440-BPME: Design of a Versatile Noise removal filter in ECG signals",
      "5. 202341004103-A HYBRID SECURITY FRAMEWORK FOR ENCRYPTION, DECRYPTION AND KEY EXCHANGE TOWARDS PQC",
      "6. 202441104056-Real-Time Detection of Crop Leaf Diseases Using EdgeYOLO algorithm",
      "7. 202441103740-UAV based Real-Time Pothole Detection Using SqueezedYOLO algorithm"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-sudha-ellison-mathe-b9966056/",
      "website": "https://ellisonsrk.wixsite.com/sudhaellisonmathe",
      "researchGate": "https://www.researchgate.net/profile/Sudha-Mathe",
      "googleScholar": "https://scholar.google.com/citations?user=wLRjwM0AAAAJ&hl=en",
      "orcid": "0000-0003-2806-5407",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56825679200",
      "vidwan": "https://vitap.irins.org/profile/260164"
    }
  },
  {
    "id": "vitap-1143-cms",
    "name": "Dr. R. Nandha Kumar",
    "employeeId": "8.70079",
    "designation": "Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "421, CB",
    "email": "nandha.r@vitap.ac.in",
    "phone": "5451",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_R_Nandha_Kumar_IMG_6597_SCOPE_36b1aaa52e.avif",
    "education": [
      "B-Tech Information Technology, Anna University",
      "ME Computer Science and Engineering, Anna University",
      "Computer Science and Engineering, Anna University"
    ],
    "researchArea": "Mobile Ad Hoc Networks, Wireless Sensor Networks, Next Generation Networks, Internet of Things, Machine Intelligence",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/nandhakumar-ramachandran-9582b856/",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=4dYNzO0AAAAJ",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0001-9861-5238",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57195073019"
    }
  },
  {
    "id": "vitap-1170-cms",
    "name": "Dr. Nuthakki Venkata Rajasekhar",
    "employeeId": "8.70081",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "229-B, AB-1",
    "email": "rajasekhar.venkata@vitap.ac.in",
    "phone": "5453",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Nuthakki_Venkata_Rajasekhar_70081_IMG_4945_SENSE_eadfe15605.avif",
    "education": [
      "ECE-JNTU ANANTAPUR",
      "Electronics Engineering-PONDICHERYY CENTRAL UNIVERSITY",
      "Ph.D. in Antenna Design and Analysis - NIT TRICHY"
    ],
    "researchArea": "1. Planar Antenna Design and Analysis. 2. Metamaterial based Antennas 3.Gian and Bandwidth enhancement of compact antennas. 4. MIMO antenna design and analysis of 5G Communications",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?hl=en&user=iznNzrUAAAAJ",
      "orcid": "0000-0001-8089-0282",
      "scopus": "57006617100"
    }
  },
  {
    "id": "vitap-1192-cms",
    "name": "Dr. Manoj Kumar Gupta",
    "employeeId": "8.70082",
    "designation": "Professor Grade 1",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "424-D, AB-1",
    "email": "manoj.gupta@vitap.ac.in",
    "phone": "5454",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Manoj_Kumar_Gupta_SMEC_1476_2a327f8859.avif",
    "education": [
      "BE, RGPV Bhopal",
      "M Tech., MANIT Bhopal",
      "IIT Delhi"
    ],
    "researchArea": "1. Tribology 2. Composites (SBC, Sustainable) 3. Colloidal and Dispersions 4. Oils (EP, AW, FM) 5. Electro-Tribo-Chemistry",
    "memberships": [
      "SAE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "D-7962-2019",
      "googleScholar": "FWsRXpYAAAAJ",
      "orcid": "0000-0002-9251-5428"
    }
  },
  {
    "id": "vitap-1145-cms",
    "name": "Dr. Sibi Chakkaravarthy S",
    "employeeId": "8.70084",
    "designation": "Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "222, CB",
    "email": "chakkaravarthy.sibi@vitap.ac.in",
    "phone": "5456",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sibi_Chakkaravarthy_S_70084_0587_206cccb3ec.avif",
    "education": [
      "B.E - Computer Science & Engineering, Anna University",
      "M.Tech - Computer Science & Engineering, Vel Tech Rangarajan Dr.Sagunthala R&D Institute of Science and Technology",
      "Information & Communication Engineering, Anna University"
    ],
    "researchArea": "Cyber attacks and detection, Cyber Security, Consumer Electronics Security",
    "memberships": [],
    "projects": [
      "Saila, FIDO enabled smartphone-based password less authentication system to protect HID injection[ Funding agency : C-HERD, DSCI, Grant in INR : 7L, Duration : On-going ]",
      "A novel deep learning model to identify cyber bullying and it's impact on mental health of the youth in India [ Funding agency : DST, CSRI, Grant in INR : 26L, Duration : On-going ]",
      "GPU accelerated security system [ Funding agency : NVIDIA, Grant in INR : 1.7L, Duration : 01.07.2018 - 01.07.2019 ]"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sibi-chakkaravarthy-sethuraman-7aba651a/",
      "website": "https://sibichakkaravarthy.github.io",
      "dblp": "https://dblp.org/pid/177/1951.html",
      "researchGate": "https://www.researchgate.net/profile/Sibi-Chakkaravarthy",
      "googleScholar": "https://scholar.google.co.in/citations?user=8pKeh40AAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0001-7778-0453",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55753988500"
    }
  },
  {
    "id": "vitap-1171-cms",
    "name": "Dr. Sunny Dayal Vanambathina",
    "employeeId": "8.7009",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "214, AB-1",
    "email": "sunny.dayal@vitap.ac.in",
    "phone": "5462",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sunny_Dayal_Vanambathina_70090_IMG_4949_SENSE_1fe3b7b635.avif",
    "education": [
      "B.Tech & Vignan's Engineering college, Vadlamudi",
      "M.Tech & NIT Calicut, Kerala",
      "PhD & NIT Warangal, Telangana",
      "Post-Doc & University of Crete, Greece"
    ],
    "researchArea": "Speech Enhancement, Machine learning, Blind source separation",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=z3cnvNcAAAAJ&hl=en",
      "scopus": "55847917900"
    }
  },
  {
    "id": "vitap-1195-cms",
    "name": "Dr. Manikanta Ravindra Kumar Vakkalagadda",
    "employeeId": "8.70092",
    "designation": "Professor Grade 1",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "401, CB",
    "email": "ravindra.v@vitap.ac.in",
    "phone": "5145",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Manikanta_Ravindra_Kumar_Vakkalagadda_70092_IMG_4889_SMEC_279f4bf081.avif",
    "education": [
      "B.Tech, Acharya Nagarjuna University",
      "M.Tech, IIT Kharagpur",
      "PhD, IIT Kharagpur"
    ],
    "researchArea": "(i) Manufacturing Science, (ii) Metal forming, (iii) Numerical modelling of Manufacturing Processes, (iv) Railway Engineering, (v) 4D printing",
    "memberships": [
      "SAEINDIA - Membership (7180410533)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=9MBgbBEAAAAJ&hl=en",
      "orcid": "0000-0001-6857-2804",
      "scopus": "56512316800"
    }
  },
  {
    "id": "vitap-1394-cms",
    "name": "Dr. Selvakumar Karuthapandi",
    "employeeId": "8.70119",
    "designation": "Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "125-G, AB-2",
    "email": "selvakumar.k@vitap.ac.in",
    "phone": "5696",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Selvakumar_Karuthapandi_70119_IMG_2567_SAS_CHY_024bf2f855.avif",
    "education": [
      "Vivekananda College - Madurai Kamaraj Univesrity",
      "The American College - Madurai Kamaraj Univesrity",
      "IIT Bombay",
      "Weizmann Institute of Science - Israel"
    ],
    "researchArea": "Organometallic Chemistry",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "DST Inspire Faculty Award"
    ],
    "links": {
      "linkedin": "https://il.linkedin.com/in/selvakumar-karuthapandi-86b3029b",
      "researchGate": "https://www.researchgate.net/profile/Selvakumar-Karuthapandi-2",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=T14nxKUAAAAJ"
    }
  },
  {
    "id": "vitap-1166-cms",
    "name": "Dr. Ganesh Reddy Karri",
    "employeeId": "8.7014",
    "designation": "Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "221, CB",
    "email": "ganesh.reddy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ganesh_Reddy_Karri_70140_IMG_4952_SCOPE_3e82aa165c.avif",
    "education": [
      "Information Technology(IT), Andhra University",
      "Information Security - Computer Science and Engineering, NIT Rourkela",
      "Computer Science and Engineering, NITK Surathkal"
    ],
    "researchArea": "Wireless Security, Cyber Security, Cloud Computing, Computer Networks, Machine Learning",
    "memberships": [
      "The Institution of Engineers(IEI), IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-k-ganesh-reddy-0109292b/?originalSubdomain=in",
      "researchGate": "https://www.researchgate.net/profile/K-Reddy-8",
      "googleScholar": "https://scholar.google.com/citations?user=l7zD_wIAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-5177-8125",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55180580900"
    }
  },
  {
    "id": "vitap-1201-cms",
    "name": "Dr. Suyog Jhavar",
    "employeeId": "8.70386",
    "designation": "Professor Grade 1",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "313-F, AB-1",
    "email": "suyog.jhavar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Suyog_Jhavar_SMEC_1890_ffeed0473e.avif",
    "education": [
      "RGPV, Bhopal",
      "Indian Institute of Technology Roorkee",
      "Indian Institute of Technology Indore",
      "University of Texas-USA"
    ],
    "researchArea": "Metal Additive Manufacturing, Welding Engineering, Automation, Industry 4.0, Digital Manufacturing",
    "memberships": [
      "Indian Institute of Metals"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/suyog-jhavar-79887325b/",
      "dblp": "E-4873-2016",
      "googleScholar": "53wrbeYAAAAJ",
      "orcid": "0000-0003-4472-4839",
      "scopus": "55873065800"
    }
  },
  {
    "id": "vitap-1356-cms",
    "name": "Dr. Anupriya Elumalai",
    "employeeId": "8.70545",
    "designation": "Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "312, CB",
    "email": "anupriya.e@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Anupriya_Elumalai_IMG_6631_SCOPE_c743348009.avif",
    "education": [
      "B.E.(CSE), VEC Vellore",
      "M.Tech.(CSE), VIT Vellore",
      "PhD(CSE), VIT Vellore"
    ],
    "researchArea": "Data Mining, Machine Learning, Information Retrieval",
    "memberships": [
      "ACM, CSI, ISTE, IAENgg"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-anupriya-krishanmurthy-16b1519a/",
      "googleScholar": "https://scholar.google.co.in/citations?hl=en&user=lrv1958AAAAJ",
      "orcid": "https://orcid.org/0000-0002-5328-732X",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57211610721, https://www.scopus.com/authid/detail.uri?authorId=56823468800"
    }
  },
  {
    "id": "vitap-1498-cms",
    "name": "Dr. Ravi Kumar Bandaru",
    "employeeId": "8.70604",
    "designation": "Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "124-C, AB-2",
    "email": "ravikumar.bandaru@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ravi_Kumar_Bandaru_70604_IMG_2623_SAS_MAT_112b3d5a7e.avif",
    "education": [
      "B.Sc (Maths, Physics, Chemistry), Acharya Nagarjuna University",
      "M.Sc Mathematics, Andhra University",
      "Ph.D, Andhra University"
    ],
    "researchArea": "Algebra-Lattice Theory, BCK-algebras and Other algebraic Structures",
    "memberships": [
      "ISCA(The Indian Science Congress Association), APTSMS"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ravi-kumar-bandaru-17b42636/",
      "researchGate": "https://www.researchgate.net/profile/Ravi-Kumar-Bandaru",
      "googleScholar": "https://scholar.google.com/citations?user=t2s1uX8AAAAJ",
      "orcid": "0000-0001-8661-7914",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55035359900",
      "vidwan": "435606"
    }
  },
  {
    "id": "vitap-1441-cms",
    "name": "Dr. Suresh Dara",
    "employeeId": "8.70628",
    "designation": "Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "618 - L, CB",
    "email": "suresh.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70628_Dr_Suresh_Dara_SCOPE_1255_0087af24fc.avif",
    "education": [
      "M.Sc in Computer Science, Andhra University",
      "M.Tech in CST, Andhra University",
      "Ph.D. in Computer Science and Engineering, IIT(ISM) Dhanbad"
    ],
    "researchArea": "AI, ML, Evolutionary Computation, Bioinformatics, Industrial IOT, NLP",
    "memberships": [
      "ISTE"
    ],
    "projects": [],
    "patents": [
      "1. Suresh Dara and Srikanth Jannu, “An IoT Based System to Identify and Classify Chest Computer Tomography Images”, Application number: 202241066030, Date of filling: 17/11/2022, Published on: 16/12/2022.",
      "2. Sreenivasa Rao Veeranki, Suresh Dara and Jyothi V K, “A Machine Learning Method For Medical Data Mining And Risk Prediction Using Big Data”, Application number: 202241071001, Date of filling: 09/12/2022, Published on: 16/12/2022."
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/suresh-dara-b21a63148/",
      "dblp": "https://dblp.org/pid/119/7535.html",
      "researchGate": "https://www.researchgate.net/profile/Suresh-Dara",
      "googleScholar": "https://scholar.google.co.in/citations?user=ldzq6M8AAAAJ&hl=en&authuser=1&oi=ao",
      "orcid": "0000-0002-1626-8701",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55488567900",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/170042"
    }
  },
  {
    "id": "vitap-1692-cms",
    "name": "Dr. Tarun Narayan Shankar",
    "employeeId": "8.70829",
    "designation": "Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "706 - C, CB",
    "email": "tarun.shankar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_TARUN_NARAYAN_SHANKAR_SCOPE_04d4a256db.avif",
    "education": [
      "Utkal University, Bhubaneswar, Odisha",
      "Birla Institute of Technology, Mesra, Ranchi",
      "Birla Institute of Technology, Mesra, Ranchi"
    ],
    "researchArea": "Information Security",
    "memberships": [
      "IEEE, ISTE, IAENG"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/t-n-shankar-56843a82/",
      "googleScholar": "https://scholar.google.com/citations?user=7BJoNVcAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56251908600"
    }
  },
  {
    "id": "vitap-1743-cms",
    "name": "Dr. Mithilesh Kumar Dubey",
    "employeeId": "8.70878",
    "designation": "Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "706 - F, CB",
    "email": "mithileshkumar.dubey@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_MITHILESH_KUMAR_DUBEY_SCOPE_39b73a8ea4.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1751-cms",
    "name": "Dr. Kiran Kumar Nallamekala",
    "employeeId": "8.70886",
    "designation": "Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "817 - E, CB",
    "email": "kirankumar.n@vitap.ac.in",
    "phone": "9441276970",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kiran_Kumar_Nallamekala_SENSE_995b2f0137.avif",
    "education": [
      "B Tech / JNTU Hyderabad",
      "M Tech / NIT Rourkela",
      "PHD/ IIT Hyderabad"
    ],
    "researchArea": "Power electronics and Electrical drives",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1752-cms",
    "name": "Dr. K Uma Mahendra Kumar",
    "employeeId": "8.70887",
    "designation": "Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "207-A, AB2",
    "email": "umamahendra.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_K_Uma_Mahendra_Kumar_SASPHY_c9361883e0.avif",
    "education": [
      "B Sc , Andhra University-Vishakapatnam",
      "M Sc- Physics, Sri Venkateswara University-Tirupati",
      "PhD Univ of Hyderabad-India and Univ of Trento-Italy",
      "University of Georgia-USA"
    ],
    "researchArea": "Computational Materials Science; Magnetism and Magnetic Materials; Density Functional Theory (DFT); Spintronics; Functional Thin Films and Coatings",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. 202441067434 - Alloy of improved magnetocaloric effect for magnetic refrigeration applications, Granted.",
      "2. 202541105092 - Semi-hard magnetic alloy for power-efficient actuators in spacecraft propulsion valves, Published.",
      "3. 202541061792- A Mn-Ni intermetallic alloys for spintronic and its thermomagnetic applications, Published.",
      "4. 202541061818 - Arc-melted Fe-Al alloys (25-30 at % Al) for stator applications, Published."
    ],
    "awards": [
      "Bose-Romagnosi Fellowship-DST-ITPAR."
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&authuser=1&user=cveViJgAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=24461721800",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/98668"
    }
  },
  {
    "id": "vitap-1809-cms",
    "name": "Dr. Marriboyina Sreedevi",
    "employeeId": "8.70951",
    "designation": "Professor Grade1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "706-H, CB",
    "email": "sreedevi.marriboyina@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Marriboyina_Sreedevi_SCOPE_41e451cb11.avif",
    "education": [
      "B.Sci (Computer Science) & Acharya Nagarjuna University",
      "Masters in Computer Science and Applications & Acharya Nagarjuna University",
      "P.hD (Computer Science and Engineering) & Acharya Nagarjuna University"
    ],
    "researchArea": "Deep Learning, Data Science, AI and ML, Data Mining",
    "memberships": [
      "1.LMCSI–00174442 (life membership for Computer Society of India) • LMISCA-L22930 (life membership for Indian Science Congress Association)"
    ],
    "projects": [
      "Rural Women Technology Park at, Tadepalli Mandal, Guntur District",
      "Aicte Idea (Idea Dvelopment, Evaluation and Application) Lab"
    ],
    "patents": [
      "1. Application No:202641084101A , System and Method for product life cycle Evaluation based on Usage- Normalized and Utility- Weighted processing published by Indian patent office on 04/06/2026.",
      "2.Application No:504596-001, Voice Controlled AI Assistant Robot- AWARDED by Indian patent office on 04/06/2026.",
      "3.Application No: 202541081890 :“Pizza Peeler Apparatus with Deployable Stand for Enhanced Surface Stability”, published by Indian patent office on 6/09/2025.",
      "4.Application No. 202041026263 :“A system and method for real time prediction of Biomedical and wearable patient diagnostic diseases” published by Indian patent office on 22/06/2020.",
      "5.Application No: 201941047401 “Computer implemented method and system for mining popular patterns” published by Indian patent office on 29/11/2019.",
      "6.Application No: 201841028150 “Multi level system and method for analyzing opinions related to assets posted on social media networking websites” filed by Indian patent office on 26/7/2018.",
      "7. Application No: 201741039232 A “System and method employed for mining regular frequent item sets” published by Indian Patent office on 3/11/2017.",
      "8.Application/Design Number: 315663-001Patent was granted/awarded for the design of wooden tulip Bud on 13/03/2019 by Indian patent office.",
      "9.Application/Design Number: 315661-001Patent was granted/awarded for the design of wooden Bird Toyon13/08/2019 by Indian patent office."
    ],
    "awards": [
      "Best Teaching Faculty Award in the department of CSE for the Academic year 2022-2023, Amrita Sai Institute of Science and Technology.",
      "Sponsored project implementation graded as excellent from Department of Science and Technology, New Delhi, India.",
      "Best Teacher award for the year 2009-2010 in Department of CSE, K L University.",
      "Active participation woman award from Computer Society of India (CSI), India for the year 2012-2013."
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?pli=1&authuser=1&user=-D5fJAAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56582077000",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/576334"
    }
  },
  {
    "id": "vitap-1307-cms",
    "name": "Dr. Phani Kumar M",
    "employeeId": "9.70022",
    "designation": "Associate Professor Senior",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G23-C, AB-2",
    "email": "phani.m@vitap.ac.in",
    "phone": "5568",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Phani_Kumar_M_SAS_MAT_1933_df8cb65bb4.avif",
    "education": [
      "B. Sc., Kakatiya University",
      "M. Sc., Kakatiya University",
      "PhD, National Institute Of Technology, Warangal."
    ],
    "researchArea": "Fluid Dynamics",
    "memberships": [
      "ISTAM"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "orcid": "https://orcid.org/0000-0001-5234-8170",
      "scopus": "57211647666",
      "vidwan": "302385"
    }
  },
  {
    "id": "vitap-1138-cms",
    "name": "Dr. E. Ajith Jubilson",
    "employeeId": "9.70029",
    "designation": "Associate Professor Senior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "816-H, CB",
    "email": "ajith.jubilson@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_E_Ajith_Jubilson_SCOPE_1956_20273c1217.avif",
    "education": [
      "B.Tech, Pondicherry University",
      "M.Tech, Pondicherry University",
      "CSE, VIT-AP"
    ],
    "researchArea": "Artificial Intelligence, Software agents, Web security, Software Engineering",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1141-cms",
    "name": "Dr. Deepasikha Mishra",
    "employeeId": "9.70034",
    "designation": "Associate Professor Senior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "326-G, AB-1",
    "email": "deepasikha.mishra@vitap.ac.in",
    "phone": "5170",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Deepasikha_Mishra_SCOPE_IMG_2165_1a6c21eb30.avif",
    "education": [
      "B.Sc Computer Science, Sambalpur University",
      "MSC,ME Computer Science, Utkal University",
      "Computer Science, NIT,Rourkela"
    ],
    "researchArea": "Image Processing, Machine Learning, Pattern Recognition, Deep Learning, Knowledge Engineering, Data Analytics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "orcid": "http://www.orcid.org/0000-0001-6115-8192",
      "scopus": "http://www.scopus.com/authid/detail.url?authorId=56537745600"
    }
  },
  {
    "id": "vitap-1144-cms",
    "name": "Dr. Hari Kishan Kondaveeti",
    "employeeId": "9.70071",
    "designation": "Associate Professor Senior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "816 - E, CB",
    "email": "kishan.kondaveeti@vitap.ac.in",
    "phone": "5341",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Hari_Kishan_Kondaveeti_70071_0222_ce0e2c7f25.avif",
    "education": [
      "B.Tech, Acharya Nagarjuna University, Andhra Pradesh",
      "M.Tech, JNTU-K, Andhra Pradesh",
      "CSE, Andhra University"
    ],
    "researchArea": "Image Processing, Machine Learning, Deep Learning, Data Analytics",
    "memberships": [
      "\"Indian Society for Technical Education (ISTE), India, Soft Computing Research Society (SCRS), India, Computer Society of India (CSI), India, Indian Unit for Pattern Recognition and Artificial Intelligence (IUPRAI), India\""
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "dblp": "https://dblp.org/pid/280/2373.html",
      "researchGate": "https://www.researchgate.net/profile/Hari-Kondaveeti",
      "googleScholar": "https://scholar.google.com/citations?user=6nk7Kz4AAAAJ&hl=en&authuser=1",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0002-3379-720X",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57192006472"
    }
  },
  {
    "id": "vitap-1173-cms",
    "name": "Dr. Samineni Peddakrishna",
    "employeeId": "9.70105",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "132, AB-1",
    "email": "samineni.peddakrishna@vitap.ac.in",
    "phone": "5464",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Samineni_Peddakrishna_SENSE_0863_2ee5d71685.avif",
    "education": [
      "BTech (ECE) & JNTU Hyderabad",
      "MTech (Embedded Systems) & JNTU Hyderabad",
      "PhD & NIT Silchar"
    ],
    "researchArea": "AI for Embedded Systems, Advanced Embedded Controllers, Embedded Linux and Device Drivers, and Antenna Designs",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Samineni-Peddakrishna/research",
      "googleScholar": "shorturl.at/gnIM1",
      "orcid": "0000-0002-5925-8124",
      "scopus": "57194064543"
    }
  },
  {
    "id": "vitap-1151-cms",
    "name": "Dr. S. Gopikrishnan",
    "employeeId": "9.70107",
    "designation": "Associate Professor Senior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "816 - K, CB",
    "email": "gopikrishnan.s@vitap.ac.in",
    "phone": "5356",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_S_Gopikrishnan_70107_0214_0692d6708b.avif",
    "education": [
      "B.E. - Computer Science and Engnieering, Anna University",
      "M.E. - Computer Science and Engineering, Anna University",
      "Ph.D., & Anna University"
    ],
    "researchArea": "Routing Protocol design for Wireless Networks, Wireless Sensor Networks, Internet of Things, Cryptography, Cyber Security, Blockchain, Machine Learning for IoT and Cyber-Physical System.",
    "memberships": [
      "IEEE, ACM, CSI, IETE, IET, IE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/s-gopikrishnan-2973194a/",
      "dblp": "https://dblp.org/pid/177/5758-1",
      "researchGate": "https://www.researchgate.net/profile/Gopikrishnan-S?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=V8Bj9scAAAAJ&hl=en&authuser=4",
      "orcid": "http://orcid.org/0000-0001-9082-9012",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57021924700",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/213560"
    }
  },
  {
    "id": "vitap-1180-cms",
    "name": "Dr. Rohit Lorenzo",
    "employeeId": "9.70161",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "158, AB-1",
    "email": "rohit.lorenzo@vitap.ac.in",
    "phone": "5158",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rohit_Lorenzo_SENSE_0754_5d7bfbd14c.avif",
    "education": [
      "UPTU Lucknow",
      "Karunya University, Coimbatore (TN)",
      "Post Doctoral Fellow, IIT Guwahati and Ph.D, NIT Silchar",
      "IIT Guwahati"
    ],
    "researchArea": "Low Power VLSI Design, CMOS VLSI Design and Memory Design",
    "memberships": [
      "Senior Member IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=v0IG_e0AAAAJ&hl=en",
      "orcid": "0000-0003-2044-5798"
    }
  },
  {
    "id": "vitap-1190-cms",
    "name": "Dr. Bappadittya Roy",
    "employeeId": "9.70163",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "313-E, AB-1",
    "email": "bappadittya.roy@vitap.ac.in",
    "phone": "5328",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bappadittya_Roy_SENSE_1454_d58699f748.avif",
    "education": [
      "BTech WBUT",
      "MTech WBUT",
      "PhD, NIT Durgapur"
    ],
    "researchArea": "Wireless communication, Characterization of Dielectric Material, Microstrip Antenna, Microwave & Millimeter-wave communications",
    "memberships": [
      "Senior Member IEEE"
    ],
    "projects": [],
    "patents": [
      "1. Smart Wind-Energy System For Monitoring And Operating Electric Devices Of Railway Compartment And,Method There of, Patent Grant Number-576007, Date of Grant-17/12/2025",
      "2. System And Method For Improving Soil Health, Patent Grant Number-579985, Date of Grant-05/02/2026",
      "3. A Method For Constructing A Multi- Band Microstrip Patch Antenna By Varying Substrates And Feeding Points, Patent Grant Number - 585728, Date of Grant - 30/03/2026"
    ],
    "awards": [],
    "links": {
      "researchGate": "56104031300",
      "googleScholar": "https://scholar.google.co.in/citations?user=zWzFaLYAAAAJ&hl=en",
      "orcid": "0000-0002-5348-7348"
    }
  },
  {
    "id": "vitap-1196-cms",
    "name": "Dr. Lakhan Dev Sharma",
    "employeeId": "9.70178",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "154, AB-1",
    "email": "lakhan.sharma@vitap.ac.in",
    "phone": "5154",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Lakhan_Dev_Sharma_70178_IMG_2656_SENSE_1919fa1977.avif",
    "education": [
      "B. E.from Rajiv Gandhi Proudyogiki Vishwavidyalaya, Bhopal",
      "M. Tech from ABV-Indian Institute of Information Technology and Management, Gwalior",
      "Ph.D. from Dr. B. R. Ambedkar National Institute of Technology, Jalandhar"
    ],
    "researchArea": "Signal Processing, Image Processing, Machine Learning, Deep Learning, Optimization Techniques",
    "memberships": [
      "Senior Member IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "website": "https://sites.google.com/view/dr-lakhan/home",
      "researchGate": "https://www.researchgate.net/profile/Lakhan-Sharma-4",
      "googleScholar": "https://scholar.google.com/citations?user=oZPkMREAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-5389-3928",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57188567436"
    }
  },
  {
    "id": "vitap-1197-cms",
    "name": "Dr. Rajeev Sharma",
    "employeeId": "9.70179",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "310-E, AB-1",
    "email": "rajeev.sharma@vitap.ac.in",
    "phone": "5706",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rajeev_Sharma_70179_IMG_4915_SENSE_55132c6c58.avif",
    "education": [
      "B.E., Rajiv Gandhi Proudyogiki Vishwavidyalaya, Bhopal, India",
      "M.Tech., National Institute of Technology Warangal, India",
      "PhD, Indian Institute of Technology Indore, India"
    ],
    "researchArea": "Biomedical Signal Analysis,Deep Learning, Signal Processing",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Rajeev-Sharma-4",
      "googleScholar": "https://scholar.google.co.in/citations?user=xdjI1-wAAAAJ&hl=en",
      "orcid": "0000-0003-0030-7021",
      "scopus": "57196545490"
    }
  },
  {
    "id": "vitap-1216-cms",
    "name": "Dr. Arindam Dey",
    "employeeId": "9.70369",
    "designation": "Associate Professor Senior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "103-B, CB",
    "email": "arindam.dey@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Arindam_Dey_SCOPE_1888_bae846c255.avif",
    "education": [
      "B.Tech (Maulana Abul Kalam Azad University of Technology)",
      "M. Tech (NIT Durgapur)",
      "PhD (NIT Durgapur)"
    ],
    "researchArea": "Soft Computing, Graph Theory and Optimization Problem",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Arindam-Dey-6",
      "googleScholar": "https://scholar.google.co.in/citations?user=sA4lzdIAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201837722"
    }
  },
  {
    "id": "vitap-1215-cms",
    "name": "Dr. Bolem Sai Chandana",
    "employeeId": "9.70371",
    "designation": "Associate Professor Senior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "812 - M, CB",
    "email": "saichandana.bolem@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bolem_Sai_Chandana_70371_IMG_4755_SCOPE_66b24c6af9.avif",
    "education": [
      "B.Tech- Jawaharlal Nehru Technological University Hyderabad(JNTUH)",
      "M.Tech- Andhra University (AU), Viskhapatnam",
      "Ph.D. -Jawaharlal Nehru Technological University(JNTUK), kakinada"
    ],
    "researchArea": "Image Processing, Hyperspectral Image Analysis",
    "memberships": [
      "Life member CSI, Life Member IETE, Life Member ISTE, MIE"
    ],
    "projects": [
      "1. “Evolutionary Algorithms for Classification of Remote Sensing Images”, File No.1-15/2015-012 Computer Society of India [CSI] R&D Project.",
      "2. “Human Activity Recognition for Abnormal Event Detection in Enhancing Security of Automated Teller Machines using Machine Learning Techniques”, File No: R.4/2/UG/2018- 19/RDUG2018036 The Institution of Engineers (IEI) R & D Project.",
      "3. “Data Mining Lab” Virtual lab development from IIT Roorkee.- Consultancy Work .",
      "4. “Human Detection and Motion Analysis from an Unmanned Arial Vehicle using Machine Learning Techniques”, File No: 4/2/UG/2020-21/UG2021003, The Institution of Engineers (IEI) R & D Project.",
      "5. “Development of a Security System using Thermal face Bio-metrics” RGEMS (Research Grant in Engineering Management and Science) grant from VIT-AP University, Rs.1.76,106.",
      "6. “Computer Aided Diagnosis (CAD) System for Ovarian Classification” Consultancy work from Sreyas Hospital and IVF center , Rs.59000 ,"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/sai-chandana-bolem-1b58142a3",
      "googleScholar": "https://scholar.google.co.in/citations?user=wIdol58AAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57221044132",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/197996"
    }
  },
  {
    "id": "vitap-1260-cms",
    "name": "Dr. M. Sucharitha",
    "employeeId": "9.70435",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "108, AB-1",
    "email": "sucharitha.jackson@vitap.ac.in",
    "phone": "5854",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_M_Sucharitha_SENSE_1894_a69e38a8ec.avif",
    "education": [
      "B.E(ECE) & Manonmaniam Sundaranar University,Tirunelveli",
      "M.E(Communication System) & Madurai Kamaraj University,Madurai",
      "Ph.D(Image Processing) & Anna University, Chennai"
    ],
    "researchArea": "Digital Image Processing, Neural Networks, Machine Learning, Deep Learning, Internet of Things",
    "memberships": [
      "IETE,ISTE,IAENG,IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/M-Sucharitha-2",
      "googleScholar": "https://scholar.google.co.in/citations?user=f5TwY8EAAAAJ",
      "orcid": "https://orcid.org/0000-0002-2744-4117",
      "scopus": "56755283400"
    }
  },
  {
    "id": "vitap-1262-cms",
    "name": "Dr. Neeraj Kumar Misra",
    "employeeId": "9.70442",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "163, AB-1",
    "email": "neeraj.misra@vitap.ac.in",
    "phone": "5862",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70442_Dr_Neeraj_Kumar_Misra_SENSE_1152_9af51d0886.avif",
    "education": [
      "B.Tech in ECE, Integral University Lucknow",
      "M.Tech in ECE, from Amity University Lucknow",
      "Ph.D (Under TEQIP-II) in Electronics Engineering, from Dr. A.P.J. Abdul Kalam Technical (AKTU) University Lucknow"
    ],
    "researchArea": "Reversible and Quantum Computing, Beyond CMOS computing with an emphasis on QCA technology, Low Power VLSI Design, Magnetic and Nano-computing Circuits based on FinFET, Design for Testability and Fault-Tolerant digital design",
    "memberships": [
      "1. Senior IEEE Member, Membership number : 92318696 2. Member International Society for Technical Education (ISTE), Membership number : LM 125080 3. Member, The Institution Of Electronics And Telecommunication Engineers (IETE), Membership number : M-502202"
    ],
    "projects": [
      "1. Role: Coordinator, AICTE-MODERNISATTION AND REMOVAL OF OBSOLENSCENCE (MODROBS)–FY: 2018-19, Title: VLSI Laboratory Development, Status: Submitted the Audit Utilization Certificate",
      "2. Role: Coordinator, AICTE-ISTE INDUCTION/REFRESHER PROGRAMMES–FY: 2021-22: Title: National Workshop on Pedagogy Innovative Methods of Teaching and Learning, Status: Submitted the Audit Utilization Certificate"
    ],
    "patents": [
      "Neeraj Kumar Misra, et. al., “VOWIFI CELL CAPACITY EVALUATION USING IEEE 802.11AX FOR VBR TRAFFIC.”, 202131062314, Indian Patent, 22nd February, 2024, Status: Granted",
      "B.Anil Kumar, Neeraj Kumar Misra, “A Hybrid Model For Detection And Classification Of imaging Related Diseases For A Subject”, 202441057003, Indian Patent, Published date : 02nd August, 2024, Status: Published",
      "B.Anil Kumar, Neeraj Kumar Misra, “A System And Method Enabling Identification Of Userinformation Associated With Users Wearing Face Mask”, 202441057541, Indian Patent, Published date : 02nd August, 2024, Status: Published",
      "Neeraj Kumar Misra, et. al., “QCIU- Education Environment System: Quantum Computing Integrated Development Education Environment Using IoT-Based System”, 2020103849, Australian International Patent AU, 27th January, 2021, Status: Granted",
      "Neeraj Kumar Misra, et. al., “LSM- Quantum Computing: LARGE DATABASES STORE INTO A VERY SMALL MEMORY USING QUANTUM COMPUTING AND AI-BASED PROGRAMMING”, 2020102068, Australian International Patent AU, 30th September, 2020, Status: Granted"
    ],
    "awards": [
      "Best Paper award on the paper titled “Design and analysis CMOS based DRAM cell structures for High Performance Embedded System” on 2nd International Conference on Micro/Nanoelectronics Devices, Circuits, and Systems (MNDCS-2022) at National Institute of Technology (NIT), Silchar, Assam, India, 2022"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-neeraj-kumar-misra-a4385514/",
      "dblp": "https://dblp.org/pid/168/8285.html",
      "researchGate": "https://www.researchgate.net/profile/Neeraj-Kumar-Misra?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.co.in/citations?user=_V5Af5kAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-7907-0276",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56405207500",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/196862"
    }
  },
  {
    "id": "vitap-1258-cms",
    "name": "Dr. Ashish Gupta",
    "employeeId": "9.70443",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "328-H, AB-1",
    "email": "ashish.gupta@vitap.ac.in",
    "phone": "5867",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ashish_Gupta_70443_IMG_2583_SENSE_600184ab15.avif",
    "education": [
      "B.Tech, UIET Kanpur",
      "M.Tech, MNNIT Allahabad",
      "Ph.D, IIT ROPAR"
    ],
    "researchArea": "Digital Signal Processing; Digital Image Processing",
    "memberships": [
      "IEEE Senior Member"
    ],
    "projects": [],
    "patents": [
      "A wireless robot system for surveillance and exploration purposes and thereof. (Application No.:202441002221) (Published)"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/ashish-gupta-77a4b824/",
      "researchGate": "https://www.researchgate.net/profile/Ashish-Gupta-72?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.co.in/citations?user=tN8ua10AAAAJ&hl=en",
      "orcid": "0000-0002-2946-7849",
      "scopus": "https://www.scopus.com/authid/detail.url?authorId=57201960161",
      "vidwan": "https://vitap.irins.org/profile/126192"
    }
  },
  {
    "id": "vitap-1412-cms",
    "name": "Dr. Virendra Kumar Verma",
    "employeeId": "9.70445",
    "designation": "Associate Professor Senior",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "622 - P, CB",
    "email": "virendra.verma@vitap.ac.in",
    "phone": "5869",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Virendra_Kumar_Verma_SAS_1443_afdea6163d.avif",
    "education": [
      "B.Sc. - University of Allahabad, Allahabad",
      "M.Sc. - University of Allahabad, Allahabad, M.Tech. - IIT Kanpur",
      "Ph.D. - University of Tokyo, Japan",
      "Post Doc. - National Synchrotron Radiation Research Center (NSRRC), Taiwan"
    ],
    "researchArea": "Dilute Magnetic Semiconductors, Multiferroic Materials, Magnetic Materials, X-ray Magnetic Circular Dichroism (XMCD), Solar Cells",
    "memberships": [
      "1. Materials Research Society of India (MRSI) _ Membership No. LMB 3553, 2. International Association of Engineers (IAENG) _ Membership Number: 178775"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "2019 - SELECTED BY DST INDIA TO CARRY OUT EXPERIMENT AT INTERNATIONAL SYNCHROTRON RADIATION CENTRE, JAPAN. (EVERY YEAR, MAXIMUM OF 40 SCIENTISTS ARE PERMITTED BY DST INDIA & JNCASR) 2018 - BEST TEACHER AWARD by Madanapalle Institute of Technology & Science, Madanapalle 2018 - RESOURCE PERSON IN WORK SHOP, Department of Physics, Can Tho University, Vietnam 2016 - BEST TEACHER AWARD by Madanapalle Institute of Technology & Science, Madanapalle 2009 - MONBUKAGAKUSHO FELLOWSHIP, Ministry of Education, Culture, Sports, Science and Technology, Govt. of Japan 2008 - ELECTED AS A SECRETARY, MESS STORE AND SUPPLY IIT Kanpur 2007 - GRADUATE APTITUDE TEST OF ENGINEERING (GATE)-2007, MHRD, Government of India, ALL INDIA RANK-80 MHRD, Government of India"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/virendra-kumar-verma-97314616b?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app",
      "researchGate": "https://www.researchgate.net/profile/Virendra-Kumar-Verma",
      "googleScholar": "WhzLGeYAAAAJ",
      "orcid": "0000-0003-3162-8477",
      "scopus": "35119707100",
      "vidwan": "244356"
    }
  },
  {
    "id": "vitap-1219-cms",
    "name": "Dr. M Azees",
    "employeeId": "9.70448",
    "designation": "Associate Professor Senior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "204-F, CB",
    "email": "azees.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/56_Azees_500e9acb51.avif",
    "education": [
      "B.E, Anna University",
      "M.E, Anna University",
      "Information Security in VANETs, Anna University"
    ],
    "researchArea": "Information Security, Blockchain Technology, Security in VANETs, Machine Learning, Body Area Networks.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/azees-m-0b99467a/",
      "dblp": "https://dblp.org/pid/175/7042.html",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=bbpaXeIAAAAJ&view_op=list_works&sortby=pubdate",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0002-5297-1269",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55823331700"
    }
  },
  {
    "id": "vitap-1324-cms",
    "name": "Dr. Surendra Reddy Vinta",
    "employeeId": "9.70482",
    "designation": "Associate Professor Senior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "620-N, CB",
    "email": "surendrareddy.vinta@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Surendra_Reddy_Vinta_70482_IMG_4959_SCOPE_eb2c252a93.avif",
    "education": [
      "Information Technology, Madras University",
      "CSE, AN university",
      "Image Processing, VBSP University"
    ],
    "researchArea": "Artificial Intelligence, Machine Learning, Deep Learning, Data Analytics, Healthcare, Data Structures",
    "memberships": [
      "ISTE, IE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "http://scholar.google.co.in/citations?user=6Os6-z0AAAAJ",
      "orcid": "http://www.orcid.org/0000-0002-5882-733X",
      "scopus": "http://www.scopus.com/authid/detail.url?authorId=57211335628"
    }
  },
  {
    "id": "vitap-1295-cms",
    "name": "Dr. K N V P S Rajesh",
    "employeeId": "9.70498",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "141, AB-1",
    "email": "rajesh.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_K_N_V_P_S_Rajesh_SENSE_1883_cdc7678127.avif",
    "education": [
      "B. Tech, JNTU Kakinada",
      "M. Tech, JNTU Kakinada",
      "PhD, Vellore Institute of Technology, Vellore"
    ],
    "researchArea": "Biomedical Signal Processing, Biomedical Image Processing, Digital Signal Processing, Machine Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "dblp": "https://dblp.uni-trier.de/pid/204/0794",
      "researchGate": "https://www.researchgate.net/profile/Rajesh-Kandala",
      "googleScholar": "https://dblp.uni-trier.de/pid/204/0794",
      "orcid": "0000-0003-3751-0453",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57194554934"
    }
  },
  {
    "id": "vitap-1484-cms",
    "name": "Dr. Shaiku Shahida Saheb",
    "employeeId": "9.70588",
    "designation": "Associate Professor Senior",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "425-E, AB-1",
    "email": "shahid.sk@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shaiku_Shahida_Saheb_74dba30f8b.avif",
    "education": [
      "B.Com( Accounting from Acharya Nagarjuna University in 1995",
      "M.Com (Accounting ) From Acharya Nagarjuna Universit in 1997, MBA (Finance) from Acharya Nagarjuna Universiry in 2004 and M.Phil (Finance) from Sri Venkateswara University in 2010",
      "Ph.D from Ranchi University in 2013"
    ],
    "researchArea": "Financial Accounting, Accounting Information Systems, Financial Management, Cost and Management Accounting, Financial Reporting, Auditing, Corporate Governance and Research Methods.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-shaiku-shahida-saheb-ba143350/",
      "researchGate": "https://www.researchgate.net/profile/Shaiku-Saheb",
      "googleScholar": "https://scholar.google.com/citations?user=qPRxl0YAAAAJ&hl=en",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0001-6406-3746",
      "scopus": "58575382800"
    }
  },
  {
    "id": "vitap-1507-cms",
    "name": "Dr. D. Kothandaraman",
    "employeeId": "9.70647",
    "designation": "Associate Professor Senior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "706 - G, CB",
    "email": "kothandaraman.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70647_Dr_D_Kothandaraman_SCOPE_1220_cf0f61fafa.avif",
    "education": [
      "B.E(CSE) and Anna University Chennai",
      "M.Tech (Information Security) and Pondicherry Central University",
      "Ph.D(CSE) and CEG Campus Anna University Chennai"
    ],
    "researchArea": "ML, DL and Data Mining",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. Method Of Securing NGIoT Infrastructure & 202141014466",
      "2. System And Method For Secure Irrigation & 202041036457",
      "3. Foot Slip Prevention System And Method & 202141057816",
      "4. Automatic Hand Sanitization System And Method Thereof & 202241011138",
      "5. Localization Method Using Integrated Sensors In Autonomous Scrubbing Robots For Industrial Cleaning & 2021101252"
    ],
    "awards": [
      "Best Researcher Award, International Scientist on Engineering, Science and Medicine, VDGOOD® Professional Association & 31-Jan-2023",
      "Second RunnerUp in National Level AIHackathon TATA MOTORS PVT, Pune & SEP-2019"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-kothandaraman-d-5ba1144a",
      "googleScholar": "https://scholar.google.co.in/citations?user=dtjQxtwAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0003-1085-0108",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55090218000"
    }
  },
  {
    "id": "vitap-1527-cms",
    "name": "Dr. Bandaru Ramakrishna",
    "employeeId": "9.7066",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "143, AB-1",
    "email": "ramakrishna.bandaru@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bandaru_Ramakrishna_7066_IMG_2672_SENSE_9cc39c3a52.avif",
    "education": [
      "B.Tech, Kakatiya University",
      "M.E, Osmania University",
      "Ph.D. IIT Madras"
    ],
    "researchArea": "Biomedical Engineering, Multidisciplinary Research: Plasmonic Biosensors, Microfluidics, Signal Processing, Sensory integration rooms",
    "memberships": [
      "OPTICA Membership Number: 1043362 SPIE ID Number is 3532707( not renewed)"
    ],
    "projects": [
      "1. Dr. Bandaru Ramakrishna(PI), “Lab-on-chip microfluidic separation and plasmonic detection of blood borne biomolecules: An integrated device development and demonstration”, ANRF/ECRG/2024/005201/LS, Amount: INR 61,57,440.00, Project duration: 36 months, Status : Ongoing",
      "2. Dr. Kanaparthi V Phani Kumar (PI),Dr. Bandaru Ramakrishna (Co-PI), Dr. U. Ganapathy Sankar (Co-PI), “Design, Development, and Validation of User-Adaptive Sensory Integration Room for Children with Autism Spectrum Disorder using IoT and Machine Learning Approach”. Funded by SERB under Core Research Grant file number CRG/2021/004097. Amount: 18.95 Lac, Project duration: 3 years (2022-2025) Status: Completed",
      "3. Bandaru Ramakrishna (Principal Investigator), Dr. VVR Sai (Co-Investigator and Guide), \"Nanoplasmonic fiber optic biosensor for urinary PSA detection: An early cancer detection,\" Funded by Department of Biotechnology (DBT) under BIRAC-SRISTI Appreciation award. Award Amount: INR 1,00,000.00, Project Duration: 12 months (June 2017-May 2018) Project No: BIRAC SRISTI PMU - 2017 /013 Project account No: ACC1718300BIRAVVRG Start date: 21 Sep 2017 End date:20 Aug 2018 Completed",
      "4. Dr.K.A Sunitha(Principle Investigator), Dr. P.A. Sridhar, Mrs.A.Brindha, Dr.Bandaru Ramakrishna (Co-Investigator), Design and develop a finger toothbrush with micro motion for early childhood caries management, Funded by SRM dental college kattangalathur, Chennai. Amount INR 70,000, Project duration 24 months (Oct 2018-March 2021 Completed)"
    ],
    "patents": [
      "1. Fiber optic Array Biosensor system with U-bent fiber sensor probes for multianalyte detection in clinical and pharmaceutical applications. Allwyn S, Bandaru Ramakrishna, Christina Christopher, V.V.R.Sai. Provisional Indian Patent Application No. 201641026626, Filed on 04th Aug 2016, Published on: 9th Feb 2018, Granted on: 25 Sep 2025",
      "2. A firefighting gun. Bandaru Ramakrishna, Chinnapalli Likith Kumar, N. Chittranjan, T. Shashank, Sayan Baidya. Patent Application No. 202041050954 A, Filed on 23rd Nov 2020, Published on 4th Dec 2020. Granted: 5th Dec 2023",
      "3. Ramakrishna bandaru, Chinnapalli likith kumar reddy, A hybrid dielectrophoretic microfluidic device for selective separation of particles Patent Application No. 202141015765 Dated 02.04.2021,Published on 3rd Dec 2021. Granted: 13/02/2024",
      "4. A User Adaptive Sensory Integration Room (Uasir)\" Patent Application No. 202441085515A, Kanaparthi V Phani Kumar, D Umamaheswara Reddy, Bandaru Ramakrishna, and U Ganapathy Sankar, Date of filing of Application :07/11/2024, Publication Date : 14/02/2025",
      "5. A Tactile Therapy System For Autism Spectrum Disorder (Asd) And A Method Thereof; Patent Application No. 202441079456 Kanaparthi V Phani Kumar, D Umamaheswara Reddy, Bandaru Ramakrishna, and U Ganapathy Sankar, Dated 18/10/2024 (43) Published on 07/03/2025",
      "6. Voice-responsive infinity illumination display device for vocal development in individuals with neurological disorders; Patent Application No.202441092193 A Kanaparthi V Phani Kumar, D Umamaheswara Reddy, Bandaru Ramakrishna, and U Ganapathy Sankar, Dated :26/11/2024 Published on 14/03/2025"
    ],
    "awards": [
      "Received IIT Madras Alumini Travel Grant 2017 of Amount 65,000 INR for a visit to Australia",
      "Received IIT Madras Research scholar Travel Grant 2015 of Amount 1.5 Lac for a visit to Portugal",
      "TCS Best research poster presentation award 2017 of 10,000 INR",
      "SRISTI-BIRAC GYTI 2017 Appreciation Grant of 1,00,000 INR funded by DBT"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ramakrishna-bandaru-3574b821/",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=D7n5hGkAAAAJ&sortby=pubdate&view_op=list_works&gmla=AOAOcb2X-E4iOX57nHiN65ZeOZVlf_nN_2aqQkXYSfsbPF4o5oZ78tZQF2GkW3LrfgJ0lGAGLgD1Co4CTWHZ078ag5AsFzTyRkJRrSwNFIbEMKi6Vwb_McZ0IJYjk5mN8-cKxVPWNqDFifmb2w"
    }
  },
  {
    "id": "vitap-1734-cms",
    "name": "Dr. Pulluri Harish",
    "employeeId": "9.70869",
    "designation": "Associate Professor Senior",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "314 -B, AB-1",
    "email": "harish.pulluri@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_PULLURI_HARISH_SENSE_eb3e22b397.avif",
    "education": [
      "B.Tech & JNTUH",
      "M.Tech & JNTUH",
      "Ph.D. & NIT Hamirpur"
    ],
    "researchArea": "Power System Optimization",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/feed/",
      "researchGate": "https://www.researchgate.net/profile/Harish-Pulluri-2",
      "googleScholar": "https://scholar.google.com/citations?user=9NWgydMAAAAJ&hl=en&gmla=ACrTK9UWtYCSxBK03E8G3K49CtjmqJ6Iy1uA-XvLd2Q2PS8jCKHSnHg3A04gCUCpPucthmKk3-qmebqCyFj29vxOr8ey_e5uu_zyrBgwfTHmOQ",
      "scopus": "https://www.scopus.com/pages/feedback/author/review-profile?authorIds=57189218169"
    }
  },
  {
    "id": "vitap-1753-cms",
    "name": "Dr.Viswanathan",
    "employeeId": "9.70888",
    "designation": "Associate Professor Senior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "816-J, CB",
    "email": "viswanathan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Viswanathan_SCOPE_67d6e5a1cf.avif",
    "education": [
      "MSC(CSE)Bharathidasan University",
      "ME Vels University",
      "VIT University Vellore, LMU Londan",
      "LMU Londan"
    ],
    "researchArea": "AI&ML, Big Data with Cloud",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/viswa-nathan-0a84402b",
      "googleScholar": "https://scholar.google.com/citations?user=erlriVgAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1509-cms",
    "name": "Dr. Satyanarayana Badeti",
    "employeeId": "10.70006",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G 23-J, AB-2",
    "email": "satyanarayana.b@vitap.ac.in",
    "phone": "5575",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Satyanaryana_Badeti_IMG_6648_SASMAT_4a570f5437.avif",
    "education": [
      "Andhra University",
      "JNT University",
      "VIT, Vellore"
    ],
    "researchArea": "Geophysical Fluid Dynamics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/satyanarayana-badeti-675a17143/",
      "researchGate": "https://www.researchgate.net/profile/Satyanarayana-Badeti-3",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=APUIkgwAAAAJ&view_op=list_works&authuser=1"
    }
  },
  {
    "id": "vitap-1292-cms",
    "name": "Dr. Sudhakar M",
    "employeeId": "10.70015",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G23-B, AB-2",
    "email": "sudhakar.matle@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sudhakar_M_SAS_MAT_1843_bf3afd5621.avif",
    "education": [
      "B.Sc, Sri venkateswara Univesity, Tirupati",
      "M.Sc, 2000, Sri Venkateswara University, Tirupati",
      "PhD in Mathematics, 2006-2011,Indian Institute of Technlogy,Madras",
      "Researcher, University of Gronigen, The Netherlands,2011 and Senior Scientist, Department of Mechanical Engineering , IIT Madras"
    ],
    "researchArea": "Numerics of PDE; finite difference method. Finite leement method, finite point set method, CFD analysis of computing, Electro-magnetic modeling",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "‪Matle Sudhakar‬ - ‪Google Scholar‬",
      "orcid": "0000-0002-0261-5776",
      "scopus": "45161821000",
      "vidwan": "301691"
    }
  },
  {
    "id": "vitap-1133-cms",
    "name": "Dr. Soubhagya Sankar Barpanda",
    "employeeId": "10.70023",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "707-D, CB",
    "email": "soubhagya.barpanda@vitap.ac.in",
    "phone": "5171",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Soubhagya_Sankar_Barpanda_70023_IMG_4864_SCOPE_b5ae90d239.avif",
    "education": [
      "B. Tech., BPUT",
      "M. Tech., NIT Rourkela",
      "CSE, NIT Rourkela"
    ],
    "researchArea": "Image Processing, Artificial Intelligence, Software Engineering",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=1kMdpZIAAAAJ&hl=en&authuser=1&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=35174208400"
    }
  },
  {
    "id": "vitap-1312-cms",
    "name": "Dr. Venkatrajam Marka",
    "employeeId": "10.70041",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "229-A, AB-1",
    "email": "v.marka@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Venkatrajam_Marka_SASMAT_c0a3bded47.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1142-cms",
    "name": "Dr. Asish Kumar Dalai",
    "employeeId": "10.70054",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "819 - M, CB",
    "email": "asish.d@vitap.ac.in",
    "phone": "5361",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Asish_Kumar_Dalai_70054_IMG_2613_SCOPE_8d41a5d321.avif",
    "education": [
      "B.Tech., GIET University",
      "M. Tech CSE, NIT Rourkela",
      "CSE, NIT Rourkela"
    ],
    "researchArea": "Network Security, Device Authentication, Artificial Intelligence, Machine Learning, Deep Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/asish-kumar-dalai-7b25ab169",
      "dblp": "https://dblp.org/pid/23/9553.html",
      "googleScholar": "https://scholar.google.com/citations?user=dXo1I9UAAAAJ&hl=en&oi=ao",
      "orcid": "https://orcid.org/0000-0003-0613-175X",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=37048485700"
    }
  },
  {
    "id": "vitap-1160-cms",
    "name": "Dr. Arun Kumar Sinha",
    "employeeId": "10.70063",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "328-D, AB-1",
    "email": "arunkumar.s@vitap.ac.in",
    "phone": "5351",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Arun_Kumar_Sinha_SENSE_867c65c402.avif",
    "education": [
      "National Institute of Technology Kurukshetra India",
      "Delhi University India",
      "Ph.D, University of Genova Italy",
      "Federal University of Santa Catarina Brazil"
    ],
    "researchArea": "Electronics, Intelligent Algorithm, Sensors, Design",
    "memberships": [
      "IEEE member number: 92033531"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "website": "https://www.linkedin.com/in/arunsinha99profile/",
      "dblp": "9890",
      "researchGate": "Arun-Sinha-5",
      "googleScholar": "9elCVDQAAAAJ",
      "orcid": "0000-0002-9043-6339",
      "scopus": "57203184223"
    }
  },
  {
    "id": "vitap-1401-cms",
    "name": "Dr. Manmadha Rao Banki",
    "employeeId": "10.70089",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "326-A, AB-1",
    "email": "rao.manmadha@vitap.ac.in",
    "phone": "5461",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Manmadha_Rao_Banki_SAS_PHY_1870_3548ea22ec.avif",
    "education": [
      "BSc MPC & Andhra University - Visakhapatnam",
      "MSc Physics & Andhra University - Visakhapatnam",
      "PhD Physics & IIT Madras - Chennai",
      "IIT Madras-Chennai & University of Houston, Texas, USA"
    ],
    "researchArea": "Nanomaterials, Energy Conversion, Bio-medical Devices and Chemical Sensors",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. 202341019160 - Reparation of Metal Surface for Selective Detection and Absorption of Gas",
      "2. 202341022988 - Highly Aligned Anodic Tio2 Nanotube Arrays for Hydrophobic Coatings",
      "3. 202341031297 - Surface Modified Batio3 Nanotubes with Cu Nanoparticles for Selective Detection of Glucose",
      "4. 202341030447 - A Method of Preparing Tio2 Nanotubes in Presence of Solar Energy and Water",
      "5. 202341046388 - A Method of Fabricating the Surface Modified Tio2 Nanotubes and Its Application In Efficient Blood Oxygenation"
    ],
    "awards": [
      "Mrs. Abayambal & Mr. Natarajan Award 2016: For the best Ph.D thesis in Energy",
      "Institute Research Scholar Award-2015: A merit certificate in recognition of Quality and Quantity of the Research Work",
      "ICTP Travel Grant-2014: Shortlisted for attending a “Workshop on Material Challenges in Devices for Fuel Solar Production and Employment” held on 19-23 May 2014 in International Centre for Theoretical Physics (ICTP), Trieste, Italy"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/mynetwork/grow/",
      "researchGate": "https://www.researchgate.net/profile/Manmadharao-Banki-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=J2uCTdEAAAAJ&view_op=list_works&authuser=1&gmla=AH8HC4xgOYqkohMTnSnJisWlUyoB4asGb0R7fLfBy2bjKRkW7F-72kChTHCXktZb9kc8bdaNVVkOAtZjG-iMRh6n",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57219471951&origin=resultslist and",
      "vidwan": "https://vidwan.inflibnet.ac.in/myprofile"
    }
  },
  {
    "id": "vitap-1162-cms",
    "name": "Dr. Sandipan Maiti",
    "employeeId": "10.70125",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "G02-C, AB-2",
    "email": "sandipan.maiti@vitap.ac.in",
    "phone": "5681",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sandipan_Maiti_70125_IMG_4682_SCOPE_00448edf3f.avif",
    "education": [
      "B.Tech, WBUT",
      "ME, BIT Mesra",
      "NIT Warangal"
    ],
    "researchArea": "DBMS, Data Warehousing, Data Mining, Pattern Recognition, Big-data Analytics,Software Engineering.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sandipan-maiti-8a982823/",
      "dblp": "https://dblp.org/pid/306/8853.html",
      "researchGate": "https://www.researchgate.net/profile/Sandipan-Maiti-2",
      "googleScholar": "https://scholar.google.com/citations?user=q6cxSqgAAAAJ&hl=en&authuser=2",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0003-1983-6054",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57209193167"
    }
  },
  {
    "id": "vitap-1164-cms",
    "name": "Dr. Neha Gupta",
    "employeeId": "10.70128",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "328-G, AB-1",
    "email": "neha.gupta@vitap.ac.in",
    "phone": "5685",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Neha_Gupta_70128_IMG_2646_SENSE_7b9ed71583.avif",
    "education": [
      "B.E. & RGPV Bhopal",
      "M.E. & Jabalpur Engineering College",
      "PhD & NIT Rourkela"
    ],
    "researchArea": "Remote Sensing, Satellite Image Processing, Machine Learning, Deep Learning",
    "memberships": [],
    "projects": [
      "Project Title: Liquid Neural Network (LNN)-Based Deep Learning Approach for Change Detection of Infrastructure and Its Prediction Using Satellite Images, Funding Agency / Sponsor: ISRO, Project ID / Reference Number: ISRO/RES/26-27, Project End Date: 02-07-2029, Current Status: Ongoing."
    ],
    "patents": [
      "1. System and Method for Detecting Variations in a Landscape Area using Remote Sensing Images, Patent Grant Number - 577907, Date of Grant - 12 January 2026",
      "2. IoT based Patient Health Monitoring System, Patent Grant Number - 570059, Date of Grant - 26 August 2025",
      "3. System And Method for Detecting Geographical Variations In An Area Of Interest, Patent Grant Number - 494778, Date of Grant - 4 January 2024",
      "4. Design And Development of the Change Detection Model Using the Satellite Images with Waho-Based U-Net, Patent Application Number-202341005552, Date of Publication-10 February, 2023",
      "5. A System For Identifying Water Bodies In Aerial Visuals, And Method Thereof, Patent Application Number- 202441009084, Date of Publication - 8 March, 2024",
      "6. Wireless Robot for Surveillance & Fire Detection, Patent Application Number-202441002221, Date of Publication- 16 February, 2024",
      "7. An Approach for Change Detection Method to Remote Sensing Images Using Deep CNN, Patent Application Number- 202241000120, Date of Publication - 14 January, 2022"
    ],
    "awards": [],
    "links": {
      "website": "https://sites.google.com/view/nehagupta27/home?authuser=0",
      "dblp": "https://dblp.org/pid/09/6861-6.html",
      "researchGate": "https://www.researchgate.net/profile/Neha-Gupta-144",
      "googleScholar": "43AKk7MAAAAJ",
      "orcid": "0000-0002-2287-1259",
      "scopus": "57209931462"
    }
  },
  {
    "id": "vitap-1405-cms",
    "name": "Dr. Nandam Ashok",
    "employeeId": "10.7013",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "125-B, AB-2",
    "email": "nandam.ashok@vitap.ac.in",
    "phone": "5691",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Nandam_Ashok_7013_0489_609887bdbf.avif",
    "education": [
      "B.Sc, Acharya Nagarjuna University",
      "M.Sc , Acharya Nagarjuna University",
      "Ph.D Indian Institute of Technology Roorkee",
      "Bengurion University of Israel, Gwangju Institute of Science and Technology"
    ],
    "researchArea": "Photonics, Plasmonics, Sensors, Supercontinuum generation",
    "memberships": [
      "IEEE member"
    ],
    "projects": [
      "Large Mode Area Optical Fibers For High Power Fiber Laser Applications- Funding Agency VITAP University"
    ],
    "patents": [],
    "awards": [
      "Kreitman Postdoctoral Fellowship-Ben-gurion University Israel, 2014"
    ],
    "links": {
      "googleScholar": "https://scholar.google.co.il/citations?user=hwDSp4MAAAAJ&hl=en",
      "vidwan": "https://vitap.irins.org/profile/260160"
    }
  },
  {
    "id": "vitap-1376-cms",
    "name": "Dr. Chalasani Rajesh",
    "employeeId": "10.70137",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "229-C, AB-1",
    "email": "rajesh.c@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Chalasani_Rajesh_SASCHY_IMG_2145_5c95973166.avif",
    "education": [
      "B.Sc., Acharya Nagarjuna University",
      "M.Sc., Chemistry, Andhra University",
      "Ph.D, Indian Institute of Science, Bangalore, 1. Tel-Aviv University, Israel, 2. University of Nebraska-Lincoln",
      "1. Tel-Aviv University, Israel, 2. University of Nebraska-Lincoln"
    ],
    "researchArea": "Materials Chemistry",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1167-cms",
    "name": "Dr. Kumar Debasis",
    "employeeId": "10.70151",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "223, CB",
    "email": "kumar.debasis@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70151_Dr_Kumar_Debasis_SCOPE_1288_d8423a5417.avif",
    "education": [
      "B.E CSE, Shivaji University (Kolhapur, Maharashtra)",
      "M.Tech CSE, Kalinga Institute of Industrial Technology (Bhubaneswar, Odisha)",
      "CSE, National Institute of Technology Patna (Patna, Bihar)"
    ],
    "researchArea": "Wireless Sensor Networks, Internet of Things, Computer Networks",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=b0helNsAAAAJ&hl=en&oi=sra",
      "orcid": "https://orcid.org/0000-0002-0352-3267",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56525331600"
    }
  },
  {
    "id": "vitap-1187-cms",
    "name": "Dr. Chandan Kumar Pandey",
    "employeeId": "10.70155",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "153, AB-1",
    "email": "chandan.pandey@vitap.ac.in",
    "phone": "5865",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Chandan_Kumar_Pandey_70155_IMG_2662_SENSE_f594ac68df.avif",
    "education": [
      "B. Tech in Electronics and Instrumentation Engineering, BPUT Rourkela",
      "M. Tech in Electronics and Communication Engineering, IIT Kharagpur",
      "PhD in Microelectronics and VLSI Design, NIT Silchar"
    ],
    "researchArea": "Microelectronics and VLSI Design, Modeling and Simulation of advanced MOS devices, Materials characterization for Semiconductor Devices, Application of devices as Biosensors and Photosensors",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "website": "https://sites.google.com/view/ckpandey/home",
      "researchGate": "https://www.researchgate.net/profile/Chandan-Pandey-11",
      "googleScholar": "https://scholar.google.com/citations?user=9xRl08oAAAAJ&hl=en",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0002-6177-6430",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201127417"
    }
  },
  {
    "id": "vitap-1193-cms",
    "name": "Dr. Agam Das Goswami",
    "employeeId": "10.70164",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "155, AB-1",
    "email": "agam.goswami@vitap.ac.in",
    "phone": "5845",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70164_Dr_Agam_Das_Goswami_SENSE_1218_351a8f6cfc.avif",
    "education": [
      "B.E Electronics & Telecommunication Pt. Ravishankar Shukla University",
      "M.E Chhattisgarh Swami Vivekanand Technical University Bhilai Chhattisgarh",
      "Ph.D NIT Rourkela"
    ],
    "researchArea": "Multi-Point Stochastic Simulation, Signal Processing, Image Processing & Machine Learning",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Agam-Goswami-2",
      "googleScholar": "https://scholar.google.co.in/citations?user=3Xi0CbUAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-3341-0597",
      "scopus": "57193321707 (https://www.scopus.com/authid/detail.uri?authorId=57458891200)",
      "vidwan": "301143"
    }
  },
  {
    "id": "vitap-1168-cms",
    "name": "Dr. Somya Ranjan Sahoo",
    "employeeId": "10.70167",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "615 - A, CB",
    "email": "somyaranjan.sahoo@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70167_Dr_Somya_Ranjan_Sahoo_SCOPE_1298_7d2cb16047.avif",
    "education": [
      "B Tech, BPUT",
      "MTech in Computer Science, BPUT Odisha",
      "Computer Science, NIT Kurukshetra"
    ],
    "researchArea": "Cyber Security, IOT Security, Artificial Intelligence, Machine Learning, Drone Application and Security",
    "memberships": [
      "ACM"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-somya-ranjan-sahoo-84891291/",
      "dblp": "https://dblp.org/pid/242/1772.html",
      "researchGate": "https://www.researchgate.net/profile/Somya-Ranjan-Sahoo",
      "googleScholar": "https://scholar.google.com/citations?user=zGfWgU0AAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-7922-4677",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57207823572"
    }
  },
  {
    "id": "vitap-1205-cms",
    "name": "Dr. Suseela Vappangi",
    "employeeId": "10.70182",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "310-D, AB-1",
    "email": "suseela.v@vitap.ac.in",
    "phone": "5709",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Suseela_Vappangi_70182_IMG_5136_SENSE_be3246d9b6.avif",
    "education": [
      "B.Tech & Jawaharlal Nehru Technological University Kakinada",
      "M.Tech & Jawaharlal Nehru Technological University Kakinada",
      "PhD and National Institute of Technology Warangal"
    ],
    "researchArea": "Wireless Communications, Visible Light Communications, Optical Wireless communications, Signal Processing for communications, Non-orthogonal multiple access, Next generation wireless communication systems",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "Suseela-Vappangi?ev=hdr_xpf",
      "googleScholar": "TbJ6llsAAAAJ",
      "orcid": "0000-0002-4997-0484",
      "scopus": "57197873049"
    }
  },
  {
    "id": "vitap-1214-cms",
    "name": "Dr. Chandu D S",
    "employeeId": "10.70196",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "151, AB-1",
    "email": "chandu.ds@vitap.ac.in",
    "phone": "5105",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Chandu_D_S_70196_IMG_4718_SENSE_5aff8f5006.avif",
    "education": [
      "B.Tech - Jawaharlal Nehru Technological University Hyderabad",
      "M.Tech - Jawaharlal Nehru Technological University Hyderabad",
      "PhD - Indian Institute of Information Technology, Design and Manufacturing Kancheepuram"
    ],
    "researchArea": "Electromagnetics, Microwave Devices and Metasurfaces",
    "memberships": [
      "IEEE, ISTE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "dblp": "pid/205/6819",
      "researchGate": "HDN-0844-2022",
      "googleScholar": "WOLhi88AAAAJ",
      "orcid": "0000-0002-6901-8503",
      "scopus": "56638569700"
    }
  },
  {
    "id": "vitap-1329-cms",
    "name": "Dr. Prashanth Maroju",
    "employeeId": "10.70197",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "325-A, AB-2",
    "email": "prashanth.m@vitap.ac.in",
    "phone": "5106",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Prashanth_Maroju_70197_IMG_4979_SAS_MAT_8a4539f00d.avif",
    "education": [
      "B.Sc, Acharya Nagarjuna University",
      "M.Sc, Osmania University",
      "Ph.D, I I T Kharagpur",
      "Universirty of KwaZulu-Natal, South Africa"
    ],
    "researchArea": "Numerical Analysis, Differential Equations, Fuzzy System, Functional Analysis, Spectral Methods",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "received Research award in 2022,2023,2024 at VITAP University Day"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/feed/",
      "googleScholar": "https://scholar.google.com/citations?user=q5n2dJcAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/results/authorNamesList.uri?name=name&st1=Prashanth&st2=Maroju&origin=searchauthorlookup",
      "vidwan": "https://vidwan.inflibnet.ac.in/myprofile"
    }
  },
  {
    "id": "vitap-1169-cms",
    "name": "Dr. Vikash Kumar Singh",
    "employeeId": "10.70202",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "G-36, AB-1",
    "email": "vikash.singh@vitap.ac.in",
    "phone": "5108",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vikash_Kumar_Singh_70202_IMG_4684_SCOPE_40d5949384.avif",
    "education": [
      "B.Tech, Gautam Buddh Technical University, Lucknow, UP",
      "M.Tech, National Institute of Technology, Durgapur, WB",
      "Computer Science and Engineering, National Institute of Technology, Durgapur, WB"
    ],
    "researchArea": "Mechanism Design, Game Theory, Crowdsourcing, Internet of Things, Healthcare",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://in.linkedin.com/in/vikash-kumar-singh-phd-23887914",
      "dblp": "https://dblp.org/pid/178/9138.html",
      "researchGate": "https://www.researchgate.net/profile/Vikash-Singh-12",
      "googleScholar": "https://scholar.google.com/citations?user=eoHiARoiXdwC&hl=en",
      "orcid": "https://orcid.org/0000-0002-8747-1627",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=35774650600"
    }
  },
  {
    "id": "vitap-1410-cms",
    "name": "Dr .Prabhakaran Thandapani",
    "employeeId": "10.70362",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "819 - D, CB",
    "email": "prabhakaran.thandapani@vitap.ac.in",
    "phone": "5985",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70362_Dr_Prabhakaran_Thandapani_1053_10b050e2a3.avif",
    "education": [
      "B.Sc Physics (2005) & Bharathidasan University, Tiruchirappalli, Tamil Nadu, India",
      "M.Sc Physics (2007) & Bharathidasan University, Tiruchirappalli, Tamil Nadu, India; M.Phil in Physics (2008), Bharathidasan University, Tiruchirappalli, Tamil Nadu, India.",
      "Ph.D in Physics & National Institute of Technology, Tiruchirappalli, India",
      "1. Fondecyt - Postdoctoral Researcher, University of ConcepciÃ³n, Chile, from Feb 2016 - Oct 2018; 2. FAPESP - Postdoctoral Researcher - Universidade Estadual de Campinas, Campinas, SP, Brazil, from March 2019 to April 2021; 3. Postdoctoral Researcher, University of concepciÃ³n, Chile, from May 2021 - Sep 2021"
    ],
    "researchArea": "Magnetoelectric polymer nanocomposites, Magnetic refrigeration, Magnetic hyperthermia, Functional materials and composites for i-caloric effect, Metal oxide nanostructures for optical and gas sensing applications.",
    "memberships": [
      "1. Magnetics Society of India – Life member: LM758; 2. The Minerals, Metals and Materials Society, USA, Associate Member: 526031, 3. International Society for Optics and Photonics (SPIE) Member ID: 3283718, 4. American Chemical Society – Community member: 30200229, 5. Materials Research Society, Singapore - 2339"
    ],
    "projects": [
      "Project No: V-LAUNCH/2022-23/004, unding Agency: VIT-AP University, Title: Binary phase ferrite nano heaters for cancer therapy, Project Amount: INR 200,000 for one year. (On-going)\""
    ],
    "patents": [],
    "awards": [
      "International Travel Grant from SERB, INDIA to present a research paper in 11th ICMAT 2023, from 26th to 30th June 2023, held in Suntec City, Singapore."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/prabhakaran-thandapani-8837172b?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3B8bZQmGbISHmEvN0Yk%2Byamw%3D%3D",
      "googleScholar": "https://scholar.google.com/citations?user=fOhQlWYAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0003-0245-8827",
      "scopus": "ResearcherID: L-3282-2018",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/257299"
    }
  },
  {
    "id": "vitap-1385-cms",
    "name": "Dr. Dripta De Joarder",
    "employeeId": "10.70381",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "816 - L, CB",
    "email": "dripta.joarder@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Dripta_De_Joarder_SAS_b99086d5fb.avif",
    "education": [
      "B. Sc.(H), University of Calcutta",
      "M. Sc., University of Calcutta",
      "Ph. D., The University of Alabama, USA",
      "Wayne State University, USA, University of Calcutta, India"
    ],
    "researchArea": "Organic synthesis, Green catalysis",
    "memberships": [
      "CRSI"
    ],
    "projects": [
      "1. UGC DAE, Detailed study of Human Neutrophil -Defensin peptide-2 (HNP-2) fragments in wound healing",
      "2. ICMR"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=Yo-hT0AAAAAJ"
    }
  },
  {
    "id": "vitap-1234-cms",
    "name": "Dr. Nagendra Panini Challa",
    "employeeId": "10.70397",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "816 - D, CB",
    "email": "nagendra.challa@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Nagendra_Panini_Challa_70397_IMG_4695_SCOPE_2d017cc417.avif",
    "education": [
      "B.E CSE, Sri Chandrasekharendra Saraswati Viswa Mahavidyalaya",
      "M.Tech, JNTU Kakinada",
      "Computer Science and Engineering , Sri Chandrasekharendra Saraswati Viswa Mahavidyalaya"
    ],
    "researchArea": "Machine Learning, Deep Learning, Artificial Intelligence, Metadata and Ontologies",
    "memberships": [
      "IEEE, IET"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/nagendra-panini-challa-70363170/",
      "dblp": "https://dblp.org/search?q=Nagendra+panini+challa",
      "researchGate": "https://www.researchgate.net/profile/Nagendra-Panini-Challa",
      "googleScholar": "https://scholar.google.co.in/citations?user=oGT6VuwAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-8894-6436",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57200286118"
    }
  },
  {
    "id": "vitap-1232-cms",
    "name": "Dr. Pradosh Ranjan Sahoo",
    "employeeId": "10.70412",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "309 - E, AB-1",
    "email": "pradosh.sahoo@vitap.ac.in",
    "phone": "5826",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70412_Dr_Pradosh_Ranjan_Sahoo_SENSE_1115_1862d44da8.avif",
    "education": [
      "Biju Patnaik University of Technology Odisha",
      "National Institute of Technology Rourkela",
      "Ph.D, National Institute of Technology Rourkela"
    ],
    "researchArea": "Decentralised control, time-delay system, output feedback control",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=rlXqeRUAAAAJ&hl=en",
      "orcid": "0000-0002-6094-1457",
      "scopus": "56046441900"
    }
  },
  {
    "id": "vitap-1239-cms",
    "name": "Dr. Atul Shankar Mani Tripathi",
    "employeeId": "10.70414",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "G02-A, AB-2",
    "email": "atul.tripathi@vitap.ac.in",
    "phone": "5828",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70414_Dr_Atul_Shankar_Mani_Tripathi_SENSE_1366_7ad3823fdf.avif",
    "education": [
      "B.Tech, Uttar Pradesh Technical University Lucknow",
      "M.Tech, Indian Institute of Technology BHU Varanasi",
      "PhD, Kyushu Institute of Technology Japan",
      "The University of Hong Kong , Hong Kong. UniversitÃ© du Littoral CÃ´te dâ€™Opale, Dunkerque France."
    ],
    "researchArea": "Organic/Flexible Electronics, Low power VLSI Design, Semiconductor device modelling, Electrocaloric Devices",
    "memberships": [
      "IEEE, MRS USA, JSAP 2016 to 2019"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Atul-Tripathi-4",
      "googleScholar": "https://scholar.google.com/citations?user=8lC2gSAAAAAJ&hl=ja",
      "orcid": "0000-0003-2586-0421",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57196718716"
    }
  },
  {
    "id": "vitap-1370-cms",
    "name": "Dr. Pratheep Kumar",
    "employeeId": "10.70421",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "224-J, AB-2",
    "email": "pratheep.kumar@vitap.ac.in",
    "phone": "5855",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70421_Dr_Pratheep_Kumar_CHY_1213_24acec94c0.avif",
    "education": [
      "BSc., University of Madras",
      "MSc., VIT University Vellore",
      "PhD, VIT University Vellore",
      "National Institute for Materials Science (NIMS), Japan"
    ],
    "researchArea": "Solid State Chemistry/Materials Chemistry/Ceramics/Thermal Expansion",
    "memberships": [
      "MRSI, ISTE"
    ],
    "projects": [
      "1. Photoluminescence Investigation of Novel Rare Earth Activated Langbeinites for White Light Emitting Diode Applications & VIT-AP/SpoRIC/RGEMS/2022-23(II)/008",
      "2. Synthesis, structural and thermal expansion studies of novel langbeinites for high temperature applications & SERB-DST"
    ],
    "patents": [
      "Method of Preparation of Langbeinite Phosphosilicates Thereof & 202041035310 A"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/pratheep-kumar-4714a752/",
      "dblp": "AAA-4675-2022",
      "researchGate": "https://www.researchgate.net/profile/Pratheep_Kumar4",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=-Z-PLxAAAAAJ",
      "orcid": "0000-0002-9852-2864",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=50162140100"
    }
  },
  {
    "id": "vitap-1435-cms",
    "name": "Dr. Rajarshi Sarkar",
    "employeeId": "10.70453",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "623-D, CB",
    "email": "rajarshi.sarkar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Rajarshi_Sarkar_IMG_8184_SASCHY_5c894e9c74.avif",
    "education": [
      "BSc Asutosh College, The University of Calcutta",
      "MS The University of Akron, USA; MSc: Presidency College, The University of Calcutta",
      "PhD The University of Akron, USA",
      "National Postdoctoral Fellow: Jadavpur University, WB, India"
    ],
    "researchArea": "Organic Materials, Metal Organic Gels, Catalysis, Self-Healing Materials, Dye Sensitized Solar Cells, Green Technology",
    "memberships": [
      "Chemical Research Society of India, American Chemical Society, Royal Society of Chemistry"
    ],
    "projects": [
      "Neural Regeneration: Design of an efficient nanocapsule for delivering nerve growth factor to the central nervous system - UGC DAE Consortium for Scientific Research",
      "Design and synthesis of novel Metal Organic Gels and its application in organic catalysis."
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/rsarkar25/",
      "googleScholar": "https://scholar.google.co.in/citations?user=XoxsMrMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=53865621600",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/299962"
    }
  },
  {
    "id": "vitap-1252-cms",
    "name": "Dr. Khasim Syed",
    "employeeId": "10.70457",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "812 - K, CB",
    "email": "syed.khasim@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Khasim_Syed_70457_IMG_4757_SCOPE_09e8c46d2f.avif",
    "education": [
      "B.Tech CSE, JNTU - Hyderabad",
      "M.Tech ( Information Technology), JNTU - Kakinada",
      "PhD(CSE) - Rayalaseema University"
    ],
    "researchArea": "Deep Learning and Machine Learning, Image Processing, Internet of Things, Cryptography & Network Security, Big Data Analytics",
    "memberships": [
      "IEEE Collabratec, International Association of Computer Scienceand Information Technology, Computer Science Teachers Association, International Association of Engineers,"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Syed-Khasim-4",
      "googleScholar": "https://scholar.google.co.in/citations?hl=en&user=SFb2FCUAAAAJ",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0003-4575-6437",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57882529500",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/302815"
    }
  },
  {
    "id": "vitap-1271-cms",
    "name": "Dr. Saladi Saritha",
    "employeeId": "10.70461",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "169, AB-1",
    "email": "saritha.saladi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Saladi_Saritha_70461_IMG_4975_SENSE_3d9d4d5430.avif",
    "education": [
      "B.Tech, JNT University, Hyderabad",
      "M.Tech, JNT University, Hyderabad",
      "Ph.D, Vellore Institute of Technology, Vellore, TN, India"
    ],
    "researchArea": "Medical image processing, Machine learning, Deep learning, Artificial intelligence, Image processing.",
    "memberships": [
      "IEEE: 98702482, IETE: m-501836"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Saritha_Saladi",
      "googleScholar": "https://scholar.google.co.in/citations?user=EeLPdsAAAAAJ&hl=en&oi=ao",
      "orcid": "0000-0002-7044-6783",
      "scopus": "57195377947"
    }
  },
  {
    "id": "vitap-1206-cms",
    "name": "Dr. Santosh Kumar Sahu",
    "employeeId": "10.70471",
    "designation": "Associate Professor Grade 2",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "310-C, AB1",
    "email": "santoshkumar.sahu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Santosh_Kumar_Sahu_70471_IMG_2309_SMEC_004dd4e598.avif",
    "education": [
      "B.TECH, SMIT under BPUT, Odisha",
      "M.TECH, NIT Kurukshetra",
      "PhD, North Eastern Regional Institute of Science & Technology (A CFTI)"
    ],
    "researchArea": "Machine Design",
    "memberships": [
      "ASME Member"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Santosh_Sahu5",
      "googleScholar": "https://scholar.google.com/citations?user=iF92RIsAAAAJ&hl=en&citsig=AMstHGThM7hpbScZhSAVCEpc LdxoDEd4sQ",
      "orcid": "0000-0002-6729-0415",
      "scopus": "57203050368"
    }
  },
  {
    "id": "vitap-1291-cms",
    "name": "Dr. M. Krishnasamy",
    "employeeId": "10.70496",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "424-G, AB-1",
    "email": "krishnasamy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_M_Krishnasamy_70496_IMG_4962_SENSE_a10007053c.avif",
    "education": [
      "B.E & University of Madras, Chennai",
      "M.Tech & Rajasthan Technical University | Kota Rajasthan",
      "PhD & NIT Silchar, Assam"
    ],
    "researchArea": "MEMS Device, Renewable Energy, Microelectronics, Piezo-Magneto-Elastic Energy Harvester",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Krishnasamy_m",
      "googleScholar": "https://scholar.google.co.in/citations?user=Jx_VKH8AAAAJ&hl=en",
      "orcid": "0000-0002-2605-1194",
      "scopus": "57195947585"
    }
  },
  {
    "id": "vitap-1456-cms",
    "name": "Dr. Naga Prasad Puvvada",
    "employeeId": "10.70518",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "103-C, CB",
    "email": "nagaprasad.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70518_Dr_Naga_Prasad_Puvvada_1037_ab0fceeafb.avif",
    "education": [
      "B.Sc. & Acharya Nagarjuna University",
      "M.Sc. & NIT Warangal",
      "Ph.D & IIT Kharagpur",
      "NBHRF-CIHR-MSSU-SPOR and Reynolds Post Doc & University of New Brunswick, Canada & Dalhousie Medicine New Brunswick"
    ],
    "researchArea": "Chemical Biology & Nanomedicine",
    "memberships": [
      "Telangana Academy Sciences-Young Scientist; Materials Research Society of India (MRSI-LMB4053), Indian Academy of Neurology (IAN -LP-113)"
    ],
    "projects": [
      "1) Potential neuroprotective role of chemically engineered GNSs/TSG/CDs nanomaterials against microglia macrophages induced cell death in stroke-79.7 LAKH &ICMR Small Grant (PI-ICMR-IIRP-2023-1583/F1) (PI-ONGOING)",
      "2) Received DST-FIST grant for development of institute R&D infrastructure as project executive number (1.5 Crore) & DST FIST (CoPI-ongoing)",
      "3) Neural Regeneration: Design of an efficient nanocapsule for delivering nerve growth factor to the central nervous system-1.65 Lakhs (Co-PI-UGC-DAE-CSR) (CoPI-ONGOING)",
      "4) Detailed study of Human Neutrophil-Defensin peptide-2 (HNP-2) fragments in wound healing-1.65 Lakhs (Co-PI-UGC-DAE-CSR) (CoPI-ONGOING)",
      "5) In vitro investigations of neuroprotection are mediated by ROS-responsive Edaravone-loaded Mannose nanospheres via HMGB1 inhibition and microglia polarization modulation-57.3 Lakhs (PI-ANRF/ECRG/2024/005471/LS) (PI-ONGOING)",
      "6) Chemically engineered nanoparticles for enhanced delivery and efficacy of chemotherapeutics in resistant strains of breast cancer-DST INSPIRE Scheme-103Lakhs (PI-Completed)-DST/INSPIRE/04/2016/000191(Completed)",
      "7) Detection and tracking of blood cancer stage during therapy via blood plasma through Raman scattering-NBHRF-CHIR-SPOR-MSSU-2015-100000 CAD (PI-completed)",
      "8) The potential role of fluorescent carbon dots against bacteria-2 Lakhs (PI-VIT-AP University Seed fund) (PI-Completed)",
      "9) Synthesis and characterization of carbon nanoparticles as a potent immune-therapeutics regimen for ovarian cancer and zirconium phosphate nanobiocomposite films to enhance the success rate of bone implants in tissue engineering˗GSBTM -62,80712 Rs (PI-GSBTM/JD(R&D)/618/21- 22/00003673) (PI-completed)"
    ],
    "patents": [],
    "awards": [
      "Received NBHRF CIHR-SPOR-MSSU Govt. Post-doctoral Fellowship, New Brunswick, Canada.",
      "Reynolds Fellowship for Post-doctoral Research at Dalhousie University, Canada (2014).",
      "Received DST Inspire Faculty, DST, Govt. of India-2016",
      "Received Telangana Academy Sciences Young Scientist Award in 2019",
      "Received BRICS Young Scientist Forum Award-2022-DST Inida"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/scientific-contributions/Nagaprasad-Puvvada-48422446",
      "googleScholar": "https://scholar.google.co.in/citations?user=JEvxHugAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=36698261600",
      "vidwan": "https://vitap.irins.org/profile/371209"
    }
  },
  {
    "id": "vitap-1458-cms",
    "name": "Dr. T Ramana",
    "employeeId": "10.70524",
    "designation": "Associate Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "623-B, CB",
    "email": "ramana.t@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_T_Ramana_SAS_0936_6b09694ce4.avif",
    "education": [
      "Andhra University",
      "Andhra University",
      "Ph.D from IIT Guwahati, Post Doctoral - The University of Tokyo, Japan",
      "The University of Tokyo, Japan"
    ],
    "researchArea": "Synthetic Organic Chemistry",
    "memberships": [],
    "projects": [
      "One-Pot Synthesis of Fused 1, 2, 3-Triazoles through Click and Cross-Coupling reaction, UGC"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Ramana-Tamminana/research",
      "googleScholar": "https://scholar.google.com/citations?user=8mgPoMIAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57191829553",
      "vidwan": "https://vitap.irins.org/profile/304081"
    }
  },
  {
    "id": "vitap-1387-cms",
    "name": "Dr. Suma Kamalesh Gandhimathi",
    "employeeId": "10.70576",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "620-K, CB",
    "email": "sumakamalesh.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Suma_Kamalesh_Gandhimathi_70576_0585_ef111967fb.avif",
    "education": [
      "B.E, Anna University: Chennai",
      "M.E, Anna University: Chennai",
      "Ph.D, Anna University: Chennai"
    ],
    "researchArea": "Artificial Intelligence, Machine Learning, Soft Computing, Medical Imaging",
    "memberships": [
      "ACM, IAENG"
    ],
    "projects": [
      "In-house Seed Funded Project – ‘Detection of Glaucoma in Fundus Images using Soft Computing Techniques’, Sanctioned by Sree Vidyanikethan Educational Trust, 2019-2020"
    ],
    "patents": [
      "1. ‘Intelligent Shopping Card by using Internet of Things (IoT), Artificial Intelligence (AI) and Machine Learning (ML) Technologies’, Patent ID: 2020102305, Australian Government, IP Australia, Published on 14.10.2020",
      "2. ‘Multiple Layered Communication with Optical Wireless Link using Integrated Wireless Sensor Networks’, Patent ID: 202141003159, Intellectual Property India, Published on 29.01.2021"
    ],
    "awards": [
      "Young Researcher Award, Springer, 2022",
      "Best Woman Faculty Award, Novel Research Academy, 2021",
      "Young Woman Engineer, The Institution of Engineering and Technology IET KKLN Awards, 2020",
      "Honorary Certificate, International Journal of Ophthalmology, 2016",
      "M.E College Topper & University Rank Holder, Anna University: Chennai, 2012",
      "Best Paper Award, National level Technical Symposium, SIGMOID 2k19, 2019"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-suma-k-g-education/",
      "researchGate": "https://www.researchgate.net/profile/Dr-K-G",
      "googleScholar": "https://scholar.google.com/citations?user=9maaYXgAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56519542300"
    }
  },
  {
    "id": "vitap-1492-cms",
    "name": "Dr. G. Soma Sekhar",
    "employeeId": "10.70635",
    "designation": "Associate Professor Grade 2",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "410, AB-1",
    "email": "somasekhar.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70635_Dr_G_Soma_Sekhar_vsb_1200_c2c3cdb60b.avif",
    "education": [
      "B.Sc (MPC) from S.V.University",
      "MBA from S.V.University, Tirupati",
      "Ph.D from S.V.University"
    ],
    "researchArea": "Operations and Supply Chain Management, Retail Management, Customer Analytics, Marketing Management and Digital Marketing",
    "memberships": [
      "Member of the International Society for Development and Sustainability (ISDS), Japan"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-somasekhar-g-47aa33116/",
      "researchGate": "Soma Sekhar Gutta (researchgate.net)",
      "googleScholar": "‪SOMASEKHAR G‬ - ‪Google Scholar‬",
      "orcid": "0000-0001-6966-7020",
      "scopus": "57204629087"
    }
  },
  {
    "id": "vitap-1516-cms",
    "name": "Dr. Girish Kumar Mekala",
    "employeeId": "10.70653",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "310-F, AB-1",
    "email": "girishkumar.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Girish_Kumar_Mekala_SENSE_1944_2fb7deaf1a.avif",
    "education": [
      "B.Tech & JNTU Hyderabad",
      "M.Tech & NIT Hamirpur, Himachal Pradesh",
      "Ph.D. & NIT Hamirpur, Himachal Pradesh"
    ],
    "researchArea": "VLSI Interconnects, TSVs, Carbon Nanotube based devices, Machine learning",
    "memberships": [
      "IEEE Senior Member"
    ],
    "projects": [
      "Quality of Signal Improvement in Prominent GNRFET based Ternary Logic System for Futuristic Dielectric Inserted MLGNRs for Integrated Circuit Designs, Startup Research Grant SERB( Completed)"
    ],
    "patents": [
      "Wearable Device for Providing Navigatio N Assistanc E to User With Visual Impairmen T and Method Thereof, Patent Application Number-202641029010, Date of Publication - 20th March 2026"
    ],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Girish-Mekala",
      "googleScholar": "https://scholar.google.com/citations?user=l2ny5ZYAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57189234596"
    }
  },
  {
    "id": "vitap-1514-cms",
    "name": "Dr. S. Bharath Bhushan",
    "employeeId": "10.70655",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "615 - K, CB",
    "email": "bharathbhushan.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_S_Bharath_Bhushan_SCOPE_0924_e884b9cd30.avif",
    "education": [
      "B.Tech & JNTUA",
      "M.Tech & JNTUA",
      "PhD & VIT University"
    ],
    "researchArea": "Cloud Computing, Virtualization & ITIL process, Networks, Databases and Software Engineering.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57195373782"
    }
  },
  {
    "id": "vitap-1519-cms",
    "name": "Dr. Yepuganti Karuna",
    "employeeId": "10.70657",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "148, AB-1",
    "email": "karuna.y@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Yepuganti_Karuna_70657_IMG_4934_SENSE_31e41d83b9.avif",
    "education": [
      "B.Tech , Andhra University , Andhra Pradesh",
      "M.Tech , National Institute of Technology , Tiruchirappalli, Tamilnadu",
      "P.hD , Vellore institute of Technology , Vellore , Tamilnadu"
    ],
    "researchArea": "Bio medical Image Processing , Bio medical Signal Processing , Artificial Intelligence , Machine Learning , Deep Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-yepuganti-karuna-03963296/",
      "researchGate": "https://www.researchgate.net/profile/Yepuganti-Karuna",
      "googleScholar": "https://scholar.google.com/citations?user=otcB9gsAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=36975611000"
    }
  },
  {
    "id": "vitap-1585-cms",
    "name": "Dr. Pamulapati Ashok Reddy",
    "employeeId": "10.7072",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "619-N, CB",
    "email": "ashokreddy.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pamulapati_Ashok_Reddy_SCOPE_eb232278b1.avif",
    "education": [
      "B.Sc(Computers), Acharya Nagarjuna University",
      "M.C.A, Acharya Nagarjuna University M.Tech(CSE), JNTU Kakinada",
      "Ph.D(CSE), Acharya Nagarjuna University"
    ],
    "researchArea": "Artificial Intelligence, Machine Learning, Data Science and Software Engineering",
    "memberships": [
      "LM CSI"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Best NSS Programme Officer and Best NSS Unit from Hon’ble President of India Sponsored by Ministry of Youth Affairs and Sports (MoYAS), Govt of India for the year 2019-20 on Sept 24th 2021 at New Delhi.",
      "Best NSS Programme Officer from the Government of Andhra Pradesh for the year 2019-20.",
      "Best Academician Award from IJIEMR-ELSEVIER on Dec 20, 2020.",
      "National Eminent Researcher Award 2020 from International Institute of Organized Research (I2OR) in the month of Dec, 2020.",
      "Best Researcher Award from IJIEMR-ELSEVIER on March 5, 2020.",
      "Best NSS Programme Officer from JNTU Kakinada on 07-11-2019 for the A.Y 2018-19.",
      "Certificate of Excellence and Best Teacher Award from Lions Club, Mylavaram for the A.Y 2018-19 on 05-09-2019.",
      "Best Teacher Award from Lakireddy Bali Reddy College of Engineering for the academic years 2019-20 and 2018-19.",
      "Flag Bearer Award from Indian Red Cross Society for the outstanding performance in NSS Activities, Good number of Blood Donation Camps and motivating the students towards blood camps on 14-06-2016.",
      "Best NSS Service Award from Andhra Pradesh Government on 26-01-2015.",
      "Gold Partner Award from Infosys, Campus Connect during Nov 2013",
      "Best Achievement Award from Infosys,Campus Connect for the conduction of Foundation Programs, during 2008-09 A.Y."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ashok-reddy-pamulapati-2a717518/",
      "googleScholar": "https://scholar.google.co.in/citations?user=fOBQt_QAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=36679797900",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/180308"
    }
  },
  {
    "id": "vitap-1641-cms",
    "name": "Dr. Saroja Kumar Rout",
    "employeeId": "10.70776",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "816 - I, CB",
    "email": "sarojakumar.rout@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Saroja_Kumar_Rout_SCOPE_IMG_8138_5fe87bf8c1.avif",
    "education": [
      "B.Sc, Utkal University, Bhubaneswar",
      "M.Tech(CSE),Utkal University, Bhubaneswar",
      "PhD (CSE),Siksha 'O' Anusandhan University, Bhubaneswar"
    ],
    "researchArea": "Wireless Sensor Network, Cloud Computing, Machine Learning & Deep Learning, Health Informatics",
    "memberships": [
      "1)Member of IE,Membership Number: M-1738679. 2)IEEE Senior Member ,Membership Number: 97493925. 3)Member of International Association of Engineers(IAENG),Membership Number: 248481"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "L N Barik Memorial award, Research and Innovation Award from The Institution of Engineers (India), 2025",
      "Best paper award :2nd International Conference on Integrated Intelligence and Communication Systems (ICIICS-2024), Sharnbasva University, Kalaburagi ,22 & 23 November 2024",
      "Gannett Memorial award, for Innovative research work, The Institute of Engineers (India) 2024.",
      "Best paper award- Springer International Conference on Computational Intelligence and Data Analytics (ICCIDA-2018), GIFT, Bhubaneswar, Odisha, India.",
      "Best paper award- Springer International Conference on Computational Intelligence and Data Analytics (ICCIDA-2018) ,GIFT, Bhubaneswar, Odisha, India. 2018",
      "Best paper award- International Conference on Advancements in Sustainable Technology (ICAST-2021) 17th - 18th December 2021 at Gandhi Institute For Technology (GIFT), Bhubaneswar. 2021"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-saroja-kumar-rout-24b4a2258/",
      "researchGate": "https://www.researchgate.net/profile/Saroja-Kumar-Rout?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=VAntnigAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57190944240",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/258535"
    }
  },
  {
    "id": "vitap-1651-cms",
    "name": "Dr. Srikanth Busa",
    "employeeId": "10.70787",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "621 - M, CB",
    "email": "srikanth.busa@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Srikanth_Busa_SCOPE_fc3981ce0a.avif",
    "education": [
      "B.Tech(CSE), V.R. Siddhartha Engineering College, Acharya Nagarjuna University.",
      "M.Tech(CSE), Acharya Nagarjuna University.",
      "Ph.D(CSE), Acharya Nagarjuna University."
    ],
    "researchArea": "Digital Image Processing, Machine Learning",
    "memberships": [
      "IAENG, ISTE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=Pe-L8m0AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57880414900",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/293967"
    }
  },
  {
    "id": "vitap-1722-cms",
    "name": "Dr. Arun Kumar Marandi",
    "employeeId": "10.7086",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "620-I, CB",
    "email": "arunkumar.marandi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_ARUN_KUMAR_MARANDI_SCOPE_679c9ace38.avif",
    "education": [
      "B.Sci. Computer Science Hons. NORTH ORISSA UNIVERSITY, TAKHATPUR, BARIPADA",
      "Master of Computer Applications, NIT Allahabad",
      "PhD, NIT JAMSHEDPUR"
    ],
    "researchArea": "Software Engineering, Deep learning, IoT and AI&ML",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. Development of a Central Monitoring Station for an Effective Handling of Patients in Hospitals Through AI and Data Science.",
      "2. INTERNET OF THINGS -BASED METEOROLOGICAL CONDITIONS MONITORING AND PREDICTION SYSTEM WITH ARTIFICIAL NEURAL NETWORK (ANN)",
      "3. Land-Based, Holonomic-Type, Mecanum-Wheeled Mobile Robot for Queue Management in Supermarkets Mechatronic Design and Kinematic Analysis.",
      "4. AUTONOMOUS ROBOTIC INSPECTION AND MAINTENANCE SYSTEM FOR INDUSTRIAL EQUIPMENT.",
      "5. CLOUD COMPUTING BASED ACCIDENT DETECTION DEVICE"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/arun-kumar-marandi-a44421355/",
      "googleScholar": "https://scholar.google.com/citations?user=HpmCG9QAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56900997000"
    }
  },
  {
    "id": "vitap-1726-cms",
    "name": "Dr. Regonda Nagaraju",
    "employeeId": "10.70863",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "626 - H, CB",
    "email": "nagaraju.regonda@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_REGONDA_NAGARAJU_SCOPE_f16f7279f5.avif",
    "education": [
      "B. Tech (CSE) & JNTU, Hyderabad",
      "M.Tech (CSE) & JNTU, Hyderabad",
      "Ph.D. (CSE) & SJJT University"
    ],
    "researchArea": "Machine Learning, Medical Imaging, Artificial Intelligence, Image Processing & Pattern Recognition.",
    "memberships": [
      "CSI, MISTE, IAENG"
    ],
    "projects": [],
    "patents": [
      "1. Granted & Published: An Apparatus and Method for Remotely Monitoring an Aquatic Animal and Classification Thereof",
      "2. Intelligent Methods for Detecting Coronavirus Using RNA and Sharing the Location Using IoT",
      "3. Facial Recognition Triple Security Entryway System Using AI and Deep Neural Networks",
      "4. Machine Learning-Based Method for Network Security in Virtual Reality Communication Networks",
      "5. Processor Implemented Method for Watermarking and Cyber Protection of Deep Learning Models",
      "6. Train Monitoring System and Method Using a Machine Learning Approach",
      "7. Design and Fabrication of IoT-Based Solar Agriculture Weeder",
      "8. A City Security-Based Sensor Arrangement for Improving the Urban Environment",
      "9. Automatic Water Controlling System for Home Gardening",
      "10. Prediction Prospect of Getting Admission into a University Using Machine Learning",
      "11. Correlation Evaluation of Economic Indicators and Inventory Price Fluctuations Based on Artificial Intelligence Systems",
      "12. Fitness and Diet Recommendation Using the C4.5 Decision Tree Model",
      "13. Kernel Lasso Regression Algorithm for Predicting Electricity Loads",
      "14. Utilizing Machine Learning to Predict the Happiness Index",
      "15. Determining the Nutritional Contents of Dishes",
      "16. Machine Learning-Based Method for Recommending Exercises",
      "17. Exploratory Data Analysis and Artificial Intelligence-Based Trading Methodology for Securities and Cryptocurrency",
      "18. Recognition of Human Activity Using Ensemble Learning of Multiple Convolutional Neural Networks",
      "19. Using a Machine Learning Classifier to Evaluate the Reliability of Web Information Content",
      "20. An Evolution of Different Data Mining Techniques for Predicting Fake Job Posts",
      "21. Temperament Trait Classification from Text Using Deep Learning Algorithms",
      "22. Adaptive Multi-Agent AI System for Autonomous Cyber Threat Detection and Mitigation"
    ],
    "awards": [
      "BEST ACADEMICIAN OF THE YEAR, Bestow Edutrex International ARC (Award & Recognition Committee), 2021"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-nagaraju-regonda-b37125238",
      "researchGate": "https://www.researchgate.net/profile/Nagaraju-Regonda-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=0ArIhSUAAAAJ&hl=en&authuser=2",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57209642071",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/645061"
    }
  },
  {
    "id": "vitap-1744-cms",
    "name": "Dr. Jawahar Muthusamy",
    "employeeId": "10.70879",
    "designation": "Associate Professor Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "817 - K, CB",
    "email": "jawahar.muthusamy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Jawahar_Muthusamy_SCOPE_1e9dee73dc.avif",
    "education": [
      "B.E. (CSE) - Anna University",
      "M.E. (CSE) - Anna University",
      "CSE. - Anna University"
    ],
    "researchArea": "Cloud Computing, Network Security",
    "memberships": [
      "IEEE, ISTE"
    ],
    "projects": [],
    "patents": [
      "1. A System and Method for Privacy-Preserving Federated Model Aggregation Using Secure Multi-Node Learning Coordination",
      "2. Artificial Intelligence Based Nerve Activation Device for Healthcare Treatment",
      "3. An Automatic Processing 0f Medical Images Using Segmented K-Means Clustering Algorithm (SKCA) Based",
      "4. Optimization of Data Using Semi Supervised Learning in Cloud Environment Based on AI",
      "5. AI Based Plant Extract Analyzing Device to Identify Disease",
      "6. An image recognition based rotating television screen to adjust to the View of viewer",
      "7. Internet of things and intelligence environmental management and smart Agriculture system"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/jawahar-muthusamy-89413161",
      "researchGate": "https://www.researchgate.net/profile/Jawahar-Muthusamy",
      "googleScholar": "https://scholar.google.com/citations?user=SMGWSmQAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57210647444",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/576473"
    }
  },
  {
    "id": "vitap-1802-cms",
    "name": "Dr. Duvvuri Sri Satya Sita Rama Sarath Babu",
    "employeeId": "10.70944",
    "designation": "Associate Professor Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1016-E, CB",
    "email": "sarath.duvvuri@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Duvvuri_Sri_Satya_Sita_Rama_Sarath_Babu_SENSE_2ee7f095a6.avif",
    "education": [
      "B.Tech., Electrical & Electronics Engineering, Pondicherry University (a Central University) Puducherry, India",
      "M.Tech., Power Electronics & Drives, Vellore Institute of Technology Vellore, India",
      "PhD., Electrical Engineering, Indian Institute of Technology Hyderabad, India"
    ],
    "researchArea": "Fault Detection & Diagnosis, Non-linear State Estimation, Analysis of Electric Machinery & Drives",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Certificate of Research Excellence for Outstanding Research Performance for the academic years 2015 and 2016 from Indian Institute of Technology Hyderabad, Kandi, TS, India",
      "Certificate of Appreciation for Research in Electrical Engineering for the academic year 2018 from Indian Institute of Technology Hyderabad, Kandi, TS, India",
      "Received Best Paper Award for the research paper titled Tuning Reduced-order Error-based ADRC for FOPDT Processes using Magnitude Optimum Approach presented at 2024 1st IEEE International Conference on Computational Intelligence for Green & Sustainable Technologies (ICCIGST-2024), Organized by Department of EEE, V. R. Siddhartha Engineering College Vijayawada (An Institution Deemed to be university), AP, India",
      "Received Best Paper Award for the research paper titled Optimal Tuning and Implementation of Error-based Reduced-order ADRC presented at 2024 1st IEEE International Conference on Computational Intelligence for Green & Sustainable Technologies (ICCIGST-2024), Organized by Department of EEE, V. R. Siddhartha Engineering College Vijayawada (An Institution Deemed to be university), AP, India"
    ],
    "links": {
      "linkedin": "linkedin.com/in/dr-sarath-duvvuri-614905289",
      "researchGate": "https://www.webofscience.com/wos/author/rid/AAR-2679-2020",
      "googleScholar": "https://scholar.google.com/citations?user=WR4r0xoAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57907233900",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/147978"
    }
  },
  {
    "id": "vitap-1136-cms",
    "name": "Dr. Maddikera Kalyan Chakravarthi",
    "employeeId": "11.70011",
    "designation": "Associate Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": null,
    "email": "kalyanchakravarthi.m@vitap.ac.in",
    "phone": "5156",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70011_Dr_Maddikera_Kalyan_Chakravarthi_SENSE_1414_28ee2f3460.avif",
    "education": [
      "B.E. and Anna University",
      "M.Tech, M.S.- VIT University, UAS, Karlsruhe",
      "Ph.D, VIT University, Chennai"
    ],
    "researchArea": "Classical & Modern Control, Sensor-IoT & Embedded systems,Process Control, Nonlinear Control Systems,Automation & Data Acquisition",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "dblp": "https://dblp.org/pid/220/7927.html",
      "researchGate": "https://www.researchgate.net/profile/Kalyan-Chakravarthi-3",
      "googleScholar": "https://scholar.google.com/citations?user=S36rjOEAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0001-9913-8867",
      "scopus": "55308250400"
    }
  },
  {
    "id": "vitap-1220-cms",
    "name": "Dr. Rasheda Parveen",
    "employeeId": "11.70062",
    "designation": "Associate Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "G24-C, AB-2",
    "email": "rasheda.p@vitap.ac.in",
    "phone": "5581",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rasheda_Parveen_70062_IMG_2690_VISH_b7d9a53430.avif",
    "education": [
      "BA (English), Sambalpur University, Odisha.",
      "MA (English), Utkal University, Odisha.",
      "PhD (English), NIT Rourkela, Odisha."
    ],
    "researchArea": "English in India, Cultural Studies, Religious Studies, Sexuality and Gender.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=VpEWChEAAAAJ&hl=en",
      "orcid": "0000-0003-3196-768X"
    }
  },
  {
    "id": "vitap-1315-cms",
    "name": "Dr. Manoj Kumar Mishra",
    "employeeId": "11.70064",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G-31, AB-1",
    "email": "manoj.m@vitap.ac.in",
    "phone": "5443",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Manoj_Kumar_Mishra_SAS_MAT_1877_bdfd63f635.avif",
    "education": [
      "B.Sc. University of Allahabad",
      "M.Sc. IIT Guwahati",
      "Ph.D. IIT(ISM) Dhanbad"
    ],
    "researchArea": "Fluid Dynamics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Manoj-Mishra-10",
      "googleScholar": "https://scholar.google.com/citations?user=niebJDcAAAAJ&hl=en",
      "orcid": "0000-0002-7047-8830",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57210740085",
      "vidwan": "260407"
    }
  },
  {
    "id": "vitap-1137-cms",
    "name": "Dr. Ravi Sankar Barpanda",
    "employeeId": "11.70066",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "622 - O, CB",
    "email": "ravi.barpanda@vitap.ac.in",
    "phone": "5354",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ravi_Sankar_Barpanda_70066_IMG_4730_SCOPE_fd4ca8515d.avif",
    "education": [
      "B.E, Fakir Mohan University",
      "Master of Technology (by Research), NIT Rourkela",
      "CSE, NIT Rourkela"
    ],
    "researchArea": "Optical Networks, Optimization, and Evolutionary Computing",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Ravi-Barpanda",
      "googleScholar": "https://scholar.google.co.in/citations?user=RQefC38AAAAJ&hl=en",
      "orcid": "https://www.scopus.com/authid/detail.uri?authorId=35753238800"
    }
  },
  {
    "id": "vitap-1251-cms",
    "name": "Dr. Tannistha Dasgupta",
    "employeeId": "11.70083",
    "designation": "Associate Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "G24-B, AB-2",
    "email": "dasgupta.tannistha@vitap.ac.in",
    "phone": "5580",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Tannistha_Dasgupta_abb3eb49a2.avif",
    "education": [
      "BA (English Honours) University of Calcutta",
      "MA English, The English and Foreign Languages University (EFLU)",
      "PhD (ELT), The English and Foreign Languages University (EFLU)"
    ],
    "researchArea": "Language Assessment, Second Language Acquisition, Task-based Language Teaching, Technology-mediated Instruction",
    "memberships": [
      "1) SIETAR India (The Society for Intercultural Education Training and Research). 2)BCFAI (Business Communication Facilitators Association of India). 3)ELTAI (English Language Teacher’s Association of India). 4) IATEFL (International Association of Teachers of English as a Foreign Language), UK. 5) TESOL (Teaching English to Speakers of Other Languages), USA. 6) AALA (Asian Association for Language Assessment), China. 7) OPEN (Online Professional English Network) Community of Practice (CoP), USA"
    ],
    "projects": [
      "1. Designing Tasks Using Edpuzzle to Evaluate Listening and Speaking Skill of Engineering Students Pursuing Integrated Programme, VIT-AP University",
      "2. NME-ICT E-Content Development Programmes, UGC-MHRD"
    ],
    "patents": [],
    "awards": [
      "English Language Centre Eastbourne Graham Smith Scholarship, IATEFL, UK, 2022.",
      "OPEN Summer 2024 Program, U.S. Department of State, nominated by the US Consulate, Hyderabad, 2024.",
      "OPEN Winter 2021 Program"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/tannistha-dasgupta-95532910a/",
      "researchGate": "https://www.researchgate.net/profile/Dasgupta-Tannistha",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=t42zD2hLmAYC",
      "orcid": "0000-0002-9973-261X",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/213583"
    }
  },
  {
    "id": "vitap-1374-cms",
    "name": "Dr. Tufan Ghosh",
    "employeeId": "11.70127",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "125-D, AB-2",
    "email": "tufan.ghosh@vitap.ac.in",
    "phone": "5693",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Tufan_Ghosh_70127_IMG_2648_SAS_CHY_877d3f0252.avif",
    "education": [
      "B.Sc. in Chemistry, The University of Burdwan",
      "M.Sc. in Chemistry, IIT Madras",
      "Ph.D. in Chemistry, IIT Madras",
      "Postdoc - (1) The Hebrew University of Jerusalem, (2) Ruhr University Bochum"
    ],
    "researchArea": "Nano- and Material Chemistry, Solar Cells, Ultrafast Spectroscopy",
    "memberships": [],
    "projects": [
      "Charge Carrier Recombination Dynamics and Electron-Phonon Coupling in Two-Dimensional Lead Halide Perovskites, Funded by: SERB-DST"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "website": "https://sites.google.com/view/tufan-ghosh-vitap",
      "googleScholar": "ZVMt5vMAAAAJ",
      "orcid": "0000-0002-4898-2117",
      "scopus": "54784365700",
      "vidwan": "301700"
    }
  },
  {
    "id": "vitap-1378-cms",
    "name": "Dr. Sabeel M Basheer",
    "employeeId": "11.70159",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "G24-F, AB-2",
    "email": "sabeel.basheer@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sabeel_M_Basheer_70159_0224_492f382a52.avif",
    "education": [
      "B.Sc Chemistry, University of Calicut",
      "M.Sc, Bharathidasan University",
      "Ph.D, National Institute of Technology Tiruchirappalli, Research Scholar, Australian National University, Canberra; Research Fellow, IPRI, University of Wollongong; NPDF, University of Calicut",
      "Research Scholar, Australian National University, Canberra; Research Fellow, IPRI, University of Wollongong; NPDF, University of Calicut"
    ],
    "researchArea": "Coordination Chemistry, Analytical Chemistry, Molecular recognition, Computational Chemistry",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sabeel-m-basheer-04a29839/",
      "researchGate": "https://www.researchgate.net/profile/Sabeel_M_Basheer2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=GO5q53AAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57188749490"
    }
  },
  {
    "id": "vitap-1403-cms",
    "name": "Dr. Soumyakanta Prusty",
    "employeeId": "11.70176",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "125-I, AB-2",
    "email": "soumyakanta.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Soumyakanta_Prusty_70176_IMG_4771_SAS_e759523428.avif",
    "education": [
      "Utkal University, India",
      "Sambalpur University, India",
      "IIT Madras",
      "1. National Taiwan University, 2. NISER"
    ],
    "researchArea": "Coordination Chemistry, Supramolecular Chemistry",
    "memberships": [],
    "projects": [
      "1. Self-assembled metallo-cage integrated stimuli responsive soft materials. (29.3 lacs; funded by DST-SERB).(Ongoing)",
      "1. Development of light-induced supramolecular polymers emerged from coordination cages (1.99 lacs; funded by VIT-AP University)(Completed)"
    ],
    "patents": [],
    "awards": [
      "1. Best Thesis Award in Inorganic and Analytical Chemistry–2018, Indian Institute of Technology Madras, Chennai."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-soumyakanta-prusty-817b3662/",
      "researchGate": "https://www.researchgate.net/profile/Soumyakanta-Prusty-2",
      "googleScholar": "https://scholar.google.co.in/citations?user=uxfGNlkAAAAJ&hl=en",
      "vidwan": "https://vitap.irins.org/profile/262231"
    }
  },
  {
    "id": "vitap-1328-cms",
    "name": "Dr. Yada Nandukumar",
    "employeeId": "11.70192",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "307-J, AB-2",
    "email": "nandukumar.y@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Yada_Nandukumar_SAS_1540_459d23c876.avif",
    "education": [
      "Kakatiya University",
      "National institute of Technology Durgapur",
      "National institute of Technology Durgapur, Indian Institute of Technology Kharagpur",
      "Indian Institute of Technology Kharagpur"
    ],
    "researchArea": "Nonlinear Dynamics, Machine Learning, Deep Learning",
    "memberships": [
      "IMS, RMS"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/yada-nandukumar-522a3351/",
      "researchGate": "https://www.researchgate.net/profile/Yada-Nandukumar?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=VGMh6sYAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/home.uri?zone=header&origin=AuthorProfile",
      "vidwan": "https://vidwan.inflibnet.ac.in/myprofile"
    }
  },
  {
    "id": "vitap-1175-cms",
    "name": "Dr. Lalitha Kumari Pappala",
    "employeeId": "11.70277",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "615 - F, CB",
    "email": "lalitha.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Lalitha_Kumari_Pappala_IMG_6558_SCOPE_e74898f117.avif",
    "education": [
      "B.Tech, JNTUH",
      "M.Tech, JNTUK",
      "Data Mining, NIT Warangal"
    ],
    "researchArea": "Machine Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-lalitha-p-179b13227/",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=G4joEgcAAAAJ",
      "orcid": "https://orcid.org/0000-0003-3741-5771",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201675691"
    }
  },
  {
    "id": "vitap-1185-cms",
    "name": "Dr. Karthika Natarajan",
    "employeeId": "11.70279",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "623-N, CB",
    "email": "karthika.n@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Karthika_Natarajan_70279_IMG_4749_SCOPE_9aad991f24.avif",
    "education": [
      "National Institute of Technology, Tiruchirappalli-Tamilnadu",
      "M.E, Anna University",
      "information retrieval, Machine learning and Deep learning, National Institute of Technology, Trichy"
    ],
    "researchArea": "Artificial Intelligence, Machine Learning, Deep Learning, Information Retrieval and Extraction",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Karthika-Natarajan-5",
      "googleScholar": "https://scholar.google.com/citations?user=PQ3jMBMAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-6700-583X",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57202160674"
    }
  },
  {
    "id": "vitap-1182-cms",
    "name": "Dr. Sheela Jayachandran",
    "employeeId": "11.7028",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "615 - B, CB",
    "email": "sheela.j@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sheela_Jayachandran_70280_IMG_4740_SCOPE_9ab74147a2.avif",
    "education": [
      "B.E, Anna University",
      "M.E, Anna University",
      "Text Mining, National Insitute of Technology, Tiruchirappalli"
    ],
    "researchArea": "Text mining, NLP, Artificial Intelligence, Machine Learning, Deep Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/feed/?msgControlName=reply_to_sender&msgConversationId=2-MGE2ZThhNmUtZWJiYy00YjFmLTlmNGUtOGRjMTY4NDU5MTQyXzAxMA%3D%3D&msgOverlay=true&trk=false",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=sk9h_F8AAAAJ&view_op=list_works&sortby=pubdate",
      "orcid": "https://orcid.org/0000-0001-7840-9680",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57502910500"
    }
  },
  {
    "id": "vitap-1183-cms",
    "name": "Dr. Udit Narayana Kar",
    "employeeId": "11.70281",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "623-O, CB",
    "email": "Uditnarayana.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Udit_Narayana_Kar_SCOPE_IMG_7307_fe8dd9f3b4.avif",
    "education": [
      "B.Tech, Biju Pattanaik University of Technology",
      "M.Tech, Institute of Technical Education and Research",
      "Computer Science and Engineering, Kalinga Institute of Industrial Technology ( KIIT University)"
    ],
    "researchArea": "Computer Networks, Wireless Communication, 5G Cellular Netwoks and Beyond, Wireless Sensor Networks, Internet of Things",
    "memberships": [
      "Institute of Technical Education and Research"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "dblp": "https://dblp.org/pid/210/3272.html",
      "researchGate": "https://www.researchgate.net/profile/Udit-Kar",
      "googleScholar": "https://scholar.google.com/citations?user=fKEAT3MAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0003-4254-3866",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57195970673"
    }
  },
  {
    "id": "vitap-1194-cms",
    "name": "Dr. Monali Bordoloi",
    "employeeId": "11.70294",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "626 - O, CB",
    "email": "monali.b@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Monali_Bordoloi_IMG_6795_SCOPE_4dbfadd39a.avif",
    "education": [
      "B.E., G.I.M.T.",
      "M.Tech., National Intitute of Technology, Silchar",
      "CSE, National Institute of Technology, SIlchar"
    ],
    "researchArea": "Artificial Intelligence, NLP, Machine Learning, Data Analysis, Information Retrieval",
    "memberships": [
      "ACM"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-monali-bordoloi-a03781a9/",
      "researchGate": "https://www.researchgate.net/profile/Monali-Bordoloi",
      "googleScholar": "https://scholar.google.com/citations?user=Cw_6nyEAAAAJ&hl=en&oi=ao",
      "orcid": "https://orcid.org/0000-0002-0685-9268",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57191193037"
    }
  },
  {
    "id": "vitap-1348-cms",
    "name": "Dr. Sukanta Nayak",
    "employeeId": "11.70305",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "225-K, AB-2",
    "email": "sukanta.nayak@vitap.ac.in",
    "phone": "5724",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sukanta_Nayak_70305_IMG_2551_SAS_MAT_cbd2608e11.avif",
    "education": [
      "B. Sc. & Sambalpur University",
      "M. Sc. & National Institute of Technology Rourkela",
      "Ph. D. & National Institute of Technology Rourkela",
      "PDRF & University of Johannesburg, South Africa"
    ],
    "researchArea": "Numerical Analysis, Differential Equations, Fuzzy Sets and Uncertainties, Artificial Intelligence and Machine Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1350-cms",
    "name": "Dr.Davala Ravi Kumar",
    "employeeId": "11.70357",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "125-F, AB-2",
    "email": "ravikumar.davala@vitap.ac.in",
    "phone": "5470",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Davala_Ravi_Kumar_70357_0487_c62a46a9ac.avif",
    "education": [
      "Andhra University",
      "Indian Institute of Technology Kanpur",
      "National Institute of Technology Rourkela"
    ],
    "researchArea": "Number Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=34P8448AAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56662200700",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/258704"
    }
  },
  {
    "id": "vitap-1367-cms",
    "name": "Dr. Debakanta Tripathy",
    "employeeId": "11.70373",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "615 - J, CB",
    "email": "debakanta.tripathy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70373_Dr_Debakanta_Tripathy_1041_a42653a04d.avif",
    "education": [
      "B.Sc Chemistry, Utkal University",
      "M. Sc. Chemistry, Utkal University",
      "PhD, IIT Madras, Fujian Institute of Research on the Structure of Matter, Chinese Academy of Sciences, Fujian, China",
      "Fujian Institute of Research on the Structure of Matter, Chinese Academy of Sciences, Fujian, China"
    ],
    "researchArea": "Supramolecular Chemistry, Metal driven self-assembly",
    "memberships": [
      "1.Life Member-Chemical Research Society of India, Life Member-Material Research Society of India, Life Member-Indian Science Congress Association, Patron Member-Odisha Chemical Society"
    ],
    "projects": [
      "1. Design and development of metal complexes as small molecule DNA intercalator, RGEMS, VIT-AP University",
      "2. Design and Synthesis of Pt(II) Based Macrocyclic Host for Selective Recognition of Aromatic Hydrocarbon, National Project Implementation Unit (NPUI), MHRD, Government of India."
    ],
    "patents": [],
    "awards": [
      "Canadian Commonwealth Scholarship, March 2011-August 2011, CBIE-DFAIT, Government of Canada"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=nMD9EbcAAAAJ&view_op=list_works&sortby=pubdate",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=36905745800",
      "vidwan": "https://vidwan.inflibnet.ac.in/myprofile"
    }
  },
  {
    "id": "vitap-1425-cms",
    "name": "Dr. C Siva Kumar Reddy",
    "employeeId": "11.70382",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": null,
    "email": "sivakumar.reddy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_C_Siva_Kumar_Reddy_SAS_1424_ef9c555cc2.avif",
    "education": [
      "BSc Sri Venkateswara university",
      "MSc Andhra University",
      "PhD Indian institute of Science Bangalore",
      "Masdar Institute, UAE and Ben Gurion University Israel"
    ],
    "researchArea": "Carbon nanotubes, Graphene, MXenes and Composites",
    "memberships": [
      "MRS India"
    ],
    "projects": [
      "1. Triboelectric Nano generator based on MXene Ink for Self-Powered Weighing Sensor- SERB-SRG",
      "2. Mechanical Characterization of MXene nano-composites-RGEMS-VIT AP University"
    ],
    "patents": [],
    "awards": [
      "Marie Curie Research Fellowship- 2023"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-siva-kumar-406a7954?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BKUUmtHDaQhedOZHtKhEXJQ%3D%3D",
      "website": "https://vitap.irins.org/profile/257288",
      "googleScholar": "https://scholar.google.co.in/citations?user=LWE9xRYAAAAJ&hl=en",
      "orcid": "0000-0002-8640-2128",
      "scopus": "http://www.scopus.com/authid/detail.url?authorId=55786160800",
      "vidwan": "https://vitap.irins.org/profile/257288"
    }
  },
  {
    "id": "vitap-1217-cms",
    "name": "Dr. Chandan Nayak",
    "employeeId": "11.70396",
    "designation": "Associate Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "328-E, AB-1",
    "email": "chandan.nayak@vitap.ac.in",
    "phone": "5416",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Chandan_Nayak_SENSE_0826_4735f82ad0.avif",
    "education": [
      "B. Tech. in EIE from Biju Patnaik University of Technology",
      "M. Tech. in ECE from Biju Patnaik University of Technology",
      "Ph.D. in Biomedical Signal Processing from NIT Raipur"
    ],
    "researchArea": "Bio-medical Signal Processing, Internet of Medical Things, Artificial Intelligence, Wearable Healthcare Monitoring, Fractional Order Filter Design",
    "memberships": [
      "Life member of the Institution of Electronics & Telecommunication Engineers-M 500134"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Chandan-Nayak-5",
      "googleScholar": "https://scholar.google.co.in/citations?user=5u-UY3IAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0003-1025-8737",
      "scopus": "https://www.webofscience.com/wos/author/record/AAI-6546-2020"
    }
  },
  {
    "id": "vitap-1237-cms",
    "name": "Dr. Siddique Ibrahim Peer Mohamed",
    "employeeId": "11.70399",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "620-B, CB",
    "email": "siddique.ibrahim@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Siddique_Ibrahim_Peer_Mohamed_70399_0248_168d1d488a.avif",
    "education": [
      "B.E, Anna University",
      "M.E, Anna University",
      "Computer Science, VIT University"
    ],
    "researchArea": "Data Analytics, Big Data Technologies, Data Mining, Artificial intelligence, Deep learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "website": "https://siddiqueskills.wordpress.com/",
      "googleScholar": "https://scholar.google.com/citations?user=ERdlJ4wAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57216902835"
    }
  },
  {
    "id": "vitap-1238-cms",
    "name": "Dr. Selva Kumar S",
    "employeeId": "11.70401",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "G05, AB-2",
    "email": "selvakumar.s@vitap.ac.in",
    "phone": "5819",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Selva_Kumar_S_70401_0216_4a8cc4488b.avif",
    "education": [
      "M.Sc - Computer Science Technology (5 Years), Anna University",
      "Master of Engineering in Computer Science and Engineering, Anna University",
      "Vellore Institute of Technology (VIT) - Vellore"
    ],
    "researchArea": "Elastic Optical Network (EON), Computer Vision and Image Processing, Optimization Techniques, Data Science and Operating Systems",
    "memberships": [
      "IAENG"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "linkedin.com/in/dr-selva-kumar-s-6b979483",
      "researchGate": "https://www.researchgate.net/profile/Selvakumar-S-2",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=kFpyvfkAAAAJ",
      "orcid": "https://orcid.org/0000-0002-0269-198X",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57214975149"
    }
  },
  {
    "id": "vitap-1395-cms",
    "name": "Dr. Triveni Rajashekhar Mandlimath",
    "employeeId": "11.7042",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "224-I, AB-2",
    "email": "triveni.mandlimath@vitap.ac.in",
    "phone": "5834",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70420_Dr_Triveni_Rajashekhar_Mandlimath_CHY_1225_72d40a2ac4.avif",
    "education": [
      "B.Sc., Kuvempu University",
      "M.Sc., Kuvempu University, Shankaraghatta, Shimoga",
      "Ph.D., VIT University, Vellore"
    ],
    "researchArea": "Development of nanomaterials for catalysis, photocatalysis, electrocatalysis, sensing and pigment applications.",
    "memberships": [
      "Materials Research Society of India and INDIAN SOCIETY FOR TECHNICAL EDUCATION"
    ],
    "projects": [
      "Design and development of novel heterojunction nano photocatalysts for water purification under visible light irradiation."
    ],
    "patents": [
      "Method of Preparation of Langbeinite Phosphosilicates Thereof, No.202041035310 A"
    ],
    "awards": [
      "RESEARCHER AWARD, VIT University Vellore, 2014 and CSIR SRF, CSIR, 2012"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/triveni-mandlimath-603556144/",
      "researchGate": "https://www.researchgate.net/scientific-contributions/Triveni-Rajashekhar-Mandlimath-2047690031",
      "googleScholar": "https://scholar.google.co.in/citations?user=uN0IPa8AAAAJ",
      "orcid": "https://www.orcid.org/0000-0003-3137-2838",
      "vidwan": "304097"
    }
  },
  {
    "id": "vitap-1248-cms",
    "name": "Dr. Praveen Maurya",
    "employeeId": "11.70425",
    "designation": "Associate Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "106, AB-1",
    "email": "praveen.maurya@vitap.ac.in",
    "phone": "5839",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Praveen_Maurya_SENSE_0857_330685f720.avif",
    "education": [
      "B.Tech & Dr. A.P.J. Abdul Kalam Technical University Lucknow",
      "M.Tech & IIT (ISM) Dhanbad",
      "PhD & IIT (ISM) Dhanbad"
    ],
    "researchArea": "Microwave, Instrumentation, MEMS, Optical communication and Electronics Communication",
    "memberships": [
      "IEEE, OSA, SPIE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Praveen-Maurya-3",
      "googleScholar": "https://scholar.google.com/citations?user=lZemeVAAAAAJ&hl=en",
      "orcid": "0000-0002-8925-2938",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=23493173600"
    }
  },
  {
    "id": "vitap-1431-cms",
    "name": "Dr. Sachil Sharma",
    "employeeId": "11.70427",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "813 - H, CB",
    "email": "sachil.sharma@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sachil_Sharma_70427_IMG_2542_SAS_ee3d509e6e.avif",
    "education": [
      "B.Sc. H.P.U. Shimla",
      "M.Sc. M.D.U. Haryana",
      "1. Ph.D. IIT Kanpur, 2.Dept. of Applied Chemistry, Tokyo University of Science, Tokyo, Japan, 3. Dept. of Chemistry, Yonsei University, Seoul, S. Korea, 4. Dalian Institute of Chemical Physics, Chinese Academy of Sciences (CAS)",
      "1.Dept. of Applied Chemistry, Tokyo University of Science, Tokyo, Japan, 2. Dept. of Chemistry, Yonsei University, Seoul, S. Korea, 3. Dalian Institute of Chemical Physics, Chinese Academy of Sciences (CAS)"
    ],
    "researchArea": "Ligand protected Metal nanoparticles and Metal Nanoclusters for Energy applications",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "1. CSIR-UGC Junior Research Fellowship (JRF) award (01.01.2004 to 31.12.2005) and CSIR-UGC Senior Research Fellowship (SRF) award (01.01.2006 to 31.12.2008)"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Sachil-Sharma",
      "googleScholar": "https://scholar.google.com/citations?user=WyfjHJ4AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57203101904",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/301707"
    }
  },
  {
    "id": "vitap-1247-cms",
    "name": "Dr. Prashanth Rajam",
    "employeeId": "11.70438",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "620-G, CB",
    "email": "prashanth.rajam@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Prashanth_Rajam_70438_0168_c8422627db.avif",
    "education": [
      "B.Tech, JNTU Hyderabad",
      "B.Tech, JNTU Hyderabad",
      "IoT and ML, NIT Rourkela"
    ],
    "researchArea": "Internet of Things (IoT), Machine Learning, Embedded Systems, Wireless Sensor Network, Industrial Automation",
    "memberships": [
      "International Association of Computer Science and Information Technology, South Asia Institute of Science and Engineering, Institute of Researcher Engineers and Doctors"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-prashanth-rajam-85740082/",
      "researchGate": "https://www.researchgate.net/profile/Prashanth-Ragam",
      "googleScholar": "https://scholar.google.com/citations?user=p_TxBhAAAAAJ&hl=en",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0001-7574-976X",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57210153200"
    }
  },
  {
    "id": "vitap-1417-cms",
    "name": "Dr. Ganesh Kotagiri",
    "employeeId": "11.70452",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "104-E, CB",
    "email": "ganesh.kotagiri@vitap.ac.in",
    "phone": "5876",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ganesh_Kotagiri_SAS_1421_9c2a0b2400.avif",
    "education": [
      "B.Sc., Osmania University",
      "M.Sc (Physics)., Osmania University",
      "Ph.D (Experimental Condensed Matter Physics)., IIT Madras",
      "Experimental Condensed Matter Physics, IIT Kanpur"
    ],
    "researchArea": "Experimental Condensed Matter Physics (Magnetic Materials)",
    "memberships": [
      "1) Magnetics Society of India (MSI), 2) Materials Research Society of India (MRSI)"
    ],
    "projects": [
      "1) Magnetoimpedance studies on nanocrystalline melt-spun ribbons for biomedical applications (VIT-AP University-RGEMS)"
    ],
    "patents": [],
    "awards": [
      "All-India-rank: 242 in CSIR-UGC-December – 2009 for Junior research fellowship.",
      "All-India-rank: 244 in Graduate Aptitude Test in Engineering (GATE) – 2010.",
      "Best paper award in National Conference on Advances in Naval materials at NIOT Chennai-2013."
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/ganesh-kotagiri-62b3b980",
      "researchGate": "https://www.researchgate.net/profile/Ganesh-Kotagiri",
      "googleScholar": "https://scholar.google.co.in/citations?user=b2dXAr4AAAAJ",
      "orcid": "0000-0003-1861-4580",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56092656700",
      "vidwan": "https://vitap.irins.org/profile/299998"
    }
  },
  {
    "id": "vitap-1253-cms",
    "name": "Dr. Chirra Venkata Ramireddy",
    "employeeId": "11.70459",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "615 - C, CB",
    "email": "venkataramireddy.chirra@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Chirra_Venkata_Ramireddy_SCOPE_1568_e9e851d38d.avif",
    "education": [
      "B.Tech, JNTUH",
      "M.Tech, Vignan's Foundation for Science, Technology and Research University",
      "Computer Applications, National Institute of Technology, Trichy"
    ],
    "researchArea": "Computer Vision, Image Processing, Machine Learning, Deep Learning, Data Analytics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "linkedin.com/in/dr-venkata-rami-reddy-chirra-64971a11b",
      "researchGate": "https://www.researchgate.net/profile/Venkata-Ch-2",
      "googleScholar": "https://scholar.google.co.in/citations?user=6BqobbcAAAAJ",
      "orcid": "https://orcid.org/0000-0002-4381-9097",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57200086816"
    }
  },
  {
    "id": "vitap-1418-cms",
    "name": "Dr. Narendra Nath Dutta",
    "employeeId": "11.70467",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "128-A, CB",
    "email": "narendranath.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Narendra_Nath_Dutta_70467_IMG_2556_SAS_PHY_4db9e6b324.avif",
    "education": [
      "B.Sc. in Physics, University of Burdwan, India",
      "M.Sc. in Physics, University of Burdwan, India",
      "Ph.D., IIT Kharagpur, India",
      "Senior Project Officer, IIT Madras, India; Postdoctoral Researcher, Auburn University, USA; Postdoctoral Fellow, IISER Mohali, India"
    ],
    "researchArea": "Theoretical Atomic and Molecular Physics, Quantum Many-Body Theory, Computational Chemistry",
    "memberships": [
      "ISAMP"
    ],
    "projects": [
      "1) Accurate Calculations of Spectroscopic and Structural Properties of Superheavy Elements, Funded by SERB-ANRF-CRG"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/narendra-nath-dutta-54bb01313/",
      "researchGate": "https://www.researchgate.net/profile/Narendra-Dutta-2",
      "googleScholar": "https://scholar.google.com/citations?user=TgyXV4UAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=48561056900",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/196481"
    }
  },
  {
    "id": "vitap-1259-cms",
    "name": "Dr. M M Venkata Chalapathi",
    "employeeId": "11.70469",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "312, CB",
    "email": "mmv.chalapthi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_M_M_Venkata_Chalapthi_SCOPE_1936_83dbc2cfc3.avif",
    "education": [
      "B. Tech, Jawaharlal Nehru Technological University Hyderabad",
      "M. Tech, Jawaharlal Nehru Technological University Anantapur",
      "Computer Science and Engineering, Sri Sathya Sai University of Technology and Medical Sciences, Sehore"
    ],
    "researchArea": "Artificial Intelligence, Ensemble Learning, Human Computer Interaction, Data Analytics, Operating Systems",
    "memberships": [
      "Institution of Engineers India"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-m-m-venkata-chalapathi-589897247",
      "googleScholar": "https://scholar.google.com/citations?user=Woyisv8AAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0001-5528-7844",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57211903586"
    }
  },
  {
    "id": "vitap-1264-cms",
    "name": "Dr. Kareemulla Shaik",
    "employeeId": "11.70474",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "812 - L, CB",
    "email": "Kareemulla.shaik@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kareemulla_Shaik_70474_IMG_4759_SCOPE_0653903507.avif",
    "education": [
      "B.Tech, JNTUH",
      "M.Tech, JNTUK",
      "Computer Science and Engineering, Koneru Lakshmaiah Education Foundation"
    ],
    "researchArea": "Computer Networks and Security",
    "memberships": [
      "IAENG, CSTA"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-kareemulla-shaik-48242149/",
      "researchGate": "https://www.researchgate.net/scientific-contributions/Kareemulla-Shaik-2190073651",
      "googleScholar": "https://scholar.google.co.in/citations?hl=en&user=pG-lQWsAAAAJ",
      "orcid": "https://orcid.org/0000-0001-8938-2452",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57200547572"
    }
  },
  {
    "id": "vitap-1269-cms",
    "name": "Dr. Radha Mohan Pattanayak",
    "employeeId": "11.70475",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "620-A, CB",
    "email": "radhamohan.pattanayak@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Radha_Mohan_Pattanayak_70475_IMG_4967_SCOPE_71ebb26cad.avif",
    "education": [
      "B.E, Biju Pattnaik University of Technology",
      "M.Tech, Berhampur University",
      "Veer Surendra Sai University of Technology (VSSUT), Burla, Odisha"
    ],
    "researchArea": "Machine Learning",
    "memberships": [
      "International Association of Engineers (IAENG)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-radha-mohan-pattanayak-aa940b52/",
      "dblp": "https://dblp.dagstuhl.de/pid/283/4755.html",
      "researchGate": "https://www.researchgate.net/profile/Radha_Pattanayak",
      "googleScholar": "https://scholar.google.com/citations?user=NPokoGoAAAAJ&hl=vi",
      "orcid": "https://orcid.org/0000-0003-3053-4858",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201672193"
    }
  },
  {
    "id": "vitap-1449-cms",
    "name": "Dr. Moru Satyanarayana",
    "employeeId": "11.70485",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "621-D, CB",
    "email": "satyanarayana.moru@vitap.ac.in",
    "phone": "5896",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70485_Dr_Moru_Satyanarayana_CHY_1337_c279097199.avif",
    "education": [
      "B.Sc. - Kakatiya University",
      "M.Sc. (Chemistry) - NIT Warangal",
      "Ph.D. (Chemistry) - NIT Warangal",
      "Iowa State University-USA, National Taiwan University-Taiwan & Indian Institute of Technology (IIT) Madras, India"
    ],
    "researchArea": "Point-of-Care Electrochemical Sensors & Electrocatalysts for Sustainable Energy Conversion",
    "memberships": [
      "Life Member : Indian Society for ElectroAnalytical Chemistry (ISEAC)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://in.linkedin.com/in/dr-satyanarayana-moru-ab332674",
      "website": "https://msnresearchgroup.wixsite.com/dr--moru-s-lab",
      "researchGate": "https://www.researchgate.net/profile/Dr-Satyanarayana-Moru",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=cQb_90AAAAAJ&view_op=list_works&authuser=1&sortby=pubdate",
      "orcid": "0000-0003-4301-0383",
      "scopus": "57954576100",
      "vidwan": "176707"
    }
  },
  {
    "id": "vitap-1442-cms",
    "name": "Dr. Manimaran",
    "employeeId": "11.70497",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G24-G, AB-2",
    "email": "manimaran.a@vitap.ac.in",
    "phone": "5961",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70497_Dr_Manimaran_MAT_1280_83bcdddd47.avif",
    "education": [
      "B.Sc (Physics), Bharathidasan University",
      "MCA., Anna University",
      "Ph.D., Bharathidasan University"
    ],
    "researchArea": "Data Science, Machine Learning, Computer Vision, Deep Learning, Natural Language Processing.",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. \"\"SENSOR BASED INTELLIGENT WEARABLE HELMET FOR EARLY DETECTION OF STROKE IN PATIENTS\" & ‭202141044803\"",
      "‬,2. \"\"WEARABLE SWEAT SENSOR BASED INTELLIGENT DEVICE TO DETECT THE STRESS LEVELS OF A PATIENT BY MONITORING CORTISOL AND BLOOD GLUCOSE LEVELS\"\" & 202141053048\""
    ],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/profmanimaran",
      "researchGate": "https://www.researchgate.net/profile/A-Manimaran",
      "googleScholar": "https://scholar.google.com/citations?user=RaRoGkUAAAAJ&hl=en&authuser=1",
      "orcid": "https://orcid.org/0000-0002-5671-9466",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57211311577",
      "vidwan": "https://vitap.irins.org/profile/367374"
    }
  },
  {
    "id": "vitap-1473-cms",
    "name": "Dr. Madhusmita Mohanty",
    "employeeId": "11.70507",
    "designation": "Associate Professor Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "425 C, AB-1",
    "email": "madhusmita.m@vitap.ac.in",
    "phone": "5405",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70507_Dr_Madhusmita_Mohanty_VSB_1173_5d22785407.avif",
    "education": [
      "BA(Economics & Staststics)/ Sambalpur University, Odisha",
      "MBA (Finance & Marketing)/ ICFAI University, Dehradun",
      "Ph.D (Financial Market) National Institute of Technology, Rourkela, Odisha, India"
    ],
    "researchArea": "Security Analysis, Portfolio Management, Project Analysis and Control Systems, Financial Analytics, and Financial Modelling",
    "memberships": [
      "AFA (American Financial Association), Orissa Economics Association"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-madhusmita-mohanty-40470b95?utm_source=share_via&utm_content=profile&utm_medium=member_android",
      "dblp": "Madhusmita Mohanty - IEEE Xplore Author Profile",
      "researchGate": "Madhusmita Mohanty (researchgate.net)",
      "googleScholar": "https://scholar.google.com/citations?user=Q3X268YAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0001-5616-7246"
    }
  },
  {
    "id": "vitap-1309-cms",
    "name": "Dr. Sambhudutta Nanda",
    "employeeId": "11.70514",
    "designation": "Associate Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "314-E, AB-1",
    "email": "sambhudutta.n@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70514_Dr_Sambhudutta_Nanda_SENSE_1316_7515944399.avif",
    "education": [
      "B Tech, BPUT Odisha",
      "M Tech, Berhampur University, Odisha",
      "Ph.D, NIT ROURKELA"
    ],
    "researchArea": "Microwave Theory and Techniques, Antenna Design, IoT, AI&ML",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-sambhudutta-nanda-75894650/",
      "googleScholar": "https://scholar.google.co.in/citations?hl=en&user=sxYlvI0AAAAJ",
      "orcid": "https://orcid.org/0000-0002-6541-8868",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57196828524",
      "vidwan": "https://vitap.irins.org/profile/272683"
    }
  },
  {
    "id": "vitap-1423-cms",
    "name": "Dr. M.Muneeswaran",
    "employeeId": "11.70519",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "128-G, CB",
    "email": "muneeswaran.m@vitap.ac.in",
    "phone": "5840",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70519_Dr_M_Muneeswaran_PHY_1374_b0f4db85ed.avif",
    "education": [
      "Gandhigram Rural University, Dindugal, Tamilnadu",
      "National Institute of Technology, Trichirappalli, Tamilnadu",
      "National Institute of Technology, Trichirappalli, Tamilnadu",
      "Institute of Physics, India (Nov-2015 to May-2016), Brain Korea Fellowship, Pukyong National University, South Korea (July-2016 to Feb 2018), Dr. D. S. Kothari Post doctoral Fellowship, University of Madras, India (March-2018 to July-2018), FONDECYT Post Doctoral Fellowship, University of Chile, Chile (July 2018 to Jan 2021), Brain Korea Fellowship, Pukyong National University, South korea (Jan-20121 to Feb-2022)"
    ],
    "researchArea": "Multiferroics, Ferroelectrics, Piezoelectrics, Magnetic Nanoparticles, and Energy storage applications",
    "memberships": [],
    "projects": [
      "\"\"\"Enriched antiferroelectric phase stability in heterovalent co-doped AgNbO3 based ceramics and their enhanced energy storage applications\"\". SERB, Research grant: 43.8 L, Duration: 3 Years"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=AF7rTUsAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-8259-0141"
    }
  },
  {
    "id": "vitap-1354-cms",
    "name": "Dr. Rafael Gonzalez Macho",
    "employeeId": "11.70521",
    "designation": "Associate Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "G 24-I, AB-2",
    "email": "rafael.gonzalez@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rafael_Gonzalez_Macho_1517_60d08f784a.avif",
    "education": [
      "Licenciatura - Universidad Complutense de Madrid, Spain",
      "Diploma of Advanced Studies - UNED, Spain",
      "PhD - UNED, Spain"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "website": "https://vit-in.academia.edu/RAFAELGONZALEZMACHO"
    }
  },
  {
    "id": "vitap-1428-cms",
    "name": "Dr. Sudharshan Vadnala",
    "employeeId": "11.70525",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "813 - C, CB",
    "email": "sudharshan.v@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sudharshan_Vadnala_SAS_0939_9238fd83b2.avif",
    "education": [
      "Kakatiya University",
      "Osmania University",
      "IIT Hyderabad",
      "IIT Bombay-INDIA and UMBC-Baltimore County -USA"
    ],
    "researchArea": "\"CMR manganites, Magnetocaloric effect, Study of material for IR detector Microfabrication using MEMS technology. Nanofibers fabrication using Electrospinning. Zinc based batteries with polymer electrolyte\"",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Excellence in Research Award, IIT Hyderabad, 2015"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sudharshan-v-23a03729/?originalSubdomain=in",
      "researchGate": "https://www.researchgate.net/profile/Sudharshan-Vadnala",
      "googleScholar": "https://scholar.google.co.in/citations?user=gl8HVooAAAAJ&hl=en",
      "orcid": "0000-0003-0466-9310",
      "scopus": "56139724200",
      "vidwan": "272925"
    }
  },
  {
    "id": "vitap-1460-cms",
    "name": "Dr. Muthu Prabhu S",
    "employeeId": "11.70542",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "621 - E, CB",
    "email": "muthuprabhu.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70542_Dr_Muthu_Prabhu_S_CHY_1362_ded2fcd000.avif",
    "education": [
      "B.Sc., Chemistry - The Gandhigram Rural Institute - Deemed to be University",
      "M.Sc., Chemistry - The Gandhigram Rural Institute - Deemed to be University",
      "Ph.D. Chemistry - The Gandhigram Rural Institute - Deemed to be University",
      "i) Jan 2021 - Dec 2022 - Research Assistant Professor, Hanyang University, Seoul, S. Korea. ii) Sep 2019 - Nov 2020 - Senior Postdoctoral Fellow, Alagappa University, Karaikudi, India. iii) Oct 2018 - Sep 2019 - Postdoctoral Research Associate, Kyungpook National University, S. Korea. iv) Sep 2016 - Aug 2018 - JSPS Postdoctoral Fellow, Kyushu University, Fukuoka, Japan. v) Dec 2015 -June 2016 - Postdoctoral Fellow, Yonsei University, Seoul, S. Korea"
    ],
    "researchArea": "Adsorption of toxins - Photodegradation - Supercapacitor.",
    "memberships": [],
    "projects": [
      "1. Removal of ECs from water using sponging materials by RGEMS, VIT-AP University, India (Ongoing)",
      "2. Removal of arsenic and fluoride from water using functionalized materials by JSPS, Kyushu University, Japan.",
      "3. MOFs-derived carbons for photoelectrochemical reduction of CO2 by BP scheme, Hanyang University, South Korea"
    ],
    "patents": [
      "1. Metal-graphene hybrid material for removing arsenic adsorption and its preparation method, and adsorption removal method of arsenic ion using the same”, Korea Patent Publication No: 10-2224990, March 03, 2021.",
      "2. Lanthanum-alkoxide hybrid material for removing toxic anions adsorption and its preparation method, and adsorption removal method of toxic anions using the same”, Korea Patent Publication No. 10-2242608, April 15, 2021",
      "3. Zirconium-alkoxide hybrid material for removing toxic anion adsorption and its preparation method, and adsorption removal method of toxic anions using the same”, Korea Patent Publication No. 10-2242610, April 15, 2021"
    ],
    "awards": [
      "Awarded Brain Pool Fellowship (formerly KRF) at Hanyang University, Seoul, South Korea (2019)",
      "Awarded Senior Post-Doctoral Fellowship at Alagappa University, Karaikudi, Tamil Nadu, India (2019)",
      "Awarded Dr. DS Kothari Post-Doctoral Fellowship (Application ID CH/17-18/0177) by UGC, New Delhi (2018)",
      "Awarded JSPS-Post-Doctoral Fellowship (P16082) at Kyushu University, Fukuoka, Japan (2016)",
      "Selected one among 15 Indian researchers in India to participate in IGCS Winter School at Madras (IITM), Chennai (2015)",
      "Best Poster presentation award (I prize) at International Conference at NIOT, Chennai (2014)",
      "UGC-Senior Research Fellow - Awarded by UGC-Research Fellowship in Sciences for Meritorious Students (2014)",
      "UGC-Junior Research Fellow - Awarded by UGC-Research Fellowship in Sciences for Meritorious Students (2012)",
      "Selected for Summer Training Programme in Chemistry-2010 (STPIC-2010), in Tamil Nadu level, conducted by Department of Inorganic Chemistry, University of Madras, Chennai (Sponsored by the Science City) on May-June (2010)"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/subbaiah-muthu-prabhu-a10762ba/",
      "website": "https://sites.google.com/view/muthuprabhu/home?authuser=0",
      "researchGate": "https://www.researchgate.net/profile/Muthu-Prabhu-Subbaiah",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=D3A13LgAAAAJ&view_op=list_works&sortby=pubdate",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0003-1553-3136",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=7101753878",
      "vidwan": "365231"
    }
  },
  {
    "id": "vitap-1347-cms",
    "name": "Dr. Mohit Kumar",
    "employeeId": "11.70562",
    "designation": "Associate Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "328-J, AB-1",
    "email": "mohitkumar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Mohit_Kumar_70562_IMG_4732_SENSE_7e34dd7322.avif",
    "education": [
      "B.Tech. in Electronics & Communication Engineering, UP technical University",
      "M.E. in Electronics Instrumentation & Control Engineering, Thapar university",
      "Ph.D. in Biomedical Signal Processing, IIT Indore"
    ],
    "researchArea": "Biomedical Signal Processing",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&view_op=list_works&gmla=AH70aAVBvgAQpG7MD5fGiOcyNm6ChQsLsSGK0KaNWdOtizgUj7uledCXmcn_GxIvmWoxVtI5fLfhJmheDDDAKDJtd7E4z1zv6CTokNH6Q7g&user=0wX6cDEAAAAJ",
      "orcid": "https://orcid.org/0000-0002-3355-8815",
      "scopus": "5249081",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/365279"
    }
  },
  {
    "id": "vitap-1351-cms",
    "name": "Dr. G D V Santhosh Kumar",
    "employeeId": "11.70563",
    "designation": "Associate Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "166, AB-1",
    "email": "santhosh.gdv@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_G_D_V_Santhosh_Kumar_70563_IMG_2652_SENSE_894843e956.avif",
    "education": [
      "B.Tech in Electronics and Communications Engineering, JNTU Hyderabad",
      "M.Tech in Integrated Circuit Technology, University of Hyderabad",
      "PhD in Electrical Engineering, IIT Hyderabad"
    ],
    "researchArea": "Digital VLSI Systems Design using FPGA/ASIC, Biomedical Micro Devices, GaN based Devices, Flexible Electronics, Electro Chemical Sensors",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com.sg/citations?hl=en&user=EKDO9VYAAAAJ",
      "orcid": "0000-0002-9703-3233",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57205631444"
    }
  },
  {
    "id": "vitap-1445-cms",
    "name": "Dr. Mohan Allam",
    "employeeId": "11.7063",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "618 - E, CB",
    "email": "mohan.allam@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70630_Dr_Mohan_Allam_SCOPE_1260_e3485b7a91.avif",
    "education": [
      "B.Tech, JNTUH",
      "M.Tech, JNTUH",
      "Ph.D. in Computer Science & Engineering, Pondicherry University"
    ],
    "researchArea": "Soft Computing",
    "memberships": [
      "ACM (4677725)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-mohan-allam-84786ba7/",
      "researchGate": "https://www.researchgate.net/profile/Mohan-Allam",
      "googleScholar": "https://scholar.google.co.in/citations?user=cH-reZsAAAAJ&hl=en",
      "orcid": "0000-0002-3117-6047",
      "scopus": "57205217437",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/148104"
    }
  },
  {
    "id": "vitap-1517-cms",
    "name": "Dr. Kosuri Yellareswararao",
    "employeeId": "11.70656",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "125-L, AB-2",
    "email": "yellareswararao.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kosuri_Yellareswararao_70656_IMG_4936_SAS_PHY_b6e8ec85fe.avif",
    "education": [
      "B.Sc , Acharya Nagarjuna University",
      "M.Sc Physics, Sri Venkateswara University College Tirupathi Andhra Pradesh",
      "PhD and Indian Institute of Science Bangalore, Karnataka India",
      "National Physical Laboratory New Delhi , Jawaharlal Nehru center for Advanced scientific Research ( JNCASR) Bangalore"
    ],
    "researchArea": "Material Science, Thin film sensors, Li-ion batteries, Electronic waste Recycling",
    "memberships": [
      "American Vacuum Society ( AVS) , USA"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=6IeOxM8AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1525-cms",
    "name": "Dr. Rajan Deorao Lanjekar",
    "employeeId": "11.70662",
    "designation": "Associate Professor Grade 1",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "328-B, AB-1",
    "email": "rajan.lanjekar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rajan_Deorao_Lanjekar_SMEC_1868_e86203e575.avif",
    "education": [
      "B.E., Government College of Engineering Chandrapur",
      "M.Tech., Indian Institute of Technology Bombay",
      "Ph.D., Indian Institute of Technology Indore",
      "Indian Institute of Science"
    ],
    "researchArea": "Internal Combustion Engines, Emissions, Fuels, Droplet and Spray",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=hrZFjT0AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1537-cms",
    "name": "Dr. Naresh Babu Muddhangala",
    "employeeId": "11.70676",
    "designation": "Associate Professor Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "425-H, AB1",
    "email": "nareshbabu.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Naresh_Babu_Muddhangala_70676_0245_4549f3c49f.avif",
    "education": [
      "B. Sc (Mathematics) & Sri Venkateswara University, Tirupati.",
      "Master of Business Administration & Jawaharlal Nehru Technological University, Anantapur.",
      "Ph.D. & Pondicherry Central University"
    ],
    "researchArea": "Marketing and Human Resources Managment",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/naresh-babu-muddangala-976b731b2/",
      "researchGate": "https://www.researchgate.net/profile/Naresh-Muddangala",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=LlwsA1MAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57218441344",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/554666"
    }
  },
  {
    "id": "vitap-1583-cms",
    "name": "Dr. Yallanti Sowjanya Kumari",
    "employeeId": "11.70718",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "619-F, CB",
    "email": "sowjanyakumari.y@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Yallanti_Sowjanya_Kumari_SCOPE_e72516cb67.avif",
    "education": [
      "SVU",
      "JNTUK, Kakinada",
      "JNTUK,Kakinada"
    ],
    "researchArea": "Image Processing",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "researchgate.net/?_tp=eyJjb250ZXh0Ijp7ImZpcnN0UGFnZSI6ImxvZ2luIiwicGFnZSI6ImhvbWUiLCJwcmV2aW91c1BhZ2UiOiJsb2dpbiIsInBvc2l0aW9uIjoiZ2xvYmFsSGVhZGVyIn19",
      "googleScholar": "https://scholar.google.com/citations?user=KCiAupkAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1590-cms",
    "name": "Dr. Balusa Bhanu Chander",
    "employeeId": "11.70725",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "619-J, CB",
    "email": "bhanuchander.b@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Balusa_Bhanu_Chander_SCOPE_f0255c2dce.avif",
    "education": [
      "B.Tech - JNTU Hyderabad",
      "M.Tech - JNTU Hyderabad",
      "Ph.D. - NIT Rourkela"
    ],
    "researchArea": "Multi Criteria Decision Making, Machine Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Paper titled ‘Underground Mining Method Selection Using WPM and PROMETHEE’ (published in the Series ‘D’ Journal of IEI, Vol. 99, Issue 1) has been selected for the subject prize by IEI Journal Prizes Awards 2019.",
      "Received Research Award in 2021 for the research publicatios at Vellore Institute of Technology, Chennai.",
      "Received Research Award in 2022 for the research publicatios at Vellore Institute of Technology, Chennai."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/feed/",
      "researchGate": "https://www.researchgate.net/profile/Bhanu-Balusa?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.co.in/citations?user=UL9xZVsAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57205321680"
    }
  },
  {
    "id": "vitap-1594-cms",
    "name": "Dr. N Lakshmipathi Anantha",
    "employeeId": "11.70729",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "619-M, CB",
    "email": "nlakshmipathi.anantha@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_N_Lakshmipathi_Anantha_SCOPE_3027481f97.avif",
    "education": [
      "MCA-Acharya Nagarujuna University",
      "M.Tech(IT)- VFSTR Deemed to be University",
      "Computer Science and Engineering-Acharya Nagarjuna University"
    ],
    "researchArea": "Machine Learning, Deep learning, Computer Vision, Natural Language Processing, Artificial Intelligence and Large Language Models",
    "memberships": [
      "IEEE Senior Member, IEEE Computer Society"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-n-lakshmipathi-anantha-7136b3135/",
      "researchGate": "https://www.researchgate.net/profile/N-Lakshmipathi-An?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=rNlzPEsAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57192398398",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/392510"
    }
  },
  {
    "id": "vitap-1600-cms",
    "name": "Dr. Shaik Subhani",
    "employeeId": "11.70735",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "812 - E, CB",
    "email": "subhani.shaik@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shaik_Subhani_SCOPE_d3fc6b8c12.avif",
    "education": [
      "B.Tech(CSE) & Andhra University",
      "M.Tech(CSE) & JNTU Hyderabad",
      "Ph.D.(CSE), Acharya Nagarjuna University"
    ],
    "researchArea": "Data Mining, Machine Learning, Artificial Intelligence, Data Science",
    "memberships": [
      "CSI"
    ],
    "projects": [],
    "patents": [
      "202041009647 A and A system and a method for speech detection and handwriting replication and writing thereof -2020"
    ],
    "awards": [
      "IJIEMR – ELSEVIER SSRN Research Awards 2020 for Best Academician awards."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/feed/",
      "researchGate": "https://www.researchgate.net/profile/Subhani-Shaik-6?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=wqJq8UEAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/pages/home?display=basic#basic",
      "vidwan": "https://vidwan.inflibnet.ac.in/error?id=3&email=subhanicse@gmail.com"
    }
  },
  {
    "id": "vitap-1609-cms",
    "name": "Dr. S Satheesh Kumar",
    "employeeId": "11.70747",
    "designation": "Associate Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "422-F, AB-1",
    "email": "satheeshkumar.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_S_Satheesh_Kumar_SENSE_IMG_7247_c29284ee3b.avif",
    "education": [
      "B.Tech (ECE), JNTU Hyderabad",
      "M.Tech (VLSI Design), Indian Institute of Technology Guwahati",
      "Ph.D from VIT, Vellore"
    ],
    "researchArea": "Radiation-Hardened circuit design, single-event transient (SET) analysis and mitigation techniques in various MOS devices, digital integrated circuit (IC) design, and semiconductor device modeling.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sathish-kumar-2379562b/?originalSubdomain=in",
      "researchGate": "https://www.researchgate.net/profile/Satheesh-Kumar-Sabavat",
      "googleScholar": "https://scholar.google.co.in/citations?user=8WelBoAAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56104830000"
    }
  },
  {
    "id": "vitap-1615-cms",
    "name": "Dr. Varunkumar Anantharaman",
    "employeeId": "11.70751",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "816 - A, CB",
    "email": "varunkumar.ka@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Varunkumar_Anantharaman_SCOPE_65e381a08d.avif",
    "education": [
      "B.E CSE & Anna University",
      "M.Tech CSE & VelTech University",
      "PhD & Anna University"
    ],
    "researchArea": "Cyber Security - Malware Analysis",
    "memberships": [
      "IEEE, ACM"
    ],
    "projects": [
      "1. VA/PT – Developing an optimal IDS for predicting the wireless interface level attacks over IEEE 802.11 environment (GNU-GPL).",
      "2. VA/PT – Analyzing vulnerability over IEEE 802.11 interfaces.",
      "3. SMA – Currently working in analyzing Sybil entities & its replications in social media (Facebook, Twitter).",
      "4. Analyzing Social Media traffic and its frustration over social networks.",
      "5. Cloud – currently working in cloud security ( Secured openSSH channel for avoiding covert channels & backdoors in cloud host’s).",
      "6. Project Titled granted “On-Demand E-Commerce application as an Industry Connect Consultancy ” Sunshine Enterprises, Vellore.",
      "7. Project Titled granted “Forest Fire Detection Using Machine Learning” selected for the funding through Tamilnadu State Council for Science and Technology during year 2019."
    ],
    "patents": [
      "1. Indian patent titled “Internet of Things Based Intelligent Irrigation System Using Cloud Computing” Appl No. 202141031458, Status – Published.",
      "2. Australian Patent titled “Internet of Things Based Intelligent Irrigation System Using Cloud Computing” status – Granted.",
      "3. Indian Patent titled “A Device for Early Detection of Oral Cavity Cancer and Method of Operation Thereof” Appl No. 202141012866, status – Published.",
      "4. Indian Patent titled “A smart application for Multi-Food Recognition using Machine learning” status – Published",
      "5. Indian Patent titled “EARLY DETECTION OF SKIN CANCER USING HANDHELD LOW-COST SMART DEVICE” Appl. No. 202141048061, status – Published",
      "6. Indian Patent titled “: Dual Lateral Flow Assay with Gold Nanoparticle for Presumptive Identification of Oral Cancer” Appl. No .202141048740 status – Published"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/varun-kumar-k-a-28ba7579/",
      "researchGate": "https://share.google/LdkeG7q24cYB2qbru",
      "googleScholar": "https://scholar.google.com/citations?user=w3mHtS4AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56287709300",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/657480"
    }
  },
  {
    "id": "vitap-1631-cms",
    "name": "Dr. Yelepi Usha Rani",
    "employeeId": "11.70759",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "621 - J, CB",
    "email": "usharani.y@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Yelepi_Usha_Rani_SCOPE_IMG_8163_3fb7914322.avif",
    "education": [
      "B.Tech,Acharya Nagarjuna University",
      "M.Tech,Jawaharlal Nehru Technological University,SIT, Hyderabad",
      "Ph.D,Jawaharlal Nehru Technological University, Hyderabad"
    ],
    "researchArea": "Machine Learning and Data Mining",
    "memberships": [
      "CSI"
    ],
    "projects": [],
    "patents": [
      "1. 421158-001 Smart Image Processing Device for Detection of Skin Cancer",
      "2. 354413-001 An Iot Covid Patient Health Monitoring System",
      "3. 380599-001 Computer Based Breath Analysis for Blood Sugar Detection"
    ],
    "awards": [
      "Best Paper Award for Conference Paper Implementation and analysis of Web application security measures using OWASP Guidelines"
    ],
    "links": {
      "linkedin": "https://in.linkedin.com/in/usharani-y-363918118?trk=people-guest_people_search-card",
      "researchGate": "https://www.researchgate.net/scientific-contributions/Yelipe-UshaRani-2114478469",
      "googleScholar": "https://scholar.google.com/citations?user=xL609BsAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57189064213&origin=recordpage",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/186105"
    }
  },
  {
    "id": "vitap-1618-cms",
    "name": "Dr. Ishfaq Ahmad Thaku",
    "employeeId": "11.70762",
    "designation": "Associate Professor Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "410, AB-1",
    "email": "ishfaqahmad.thaku@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ishfaq_Ahmad_Thaku_VSB_IMG_8188_cc198f3f45.avif",
    "education": [
      "B.Com, University of Kashmir",
      "M.Com, University of Kashmir",
      "PhD, Aligarh Muslim University"
    ],
    "researchArea": "International Business & Finance",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/ishfaq-ahmad-thaku-880a1450?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app",
      "googleScholar": "https://scholar.google.com/citations?user=mnif0e0AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1635-cms",
    "name": "Dr. Manas Ranjan Dash",
    "employeeId": "11.7077",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "818 - H, CB",
    "email": "manasranjan.dash@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Manas_Ranjan_Dash_SASCHY_IMG_7271_21f5a3c0b9.avif",
    "education": [
      "B.Sc. (Chemistry Honors), Sambalpur University",
      "M.Sc. in Chemistry, Sambalpur University",
      "Ph.D. in Chemistry, Indian Institute of Technology (IIT) Madras, Post docs from Max Planck Institute for Chemistry Germany and National Chiao Tung University Taiwan",
      "Post docs from Max Planck Institute for Chemistry Germany and National Chiao Tung University Taiwan"
    ],
    "researchArea": "Physical Chemistry, Gas Phase Kinetics, Atmospheric Chemistry, Computational Chemistry",
    "memberships": [],
    "projects": [
      "DIT University seed money grant (300,000 INR), Project No.: DITU/R & D/2022/015/Chemistry"
    ],
    "patents": [
      "1.Filing Date: February 08, 2025; Application number:202511010734; Publication Date: February 21, 2025, Indian Patent. Title of the invention: “A system for detecting vacuum in a glass gas chamber.",
      "2.Filing Date: December 12, 2024; Application number:202411098204; Publication Date: January 01, 2025. Indian Patent. Title of the invention: “An optical system and a method for analyzing the purity of a solvent.",
      "3. Filing Date: October 07, 2023; Reference number:2023100709251300DE; Application number:202023105807; Grant date: 06.11.2023. German Patent. Title of the invention: “Zusammensetzung und System zur Synthese und Charakterisierung von zellulosischen Nanokristall aus pflanzlichen Abfällen zur Farbentfernung”(Composition and system for synthesizing and characterizing cellulosic nanocrystal from vegetable waste for dye removal)."
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-manas-ranjan-dash-48a9a5176/",
      "researchGate": "https://www.researchgate.net/profile/Manas-Dash-2",
      "googleScholar": "https://scholar.google.co.in/citations?hl=en&user=nuEUWcMAAAAJ&view_op=list_works&sortby=pubdate",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55258199700",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/242956"
    }
  },
  {
    "id": "vitap-1659-cms",
    "name": "Dr. Sangeeta Adhikari",
    "employeeId": "11.70795",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "104-C, CB",
    "email": "sangeeta.adhikari@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sangeeta_Adhikari_SASCHY_3acb224c11.avif",
    "education": [
      "B. Sc. (Chemistry Honours) & Government Autonomous College (Affiliated to Sambalpur University)",
      "M. Sc. (Chemistry) & National Institute of Technology, Rourkela",
      "1) Ph. D. (Ceramic Engineering) & National Institute of Technology, Rourkela, 2) Post-doctoral studies at Indian Institute of Science, Bangalore & Research Professor at Chonnam National University, Republic of Korea",
      "Post-doctoral studies at Indian Institute of Science, Bangalore & Research Professor at Chonnam National University, Republic of Korea"
    ],
    "researchArea": "Processing of Nanomaterials, Photoelectrochemistry, Photocatalysis, Electrochromism, Energy Storage and Conversion Devices, and Environmental Nanotechnology.",
    "memberships": [
      "Member of Society of Materials Chemistry- India (Smc-India); Member of Korean Institute of Chemical Engineers (Kiche)"
    ],
    "projects": [
      "Project Topic: Design and Function of Metal Organic Frameworks (MOF)-Based Catalysts for Optimizing Persistent Organic Pollutants (POP) Remediation (Mid-Level Research Project, Funding Agency: National Research Foundation of Korea, Republic of Korea)",
      "Project Topic: Surface Modified Nanostructures for Advanced Catalysis (Environmental Remediation) and Energy Storage via Atomic Layer Deposition (Funding Agency: National Research Foundation of Korea, Republic of Korea)"
    ],
    "patents": [],
    "awards": [
      "Brain Pool Program- Invited Scientist- National Research Foundation of Korea, 2023",
      "Korea Research Postdoctoral Fellowship, National Research Foundation of Korea, 2018",
      "Ds Kothari Postdoctoral Fellowship, Ugc-India, 2016",
      "Department of Science And Technology, India, Awarded A Travel Grant for Presenting A Research Paper In Msat-8, Bangkok, Thailand During December 2014 (SB/ITS-Y/04472/2014-2015)",
      "Best Poster Award In International Symposium In Solid State Chemistry-2016 Held At Jncasr, Bangalore",
      "Best Oral Presenter in ICNT-2015 held at Haldia Institute of Technology, Haldia, West Bengal",
      "Best Poster Award in SCINO-2013 held at Bharathiar University, Coimbatore",
      "Best Oral Presenter in CCC-2012 held at NIT, Jalandhar"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sangeeta-adhikari-06087253/",
      "researchGate": "https://www.researchgate.net/scientific-contributions/Sangeeta-Adhikari-2235424578",
      "googleScholar": "https://scholar.google.com.sg/citations?hl=th&user=9fjLpGwAAAAJ&view_op=list_works"
    }
  },
  {
    "id": "vitap-1666-cms",
    "name": "Dr. Mohammad Sirajuddin",
    "employeeId": "11.70801",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "816 - C, CB",
    "email": "sirajuddin.md@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Mohammad_Sirajuddin_SCOPE_af96733760.avif",
    "education": [
      "B.Tech (CSE), Jawaharlal Nehru Technological University Hyderabad (JNTUH)",
      "M.Tech (CSE), Jawaharlal Nehru Technological University Kakinada (JNTUK)",
      "Ph.D. (CSE), Jawaharlal Nehru Technological University Kakinada (JNTUK)"
    ],
    "researchArea": "Wireless Adhoc & Sensor Networks, Cyber Security , Edge & Fog Computing",
    "memberships": [
      "MIEI, ACM, ICSES, IAENG"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-mohammad-sirajuddin-14b63690",
      "googleScholar": "https://scholar.google.com/citations?user=whUPonsAAAAJ&amp;hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56437567500",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/616907/NjE2OTA3"
    }
  },
  {
    "id": "vitap-1668-cms",
    "name": "Dr. Inampudi Govardhana Rao",
    "employeeId": "11.70805",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "816 - O, CB",
    "email": "govardhanarao.i@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Inampudi_Govardhana_Rao_SCOPE_80cf7666af.avif",
    "education": [
      "JNTU Hyderabad",
      "University College of Engineering, Osmania University",
      "University College of Engineering, Osmania University"
    ],
    "researchArea": "Cyber Security, Digital Forenscics, Quantum Computing, Video analytics, AIML",
    "memberships": [
      "ACM"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/inampudi-govardhanrao-b7751a31a",
      "researchGate": "https://www.researchgate.net/profile/Govardhana-Inampudi",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=MzN0qLIAAAAJ&view_op=list_works&authuser=1",
      "scopus": "https://www.webofscience.com/wos/author/record/MHR-3987-2025",
      "vidwan": "https://osmania.irins.org/profile/599354"
    }
  },
  {
    "id": "vitap-1685-cms",
    "name": "Dr. A V Narendra Kumar",
    "employeeId": "11.70822",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "626 - D, CB",
    "email": "narendrakumar.av@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_A_V_NARENDRA_KUMAR_SAS_4eb5545ed1.avif",
    "education": [
      "BSc in Chemistry & Madras University",
      "MSc in Chemistry & Madras University",
      "Phd in Chemistry from CSIR-Central Electrochemical Research Institute & Degree awarded from Bharathidasan University, Yonsei University, South Korea. Zhejiang University of Technology, China, Hanyang University, South Korea, Kyungpook National University, South Korea.",
      "Yonsei University, South Korea. Zhejiang University of Technology, China, Hanyang University, South Korea, Kyungpook National University, South Korea."
    ],
    "researchArea": "Electrocatalysis, Nanomaterials, Water remediation through Advanced Oxidation Process.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=gSySe2EAAAAJ&view_op=list_works&gmla=APjjwub10iNFV0OPks3jxMRqxyh9z9kXieHQwdeOrhp_eqtSf_Srv-uEyNc-5QpjllkIjLvm7nR6jAzLhe6oFaoSUYTMBA6owZ1TI3fU49JotfLDWUtFVCxE204kldciC5QpucKqDOR-70BPSlFgySwCtWFjJGv3p3-5"
    }
  },
  {
    "id": "vitap-1686-cms",
    "name": "Dr. Narayana Thota",
    "employeeId": "11.70823",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "621 - L, CB",
    "email": "narayana.thota@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Narayana_Thota_SASPHY_98f95c72bf.avif",
    "education": [
      "B.Sc, Sri Krishna Devaraya University (Silver Jubilee College)",
      "M.Sc in Physics, Sri Venkateeswara University",
      "1) Ph.D in Physics, Yogi Vemana University, 2). Research Associate, The Hong Kong University of Science and Technology, Hong Kong; 3). DST-INSPIRE Faculty, Indian Institute of Sciences, Bangalore; 4). Research Associate, Indian Institute of Technology-Delhi",
      "1). Research Associate, The Hong Kong University of Science and Technology, Hong Kong; 2). DST-INSPIRE Faculty, Indian Institute of Sciences, Bangalore; 3). Research Associate, Indian Institute of Technology-Delhi"
    ],
    "researchArea": "Semiconductors, 2D Materials and Devices, Light-Matter Interaction, Surface and Interface Physics, Micro-Nano Fabrication, Thin Film Technology.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-narayana-thota-a46903198/"
    }
  },
  {
    "id": "vitap-1697-cms",
    "name": "Dr. Amit Bhaskar",
    "employeeId": "11.70834",
    "designation": "Associate Professor Grade 1",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "415-G, AB-2",
    "email": "amit.bhaskar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_AMIT_BHASKAR_VSL_60d05bb7b0.avif",
    "education": [
      "Bachelors in Law from Campus Law Centre, Delhi University",
      "LLM in Business Laws from National Law School, Bangalore",
      "PhD in Criminal Law from National Law University, New Delhi"
    ],
    "researchArea": "Criminal Law",
    "memberships": [
      "Indian Society of Criminology, Indian Society of Victimology"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Award of Junior Research Fellowship by UGC, New Delhi."
    ],
    "links": {}
  },
  {
    "id": "vitap-1700-cms",
    "name": "Dr. Javvaji Venkata Kanaka Ratnam",
    "employeeId": "11.70837",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "626 - G, CB",
    "email": "jvk.ratnam@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_JAVVAJI_VENKATA_KANAKA_RATNAM_SCOPE_107f635b55.avif",
    "education": [
      "AMIE from The Institution of Engineers (India), Calcutta",
      "M.E. Specialization in Computer Technology from Swami Ramanand Teerth Marathwada University, Nanded, Maharashtra State",
      "Ph.D. from Jawaharlal Nehru Technological University Anantapur, Andhra Pradesh"
    ],
    "researchArea": "Data Science, Data Analytics, Cryptography, Computer Networks, Security, Machine Learning, Deep Learning",
    "memberships": [
      "Life Member of C.S.I. (N 1028796)"
    ],
    "projects": [],
    "patents": [
      "Application Number: 202241004368 A, Title: A Digital Signal Processing System for an Electronic Gaming Device"
    ],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=0ekBl34AAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201875410",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/234395"
    }
  },
  {
    "id": "vitap-1702-cms",
    "name": "Dr. Sunkesula Moulana Abdul Kalam Azad",
    "employeeId": "11.70839",
    "designation": "Associate Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "162, AB-1",
    "email": "abdulkalam.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_SUNKESULA_MOULANA_ABDUL_KALAM_AZAD_SENSE_1f2b25e748.avif",
    "education": [
      "B.Tech, Sri Venkateswara University, Tirupati",
      "M.Tech, Bijupattnaik University of Technology, Rourkela",
      "Ph.D, NIT Tiruchirappalli"
    ],
    "researchArea": "Industrial Automation and Control Communication, Industry 4.0, Industrial IoT",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. 202341052924 - IoT based Remote Vigilance System for Children and the Elderly",
      "2. 202341062388 - A system and method facilitating Contactless Food Delivery"
    ],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/s-m-a-k-a-60058b85",
      "googleScholar": "https://scholar.google.com/citations?user=VKAW2i4AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57191342328"
    }
  },
  {
    "id": "vitap-1703-cms",
    "name": "Dr. Venkatesh B",
    "employeeId": "11.70842",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "615 - O, CB",
    "email": "venkatesh.b@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_VENKATESH_B_SCOPE_e06a181c2e.avif",
    "education": [
      "B. Tech (2009) & JNTU Anantapur",
      "M.Tech (2013) & JNTU Anantapur",
      "Ph.D(2021) & VIT University, Vellore"
    ],
    "researchArea": "Deep Learning, Computer Vision, Data Mining, Machine Learning",
    "memberships": [
      "IAENG (International association for the Engineers)"
    ],
    "projects": [],
    "patents": [
      "1. 202241057079 and A Threat Detection System For Protecting A Device Against A Cyber-Attack And Method Thereof"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-venkatesh-b-565678124",
      "researchGate": "https://www.researchgate.net/profile/Venkatesh_Bachu",
      "googleScholar": "https://scholar.google.co.in/citations?user=iPiQcXoAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57208533459",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/193408"
    }
  },
  {
    "id": "vitap-1705-cms",
    "name": "Dr. Paritala Jhansirani",
    "employeeId": "11.70844",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "817 - L, CB",
    "email": "jhansirani.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_PARITALA_JHANSIRANI_SCOPE_9fc2dac779.avif",
    "education": [
      "BTech-CSIT, JNTUH",
      "MTech-IT, Satyabhama University",
      "PhD, Cloud Computing, GITAM, Hyderabad"
    ],
    "researchArea": "Cloud computing, Networks security",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57211412471"
    }
  },
  {
    "id": "vitap-1712-cms",
    "name": "Dr. Manimuthu A",
    "employeeId": "11.70849",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1017-C, CB",
    "email": "manimuthu.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_MANIMUTHU_A_SCOPE_516ccef20c.avif",
    "education": [
      "B.Sc Thiruvalluvar university",
      "MCA ` Thiruvalluvar university",
      "Ph.D Bharathiar University"
    ],
    "researchArea": "Cloud Computing ,Machine Learning ,Deep Learning .",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-manimuthu-a-8023055b",
      "googleScholar": "https://scholar.google.com/citations?user=g1JP5uYAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57217912866"
    }
  },
  {
    "id": "vitap-1716-cms",
    "name": "Dr. Karnam Balaji",
    "employeeId": "11.70854",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "104-A, CB",
    "email": "karnam.balaji@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_KARNAM_BALAJI_SCOPE_790f2ab1f7.avif",
    "education": [
      "B.Tech CSE from JNTU-Hyderabad",
      "M.Tech Cn & IS from JNTU- Anathapur",
      "Ph.D CSE from KLEF"
    ],
    "researchArea": "Cloud Computing, Information Security, Quantum Cryptography",
    "memberships": [
      "ACM"
    ],
    "projects": [],
    "patents": [
      "1. 363033-001 - An IOT enabled GPS Car tracking device",
      "2. 202441063603 - CHATBOT FOR OPTIMIZING AGGRESSION OF AN ATTENTION DEFICIT HYPERACTIVITY DISORDER (ADHD) PATIENT"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-balaji-karnam-59909a43/",
      "researchGate": "https://www.researchgate.net/profile/K-Balaji-3",
      "googleScholar": "https://scholar.google.com/citations?user=GlG9rTsAAAAJ&hl=en&authuser=2",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57217684556",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/277641"
    }
  },
  {
    "id": "vitap-1727-cms",
    "name": "Dr. Arkdev",
    "employeeId": "11.70862",
    "designation": "Associate Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "615-D, CB",
    "email": "ark.dev@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_ARKDEV_SENSE_e1a8f52d05.avif",
    "education": [
      "B.Tech, West Bengal University of Technology",
      "M.Tech, National Institute of Technology Manipur",
      "Ph.D, National Institute of Technology Manipur"
    ],
    "researchArea": "Control Systems, Renewable Energies, Optimization, Batteries, Power System Operation and Control",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ark-dev-35702a169/",
      "googleScholar": "https://scholar.google.com/citations?user=ZdmfZmYAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57202287000"
    }
  },
  {
    "id": "vitap-1745-cms",
    "name": "Dr. Kanhaiya Sharma",
    "employeeId": "11.7088",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "817 - B, CB",
    "email": "kanhaiya.sharma@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kanhaiya_Sharma_SCOPE_4bb38d46bc.avif",
    "education": [
      "B.Sc",
      "M.Tech(CSE)",
      "PhD(CSE), Pandit Deendayal energy University, Gandhinagar, Gujarat, India"
    ],
    "researchArea": "Big Data Analytics, Microstrip Antenna Design, Machine Learning",
    "memberships": [
      "ISTE, WAMS"
    ],
    "projects": [
      "Design of high-cost low dielectric microstrip antenna using low cost high dielectric microstrip antenna” , Grant No ORSP/R&D/2019/JAGP/042 Amount INR 240000/- duration 12 months from 28-March-2019, Sponsored by Office of Research & Sponsored Program of Pandit Deendayal Petroleum University, Gandhinagar."
    ],
    "patents": [
      "1. COMPACT QUAD-PORT CONFORMAL 8.31ghz-36.14ghz MIMO ANTENNA",
      "2. Automated gas leak detection and prevention system with multi-level alert and remote notification features",
      "3. A triangular-slotted ultra-wideband textile antenna for biomedical wearable applications",
      "4. HYBRID MULTI-SENSING DUAL-AXIS SOLAR TRACKING SYSTEM USING EPHEMERIS- BASED AND SENSOR-DRIVEN INTELLIGENT CONTROL",
      "5. SMART WEARABLE TEXTILE ANTENNA SYSTEM WITH ARTIFICIAL INTELLIGENCE FOR NON-INVASIVE CANCER DETECTION"
    ],
    "awards": [
      "Springer Nature Editor of Distinction Awards 2026"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/kanhaiya-sharma-10779316/",
      "researchGate": "https://www.researchgate.net/profile/Kanhaiya-Sharma-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=UFUhHWwAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57216289106"
    }
  },
  {
    "id": "vitap-1746-cms",
    "name": "Dr. Debmalya Das",
    "employeeId": "11.70881",
    "designation": "Associate Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "818 - L, CB",
    "email": "debmalya.das@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_DEBMALYA_DAS_SASPHY_3a2b2c4170.avif",
    "education": [
      "B.Sc. (Hons.) in Physics from University of Calcutta",
      "M.Sc. in Physics from IIT Guwahati",
      "Ph.D. in Physical Sciences from IISER Mohali",
      "Research Associate at IISER Mohali, Postdoctoral Fellow at Harish-Chandra Research Institute, Postdoctoral Associate at University of Rochester, Ricercatore a Tempo Determinato di Tipo A (Junior Assistant Professor) at Universita degli studi di Bari Aldo Moro"
    ],
    "researchArea": "Quantum Optics, Open Quantum Systems, Quantum Computation and Information Theory, Quantum Thermodynamics, and Quantum Foundations",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/debmalya-das-b1196116/",
      "researchGate": "https://www.researchgate.net/profile/Debmalya-Das?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=72N1uQQAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1755-cms",
    "name": "Dr.Prakash Kumar Sarangi",
    "employeeId": "11.7089",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "817-D, CB",
    "email": "prakashkumar.sarangi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Prakash_Kumar_Sarangi_SCOPE_928c94f22d.avif",
    "education": [
      "B. Sc. & Utkal University, Bhubaneswar, Odisha, India",
      "M. Sc., M. Tech (CS) & Utkal University, Bhubaneswar, Odisha, India",
      "Ph. D. (CS) & Utkal University, Bhubaneswar, Odisha, India, PDF & Lincoln University College, 47301, Petaling Jaya, Selangor Darul Ehsan , Malaysia.",
      "PDF & Lincoln University College, 47301, Petaling Jaya, Selangor Darul Ehsan , Malaysia."
    ],
    "researchArea": "Natural Language Processing, Generative AI, Bioinformatics",
    "memberships": [
      "l. No. Professional Society Membership Number 1 IEEE (Institute of Electrical and Electronics Engineers) :98368971, 2. ISTE (Indian Society for Technical Education): LM 143875, 3. ISOC (Internet Society):2352774, 4. IAENG (International Association of Engineers):256119, 5. OITS (Orissa Information Technology Society):L07/381, 6. OMS (Odisha Mathematical Society):7203/202"
    ],
    "projects": [],
    "patents": [
      "1. 202541123792 Real-Time Cognitive AI Framework for Cyber Threat Detection and Mitigation in Networks",
      "2. 6479850 Design Patent – Lung Cancer Testing Device",
      "3. 480833-001 Design Patent – AI Based Device for Brain Abnormality Detection",
      "4. 202541027616 Enabled AI-Based Network Traffic Optimization for Seamless IoT Connectivity",
      "5. 202441058498 Multi-Agent Reinforcement Learning Framework for Traffic Management in Smart Cities",
      "6. 202441056938 AI Virtual Assistant for Linux Operating System",
      "7. 202341072707 Diagnosing and Evaluating Orthopedic Pathologies via Imaging Methods: A Systematic Review and Meta-Analysis",
      "8. 202441032263 Deep Reinforcement Learning Framework for Autonomous Navigation in Unstructured Environments",
      "9. 202441016214 Blockchain-Based Decentralized Authentication and Authorization System for Secure Transactions",
      "10. 354248-001 Design Patent – Bacterial Prevented Length Adjustable Tooth Brush",
      "11. 202241070444 An Adaptive Multi-Objective Machine Learning Framework for Edge Computing Based on a Multiple Gradient Descent Design",
      "12. 202241032179 The Role of the Internet of Things on the Relationship between Job Balance and Employee Productivity in the IT Industry",
      "13. 362754-001 Design Patent – Smart Foldable Table",
      "14. 202111055706 A Method to Reveal Motif Patterns of COVID-19 Using Multiple Sequence Alignment",
      "15. 202111051122 A Novel Method for Diseases Detection from RNA Secondary Structure Using Convolutional Neural Network",
      "16. 20211104989 A Novel Bedcover for Detection of Sleep Pattern and System Thereof",
      "17. 202111049898 A Novel Container with Plurality of Compartments",
      "18. 202111049899 A Novel Dress for Maternity and Post Natal Care",
      "19. 202111049893 A Novel Hand Held Device for Detection of Nanoparticles in PPE Kit Using AI Deployment",
      "20. 202111049889 A Novel Herbal Multilayer Face Mask",
      "21. 202111049901 A Novel Multipurpose Travel Bag",
      "22. 202111049896 A Novel Process for Colouring Fabric Using Cissus Javana",
      "23. 202111049220 A Novel Water Based Nano Anti Fog Spray",
      "24. 202111055708 A Portable Vaccine Storage Container",
      "25. 202111055534 A System of Contactless Umpiring in Cricket Match and Method Thereof",
      "26. 202111055528 A System of Musical Songs to Language and Dance Detection Using NLP Based CNN",
      "27. 202111056375 A System of RNA Structure Prediction Using Cellular Automata",
      "28. 202111055703 An IoT Based Single Use Device for Collecting Blood Samples",
      "29. 202111055419 COVID-19 Genome Analysis for Drug Discovery Using Pairwise Sequence Alignment",
      "30. 202111055564 Disposable Face Masks as Breathalysers for Real-Time Monitoring of Health of Lungs",
      "31. 202111055536 Securing IoT Devices in Edge Computing Through Reinforcement Learning",
      "32. 202111055530 System for Underground Water Prediction Using Deep Learning",
      "33. 202111049227 A Novel Brassier for Heart Monitoring",
      "34. 202141027189 A Vehicle System with Haptic Output for Impaired Based on Machine Learning and Artificial Intelligence Interfaces",
      "35. 20213014876 Fatigue Crack Rate Propagation Estimation Model Using Least Square SVM Algorithm",
      "36. 202141007441 Enhanced Image Compression System with Parallelized Binary Search Tree Optimization Method for Medical Images"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-prakash-kumar-sarangi-43212032/",
      "researchGate": "https://scholar.google.com/citations?user=BvAFH20AAAAJ&hl=en",
      "googleScholar": "https://scholar.google.com/citations?user=BvAFH20AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57423683100",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/266926"
    }
  },
  {
    "id": "vitap-1789-cms",
    "name": "Dr. K Sree Divya",
    "employeeId": "11.70934",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1013 - J, CB",
    "email": "sreedivya.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_K_Sree_Divya_SCOPE_bc9a14b3d1.avif",
    "education": [
      "B.Tech, JNTUH",
      "M.Tech, JNTUA",
      "Ph.D, Sri Padmavathi Mahila Visvavidyalayam"
    ],
    "researchArea": "Machine Learning, Data Analytics, Deep Learning",
    "memberships": [
      "IEEE, ISTE"
    ],
    "projects": [],
    "patents": [
      "AUTOMATIC DETECTION OF SHOULDER PAIN and Patent No. 3823"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-sree-divya-koppeti-7a191829/",
      "googleScholar": "https://scholar.google.com/citations?user=Sl6XF40AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/pages/authors/57955831000",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/460458"
    }
  },
  {
    "id": "vitap-1805-cms",
    "name": "Dr. Venkata Subbarao Bala Chaitanya Duvvury",
    "employeeId": "11.70947",
    "designation": "Associate Professor Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1016-H, CB",
    "email": "balachaitanya.duvvury@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Venkata_Subbarao_Bala_Chaitanya_Duvvury_SENSE_9c5e2ede4c.avif",
    "education": [
      "B.Tech in Electrical & Electronics Engineering (EEE), JNTU Kakinada, Andhra Pradesh",
      "M.Tech in Power Systems, Electrical Engineering, IIT BHU Varanasi, Uttar Pradesh",
      "Ph.D. in Power & Energy Systems, Electrical Engineering, IIT Kharagpur, West Bengal"
    ],
    "researchArea": "Improved Fault Detection Sensitivity of Transformer Windings using Advanced Frequency Response Analysis (FRA) Measurement Techniques",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-vsb-chaitanya-duvvury/",
      "researchGate": "https://www.researchgate.net/profile/V-S-B-Chaitanya-Duvvury?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=bcnpsIwAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57212490320"
    }
  },
  {
    "id": "vitap-1829-cms",
    "name": "Dr. Tangala Venkateswarlu",
    "employeeId": "11.70971",
    "designation": "Associate Professor Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": null,
    "email": "venkateswarlu.tangala@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Tangala_Venkateswarlu_VSB_b0b5aa117a.png",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1830-cms",
    "name": "Dr. Tatireddy Subbareddy",
    "employeeId": "11.70972",
    "designation": "Associate Professor Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": null,
    "email": "t.subbareddy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Tatireddy_Subbareddy_SCOPE_8ceb37015e.png",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1318-cms",
    "name": "Dr. Komandla Mahipal Reddy",
    "employeeId": "12.70097",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G23-E, AB-2",
    "email": "mahipal.reddy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Komandla_Mahipal_Reddy_70097_IMG_4703_SAS_MAT_14a3f6294a.avif",
    "education": [
      "B.Sc from Kakatiya University",
      "M.Tech from NITK Surathkal",
      "Ph.D from IIT Madras"
    ],
    "researchArea": "Numerical Methods, Optimization Techniques, Graph theory, Fractals, Fractal Optimization",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=sZJypuoAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1256-cms",
    "name": "Dr. Sudesh Manger",
    "employeeId": "12.70109",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "G24-E, AB-2",
    "email": "sudesh.manger@vitap.ac.in",
    "phone": "5583",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sudesh_Manger_70109_IMG_4870_VISH_961c29a13c.avif",
    "education": [
      "Bachelor of Arts & North Bengal University",
      "Masters of Arts & Osmania University",
      "Ph.D & The English and Foreign Languages University"
    ],
    "researchArea": "Translation Studies, Nepali Literature, Post Colonial Literature, Dalit Muslim Literature",
    "memberships": [],
    "projects": [],
    "patents": [
      "202141037208/IPR2021020 and IR Based Bio-Waste Disposal Machine"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sudesh-manger-863279236/?originalSubdomain=in",
      "researchGate": "https://www.researchgate.net/profile/Sudesh-Manger",
      "googleScholar": "https://scholar.google.com/citations?user=vLqwnqoAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0003-0392-7859",
      "vidwan": "https://vitap.irins.org/profile/301809"
    }
  },
  {
    "id": "vitap-1379-cms",
    "name": "Dr Lakshmi Sowjanya Pali",
    "employeeId": "12.70112",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "125-C, AB-2",
    "email": "lakshmi.sowjanya@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Lakshmi_Sowjanya_Pali_IMG_6581_SASPHY_7269937254.avif",
    "education": [
      "B.Sc. Andhra University",
      "M.Sc. Acharya Nagarjuna University, M.Tech. Visvesvaraya National Institute of Technology (VNIT), Nagpur",
      "Ph.D, Intian Institute of Technology Kanpur"
    ],
    "researchArea": "Energy Materials, Solar Energy Harvesting, Gas Sensors",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/sowjanya-pali",
      "googleScholar": "https://scholar.google.com/citations?user=65HYWgsAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57200091568"
    }
  },
  {
    "id": "vitap-1319-cms",
    "name": "Dr. R Sinuvasan",
    "employeeId": "12.70116",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "124-N, AB-2",
    "email": "sinuvasan.r@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_R_Sinuvasan_SAS_MAT_1958_8d010dca24.avif",
    "education": [
      "B.Sc., Thiruvalluvar University",
      "M.Sc., Pondicherry University",
      "Ph.D., Pondicherry University"
    ],
    "researchArea": "Integrable Systems",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sinuvasan-r-87402b52/",
      "researchGate": "https://www.researchgate.net/profile/Sinuvasan-Rangasamy?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=xQSldSoAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56912325700",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/260006"
    }
  },
  {
    "id": "vitap-1322-cms",
    "name": "Dr. Lisna PC",
    "employeeId": "12.70145",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "225-L, AB-2",
    "email": "lisna.pc@vitap.ac.in",
    "phone": "5752",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70145_Dr_Lisna_PC_MAT_1270_6083572592.avif",
    "education": [
      "B.Sc. Mathematics, The Zamorin's Guruvayurappan College Calicut",
      "M.Sc.(Tech.) in Mathematics and Scientific Computing, National Institute of Technology Calicut",
      "Graph Coloring, National Institute of Technology Calicut"
    ],
    "researchArea": "Graph theory, b-coloring, Achromatic Coloring, Injective Coloring, Applications of b-coloring in network analysis",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "vidwan": "304060"
    }
  },
  {
    "id": "vitap-1257-cms",
    "name": "Dr. Rakhi N K",
    "employeeId": "12.70154",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "225-N, AB-2",
    "email": "rakhi.nk@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70154_Dr_Rakhi_N_K_VISH_1267_5dd25a84ca.avif",
    "education": [
      "BA English Language and Literature, University of Calicut",
      "MA Linguistics, The English and Foreign Languages University (EFLU), Hyderabad",
      "Applied Linguistics. Corpus Linguistics, Indian Institute of Technology Jodhpur"
    ],
    "researchArea": "Linguistics, Corpus Linguistics, Syntax and Morphology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "linkedin.com/in/rakhi-nk-2b786b185",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=OICB6k0AAAAJ"
    }
  },
  {
    "id": "vitap-1265-cms",
    "name": "Dr. Raghavi R. K.",
    "employeeId": "12.70194",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "202-E, AB-2",
    "email": "raghavi.rk@vitap.ac.in",
    "phone": "5804",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Raghavi_R_K_VISH_1562_185cd2eb96.avif",
    "education": [
      "B.A English, Cauvery College for Women, Bharathidasan University",
      "MA English, Ethiraj College for Women, University of Madras",
      "PhD English, National Institute of Technology Trichy"
    ],
    "researchArea": "Graphic Medicine, Health Humanities, Comics Studies, Literature and Medicine and Visual Studies",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=KiseGwsAAAAJ"
    }
  },
  {
    "id": "vitap-1268-cms",
    "name": "Dr. Deepjoy Katuwal",
    "employeeId": "12.70201",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "202-G, AB-2",
    "email": "deepjoy.katuwal@vitap.ac.in",
    "phone": "5714",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Deepjoy_Katuwal_VISH_1555_65f9d7216d.avif",
    "education": [
      "St. Joseph's College, Darjeeling (North Bengal University)",
      "Darjeeling Government College (North Bengal University)",
      "The English and Foreign Languages University (EFLU), Hyderabad"
    ],
    "researchArea": "Eastern Himalayan Language & Culture, Indian English Literature, South Asian Studies, English Language Teaching",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/deepjoy-katuwal-95578631/"
    }
  },
  {
    "id": "vitap-1341-cms",
    "name": "Dr. V. Raja",
    "employeeId": "12.70284",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G24-H, AB-2",
    "email": "raja.v@vitap.ac.in",
    "phone": "5506",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_V_Raja_70284_IMG_4866_SAS_MAT_9e556f41d9.avif",
    "education": [
      "B.Sc. Mathematics, Gandhigram Rural University",
      "M.Sc. Mathematics, Pondicherry Central University",
      "Ph.D. Mathematics, Pondicherry Central University"
    ],
    "researchArea": "Graph Theory",
    "memberships": [
      "Life Member in Indian Mathematical Society, Life Member in Ramanujan Mathematical Society,"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=BTt5gHIAAAAJ&hl=en&oi=sra"
    }
  },
  {
    "id": "vitap-1210-cms",
    "name": "Dr. Afzal Hussain Shahid",
    "employeeId": "12.7031",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "816 - N, CB",
    "email": "afzal.hussain@vitap.ac.in",
    "phone": "5970",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Afzal_Hussain_Shahid_SCOPE_1907_9cacb6a812.avif",
    "education": [
      "B. Tech. (CSE), West Bengal University of Technology",
      "M.Tech. (CSE), National Institute of Technology Patna",
      "Computer Science & Engineering, National Institute of Technology Patna"
    ],
    "researchArea": "Artificial Intelligence, Machine Learning, Soft Computing, Deep Learning, Healthcare Analytics",
    "memberships": [
      "Indian Society for Technical Education"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=ZFuXXO0AAAAJ&hl=en&authuser=1",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57209536029"
    }
  },
  {
    "id": "vitap-1278-cms",
    "name": "Dr. Suresh Jagannadham",
    "employeeId": "12.70358",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "124-G, AB-2",
    "email": "suresh.jagannadham@vitap.ac.in",
    "phone": "5109",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70358_Dr_Suresh_Jagannadham_VISH_1126_64848f2ff3.avif",
    "education": [
      "BA-Acharya Nagarjuna University",
      "MA in Hindi, University of Hyderabad",
      "Ph.D in Hindi, University of Hyderabad"
    ],
    "researchArea": "Contemporary / Modern Hindi Literature, Documentation of Tribal Oral Traditions, Arts, Language, Literature and Philosophy of Tribes, Socio,Cultural identity of De-notified, Nomadic and Semi -Nomadic Tribes in India.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1381-cms",
    "name": "Dr. Ritambhara Sharma",
    "employeeId": "12.70372",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "124-A, AB-2",
    "email": "ritambhara.sharma@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70372_Dr_Ritambhara_Sharma_CHY_1687_734bbc9ad5.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1415-cms",
    "name": "Dr. V V Sreenivasu M",
    "employeeId": "12.70387",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "G23-D, AB-2",
    "email": "sreenivasu.mummidivarapu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70387_Dr_V_V_Sreenivasu_M_SAS_1075_4117ac71da.avif",
    "education": [
      "BSc, Andhra University",
      "MSc, Andhra University",
      "1) PhD, IIT Bombay, 2) PDF, NUI Galway",
      "PDF, NUI Galway"
    ],
    "researchArea": "Supramolecular Chemistry",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=gCmqJD4AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1221-cms",
    "name": "Dr. Rajesh Duvvuru",
    "employeeId": "12.70388",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "816 - M, CB",
    "email": "rajesh.duvvuru@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rajesh_Duvvuru_70388_IMG_4941_SCOPE_0777925965.avif",
    "education": [
      "B.Tech, Sri Venkestwara University",
      "Spatial Information Technology, Andhra University"
    ],
    "researchArea": "Geospatial Intelligence, Deep Learning, IoT, Remote Sensing and Disaster Management",
    "memberships": [
      "Institution of Engineers India, The Institute of Ellectronics and Telecommunication Engineers (IETE), Indian Society of Geomatics, Indian Society Of Remote Sensing"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "dblp": "https://dblp.org/pid/132/0053.html",
      "researchGate": "https://www.researchgate.net/profile/Rajesh-Duvvuru",
      "googleScholar": "https://scholar.google.com/citations?user=dAT7JPIAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-5053-0590",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55941296400"
    }
  },
  {
    "id": "vitap-1224-cms",
    "name": "Dr. Beebi Naseeba",
    "employeeId": "12.7039",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "618 -A, CB",
    "email": "beebi.naseeba@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Beebi_Naseeba_SCOPE_1833_244e6fa9e6.avif",
    "education": [
      "B.Tech CSE, Andhra University",
      "M.Tech CSE, JNTU Hyderabad",
      "Computer Science & Systems engineering, Andhra University"
    ],
    "researchArea": "Artificial Intelligence, Machine Learning, Deep Learning,Image Processing",
    "memberships": [
      "International Association of Engineers (IAENG)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=vMjkNGAAAAAJhttps://www.scopus.com/authid/detail.uri?authorId=58110191700",
      "orcid": "https://orcid.org/0000-0002-4537-0270",
      "scopus": "https://www.researchgate.net/profile/Beebi-Naseeba",
      "vidwan": "linkedin.com/in/beebi-naseeba-903010239"
    }
  },
  {
    "id": "vitap-1363-cms",
    "name": "Dr. Francis P",
    "employeeId": "12.70405",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "124-K, AB-2",
    "email": "francis@vitap.ac.in",
    "phone": "5606",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Francis_P_SAS_MAT_1960_d76f1ae25f.avif",
    "education": [
      "B.Sc. Mathematics, Gandhigram Rural University",
      "M.Sc. Mathematics, Pondicherry University",
      "Ph.D. Mathematics, Pondicherry University",
      "Post Doc Computer Science, Indian Institute of Technology Palakkad"
    ],
    "researchArea": "Graph Coloring and Domination",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/francis-xavier-9bb2aba5/",
      "researchGate": "https://www.researchgate.net/profile/P-Francis",
      "googleScholar": "https://scholar.google.com/citations?user=fYfmVkMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56504699300",
      "vidwan": "https://vitap.irins.org/profile/300376"
    }
  },
  {
    "id": "vitap-1305-cms",
    "name": "Dr. Naveen Kumar Ch",
    "employeeId": "12.70409",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "622- N, CB",
    "email": "naveen.cherupelly@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70409_Dr_Naveen_Kumar_Ch_VISH_1378_283341ff47.avif",
    "education": [
      "Univ. Arts &Science College & Kakatiya University",
      "University of Hyderabad",
      "University of Hyderabad",
      "University of Hyderabad"
    ],
    "researchArea": "Science, Technology and Societal Studies",
    "memberships": [
      "Indian Sociological Society"
    ],
    "projects": [
      "The Idea of Digital University: Pre-implementation Analysis of the Digital University Program in India - ICSSR -(Indian Council of Social Science Research)"
    ],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1408-cms",
    "name": "Dr. Nallamuthu S",
    "employeeId": "12.7041",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "812 - J, CB",
    "email": "nallamuthu.s@vitap.ac.in",
    "phone": "5965",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70410_Dr_Nallamuthu_S_PHY_1380_7700a97403.avif",
    "education": [
      "B.Sc-Physics, Bharathidasan University -Tiruchirappalli",
      "M.Sc-Applied Physics, National Institute of Technology Tiruchirappalli",
      "Ph.D, National Institute of Technology Tiruchirappalli",
      "Post Doctoral Fellow- Indian Institute Of Technology–Madras"
    ],
    "researchArea": "Quantum materials, Frustrated magnetism, Quantum Computing, Quantum Devices",
    "memberships": [],
    "projects": [
      "Investigation of quantum spin liquid in Rare-Earth Pyrochlores A2B2O7, where A3+ (La, Ce, Yb) and B4+ (Ti and Ru) for quantum computation applications. Funding agency- UGC-DAE Consortium for Scientific Research, Indore, India."
    ],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=2wRWZCAAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=43061512000",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/304563"
    }
  },
  {
    "id": "vitap-1246-cms",
    "name": "Dr. Siva Ramakrishna P",
    "employeeId": "12.70422",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "131, AB-1",
    "email": "sivaramakrishna.pillutla@vitap.ac.in",
    "phone": "5836",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Siva_Ramakrishna_P_70422_IMG_4917_SENSE_3fb47929ed.avif",
    "education": [
      "Electronics and Communication Engineering, Andhra University",
      "M.Tech(VLSI-SD), National Institute of Technology Warangal",
      "VLSI Design, National Institute of Technology Warangal"
    ],
    "researchArea": "Digital VLSI Architectures",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=Mfb7QyYAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1392-cms",
    "name": "Dr. Varunkumar Merugu",
    "employeeId": "12.70431",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "626 - C, Central Block",
    "email": "varunkumar.merugu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Varunkumar_Merugu_SAS_0895_7bfe5ec887.avif",
    "education": [
      "B.Sc, Kakatiya University Warangal",
      "M. Sc,. NIT Warangal",
      "Ph. D., NIT Warangal"
    ],
    "researchArea": "Biofluid Mechanics, CFD, Mass Transfer",
    "memberships": [
      "Andhra Pradesh and Telangana Society for Mathematical Sciences (APTSMS), International Association of Engineers(IAENG)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Varunkumar-Merugu?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=6JBDYVsAAAAJ&hl=nl",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57817901000",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/302589"
    }
  },
  {
    "id": "vitap-1406-cms",
    "name": "Dr.Karunakar Perumandla",
    "employeeId": "12.70439",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "626 - K, CB",
    "email": "karunakar.perumandla@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70439_SAS_Dr_Karunakar_Perumandla_1061_57f05fd986.avif",
    "education": [
      "B.Sc. & Osmania University",
      "M.Sc. & NIT Warangal",
      "PhD in Mathematics & NIT Rourkela"
    ],
    "researchArea": "Interval and Fuzzy Differential Equations, Interval and Fuzzy Linear System of Equations, and Fractional Differential Equations",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "http://www.linkedin.com/in/dr-karunakar-perumandla-887231206",
      "researchGate": "https://www.researchgate.net/profile/Perumandla-Karunakar",
      "googleScholar": "http://surl.li/jbupk",
      "orcid": "0000-0002-1823-2366",
      "scopus": "57194512237",
      "vidwan": "300175"
    }
  },
  {
    "id": "vitap-1249-cms",
    "name": "Dr. G. Bharath Reddy",
    "employeeId": "12.70446",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "127, AB-1",
    "email": "bharathreddy.gudibandi@vitap.ac.in",
    "phone": "5870",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70446_Dr_G_Bharath_Reddy_SENSE_1082_94e923f53b.avif",
    "education": [
      "BTech in ECE and JNTU Kakinada",
      "MTech in Wireless communication and PSG college of Techology, coimbatore",
      "PhD in RF and Microwave Engineering and National Institute of Technology, Tiruchirappalli"
    ],
    "researchArea": "Antenna design, Microwave circuit design, Metamaterial design, Array synthesis, Machine learning applications to antenna design",
    "memberships": [
      "IEEE, IEEE MTT, IEEE APS"
    ],
    "projects": [
      "1. Radio direction finder using a novel 24 element antenna with Ideal pattern diversity, Project ID / Reference Number- VIT-AP/SPORIC/RGEMS/2025-26/008, Project Start Date - 4-12-2025, Current Status - Ongoing"
    ],
    "patents": [
      "1. Non-Overlapping Beam Antenna Array for Direction Finding Applications, Patent Publication Number- ISSUE No.37/2024, Date of Publication 13/09/2024, ,Patent Status - Published",
      "2. A vehicle Detection System and Method Using short- Range lora For Preventing accidents, Patent Publication Number - ISSUE NO.28/2025, Date of Publication - 1/07/2025, Patent Status - Published",
      "3. Wearable Safety Monitoring Device for Manual Scavengers, Patent Application Number - 202641007660A, Date of Publication-13-2-26, Patent Status - Published"
    ],
    "awards": [
      "Qualified in UGC NET-2017 for both JRF and Assistant professor.",
      "Visweswarayya PhD Fellowship for pursuing PhD (DietY)",
      "Received DeitY Travel grant for attending the international conference NCC-2018",
      "Received Raman research award twice in VIT AP universiy"
    ],
    "links": {
      "website": "https://www.researchgate.net/profile/Bharath_Reddy_Gudibandi",
      "researchGate": "https://www.researchgate.net/profile/Bharath-Reddy-Gudibandi",
      "googleScholar": "tmXgVd8AAAAJ",
      "orcid": "0000-0002-9180-8587",
      "scopus": "57194650310"
    }
  },
  {
    "id": "vitap-1267-cms",
    "name": "Dr. Abdul Kayom Md Khairuzzaman",
    "employeeId": "12.70447",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "156, AB-1",
    "email": "kayomabdul@vitap.ac.in",
    "phone": "5871",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70447_Dr_Abdul_Kayom_Md_Khairuzzaman_SENSE_1089_ab93192103.avif",
    "education": [
      "B.Tech (ECE), North Eastern Hill University",
      "M.Tech (Bioelectronics), Tezpur University",
      "Ph.D (Image Processing), NIT Silchar"
    ],
    "researchArea": "Image Processing, Multi-level Thresholding based Image Segmentation, Soft Computing, Swarm Intelligence, Particle Swarm Optimization",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Abdul-Kayom-Khairuzzaman",
      "googleScholar": "https://scholar.google.com/citations?user=XHuWkcUAAAAJ&hl=en",
      "orcid": "0000-0001-5191-5743",
      "scopus": "57194333256"
    }
  },
  {
    "id": "vitap-1439-cms",
    "name": "Dr. Soumen Kundu",
    "employeeId": "12.7045",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "104-H, CB",
    "email": "soumen.kundu@vitap.ac.in",
    "phone": "5874",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Soumen_Kundu_70450_IMG_2576_SAS_MAT_08344f2c78.avif",
    "education": [
      "B.Sc. in Mathematics, The University of Burdwan",
      "M.Sc. in Mathematics with Computer Applications, NIT Durgapur",
      "PhD, NIT Durgapur"
    ],
    "researchArea": "Mathematical Biology, Dynamical Systems, Disease Dynamics, Delay Differential Equation, Stochastic Analysis",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Soumen-Kundu-2?ev=hdr_xprf&_tp=eyJjb250ZXh0Ijp7ImZpcnN0UGFnZSI6ImhvbWUiLCJwYWdlIjoiaG9tZSIsInBvc2l0aW9uIjoiZ2xvYmFsSGVhZGVyIn19",
      "googleScholar": "S_K1nKgAAAAJ",
      "orcid": "0000-0003-1292-1686",
      "scopus": "57214483831",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/299928"
    }
  },
  {
    "id": "vitap-1440-cms",
    "name": "Dr. Faizan Danish",
    "employeeId": "12.7046",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "320-A, AB-2",
    "email": "faizan.danish@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Faizan_Danish_70460_IMG_2676_SAS_MAT_efeaa39f29.avif",
    "education": [
      "UG & University of Kashmir",
      "PG & University of Kashmir",
      "PhD & Sher-e-Kashmir University of Agricultural Sciences and Technology of Jammu",
      "PDF and New York University, New York ,USA"
    ],
    "researchArea": "Sampling Theory, Mathematical Programming ,Biostatistics",
    "memberships": [
      "American Statistical Association since 2019, Institute of Mathematical Statistics since 2020, International Indian Statistical Association since 2017, Indian Association of Statistics in Clinical Trials since 2020, Life member of the Society for Bioinformatics and Biological Sciences since 2017, Lifetime Membership awarded by International Journal for Research Under Literal Access since 2018, Society of Statistics, Computer and Applications since 2021, Indian Society for Probability and Statistics since 2022"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "1. Awarded IMRF YOUNG SCIENTIST AWARD in STATISTICS by INTERNATIONAL MULTIDISCIPLINARY RESEARCH FOUNDATION on the eve of IMRF‟s 66th international gathering International Conference on Advances in Mathematics, Computers and Physical Sciences at IMRF Chandigarh chapter, Chandigarh , India on Feb 22nd , 2018",
      "2. Received IARDO Award for Outstanding Doctoral Best Thesis-2018 on the grand occasion of International Award Conference on Multidisciplinary Research and Innovation on 28th October,2018",
      "3. Awarded with Best Research Presentation award (Oral) at an International conference on” Recent Trends in Engineering Technology, Agriculture, Applied Sciences, Humanities and Business Management for Sustainable Development (ETAHBS-2018)” organized by Department of Metallurgical and Material Engineering, National Institute of Technology of Srinagar, Jammu and Kashmir, India and Krishi Sanskrit New Delhi on 20th–21th October,2018.",
      "4. Received BEST YOUNG SCIENTIST AWARD‟18 for outstanding excellence in the field of Research and Co-curriculum by International Journal for Research Under Literal Access at Breeze Residency, Trichy, Tamilnadu on 15th August, 2018.",
      "5. Awarded with Best Oral Presentation award for the presentation, „Stratified Random Sampling for Apple Production in J&K-A Statistical Investigation‟ at the national seminar organized by SKUAST-Jammu from 19-20 November, 2018.",
      "6. Author of the SOUVENIR of 19th Annual National Conference , Society of Statistics, Computer Science and Applications (SSCA-2017) on Statistics and Informatics in Agriculture and Allied Sciences Organized by Sher-e- Kashmir University of Agricultural Sciences and Technology of Jammu, J&K, India from 06-08 March,2017.",
      "7. Best Researcher Award in Online Award Ceremony organized by Institute of Technical and Scientific Research, Jaipur, India on 13th Sep. 2020.",
      "8. Received Best Paper Certificate for the Paper, “Status of Growth in Area, Production and Productivity of Major Crops in Jammu Province of J&K State. International Journal of Economics, Commerce and Research. 7(3): 1-12” by TJPRC journals.",
      "9. Received Best Paper presentation award on Two day Multidisciplinary International Conference held at SKUAST-J, Jammu, J&K, India on 20-21, October ,2021 at SKUAST-Kashmir, J&K, India.",
      "10. Innovative paper of the 40th volume of the journal: Danish, F. , Rizvi, S.E.H. , Sharma, M. K. and Jeelani , M.I, Kumar, B. and Dar, Q.F. (2019): Optimum Stratification for two Stratifying variables , Revista Investigacion Operacional.40(5). 562-573."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/faiza n- danish-283793aa/",
      "researchGate": "https://www.researchgate.net/profile/Faizan-Danish",
      "orcid": "\"https://orcid.org/0000-0002-0476- 9744\"",
      "scopus": "57195525138",
      "vidwan": "299950"
    }
  },
  {
    "id": "vitap-1320-cms",
    "name": "Dr. Bommareddy Lokesh",
    "employeeId": "12.70479",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "723 -M, CB",
    "email": "lokesh.bommareddy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bommareddy_Lokesh_SCOPE_0803_d3b2d02bf1.avif",
    "education": [
      "B.Tech, JNTU",
      "M.Tech, Andhra University",
      "Computer Science & Engineering, National Institute of Technology Puducherry"
    ],
    "researchArea": "Software-defined Networking",
    "memberships": [
      "IAENG"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/lokesh-bommareddy-a89a0729/",
      "website": "https://sites.google.com/d/1KjYsh6uq_Jqu_FKL2NX1wOKpw5HtYlmL/p/1G7vD-YesizGLWpQAy8OJG-gKbtAxR_bx",
      "googleScholar": "http://scholar.google.co.in/citations?user=LDfS6qMAAAAJ",
      "orcid": "http://www.orcid.org/0000-0002-8753-6160",
      "scopus": "http://www.scopus.com/authid/detail.url?authorId=57219484278"
    }
  },
  {
    "id": "vitap-1330-cms",
    "name": "Dr. Ramkumar D",
    "employeeId": "12.70488",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "620-M, CB",
    "email": "ramkumar.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ramkumar_D_70488_0164_07b5aafe5a.avif",
    "education": [
      "B. Tech (Information Technology), Anna University",
      "M.E (Computer Science and Engineering), Anna University",
      "Information and Communication Engineering, ANNA University"
    ],
    "researchArea": "Internet of Things, Artificial Intelligence, VANET, Wireless Sensor Networks, Machine Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/ramkumar-d-53795378/",
      "researchGate": "https://www.researchgate.net/profile/Ramkumar-Devendiran",
      "googleScholar": "https://scholar.google.com/citations?user=j78bBLwAAAAJ&hl=en&authuser=4",
      "orcid": "https://orcid.org/0000-0002-2200-4948",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56142031000"
    }
  },
  {
    "id": "vitap-1286-cms",
    "name": "Dr. Debanjali Sarkar",
    "employeeId": "12.70489",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "424-E, AB-1",
    "email": "debanjali.sarkar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Debanjali_Sarkar_SENSE_1527_ddce4c478c.avif",
    "education": [
      "B.E, Dayananda Sagar College of Engineering, Bengaluru",
      "M.Tech, Visvesvaraya Technological University, Regional Center Mysuru",
      "Ph.D, National Institute of Technology Silchar"
    ],
    "researchArea": "Ultra-wideband Antenna, Biomedical Antenna, Printed Microwave Components, RF Energy Harvesting, Machine Learning, Evolutionary Algorithms",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-debanjali-sarkar-b4623a11b",
      "researchGate": "https://www.researchgate.net/profile/Debanjali-Sarkar",
      "googleScholar": "https://scholar.google.co.in/citations?hl=en&user=deKhusoAAAAJ&view_op=list_works&authuser=1&sortby=pubdate",
      "orcid": "0000-0002-8509-3052",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/301038"
    }
  },
  {
    "id": "vitap-1284-cms",
    "name": "Dr. Deepthi Godavarthi",
    "employeeId": "12.70505",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "813 - E, CB",
    "email": "deepthi.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Deepthi_Godavarthi_SCOPE_1875_a403772688.avif",
    "education": [
      "B.Tech, Andhra University",
      "M.Tech, Andhra University",
      "Computer Science and Systems Engineering, Andhra University"
    ],
    "researchArea": "Natural Language Processing,Machine Learning,Deep Learning,Computer Vision,Block Chain Technology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/deepthi-godavarthi-12499a229/",
      "researchGate": "https://www.webofscience.com/wos/author/record/HMV-9814-2023",
      "googleScholar": "https://scholar.google.co.in/citations?user=SUS8necAAAAJ",
      "orcid": "https://orcid.org/0000-0003-0712-6899",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57226560215"
    }
  },
  {
    "id": "vitap-1455-cms",
    "name": "Dr. Sandhya Sadanandan",
    "employeeId": "12.70509",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "620-C, CB",
    "email": "sandhya.sadanandan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sandhya_Sadanandan_SAS_1494_82a7b52d29.avif",
    "education": [
      "B.Sc Chemistry, University of Calicut",
      "M.Sc Chemistry, Madras University",
      "PhD in Organic Chemistry, IIT Delhi"
    ],
    "researchArea": "Organic Chemistry-Peptide chemistry, BioorganicChemistry, Drug design and medicinal Chemistry",
    "memberships": [
      "Member of Indian Peptide Society"
    ],
    "projects": [
      "Ongoing, ANRF_TARE, Design and Synthesis of Enzyme-Responsive Peptide Macrocycles for Cancer Therapy"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?view_op=search_authors&mauthors=sandhya+sadanandan&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=37010401700"
    }
  },
  {
    "id": "vitap-1308-cms",
    "name": "Dr. Swati Shukla",
    "employeeId": "12.70513",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "152, AB-1",
    "email": "swati.shukla@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Swati_Shukla_SENSE_0806_08f874999f.avif",
    "education": [
      "Pt R.S University",
      "IIT Delhi",
      "Ph.D, IIT Guwahati"
    ],
    "researchArea": "Power System Simulation, Development of EV Simulators,Demand Response Management, Electromagnetic Transient Analysis, Smart Homes",
    "memberships": [
      "ISTE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "http://scholar.google.co.in/citations?user=ceyyeaEAAAAJ",
      "orcid": "http://www.orcid.org/0000-0002-2225-6029",
      "scopus": "http://www.scopus.com/authid/detail.url?authorId=7202528443"
    }
  },
  {
    "id": "vitap-1313-cms",
    "name": "Dr. M.Mahesh",
    "employeeId": "12.70515",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "313-C, AB-1",
    "email": "mahesh.m@vitap.ac.in",
    "phone": "5327",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_M_Mahesh_70515_IMG_4680_SENSE_a8ded3f068.avif",
    "education": [
      "JNTU Hyderbad",
      "JNTU Anantapur",
      "Ph.D,National Institute of Technology Puducherry"
    ],
    "researchArea": "Wireless communication, Wireless networks, Communication Systems",
    "memberships": [
      "IEEE Member"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Miriyala-Mahesh",
      "googleScholar": "5w2YXPsAAAAJ",
      "orcid": "0000-0001-8297-2134",
      "scopus": "57197600838"
    }
  },
  {
    "id": "vitap-1421-cms",
    "name": "Dr. S Dasaradha Rama Rao",
    "employeeId": "12.70516",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "813 - B, CB",
    "email": "dasaradharamarao.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_S_Dasaradha_Rama_Rao_SAS_0951_f48c899bd7.avif",
    "education": [
      "B.Sc., Acharya Nagarjuna University",
      "M. Sc., Acharya Nagarjuna University",
      "Ph.D., Indian Institute of Technology Madras",
      "Post-Doc., JNCASR, Bengaluru, Invited researcher, CNRS, Grenoble, France"
    ],
    "researchArea": "Transport studies on low-dimensional materials, Electro and Photo-catalysis, Energy Conversion and Storage, Hydrogen generation and Fuel cells",
    "memberships": [
      "Life member (LM791) in \"Magnetics Society of India\""
    ],
    "projects": [
      "1. Layered Transition Metal Dichalcogenides based hybrid nano-heterostructures for Energy conversion applications,PI: Dr. S. D. Ramarao, Funding agency: VIT-AP University, Cost of the project: 1,99,656",
      "2. Title: Exploring Ferroelectric-based photovoltaics, PI: Dr. C. Thirmal, Co-PI: Dr. S. D. Ramarao, Funding agency: VNR Vignana Jyothi Institute of Engineering and Technology, SEED Grant, Cost of the project: 3.5 lakh",
      "3. Title: Tailoring electronic and magnetic properties of two-dimensional layered transition metal oxides for spintronics applications, PI: Dr. S. D. Ramarao, Co-PI: Dr. Rajib Mondal, Funding agency: UGC-DAE-CSR, Cost of the project: 45000"
    ],
    "patents": [],
    "awards": [
      "Smt. Annamaraju Rajyalakshmamma Memorial award, “Certificate of Excellence for Securing First rank (1st) in the entrance examination for Admission into M.Sc (Physics) conducted by Acharaya Nagarjuna University, Guntur, Andhra Pradesh.",
      "Best paper award in “International Symposium for Research Scholars on Metallurgy, Materials Science and Engineering”, December 13-15, 2012. Title: Effect of Microwave Sintering on Lattice Vibrations and Microwave Dielectric Properties of ZnWO4.",
      "Best paper award in “International Symposium for Research Scholars on Metallurgy, Materials Science and Engineering”, December 11-13, 2014. Title: Temperature and Composition Induced Phase transition in SmNbO4"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-s-d-ramarao-8799b2257/",
      "website": "https://sites.google.com/site/dasaradh4phy/home?authuser=0",
      "researchGate": "https://www.researchgate.net/profile/S-D-Ramarao",
      "googleScholar": "e1Am33YAAAAJ",
      "orcid": "0000-0002-9252-8587",
      "scopus": "57212026533",
      "vidwan": "210921"
    }
  },
  {
    "id": "vitap-1314-cms",
    "name": "Dr. Tauseef Khan",
    "employeeId": "12.70522",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "618 -M, CB",
    "email": "tauseef.khan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Tauseef_Khan_SCOPE_1910_9c63962759.avif",
    "education": [
      "Bachelor of Engineering, CSVTU",
      "Master of Technology, WBUT",
      "Computer Science and Engineering, Aliah University, Kolkata"
    ],
    "researchArea": "Digital Image Processing, Machine Learning, Deep Learning, Pattern Recognition, Operating System",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Tauseef-Khan-3",
      "googleScholar": "https://scholar.google.com/citations?user=1lXMLpEAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/freelookup/form/author.uri"
    }
  },
  {
    "id": "vitap-1343-cms",
    "name": "Dr. Kankanala Srinivas",
    "employeeId": "12.70527",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "146, AB-1",
    "email": "srinivas.kankanala@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kankanala_Srinivas_SENSE_0820_e67845e100.avif",
    "education": [
      "B.Tech (ECE), JNTUH",
      "M.Tech (VLSI System Design), VNR VJIET/JNTU HYDERABAD",
      "PhD, National Institute of Technology Patna"
    ],
    "researchArea": "Image processing, Soft computing, Compressive sensing, Machine learning, DOA estimation",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "AAU-1515-2021",
      "googleScholar": "tDS2yscAAAAJ",
      "orcid": "0000-0002-0426-4850",
      "scopus": "56425392600"
    }
  },
  {
    "id": "vitap-1465-cms",
    "name": "Dr. Ramesh Prasad Panda",
    "employeeId": "12.70538",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "124-B, AB2",
    "email": "ramesh.panda@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70538_Dr_Ramesh_Prasad_Panda_MAT_1240_e9dfc9d42c.avif",
    "education": [
      "B.Sc. (Honours) in Mathematics, Sambalpur University, Burla, Odisha",
      "M.Sc. in Mathematics, Indian Institute of Technology Kanpur",
      "PhD in Mathematics, Indian Institute of Technology Guwahati",
      "1. Post-Doctoral Fellow, Indian Institute of Technology Kanpur, Kanpur (2021 - 2022), 2. Visiting Fellow, DAE-National Institute of Science Education and Research, Bhubaneswar (2020 - 2021), 3. Post-Doctoral Fellow, DAE-National Institute of Science Education and Research, Bhubaneswar (2018 - 2020)"
    ],
    "researchArea": "Algebraic Graph Theory, Algebraic Combinatorics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Best paper presentation award by Academy of Discrete Mathematics and Applications in 2017",
      "GATE 2013"
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/ramesh-prasad-panda-phd-232371216",
      "researchGate": "https://www.researchgate.net/profile/Ramesh-Panda-2",
      "googleScholar": "https://scholar.google.co.in/citations?user=9Pp0zi4AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57210315822",
      "vidwan": "https://vitap.irins.org/profile/365286"
    }
  },
  {
    "id": "vitap-1373-cms",
    "name": "Dr. Anurag De",
    "employeeId": "12.70557",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "618 - C, CB",
    "email": "anurag.de@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Anurag_De_SCOPE_1917_edd9ccbcf2.avif",
    "education": [
      "B.Tech, KIIT University, Bhubaneswar",
      "M.Tech, NIT Agartala",
      "M.Tech, NIT Agartala"
    ],
    "researchArea": "Activity recognition for ambient intelligence, Human fall detection, Cyber-physical Systems, Software Engineering, Microprocessors.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=vYq7zm8AAAAJ&view_op=list_works&gmla=AJsN-F6ASPqelFzSu3_L5mC8gNn4yTJDnpVaVw-",
      "orcid": "https://orcid.org/0000-0003-4829-1583",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56763457100"
    }
  },
  {
    "id": "vitap-1358-cms",
    "name": "Dr. Hanumantharao Bitra",
    "employeeId": "12.70564",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "422-E AB-1",
    "email": "hanumantharao.bitra@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70564_Dr_Hanumantharao_Bitra_SENSE_1223_925729b05e.avif",
    "education": [
      "ECE, JNTU Kakinada",
      "DECS, JNTU Anantapur",
      "PhD on Signal Processing & Wireless Communications, NIT Tiruchirappalli"
    ],
    "researchArea": "Signal Processing & Wireless Communications",
    "memberships": [
      "IEEE (Member id 96244619)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/hanumantharao-bitra-a6729978/",
      "researchGate": "https://www.researchgate.net/profile/Hanumantharao-Bitra",
      "googleScholar": "https://scholar.google.co.in/citations?user=QvhIrbgAAAAJ&hl=en",
      "orcid": "0000-0001-8006-479X",
      "scopus": "57211157609"
    }
  },
  {
    "id": "vitap-1383-cms",
    "name": "Dr. Visalakshi Annepu",
    "employeeId": "12.70568",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "623-L, CB",
    "email": "visalakshi.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Visalakshi_Annepu_SCOPE_1873_3425a34381.avif",
    "education": [
      "JNTU Kakinada",
      "Andhra University",
      "Vit-Vellore"
    ],
    "researchArea": "Wireless Networks, Computer Networks, Machine Learning, Artificial Intelligence, Soft Computing Techniques",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Received Research award from Vellore Institute of Technology, Vellore."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/feed/",
      "googleScholar": "https://scholar.google.co.in/citations?user=e_BqrQgAAAAJ&hl=en",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0002-7199-1898",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56880350400",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/474099"
    }
  },
  {
    "id": "vitap-1218-cms",
    "name": "Dr. Kishor E",
    "employeeId": "12.70574",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "326-C, AB-1",
    "email": "kishor.e@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kishor_E_SMEC_1020_201807dcd7.avif",
    "education": [
      "B.Tech (Kerala University)",
      "M.Tech (Kerala University)",
      "Ph.D (IIT Madras)",
      "IIT Madras, IISc Bangalore, IIT Palakkad"
    ],
    "researchArea": "Molecular Dynamics simulations, Radiation damage properties, Thermal contact resistance",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=NZ8WtEwAAAAJ&hl=en&oi=sra"
    }
  },
  {
    "id": "vitap-1478-cms",
    "name": "Dr. Kashif Beg",
    "employeeId": "12.7058",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "425-D, AB-1",
    "email": "kashif.beg@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kashif_Beg_VSB_0837_dc86ff501b.avif",
    "education": [
      "B.COM (Hons.) Aligarh Muslim University (AMU)",
      "M.Com (Accounting & Finance)",
      "PH.D. from Aligarh Muslim University (AMU)"
    ],
    "researchArea": "Corporate Accounting, Financial Accounting, Financial Management, Tax and Investment",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/feed/",
      "researchGate": "https://www.researchgate.net/profile/Kashif-Beg",
      "googleScholar": "https://scholar.google.com/citations?user=ICh_5XwAAAAJ&hl=en",
      "orcid": "0000-0001-5638-2229"
    }
  },
  {
    "id": "vitap-1397-cms",
    "name": "Dr. B.V.Gokulnath",
    "employeeId": "12.70585",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "626 - E, CB",
    "email": "gokulnath.b@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70585_Dr_B_V_Gokulnath_1049_617b3c1d37.avif",
    "education": [
      "BTech & ANNA UNIVERSITY (K.S.R College of Technology)",
      "MTech & VIT UNIVERSITY VELLORE",
      "PhD & VIT UNIVERSITY VELLORE"
    ],
    "researchArea": "DEEP LEARNING and IMAGE PROCESSING",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Gokulnath-B-V",
      "googleScholar": "https://scholar.google.com/citations?user=NDuwA5kAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57218405355"
    }
  },
  {
    "id": "vitap-1402-cms",
    "name": "Dr. Chintakindi Balaram Murthy",
    "employeeId": "12.70591",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "128-E, CB",
    "email": "balaram.ch@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70591_Dr_Chintakindi_Balaram_Murthy_SCOPE_1195_832e695fca.avif",
    "education": [
      "BTech in Electronics & Communication Engineering, JNTU Hyderabad",
      "Mtech in Embedded Systems, JNTU Hyderabad",
      "PhD in Artifical Intelligence & Embedded Systems, NIT Warangal"
    ],
    "researchArea": "Computer Vision, Embedded Vision, Image & Video Processing, Internet of Things, Reinforcement Learning & Natural Language Processing",
    "memberships": [
      "ISTE-LM 140192"
    ],
    "projects": [],
    "patents": [
      "1. 202441104056 System and method for identifying crop disease and determining crop disease category in real-time.",
      "2. 202441103740 System and method for detecting potholes and geotagging detected potholes in real-time.",
      "3. 202541003072 System and method for Deraining and reconstruction of images.",
      "4. 202541008075 An Accident Prevention System for a Vehicle in hazy environment"
    ],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?view_op=list_works&hl=en&hl=en&user=wOsyqD0AAAAJ",
      "orcid": "0000-0003-0874-6264",
      "scopus": "https://www.scopus.com/feedback/author/reviewAuthorProfile.uri?authorIds=57216886632"
    }
  },
  {
    "id": "vitap-1409-cms",
    "name": "Dr. Naresh Sammeta",
    "employeeId": "12.70592",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "128-C, CB",
    "email": "naresh.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Naresh_Sammeta_SCOPE_1577_3bce5bcc61.avif",
    "education": [
      "B.E in Computer Science & Engineering, Madras University",
      "M.E in Computer Science & Engineering, Anna University-",
      "PhD in Computer Science & Engineering, JNTUK, Kakinada"
    ],
    "researchArea": "Cloud Computing, Blockchain, Cryptography, Data Structures and Algorithms, Java Programming, Web Technologies.",
    "memberships": [
      "MISTE, IACSIT, IAENG, CSTA"
    ],
    "projects": [],
    "patents": [
      "1. Palk Strait Boundary Scanning and Boat Surveillance System 202241077704",
      "2. Ensemble Artificial Intelligence based Programmable Digital Billboards with Automatic Variation of Images and Text 202141035052",
      "3. REDUCEMEMNT OF GLASS BOTTLE DEFECT USING IoT 202141016344",
      "4. AN IOT ENABLED FOOT OPERATED TWO WHEELER STEERING MECHANISM FOR HANDICAPPED PERSONS 2020102133"
    ],
    "awards": [],
    "links": {
      "dblp": "https://dblp.org/pid/335/6444.html",
      "researchGate": "https://www.researchgate.net/profile/Naresh-Sammeta-2",
      "googleScholar": "https://scholar.google.com/citations?user=WDxi4TkAAAAJ&hl=en&oi=ao",
      "orcid": "https://orcid.org/0000-0003-0659-9467",
      "scopus": "55941061600",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/300836"
    }
  },
  {
    "id": "vitap-1411-cms",
    "name": "Dr. Debosmita Biswas",
    "employeeId": "12.70596",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "723 - K, CB",
    "email": "debosmita.b@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Debosmita_Biswas_VISH_1838_e1170e97ec.avif",
    "education": [
      "B.A. (H) English, University of Calcutta",
      "M.A. English, The English and Foreign Languages University (EFLU)",
      "PhD, The English and Foreign Languages University (EFLU)"
    ],
    "researchArea": "History of Ideas, Thanatology, Moral Philosophy",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/407637"
    }
  },
  {
    "id": "vitap-1413-cms",
    "name": "Dr. D.Santha Devi",
    "employeeId": "12.70602",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "626 - M, CB",
    "email": "santhadevi.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_D_Santha_Devi_70602_IMG_4925_SCOPE_a9aff86f50.avif",
    "education": [
      "Computer Science and Engineering, University of Madras",
      "Computer Technology and Application, University of Delhi",
      "PhD in Computer Science and Engineering, NIT Tiruchirappalli"
    ],
    "researchArea": "IoT- Edge Security (Netflow based Malware Detection and Classification)",
    "memberships": [
      "CSI"
    ],
    "projects": [],
    "patents": [
      "394743-001"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-santhadevi-d-b3624014a/",
      "researchGate": "https://www.researchgate.net/profile/Dr-Santhadevi",
      "googleScholar": "https://scholar.google.com/citations?user=QyLREEEAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-2734-7747",
      "scopus": "57192107658"
    }
  },
  {
    "id": "vitap-1427-cms",
    "name": "Dr. Abdul Raffie Naik",
    "employeeId": "12.70616",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "G24-L, AB-2",
    "email": "abdulraffie.naik@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Abdul_Raffie_Naik_VISH_1919_4c49162d3a.JPG",
    "education": [
      "B.A Hons Aligarh Muslim University",
      "MSc Clinical and Counselling Psychology Central University of Karnataka",
      "PH.D Aligarh Muslim University"
    ],
    "researchArea": "Clinical, Counselling and Positive Psychology, Research, Intervention Studies",
    "memberships": [
      "1. Life time member of Counsellor Council of India Membership No: CRN9144765. 2. Indian Academicians and Researchers Association Membership No: M / M-804. 3 Life time member of International Association of Holistic Psychology. Membership NO. IAHP190B817."
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-abdul-raffie-naik-88322481/",
      "researchGate": "https://www.researchgate.net/profile/Abdul-Naik",
      "googleScholar": "https://scholar.google.com/citations?user=kLjvLRQAAAAJ&hl=en",
      "orcid": "http://www.orcid.org/0000-0003-2908-4917",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/434028"
    }
  },
  {
    "id": "vitap-1436-cms",
    "name": "Dr. Venkata Bhikshapathi Chenam",
    "employeeId": "12.70619",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "812 - F, CB",
    "email": "venkatab.chenam@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Venkata_Bhikshapathi_Chenam_SCOPE_0798_e1a68bd106.avif",
    "education": [
      "CSE, Acharya Nagarjuna University",
      "CST, Andhra University",
      "VNIT nagpur"
    ],
    "researchArea": "Cryptography- Searchable Encryption",
    "memberships": [
      "IEEE-99091258, CSI-5051230005"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/venkata-bhikshapathi-chenam-8b853755/",
      "researchGate": "https://www.researchgate.net/profile/Venkata-Chenam",
      "googleScholar": "https://scholar.google.co.in/citations?user=L3v5YRkAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0003-2702-2157",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58613607900"
    }
  },
  {
    "id": "vitap-1494-cms",
    "name": "Dr. N.Prabhakar",
    "employeeId": "12.70638",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "425-I , AB-1",
    "email": "prabhakar.n@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_N_Prabhakar_VSB_1026_0693aaed8a.avif",
    "education": [
      "B.Com Kakatiya University",
      "MBA Kakatiya University",
      "Ph.D (Management) Pondicherry Univeisty"
    ],
    "researchArea": "Accounting for Managers, Financial Management, Management Accounting,Security Market Operations, and Security Analysis & Portfolio Management",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/prabhakar-nandru-251266188",
      "researchGate": "https://www.researchgate.net/profile/Prabhakar-Nandru",
      "googleScholar": "https://scholar.google.com/citations?user=BmYAIqkAAAAJ&hl=en&authuser=1",
      "orcid": "https://orcid.org/0009-0001-2297-3423"
    }
  },
  {
    "id": "vitap-1448-cms",
    "name": "Dr. Pokuri Srinivasa Rao",
    "employeeId": "12.7064",
    "designation": "Assistant professor senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "620-L, CB",
    "email": "pokuri.srinivasarao@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pokuri_Srinivasa_Rao_70640_IMG_4734_SCOPE_99da80a184.avif",
    "education": [
      "BE(CSE), Anna University",
      "M.Tech(CSE), Acharya Nagarjuna University",
      "Ph.D(CSE), Acharya Nagarjuna University"
    ],
    "researchArea": "Network Security",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/scientific-contributions/Srinivasa-Rao-Pokuri-2214603443",
      "googleScholar": "https://scholar.google.com/citations?user=A7zBYSkAAAAJ&hl=en",
      "orcid": "https://dblp.org/pid/335/8132.html",
      "scopus": "57463110700 ( https://www.scopus.com/authid/detail.uri?authorId=57463110700&origin=recordpage)"
    }
  },
  {
    "id": "vitap-1450-cms",
    "name": "Dr. Devulapalli Sudheer",
    "employeeId": "12.70641",
    "designation": "Assistant Professor senior grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "104-D, CB",
    "email": "sudheer.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Devulapalli_Sudheer_SCOPE_0920_3c46bb5f57.avif",
    "education": [
      "B.Tech, JNTUK University",
      "M.Tech, JNTUK University",
      "PhD, VIT Vellore"
    ],
    "researchArea": "Computer Vision",
    "memberships": [
      "IEEE- 93882708, Computer Society of India, Hyderabad Chapter - 5021230026, Scientific International Publishing House,(SIPHs) life time member - SIPH2023106."
    ],
    "projects": [],
    "patents": [
      "Crop Recommendation And Disease Prediction System, 202341028135"
    ],
    "awards": [
      "Best Young Researcher Award, CSI-Hyderabad, 06-May-2023, Best Young Researcher Award, Scientific International Publishing House (SIPH), 27-Feb-2023"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-sudheer-devulapalli-681495124/",
      "googleScholar": "vWAF_BYAAAAJ",
      "orcid": "0000-0001-7056-5195",
      "scopus": "57211048910",
      "vidwan": "323589"
    }
  },
  {
    "id": "vitap-1451-cms",
    "name": "Dr. Koduru Hajarathaiah",
    "employeeId": "12.70642",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "618 - D, CB",
    "email": "hajarathaiah.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Koduru_Hajarathaiah_SCOPE_0794_c811f73611.avif",
    "education": [
      "B.Tech & JNTUH",
      "M.Tech & JNTUA",
      "Ph.D & SRM University-AP"
    ],
    "researchArea": "Complex Networks, Social Networks",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. Systems And Methods For Identifying Influential People In Social Networks(202241074988),",
      "2. Systems And Methods For Identifying Influential People In Complex Networks( 202241075862),",
      "3. System Of Finding Influential People In Social Networks With A Combination Of Local And Global Approaches And Method Thereof (202341023978)."
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/koduru-hajarathaiah-74093613a/",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=oC4IQNwAAAAJ",
      "orcid": "0000-0001-9504-2307",
      "scopus": "57209219091",
      "vidwan": "369845"
    }
  },
  {
    "id": "vitap-1453-cms",
    "name": "Dr. V.Sri Lakshmi",
    "employeeId": "12.70643",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "723 - O, CB",
    "email": "srilakshmi.v@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_V_Sri_Lakshmi_70643_0210_4458070a9b.avif",
    "education": [
      "BA(CAMS) Acharya Nagarjuna University",
      "M.Tech(CSE): Jawaharlal Nehru Technological University,Kakinada",
      "Ph.D (CSE) Acharya Nagarjuna University"
    ],
    "researchArea": "Image Processing",
    "memberships": [
      "ISTE-139219"
    ],
    "projects": [],
    "patents": [
      "IoT BASED SMART FARMING USING ARTIFICIAL INTELLIGENCE, Application Number: 202241066465 A"
    ],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=746mwoQAAAAJ&amp;hl=en&amp;authuser=1",
      "orcid": "https://orcid.org/0000-0002-2058-0781",
      "scopus": "57658283500"
    }
  },
  {
    "id": "vitap-1506-cms",
    "name": "Dr. Sunkara Kalyani",
    "employeeId": "12.70646",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "G02-G, AB-2",
    "email": "kalyani.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70646_Dr_Sukara_Kalyani_SCOPE_1129_364f88afa4.avif",
    "education": [
      "BSc. Statistics Computer science, Andhra University",
      "Msc. Computer Science and Mtech.Computer Science, Andhra University",
      "PhD Computer SciencePhD Computer Science"
    ],
    "researchArea": "Data Analytics, Natural Language Processing, Anomaly Detection, Predictive Analytics. Data Visualization, Cryptography and Network Security",
    "memberships": [
      "IEEE, IAENG, ACM, CSI, IEI, IUCEE"
    ],
    "projects": [],
    "patents": [
      "1. 202023107716-Granted on Intelligent tender coconut cutting device",
      "2. 359952-001-IOT designed Oxygen test meter for water quality monitoring",
      "3. 202321072813-Driverless Auto Electric Vehicle Auto Monitor and control using IoT Based system"
    ],
    "awards": [
      "Women Excellence Award-2023 from MSConnect",
      "NPTEL Topper of the Course Python for Data Science",
      ".Visista Seva award from Vignan's Institute of Engineering for Women,"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-kalyani-sunkara-037a38109/",
      "googleScholar": "https://scholar.google.com/citations?user=2dYU3-QAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/results/authorNamesList.uri?name=name&st1=Sunkara&st2=Kalyani&origin=searchauthorlookup",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/530108"
    }
  },
  {
    "id": "vitap-1508-cms",
    "name": "Dr. Kailash Chandra Mishra",
    "employeeId": "12.70648",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "623-C, CB",
    "email": "kailashchandra.mishra@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kailash_Chandra_Mishra_SCOPE_0733_15be5c1439.avif",
    "education": [
      "BE(IT) at Berhampur University",
      "M.Tech(CSE) at BPUT",
      "PhD(CSE) at NIT Jamshedpur"
    ],
    "researchArea": "Cyber Security, Network Security, Cloud Computing, IoT, User Authentication",
    "memberships": [],
    "projects": [],
    "patents": [
      "\"Dynamic user Authentication\" application number: 202231008515"
    ],
    "awards": [],
    "links": {
      "googleScholar": "h7pqT4YAAAAJ",
      "orcid": "0000-0003-4967-3938",
      "scopus": "57222105293"
    }
  },
  {
    "id": "vitap-1528-cms",
    "name": "Dr. Moumita Saha",
    "employeeId": "12.70659",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "424-F, AB-1",
    "email": "moumita.saha@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Moumita_saha_SENSE_1973_754daf1cd1.avif",
    "education": [
      "B.E, Tripura Institute of Technology",
      "M.Tech, Tripura University",
      "Post Doctoral Fellow, IIT Bombay and Ph.D, National Institute of Technology Agartala",
      "PDF, Indian Institute of Technology Bombay"
    ],
    "researchArea": "Nonlinear Optics, Power Electronics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-moumita-saha-1845b42b0/?originalSubdomain=in",
      "researchGate": "https://www.researchgate.net/profile/Moumita-Saha-4",
      "googleScholar": "https://scholar.google.com/citations?user=9Tv0PQkAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57223035595",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/474515"
    }
  },
  {
    "id": "vitap-1531-cms",
    "name": "Dr. Dwarasala Adilakshmi",
    "employeeId": "12.70672",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "G24-D, AB-2",
    "email": "adilakshmi.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Dwarasala_Adilakshmi_SAS_PHY_1863_19aa349906.avif",
    "education": [
      "B.Sc, Acharya Nagarjuna University",
      "M.Sc, Indian Institute of Technology Madras",
      "Ph.D, Indian Institute of Science (IISc), University of Wisconsin-Madison and University of Colorado Denver",
      "University of Wisconsin-Madison and University of Colorado Denver"
    ],
    "researchArea": "NMR spectroscopy – Methodological developments and applications. Computational NMR and Quantum computing in NMR",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1542-cms",
    "name": "Dr. Kritika Bansal",
    "employeeId": "12.70673",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "424-A, AB-1",
    "email": "kritika.b@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kritika_Bansal_70673_IMG_5132_SENSE_9723962091.avif",
    "education": [
      "B.Tech in ECE, Maharshi Dayanand University",
      "M.Tech (Control System), National Institute of Technology Kurukshetra",
      "Ph.D. (Control of Cyber-physical Systems), National Institute of Technology Delhi"
    ],
    "researchArea": "Control System, Robotics, Cyber-physical Systems",
    "memberships": [
      "IEEE Member"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=2EnvPyAAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1575-cms",
    "name": "Dr. Ravi Kumar Poluru",
    "employeeId": "12.70699",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "G02-F, AB-2",
    "email": "ravikumar.poluru@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ravi_Kumar_Poluru_SCOPE_2a312b38bd.avif",
    "education": [
      "B.Tech JNTU Hyderabad",
      "M.Tech JNTU Anantapur",
      "Ph.D VIT Vellore"
    ],
    "researchArea": "Internet of Things, Wireless Sensor Networks, Machine Learning, Deep Learning, Optimization Techniques",
    "memberships": [
      "Senior IEEE, IFERP, LMISTE,LWSDIWC,LMIAENG"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ravi-kumar-poluru-ph-d-senior-ieee-lmiste-lmiaeng-9bb48066/",
      "researchGate": "https://www.researchgate.net/profile/Ravi-Kumar-234?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=7m89BWYAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57197759573oo",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/217051"
    }
  },
  {
    "id": "vitap-1569-cms",
    "name": "Dr. Pujari Jeevana Jyothi",
    "employeeId": "12.707",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "619-L, CB",
    "email": "jeevanajyothi.pujari@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pujari_Jeevana_Jyothi_SCOPE_IMG_2129_1155d87a4c.avif",
    "education": [
      "B.Tech., JNTUH",
      "M.Tech., ANU",
      "ANU"
    ],
    "researchArea": "Machine Learning, Deep Learning, Soft Computing",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=tq8VrrgAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57195413595"
    }
  },
  {
    "id": "vitap-1582-cms",
    "name": "Dr. Anil Kumar Nayak",
    "employeeId": "12.70717",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "328-C, AB-1",
    "email": "anilkumar.nayak@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Anil_Kumar_Nayak_SENSE_8b62304e57.avif",
    "education": [
      "B.Tech (Electronics and Telecommunication Engineering) & Biju Patnaik University of Technology Rourkela Odisha",
      "M.Tech (RF and Microwave Engineering) & Indian Institute of Technology, Kharagpur",
      "Ph.D. (RF and Microwave Engineering) & Indian Institute Of Technology Roorkee and University of Alberta, Canada",
      "PDF & Indian Institute Of Technology Indore"
    ],
    "researchArea": "\" RF and Microwave Engineering: SIW transitions, composite right–left hand (CRLH) material for future communication, frequency-reconfigurable, ultrawide-band, and computational electromagnetic, in-band and out-band full duplex antenna, implantable antenna for biomedical application, and on-chip antennas.\"",
    "memberships": [
      "IEEE Member, AP-S MTT, ans AESS Society, URSI Senior Member"
    ],
    "projects": [],
    "patents": [
      "1. Anil Kumar Nayak et al., \"\"A Dual-Band In-Band Full-Duplex (DB-IBFD) Planar Antenna System.,\"\" Provisional Application Filed for Indian Patent, ( Published: Application No 202541022279)",
      "2. Anil Kumar Nayak et al., \"\"A Multi-Horn Antenna Device for Unmanned Aerial Vehicle Applications,\"\" Provisional Application Filed for Indian Patent, Application no.-202421016266 (Granted)"
    ],
    "awards": [
      "Paper entitled \" Ultra-Wideband Full-Duplex Antenna for 5G Applications\" (Authors: A. K. Nayak, S. Singh, A. S, R. Mishra and K. C. Rout (Presenter: Anil Kumar Nayak) obtained the First Runners-up Track Best Paper Award of 2023 IEEE International Symposium on Antennas and Propagation (ISAP2023), Berjaya Times Square Hotel, Kuala Lumpur, Malaysia from 30 October 2023 to 02 November 2023.",
      "Paper entitled \" Compact Antenna using IDC based CRLH-TL unit cell for L-band applications\" (Authors: A. K Nayak, Shashi Busan Panda, Kailash Rout and H. Mohapatra (Presenter: Anil Kumar Nayak) obtained the Best Paper Award of IEEE ICIT-2018, CET, Bhubaneswar, Dec 2018.",
      "Paper entitled\" SIW-based Patch Antenna with Improved Performance \" (Authors: Anil Kumar Nayak and A Patnaik, Presenter: Anil Kumar Nayak) obtained the third prize in the Student Paper Competition (SPC) of IEEE Applied Electromagnetics Conference (IEEE AEMC 2017)",
      "The paper entitled\" A Novel SIW H-plane antenna for Ku band application \" (Authors: A.K Nayak, Shashi Busan Panda, and Kailash Rout, Presenter: Anil Kumar Nayak) obtained the Best Paper Award of ICCI-SEM 2K17, Bhubaneswar, Feb 2017.",
      "Paper entitled \" GPS Navigation\" (Authors: A. K Nayak, D.R. Jena, Presenter: Anil Kumar Nayak) obtained the third prize of CVTRONICS 2006, CVRAMAN Engg. College Bhubaneswar, Feb 2006.",
      "A paper entitled \" Speared Spectrum Modulation in Communication\" (Authors: A. K Nayak, D.R. Jena, Presenter: Anil Kumar Nayak) obtained a Best Paper Award of ADVITA 2006, GIET Gunpur, Jan 2006."
    ],
    "links": {
      "linkedin": "linkedin.com/in/dr-anil-kumar-nayak-777a38123",
      "researchGate": "https://www.researchgate.net/profile/Anil-Nayak-3",
      "googleScholar": "https://scholar.google.com/citations?user=ihidNzcAAAAJ&hl=th"
    }
  },
  {
    "id": "vitap-1586-cms",
    "name": "Dr. Annapureddy V N Reddy",
    "employeeId": "12.70721",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "619-I, CB",
    "email": "vnreddy.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Annapureddy_V_N_Reddy_SCOPE_0eedf22182.avif",
    "education": [
      "B.Tech , Nagarjuna University",
      "M.Tech , Andhra University",
      "Computer Science and Engineering, KL University"
    ],
    "researchArea": "Image Processing, Machine Learning, Deep Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/",
      "googleScholar": "https://scholar.google.co.in/citations?user=114lDEgAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57218921687",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/208956"
    }
  },
  {
    "id": "vitap-1592-cms",
    "name": "Dr. Palacharla Ravi Kumar",
    "employeeId": "12.70727",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "615 - N, CB",
    "email": "ravikumar.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Palacharla_Ravi_Kumar_SCOPE_6b7bf7b187.avif",
    "education": [
      "B.Tech, JNTUH",
      "M.Tech Acharya Nagarjuna University",
      "Ph.D Andhra University"
    ],
    "researchArea": "Natural Language Processing",
    "memberships": [
      "ISTE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=8yvFGwMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57284749800"
    }
  },
  {
    "id": "vitap-1595-cms",
    "name": "Dr. Guruprakash Jayabalasamy",
    "employeeId": "12.7073",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "128-F, CB",
    "email": "guruprakash.j@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Guruprakash_Jayabalasamy_70730_SCOPE_87c529ffc9.avif",
    "education": [
      "Bachelor of Engineering (BE), MKU",
      "Master of Technology (M.Tech.), VTU",
      "Doctor of Philosophy - PhD, Vellore Institute of Technology"
    ],
    "researchArea": "Software Engineer & Blockchain",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/guruprakash-j/",
      "researchGate": "https://www.researchgate.net/profile/Guruprakash-Jayabalasamy",
      "googleScholar": "https://scholar.google.com/citations?user=W6K0C_QAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57218643244"
    }
  },
  {
    "id": "vitap-1602-cms",
    "name": "Dr. Susmita Mahato",
    "employeeId": "12.70737",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "329-C, AB-1",
    "email": "susmita.mahato@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Susmita_Mahato_SASMAT_6464f9569c.avif",
    "education": [
      "B.C.A , Indira Gandhi National Open University",
      "M.C.A, Indira Gandhi National Open University",
      "PhD, National Institute of Technology, Jamshedpur"
    ],
    "researchArea": "Information Security",
    "memberships": [
      "CSI"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-susmita-mahato-8086a29a",
      "googleScholar": "https://scholar.google.com/citations?user=yJ68xKkAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55812466500"
    }
  },
  {
    "id": "vitap-1604-cms",
    "name": "Dr. Shajan Joseph",
    "employeeId": "12.70739",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "225-B, AB-2",
    "email": "shajan.joseph@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shajan_Joseph_SASMAT_8c006550e8.avif",
    "education": [
      "BSc (Physics) & Mahatma Gandhi University, Kottayam",
      "MCA & Madras University, Chennai",
      "PhD & Anna Uniersity, Chennai"
    ],
    "researchArea": "Mobile Adhoc Network (MANET) Security",
    "memberships": [
      "IEEE, CSI"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1605-cms",
    "name": "Dr. Karrothu Aravind",
    "employeeId": "12.7074",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "626 - N, CB",
    "email": "aravind.karrothu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Karrothu_Aravind_SCOPE_472ef80f94.avif",
    "education": [
      "Information Technology & VIT University-Vellore",
      "IT (Networking) & VIT University-Vellore",
      "Information Security & VIT University-Vellore"
    ],
    "researchArea": "Information Security, Data Communication and Computer Networks",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=UM-06poAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57191624481",
      "vidwan": "284553"
    }
  },
  {
    "id": "vitap-1608-cms",
    "name": "Dr. Kommerla Siva Kumar",
    "employeeId": "12.70743",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "204-E, CB",
    "email": "sivakumar.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kommerla_Siva_Kumar_SCOPE_6e8982f1b3.avif",
    "education": [
      "B.Tech - CSE , JNTU - Hyderabad.",
      "M.Tech - CSE , JNTU - Kakinada.",
      "Ph.D - CSE , VTU - Karnataka."
    ],
    "researchArea": "Computer Vision and Digital Image Processing, Machine Learning , Deep Learning.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57832933600"
    }
  },
  {
    "id": "vitap-1611-cms",
    "name": "Dr. Aruru Sai Kumar",
    "employeeId": "12.70744",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "164, AB-1",
    "email": "saikumar.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Aruru_Sai_Kumar_SENSE_IMG_7279_6d0ef1b569.avif",
    "education": [
      "B.Tech & JNTU Hyderabad",
      "M.Tech & VIT University Vellore",
      "PhD & NIT Warangal"
    ],
    "researchArea": "Low Power VLSI Design",
    "memberships": [
      "IETE LIFE MEMBER-: M-502917"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "I have been recognized among the “World's Top 2% Scientists globally for 2023”, according to the esteemed analysis conducted by Stanford University and Elsevier (Scopus), which is published on September 16, 2024."
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Aruru-Sai-Kumar",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=U6DJkcMAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57215574825",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/250583"
    }
  },
  {
    "id": "vitap-1612-cms",
    "name": "Dr. Vivek Upadhyaya",
    "employeeId": "12.70745",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "329-F, AB-1",
    "email": "vivek.upadhyaya@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vivek_Upadhyaya_SENSE_IMG_7263_d9d79112d7.avif",
    "education": [
      "B.E. & University of Rajasthan, Jaipur",
      "M.Tech, Malaviya National Institute of Technology Jaipur (MNIT)",
      "PhD, Malaviya National Institute of Technology Jaipur (MNIT)"
    ],
    "researchArea": "Medical Imaging, Digital Image Processing, Digital Signal Processing, Biomedical Signal Processing",
    "memberships": [
      "Senior Member IEEE (95261351)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-vivek-upadhyaya-ph-d-35a66619",
      "researchGate": "https://www.researchgate.net/profile/Vivek-Upadhyaya-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&authuser=3&user=lF9-N1wAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57192688125",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/122397"
    }
  },
  {
    "id": "vitap-1613-cms",
    "name": "Dr. Sajad Nabi Dar",
    "employeeId": "12.70749",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "620-F, CB",
    "email": "sajad.nabidar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sajad_Nabi_Dar_VISH_IMG_8160_3ebd7782b6.avif",
    "education": [
      "B.Sc. with Geography at University of Kashmir",
      "M.Sc. Geography at University of Kashmir",
      "Ph.D. Geography at University of Kashmir"
    ],
    "researchArea": "Sustainable Tourism, Climate Change Adaptation, Disaster Risk Reduction, Natural Resource Management.",
    "memberships": [],
    "projects": [
      "The Impact of Jal Jeevan Mission on Water Accessibility and Quality: An Empirical Study in Leh Ladakh (ICSSR)"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sajad-nabi-dar/",
      "researchGate": "https://www.researchgate.net/profile/Sajad-Dar?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=D0KN4WEAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57204061365",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/640656"
    }
  },
  {
    "id": "vitap-1652-cms",
    "name": "Dr. Debasis Dwibedy",
    "employeeId": "12.70788",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "619-K, CB",
    "email": "d.dwibedy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Debasis_Dwibedy_SCOPE_IMG_7311_e61b880f72.avif",
    "education": [
      "B.Tech (CSE), Biju Patnaik University of Technology (BPUT), Rourkela, Odisha",
      "M.Tech (CSE), Kalinga Institute of Industrial Technology (KIIT), Bhubaneswar, Odisha",
      "PhD(CSE), Veer Surendra Sai University of Technology (VSSUT), Burla, Odisha"
    ],
    "researchArea": "Theoretical Computer Science (Online and Semi-online Algorithms, Computational Complexity, Data Structures, Graph Theory), and Predictive Data Analytics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-debasis-dwibedy-42252526",
      "researchGate": "https://www.researchgate.net/profile/Debasis-Dwibedy?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=3DoGmNEAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57217959149"
    }
  },
  {
    "id": "vitap-1654-cms",
    "name": "Dr. Tata Gayathri",
    "employeeId": "12.7079",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "817 - M, CB",
    "email": "gayathri.t@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Tata_Gayathri_656b01d545.avif",
    "education": [
      "B.Tech, Andhra University",
      "M.Tech, Anna university",
      "Ph.D, Andhra University"
    ],
    "researchArea": "Big Data, Machine Learning, Artificial Intelligence, Neural Networks, Image Processing",
    "memberships": [
      "CSI"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/tata-gayathri-39620b382/",
      "researchGate": "https://www.researchgate.net/profile/Tata-Gayathri",
      "googleScholar": "https://scholar.google.com/citations?user=-Es3fjAAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57210696216",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/148184"
    }
  },
  {
    "id": "vitap-1662-cms",
    "name": "Dr. Turbasu Sengupta",
    "employeeId": "12.70799",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "818 - F, CB",
    "email": "turbasu.sengupta@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Turbasu_Sengupta_SASCHY_9a0ba0bc9f.avif",
    "education": [
      "B.Sc Chemistry (Honours), Serampore College, University of Calcutta",
      "M.Sc Physical Chemistry, Scottish Church College, University of Calcutta",
      "1) Ph.D CSIR National Chemical Laboratory, AcSIR, 2) Postdoctoral Researcher, University of Ulsan, South Korea, 3) Postdoctoral Associate, Virginia Commonwealth University, USA, 4) Research Scientist, PI Industries Ltd, Udaipur",
      "(1) Postdoctoral Researcher, University of Ulsan, South Korea (2) Postdoctoral Associate, Virginia Commonwealth University, USA (3) Research Scientist, PI Industries Ltd, Udaipur"
    ],
    "researchArea": "Computational Chemistry, Superatoms, Clusters & Nanoparticle, Advanced Functional Materials & Large Assemblies, Heterogeneous/Homogeneous Catalysis, Density Functional Theory, Electronic structure & Spectroscopic Properties, Machine Learning, Solvation Effect",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Krishnan Award for Best Research Paper Published in Computational Chemistry, CSIR National Chemical Laboratory, February 2016",
      "Senior Research Fellowship (SRF) Awarded by University Grants Commission, July 2015",
      "Secured Graduate Aptitude Test in Engineering (GATE) Chemistry, February 2012",
      "Secured CSIR–UGC National Eligibility Test (NET) for Lectureship and Research Fellowship Grant, December 2011"
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/turbasu-sengupta-44214929b",
      "researchGate": "https://www.researchgate.net/profile/Turbasu-Sengupta",
      "googleScholar": "https://scholar.google.co.in/citations?user=9haLEIEAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56437391500"
    }
  },
  {
    "id": "vitap-1667-cms",
    "name": "Dr. Rama Krishna Rongali",
    "employeeId": "12.70802",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "622-A, CB",
    "email": "ramakrishna.r@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rama_Krishna_Rongali_SASMAT_73cbce8431.avif",
    "education": [
      "B.Sc (M.P.C) & Andhra University, Visakhapatnam, India.",
      "M.Sc (Mathematics) & Pondicherry University, Puducherry.",
      "1) Ph.D & Jawaharlal Nehru Centre for Advanced Scientific Research (JNCASR), Bengaluru, India., 2) Research Associate & Jawaharlal Nehru Centre for Advanced Scientific Research (JNCASR), Bengaluru, India.",
      "Research Associate & Jawaharlal Nehru Centre for Advanced Scientific Research (JNCASR), Bengaluru, India."
    ],
    "researchArea": "Kinetic Theory of Granular Gases, Rarefied Gas Dynamics and Mathematical Modelling.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1673-cms",
    "name": "Dr. Mallela Siva Nagaraju",
    "employeeId": "12.7081",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "622-H, CB",
    "email": "sivanagaraju.mallela@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_MALLELA_SIVA_NAGARAJU_SCOPE_a3a8198934.JPG",
    "education": [
      "B.Tech (CSE) & JNTU Kakinada",
      "M.Tech (CSE) & JNTU Kakinada",
      "Ph.D. (CSE) & VIT-AP University"
    ],
    "researchArea": "Medical Image Processing, Deep Learning, Machine Learning",
    "memberships": [
      "IAENG-342712"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=sAKrHwsAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57465860000"
    }
  },
  {
    "id": "vitap-1681-cms",
    "name": "Dr. P Arul Nehru",
    "employeeId": "12.70821",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "424-J, AB-1",
    "email": "arul.nehru@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_P_Arul_Nehru_VISH_f48f51fae4.avif",
    "education": [
      "BA English, Thiruvalluvar University. BEd English, The English and Foreign Languages University",
      "MA English, Pondicherry University. M.Ed, Regional Institute of Education (NCERT), Mysore University of Mysore",
      "PhD (English Language Education), The English and Foreign Languages University"
    ],
    "researchArea": "Reading Comprehension, Mind Mapping, Multilingualism, Second Language Acquisition, Language Pedagogy and Teacher Education",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=tpbpV08AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1701-cms",
    "name": "Dr. Sivakavi Naga Venkata Bramareswara Rao",
    "employeeId": "12.70838",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "110, AB-1",
    "email": "bramareswararao.snv@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_SIVAKAVI_NAGA_VENKATA_BRAMARESWARA_RAO_SENSE_206fccb01d.avif",
    "education": [
      "B.E., Andhra University",
      "M.E., Andhra University",
      "Ph.D., Andhra University"
    ],
    "researchArea": "Microgrids, Power Quality, AI applications to Power Systems",
    "memberships": [
      "MIEEE"
    ],
    "projects": [],
    "patents": [
      "1. 202241039576, Hybrid Renewable Energy System Covering Energy Storage Device Coordination Method (Utility Patent)",
      "2. 202241076962, Artificial Intelligence-Based Load Demand Forecasting for Green Microgrid Cluster (Utility Patent)",
      "3. 380823-001, Multi-Antenna Supporter (Granted Design Patent)"
    ],
    "awards": [
      "Visvesvaraya PhD Fellowship, Digital India Corporation, MeitY, Government of India, 2023"
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-s-n-v-bramareswara-rao-564b27a3",
      "researchGate": "https://www.researchgate.net/profile/N-V-Rao-S?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=UAXd788AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57202995366",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/301393"
    }
  },
  {
    "id": "vitap-1707-cms",
    "name": "Dr. Mohammad Amin Wani",
    "employeeId": "12.70846",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "G24-J, AB-2",
    "email": "mohammadamin.wani@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_MOHAMMAD_AMIN_WANI_VISH_f96a962159.avif",
    "education": [
      "Bachelor of Arts (BA) University of Kashmir",
      "MA Psychology Chaudhary Charan Singh University Meerut",
      "PhD Psychology Annamalai University Tamil Nadu"
    ],
    "researchArea": "HIV/AIDS, Midlife Crisis, Coping Strategies, Psychometrics, Scale Development, Health Psychology, and Aging Psychology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Award of Excellence for young researcher in Psychology by Hon'ble State Minister of Uttarakhand, India, Mrs. Madhu Bhatt, at the International Seminar on \"\"Integration of Science & Special Education\"\" held on July 7, 2024.",
      "Best Researcher Award International organization of scientific research and development in “94th International Research Awards on Engineering, Science and Management” on 4th November 2018 at Ranchi.",
      "Professor Deepak Bhat Award by Indian Academy of Psychology In Three days International Conference on “Psychology for Building Global Community” organized by Department of Psychology, University of Rajasthan, Jaipur in Feb 2016\""
    ],
    "links": {
      "linkedin": "linkedin.com/in/dr-mohammad-amin-wani-32594111b",
      "researchGate": "https://www.researchgate.net/profile/Mohammad-Wani?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=EcWvERIAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57209141983",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/705674"
    }
  },
  {
    "id": "vitap-1710-cms",
    "name": "Dr. Popuri Srinivasa Rao",
    "employeeId": "12.70847",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1017-B, CB",
    "email": "srinivas.popuri@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_POPURI_SRINIVASA_RAO_SCOPE_f3e8543e71.avif",
    "education": [
      "B.TECH from JNTUK",
      "M.TECH from JNTUK",
      "P.hD from VIT-AP"
    ],
    "researchArea": "Data warehousing with optimization techniques",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=xz6eqygAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58002095100",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/409942"
    }
  },
  {
    "id": "vitap-1730-cms",
    "name": "Dr. Sourav Ghosh",
    "employeeId": "12.70865",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "309 - C, AB-1",
    "email": "sourav.ghosh@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sourav_Ghosh_SENSE_e9e97b6101.avif",
    "education": [
      "B.Tech in ECE, Kalyani Government Engineering College, WBUT",
      "M.Tech in Nanotechnology, VIT Vellore",
      "PhD, IIT Madras",
      "IIT Madras"
    ],
    "researchArea": "Nanomaterials for energy storage devices and applied machine learning",
    "memberships": [
      "IEEE, IFERP, IAENG"
    ],
    "projects": [],
    "patents": [
      "1. Temperature tolerant and highly cyclable all-oxynitride-based solid state asymmetric supercapacitors (Indian patent grant no: 461057).",
      "2. Accelerated machine-learning-based system and method for predicting appropriate materials and rapid prototyping of energy-storage devices (Indian patent grant no: 495621)."
    ],
    "awards": [
      "Seal of Excellence in “Marie Skłodowska-Curie Actions Postdoctoral Fellowship – 2024",
      "Trusted Reviewer Award by IOP (Institute of Physics), 2024.",
      "Awardee of the best Ph.D. thesis award from the Department of Metallurgical and Materials Engineering, Indian Institute of Technology Madras, 2022.",
      "Winner of ‘Institute Research Award’ for excellence in research work, IIT Madras, 2021.",
      "Winner of the ‘Best Research Award,’ in the Chemical Engineering and Chemistry Conference, Students’ Research Convention, IIT Kanpur, 2021.",
      "A winning team member of ‘Sweden India Mobility Hack’ by Swedish Institute, 2021.",
      "Winner of Augmenting Writing Skills for Articulating Research (AWSAR) award from DST, India in ‘Popular Science Story (Ph.D.) 2020’ category.",
      "Awardee of ‘Young Researcher Award’ by the Institute of Scholars (2020)."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/souravsupercaps/",
      "researchGate": "https://www.researchgate.net/profile/Sourav-Ghosh-21",
      "googleScholar": "https://scholar.google.com/citations?user=-jR82kgAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201532846"
    }
  },
  {
    "id": "vitap-1742-cms",
    "name": "Dr. Pallepogu Prasanna Kumar",
    "employeeId": "12.70877",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "621-C, CB",
    "email": "prasannakumar.pallepogu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pallepogu_Prasanna_Kumar_SENSE_edbfb1e067.avif",
    "education": [
      "B.Tech (ECE), JNTUK",
      "M.Tech (Electronics), Pondicherry University",
      "PhD in RF and Microwave, IIITDM Kancheepuram",
      "Postdoctoral Researcher, IIT Madras"
    ],
    "researchArea": "Antenna Design, RF & Microwave Engineering, High-Speed Optical Communication, Signal Integrity & EMC, High-Speed Interconnects and Electronic Packaging.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://in.linkedin.com/in/pallepogu-prasanna-kumar-98a09231",
      "researchGate": "https://www.researchgate.net/profile/Pallepogu-Prasanna-Kumar",
      "googleScholar": "https://scholar.google.com/citations?user=0AeUG48AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/pages/authors/57216459746"
    }
  },
  {
    "id": "vitap-1747-cms",
    "name": "Dr. Kadiyam Rajshekar",
    "employeeId": "12.70882",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "817 - C, CB",
    "email": "kadiyam.rajshekar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_KADIYAM_RAJSHEKAR_SENSE_de2da9b420.avif",
    "education": [
      "B.Tech. and QIS College of Engineering and Technology (JNTU Kakinada Afflicated)",
      "M.Tech. and Vellore Institute of Technology, Vellore, Tamil Nadu, India.",
      "Ph.D., and Vellore Institute of Technology, Vellore, Tamil Nadu, India."
    ],
    "researchArea": "Semiconductor Device Physics, TCAD Modeling, and Fabrication and Characterisation of Oxide Semiconductor Thin Film Transistors",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Senior Research Fellowship Direct, Council of Scientific & Industrial Research, India and 2018"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=dy6-IEMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/pages/organization/60010618"
    }
  },
  {
    "id": "vitap-1754-cms",
    "name": "Dr. Potnuru Lokeswara Rao",
    "employeeId": "12.70889",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "817-O, CB",
    "email": "lokeswararao.potnuru@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Potnuru_Lokeswara_Rao_SASPHY_69974d34e2.avif",
    "education": [
      "BSc, Andhra University",
      "MSc, Pondicherry University",
      "PhD, IISc, Postdoc1-TIFR Hyderabad, Postdoc2-University of California Santa Barbara, Postdoc3-Northwestern University",
      "Postdoc1-TIFR Hyderabad, Postdoc2-University of California Santa Barbara, Postdoc3-Northwestern University"
    ],
    "researchArea": "Magnetic Resonance - Methods development, applications to materials, small molecules.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/lokeswara-rao-p-53a7b91b/",
      "researchGate": "https://www.researchgate.net/profile/Lokeswara-Rao?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=s0_NkrwAAAAJ&hl=en&oi=ao"
    }
  },
  {
    "id": "vitap-1756-cms",
    "name": "Dr. Sk. Sazim",
    "employeeId": "12.70891",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "817-I, CB",
    "email": "sazim.sk@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sk_Sazim_SAS_aa0d7194dc.avif",
    "education": [
      "B. Sc. (Physics Hons.), The university of Burdwan, Bardhaman, WB",
      "M. Sc. (Physics), The university of Burdwan, Bardhaman, WB",
      "1. PhD (Quantum computing), Homi Bhaba National Institute, Mumbai, 2. Postdoctoral fellow, Harish-Chandra Research Institute, Allahabad; 3. Stefan Schwarz fellow, RCQI, IP, Slovak Academy of Science, Bratislava; 4. PASIFIC fellow (MSCA cofund), CFT, Polish Academy of Science, Warsaw; 5. Visiting fellow, Universite Libre de Bruxelles, Brussels",
      "1. Postdoctoral fellow, Harish-Chandra Research Institute, Allahabad; 2. Stefan Schwarz fellow, RCQI, IP, Slovak Academy of Science, Bratislava; 3. PASIFIC fellow (MSCA cofund), CFT, Polish Academy of Science, Warsaw; 4. Visiting fellow, Universite Libre de Bruxelles, Brussels"
    ],
    "researchArea": "Quantum error correction, algorithms, and foundations",
    "memberships": [],
    "projects": [
      "1. Robustness and certification of quantum resources, Slovak Academy of Science, Bratislava 2019-22;",
      "2. Higher order maps and (quantum) communication network, Pasific project (2022-24), EU Horizon 2020 and Maria-Skĺodowska-Curie COFUND, Total amount: 149940 Euro."
    ],
    "patents": [
      "Thermodynamic Autonomous Quantum Error Cooling: CKL-Compliant Controllers for Fault-Tolerant Memory and Hybrid QEC, Provisional Patent Application (Singapore), Appl. Id 10202503402S (16 December 2025"
    ],
    "awards": [
      "Marie Skłodowska-Curie Fellowship at Polish Academy of Sciences (PAN), Warsaw (2022).",
      "Stefan Schwarz stipend from Slovak Academy of Sciences (SAV), Slovakia (2019).",
      "National Eligibility Test (NET), CSIR-UGC, India (2010).",
      "West Bengal Govt Merit-Cum-Means Scholarship (2007)"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sk-sazim-06a622334/",
      "googleScholar": "https://scholar.google.com/citations?user=j1Gm6hEAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/inward/authorDetails.uri?authorID=55928605000&partnerID=MN8TOARS"
    }
  },
  {
    "id": "vitap-1770-cms",
    "name": "Dr. Bellamkonda Lakshmi Praveena",
    "employeeId": "12.70906",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "819 - E, CB",
    "email": "lakshmipraveena.bellamkonda@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bellamkonda_Lakshmi_Praveena_SCOPE_0443c3f817.avif",
    "education": [
      "B.tech(cse),Acharya Nagarjuna University",
      "M.tech(cse), JNTUK",
      "Ph.D, SPMVV"
    ],
    "researchArea": "Machine learning, deep learning , computer vision , health care, agriculture, neurological disorders, dentistry.",
    "memberships": [
      "ACM - 8469489 , CSI - 5021240051, IAENG - 154405, AIMER"
    ],
    "projects": [
      "1. Smart SQL Bot - Dataware housing department - Hexagon LLP",
      "2. Dental AI - Detect dental diseases from pathology x-rays - Vishnu Dental College & Hospital, Bhimavaram"
    ],
    "patents": [
      "1. App No: 202341027693 - Title: Neuro Disorders Diagnosis Application",
      "2. App No: 202441027697 -Title: Heal AI Healthcare Assistant",
      "3. App No:'202441074678 - Title: The Triple Threat: YOLOv5, YOLOv8 & YOLOv9– Reinventing X-ray Security",
      "4. App No:202441083949 - Title: Cognitive Profiling System for Enhancing Placement Opportunities in Higher Education"
    ],
    "awards": [
      "1. Best Thesis Award, SPMVV, 2022",
      "2. Best Educationist, Outlook Express, 2024"
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/laxmi-praveena",
      "researchGate": "https://www.researchgate.net/profile/Lakshmi-Praveena-B",
      "googleScholar": "https://scholar.google.com/citations?user=DRFRoMIAAAAJhl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57205298218",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/378131"
    }
  },
  {
    "id": "vitap-1778-cms",
    "name": "Dr. Pritesh Kumar Yadav",
    "employeeId": "12.70915",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "812-P, CB",
    "email": "pritesh.K@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pritesh_Kumar_Yadav_SENSE_9a3f7e477a.avif",
    "education": [
      "B.Tech, Uttar Pradesh Technical University",
      "M.Tech, Indian Institute of Information Technology Allahabad",
      "Ph.D, Indian Institute of Information Technology Allahabad"
    ],
    "researchArea": "RF/Analog Integrated Circuits",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/pritesh-kumar-yadav-aa970269",
      "googleScholar": "https://scholar.google.com/citations?user=E3L_qxoAAAAJ&hl=en&oi=ao"
    }
  },
  {
    "id": "vitap-1798-cms",
    "name": "Dr. Allam Akshaykranth",
    "employeeId": "12.7094",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1016-M, CB",
    "email": "akshaykranth.allam@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Allam_Akshaykranth_SENSE_d4c537b198.avif",
    "education": [
      "B Tech (ECE), JNTUH",
      "M.Tech, JNTUH",
      "Ph.D, NIT Warangal"
    ],
    "researchArea": "Semiconductor Device Modelling and Nanomaterials",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-a-akshaykranth-0bb67b45/",
      "googleScholar": "https://scholar.google.com/citations?user=DPb-vmwAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57194379411"
    }
  },
  {
    "id": "vitap-1806-cms",
    "name": "Dr. Viwek Kumar",
    "employeeId": "12.70948",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "313-G, AB-1",
    "email": "viwek.kumar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Viwek_Kumar_SMEC_228ebf6343.avif",
    "education": [
      "B.Tech (Mechanical Engineering) - Kurukshetra University",
      "M.Tech (Machine Design) - Indian Institute of Engineering Science of Technology (IIEST), Shibpur",
      "Ph.D. (Mechanical Engineering) - IIT Guwahati",
      "Post Doctoral Research - IIT Kanpur"
    ],
    "researchArea": "Smart Materials and Structures, Powder Metallurgy, Composite Materials, Finite Element Analysis, Structural Mechanics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Travel Grant, CSIR, 2023"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/viwek-kumar-5839a733/",
      "googleScholar": "https://scholar.google.com/citations?user=dpuDyB4AAAAJ&hl=en&oi=ao"
    }
  },
  {
    "id": "vitap-1812-cms",
    "name": "Dr. Saurabh Kharwar",
    "employeeId": "12.70954",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1017 - M, CB",
    "email": "saurabh.kharwar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Saurabh_Kharwar_SENSE_90cf6eebad.avif",
    "education": [
      "B.Tech - Dr. A.P.J. Abdul Kalam Technical University Lucknow",
      "M.Tech - National Institute of Technology Patna",
      "PhD - National Institute of Technology Patna"
    ],
    "researchArea": "Microelectronics and VLSI design",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-saurabh-kharwar-phd-85a93898/",
      "googleScholar": "https://scholar.google.com/citations?user=mq7NA4AAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1815-cms",
    "name": "Dr. Sivaranjan Uppala",
    "employeeId": "12.70957",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "1016-K, CB",
    "email": "sivaranjan.uppala@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Uppala_Sivaranjan_SASCHY_0b19870d65.avif",
    "education": [
      "B.Sc., Acharya Nagarjuna University",
      "M.Sc., Andhra University",
      "Ph.D., IISER Mohali",
      "Postdoctoral Fellow, Hebrew University-Israel"
    ],
    "researchArea": "NMR Spectroscopy, dissolution Dynamic Nuclear Polarization (d-DNP)",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Best Poster Presentation Award in 22nd NMRS-2016 at IIT Kharagpur;",
      "Qualified GATE-2011 in Chemical Sciences;",
      "Qualified NET-LS (CSIR/UGC-2009) in Chemical Sciences"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=0TpzSiYAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1817-cms",
    "name": "Dr. Emandi Jagadeeswara Rao",
    "employeeId": "12.70959",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "623-G, CB",
    "email": "jagadeeswararao.emandi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Emandi_Jagadeeswara_Rao_SENSE_fe2a729c2c.avif",
    "education": [
      "B.Tech. & JNTU Kakinada",
      "M.Tech. & Andhra University",
      "Ph.D. & Pondicherry University (Central University), Post. Doc. & NIT Rourkela",
      "Post. Doc. & NIT Rourkela"
    ],
    "researchArea": "VLSI Design & Embedded Systems",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/E-Rao/achievement/6a969afb13c3715a7e49713c",
      "googleScholar": "https://scholar.google.co.in/citations?user=CRTTAI8AAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57204909304",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/596874"
    }
  },
  {
    "id": "vitap-1821-cms",
    "name": "Dr. Himadri Sekhar Sarkar",
    "employeeId": "12.70963",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "1017-J, CB",
    "email": "himadrisekhar.sarkar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Himadri_Sekhar_Sarkar_SASCHE_3620234bcd.avif",
    "education": [
      "B.Sc. (Hons.) in Chemistry, Burdwan Raj College, The University of Burdwan, West Bengal, India",
      "M.Sc. in Chemistry (Organic Chemistry specialization), The University of Burdwan, West Bengal, India",
      "1. Ph.D. in Chemistry (2018), Visva-Bharati (A Central University), West Bengal, India, 2. Japan Society for the Promotion of Science (JSPS) Postdoctoral Fellow (2018 – 2021), Supervisor: Prof. Shin Mizukami, Institute of Multidisciplinary Research for Advanced Materials (IMRAM), Tohoku University, Japan; 3. ANRF-National Postdoctoral Fellow (NPDF) (2021 – 2023), Mentor: Dr. Arindam Talukdar, Scientist F, Dept. of Organic & Medicinal Chemistry, CSIR-Indian Institute of Chemical Biology, India; 4. Research Associate-II (2023 – 2024), Supervisor: Dr. Arindam Talukdar, Scientist F, Dept. of Organic & Medicinal Chemistry, CSIR-Indian Institute of Chemical Biology, India; 5. Research Associate-III (2024 – 2026), Supervisor: Dr. Arindam Talukdar, Scientist F, Dept. of Organic & Medicinal Chemistry, CSIR-Indian Institute of Chemical Biology, India",
      "1. Japan Society for the Promotion of Science (JSPS) Postdoctoral Fellow (2018 – 2021), Supervisor: Prof. Shin Mizukami, Institute of Multidisciplinary Research for Advanced Materials (IMRAM), Tohoku University, Japan; 2. ANRF-National Postdoctoral Fellow (NPDF) (2021 – 2023), Mentor: Dr. Arindam Talukdar, Scientist F, Dept. of Organic & Medicinal Chemistry, CSIR-Indian Institute of Chemical Biology, India; 3. Research Associate-II (2023 – 2024), Supervisor: Dr. Arindam Talukdar, Scientist F, Dept. of Organic & Medicinal Chemistry, CSIR-Indian Institute of Chemical Biology, India; 4. Research Associate-III (2024 – 2026), Supervisor: Dr. Arindam Talukdar, Scientist F, Dept. of Organic & Medicinal Chemistry, CSIR-Indian Institute of Chemical Biology, India"
    ],
    "researchArea": "Organic Synthesis, Molecular Recognition, Chemical Biology, Medicinal Chemistry, Cell & Molecular Biology, Protein Engineering, Molecular Modeling, DFT calculations, In Vitro and In Vivo Preclinical Assay, Targeted Protein Degradation (TPD), PROTACs, Molecular Glues (MGs) and Translational Drug Discovery.",
    "memberships": [
      "\"1. Member of the American Chemical Society (ACS), 2. Member of the Royal Society of Chemistry (MRSC), 3. Lifetime Fellow of the Indian Chemical Society (FICS), 4. Member of the International Chemical Biology Society (ICBS), 5. Member of the Society of Biological Chemists (India)\""
    ],
    "projects": [
      "Principal Investigator (PI), ANRF-National Postdoctoral Fellowship (NPDF), Department of Science and Technology (DST), Govt. of India, Project Title: Photoreversible Spatiotemporal Control of Targeted Protein Degradation via Small Molecule–Protein Engineering: A Promising New Direction in Photopharmacology, Period: April 2011- April 2023,"
    ],
    "patents": [
      "1. PROTACs for ASK1 Protein Degradation: Preparation and Use Thereof, A. Talukdar, H. S. Sarkar, P. Chakrabarti, I. Hoque, A. Sen, U. G. Dastidar, and A. Dey, PCT Int. Appl.: WO2024236595A1, Date of filing: 13th May 2024, Theme: Healthcare.",
      "2. Small molecule modulators for PPAR gamma in ameliorating non-alcoholic fatty liver disease: Preparation and Use thereof, A. Talukdar, P. Chakrabarti, S. Goon, D. Sarkar, S. K. Maiti, A. D. Sharma, S. Pal, and H. S. Sarkar, Application Number: 202311083005, Date of filing: 05th December 2023, Theme: Healthcare."
    ],
    "awards": [
      "MSCA Seal of Excellence Certificate, Marie Skłodowska Curie (MSCA) Postdoctoral Fellowship 2025, European Commission, Brussels, 16th February 2026.",
      "MSCA Seal of Excellence Certificate, Marie Skłodowska Curie (MSCA) Postdoctoral Fellowship 2024, European Commission, Brussels, 14th February 2025.",
      "EMBO Travel Grant to present oral talk at the EMBO Workshop: Chemical Biology 2024, 09-12th September 2024, EMBL Advanced Training Centre, Heidelberg, Germany.",
      "Best poster presentation and flash talk award on “Targeted degradation of apoptosis signal-regulating kinase 1 using selonsertib-based PROTACs: A promising approach for the treatment of NAFLD/NASH” in the ‘Chemical Biology and Physiology-2023’ at Oregon Health & Science University, Portland, USA, 14-17th December, 2023.",
      "International Travel Grant for Young Scientists-2023 by Science & Engineering Research Board (SERB), Department of Science and Technology (DST), Govt. of India.",
      "Foreign Travel Grant-2023 by Council of Scientific & Industrial Research (CSIR), Ministry of Science and Technology, Government of India.",
      "Best poster presentation award on “Development of a chemical biology tool enabling reversible optical control of protein labeling: A promising new direction in photopharmacology” in the International Conference on Frontier Areas of Science and Technology (ICFAST) at the University of Hyderabad, 2022.",
      "DBT-Research Associate Fellowship-2021 by the Department of Biotechnology (DBT), Ministry of Science and Technology, Government of India.",
      "National Postdoctoral Fellowship (NPDF)-2020 at the CSIR-Indian Institute of Chemical Biology (IICB) by the Science and Engineering Research Board (SERB), Department of Science and Technology (DST), Government of India.",
      "JSPS Postdoctoral Fellowship-2018 at the Tohoku University, Japan, by the Japan Society for the Promotion of Science (JSPS), Ministry of Education, Culture, Sports, Science and Technology (MEXT), Government of Japan.",
      "“Professor Asima Chatterjee Young Scientist Award-2018” for contribution to Synthetic Organic Chemistry by Professor Asima Chatterjee Foundation, Kolkata, India.",
      "Best poster presentation award on “Development of a chemosensor to visualize DCP, a nerve agent mimic, in Catfish brain” in the Professor Asima Chatterjee Birthday Centenary Celebration Seminar at the University of Calcutta, 2018."
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/himadri-sekhar-sarkar",
      "researchGate": "https://www.researchgate.net/profile/Himadri_Sarkar4?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.co.in/citations?user=bSd7dbwAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57190371268"
    }
  },
  {
    "id": "vitap-1827-cms",
    "name": "Dr. A S Arunkumar",
    "employeeId": "12.70969",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "723-B, CB",
    "email": "as.arunkumar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_A_S_Arunkumar_vish_74484c2423.avif",
    "education": [
      "B Sc. Zoology & University of Madras,",
      "M A Anthropology & University of Madras",
      "Ph D Anthropology & Pondicherry University, PDF & French Institute of Pondicherry",
      "PDF & French Institute of Pondicherry"
    ],
    "researchArea": "political ecology, coastal studies, and the anthropology of media and caste",
    "memberships": [],
    "projects": [
      "Modern Endangered Archives Program (MEAP-04-0078): 'Archiving Tamil Fish Workers in Print', funded by UCLA Library, University of California, Los Angeles (November 2022 – October 2023)."
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/arunkumar-a-s-7b42523aa",
      "googleScholar": "https://scholar.google.com/citations?user=btkTTS0AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1828-cms",
    "name": "Dr. Kumar Nishant Ranjan Sinha",
    "employeeId": "12.7097",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "329-B, AB-1",
    "email": "nishant.sinha@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kumar_Nishant_Ranjan_Sinha_SMEC_36f4f6c63e.avif",
    "education": [
      "B. Tech., West Bengal University of Technology, West Bengal",
      "1. Ph.D., Indian Institute of Technology Patna, India, 2. Post-Doc, Institute of Technical Thermodynamics, TU Darmstadt, Germany. 3. Post-doc, School of Mechanical Engineering, Purdue University, USA",
      "1. Post-Doc, Institute of Technical Thermodynamics, TU Darmstadt, Germany. 2. Post-doc, School of Mechanical Engineering, Purdue University, USA"
    ],
    "researchArea": "Phase Change Heat Transfer, Bubble Acoustics, Deep Learning, Thermal Management",
    "memberships": [
      "American Society of Mechanical Engineering"
    ],
    "projects": [],
    "patents": [
      "FoamPipe Filed with European Patent Office"
    ],
    "awards": [
      "Best Presentation Award, Cooling Technology Research Center (CTRC) Review Meeting, Purdue University, USA, 2025.",
      "Best Poster Award, Research Scholars’ Day, Indian Institute of Technology Patna, India, 2020.",
      "Best Paper Award, ISHMT-ASTFE Heat and Mass Transfer Conference, Indian Institute of Technology Roorkee, India, 2019.",
      "Best Presentation Award, “My Research in Three Minutes,” Indian Institute of Technology Patna, India, 2018.",
      "First Rank in B.Tech. Mechanical Engineering, Netaji Subhash Engineering College, Kolkata, India, 2016, CGPA: 9.04/10.",
      "Doctoral Research Fellowship, Ministry of Human Resource Development (MHRD), Government of India, 2019–2022.",
      "Research Fellowship, Department of Science and Technology (DST), Government of India, 2016–2019."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/kumar-nishant-ranjan-sinha-50136346/",
      "researchGate": "https://www.researchgate.net/profile/Kumar-Sinha-2",
      "googleScholar": "https://scholar.google.com/citations?user=bABCrnYAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1326-cms",
    "name": "Dr. Peeyush Singh",
    "employeeId": "13.70186",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "307-A, AB-2",
    "email": "peeyush.singh@vitap.ac.in",
    "phone": "5800",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Peeyush_Singh_70186_IMG_4971_SENSE_f48be8df7a.avif",
    "education": [
      "University of Allahabad",
      "University of Allahabad",
      "IIT Kanpur",
      "TIFR Centre for Appliable Mathematics (TIFR CAM)"
    ],
    "researchArea": "Parallel Computing ,Numerical Analysis and Mathematical Modelling",
    "memberships": [],
    "projects": [
      "Numerical algorithm and error estimates for quasi-variational inequality and pseudo-monotone operators arise in elasto-hydrodynamic lubrication (EHL) problems on smooth/rough surfaces by conforming and non conforming FVM/FEM methods DST-SERB"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "1b9ErAYAAAAJ",
      "orcid": "0000-0002-8628-6606",
      "scopus": "57219479830",
      "vidwan": "301706"
    }
  },
  {
    "id": "vitap-1266-cms",
    "name": "Dr. Chandan Vishwas",
    "employeeId": "13.70189",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "307-B, AB-2",
    "email": "chandan.vishwas@vitap.ac.in",
    "phone": "5801",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Chandan_Vishwas_VISH_0760_2d7469fb16.avif",
    "education": [
      "Banaras Hindu University",
      "Banaras Hindu University",
      "Pondicherry University"
    ],
    "researchArea": "French Canadian language, literature and culture. French literature and culture",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "orcid": "0000-0001-6642-9801"
    }
  },
  {
    "id": "vitap-1327-cms",
    "name": "Dr. Pratik Premadarshi Ray",
    "employeeId": "13.70191",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "307-I, AB-2",
    "email": "pratik.ray@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pratik_Premadarshi_Ray_SAS_1519_4ca945f339.avif",
    "education": [
      "B.Sc. in Mathematics, Utkal University",
      "M.Sc. in Mathematics, Utkal University",
      "Ph.D. in Mathematics, Birla Institute of Technology and Science (BITS), Pilani – Hyderabad Campus"
    ],
    "researchArea": "Cosmology and Relativity, Modifies Theory of Gravity, Theoretical Dark Energy",
    "memberships": [
      "AMS, IMS, OMS, ASI, ISGRG, IAGRG, TSI"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "1. Research Award for Publications (Engineering and Sciences), VIT-AP University, 2022,",
      "2. ITS recognition from DST-SERB, Govt. of India for presenting research work at Kyoto University, Japan in February, 2019,",
      "3. ITS recognition from DST-SERB, Govt. of India for presenting research work at at Yerevan State University, Armenia in September, 2019"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Pratik-Ray",
      "googleScholar": "https://scholar.google.com/citations?user=T5v72ZEAAAAJ&hl=en&authuser=1",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57194213494&origin=resultslist",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/258589"
    }
  },
  {
    "id": "vitap-1172-cms",
    "name": "Dr. Senthil Murugan",
    "employeeId": "13.70276",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": null,
    "email": "senthil.murugan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/26_Senthil_Murugan_78b2a54d52.avif",
    "education": [
      "B.Tech & G.G.R College, Anna University, Chennai",
      "M.E. & GTEC College, Anna University, Vellore",
      "Ph.D. in IT & Vellore Institute of Technology, Vellore, Staff and Researcher & University of Luxembourg",
      "Staff and Researcher & University of Luxembourg"
    ],
    "researchArea": "Artificial Intelligence, Internet of Things, Big Data Analytics, Natural Language Processing, Data Mining",
    "memberships": [
      "1. Member at IEEE Association (Member No: 93805249) 2. Member at International Association of Engineers (IAENG) (Member No: 273314) 3. Member at VIT Alumni Association"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/senthil-murugan-nagarajan-57916676/",
      "googleScholar": "https://scholar.google.co.in/citations?user=4xXWyckAAAAJ&hl=en&authuser=1",
      "orcid": "https://orcid.org/0000-0001-9284-7724",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57209023165"
    }
  },
  {
    "id": "vitap-1344-cms",
    "name": "Dr. Aswathy R K",
    "employeeId": "13.70285",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G24-K, AB-2",
    "email": "aswathy.rk@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Aswathy_R_K_70285_0225_e168c4f891.avif",
    "education": [
      "University of Calicut",
      "National Institute of Technology, Calicut",
      "National Institute of Technology, Calicut"
    ],
    "researchArea": "Fractals and Fixed Point Theorem",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1275-cms",
    "name": "Dr. Ankita Swetaparna",
    "employeeId": "13.70353",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "325-H, AB-2",
    "email": "ankita.swetaparna@vitap.ac.in",
    "phone": "5813",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ankita_Swetaparna_IMG_4901_70353_VISH_ea15260390.avif",
    "education": [
      "B.A. English (Hons.), B.J.B College (Utkal University)",
      "M.A. Applied Linguistics, University of Hyderabad",
      "Ph. D in English, Sambalpur University"
    ],
    "researchArea": "Discourse Analysis, Pragmatics, Phonetics, Sociolinguistics, Second Language Acquisition",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1390-cms",
    "name": "Dr. Kingshuk Sarkar",
    "employeeId": "13.70365",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "325-E, AB-2",
    "email": "kingshuk.sarkar@vitap.ac.in",
    "phone": "5806",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kingshuk_Sarkar_SAS_1582_d8ea0f974e.avif",
    "education": [
      "BSc Physics Honours, University of Calcutta",
      "MSc Physics, IIT Bombay",
      "PhD in Physics, IISc Bangalore",
      "Post Doctoral Research Fellow Tel Aviv University, Israel and Ben Gurion University, Israel"
    ],
    "researchArea": "Theoretical and Computational Quantum Condensed Matter Physics, Magnetic and Superconducting Systems, Monte Carlo Simulations, Boltzmann Transport theory, Dirac Materials, Machine Learning and Quantum Computation",
    "memberships": [
      "Life Member of Indian Physics Association, Reviewer of APS journals, Physical Review Letter, Physical Review Research etc., Member of American Physical Society (APS) and Israel Physical Society (IPS)."
    ],
    "projects": [
      "Title: Investigations of Magnetocaloric and Thermoelectric Effects in Magnetic and Superconducting Materials Using Monte Carlo, Time-Dependent Ginzburg Landau Simulations, Density Functional Theory and Machine Learning Techniques."
    ],
    "patents": [],
    "awards": [
      "Recipient of TATA-Tel Aviv University Post-Doctoral Fellowship 2020-2021 from Tata Education and Development Trust, India",
      "Recipient of the Post-Doctoral Fellowship at Tel Aviv University, Israel from April 2020 to September 2021",
      "Recipient of the Kreitman Foundation Post-Doctoral fellowship at the Ben Gurion University of the Negev, Israel from March 2018",
      "CSIR-NET Junior Research Fellowship (JRF) 2009-2011",
      "CSIR-NET Senior Research Fellowship (SRF) 2011-2014",
      "Recipient of CSIR Foreign Travel Grant to participate in Victorian Summer School of Ultracold Physics (VSSUP 2014) at Melbourne, Australia",
      "Recipient of IISc Foreign travel grant funded by Graduate Associate Research Program (GARP), IISc Bangalore to visit Melbourne-Brisbane, Australia",
      "Qualified National Eligibility Test (NET 2009) conducted by Council for Scientific and Industrial Research (CSIR)",
      "Project Research Assistant in IISc Bangalore 2015-2017",
      "Recipient of Merit-Cum-Means (MCM) scholarship while pursuing Master of Science program at Indian Institute of Technology Bombay from 2007-2009"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-kingshuk-sarkar-phd-b3317b35/",
      "researchGate": "https://www.researchgate.net/profile/Kingshuk-Sarkar-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.co.in/citations?user=j1NlyYQAAAAJ&hl=en",
      "orcid": "0000-0001-8890-452X",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201510603",
      "vidwan": "https://vitap.irins.org/profile/304871"
    }
  },
  {
    "id": "vitap-1352-cms",
    "name": "Dr.N.Rajasekhar",
    "employeeId": "13.70395",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G23-F, AB-2",
    "email": "rajashekar.naraveni@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_N_Rajasekhar_IMG_6606_SAS_811175345e.avif",
    "education": [
      "B.Sc (M.P.Cs), Under Kakatiya University",
      "M.Sc (Mathematics), Osmania University",
      "Ph.D(Mathematics), IIT Delhi"
    ],
    "researchArea": "Computation of Partial Differential Equations(PDEs) and fractional PDEs using WEB-Spline method and finite element method.",
    "memberships": [
      "IMS,RMS"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=cN9ZZ38AAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57207735497",
      "vidwan": "301765"
    }
  },
  {
    "id": "vitap-1361-cms",
    "name": "Dr. Avadhesh Kumar",
    "employeeId": "13.70398",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "307-D, AB-2",
    "email": "avadhesh.kumar@vitap.ac.in",
    "phone": "5844",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Avadhesh_Kumar_SASMAT_IMG_2147_14ee8686ab.avif",
    "education": [
      "B.SC. CSJM University, Kanpur, India",
      "M.Tech. (Computer Science & Data Processing), IIT Kharagpur, India",
      "Ph.D. (Applied Mathematics), IIT Mandi, India",
      "Research Associate, NIT Hamirpur, India"
    ],
    "researchArea": "Impulsive differential equation, Mathematical control theory, Stability theory, Machine Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/avadhesh-kumar-978b0457/",
      "website": "https://sites.google.com/view/avdesh",
      "researchGate": "https://www.researchgate.net/profile/Avadhesh-Kumar-6",
      "orcid": "0000-0003-2206-5377",
      "scopus": "57214420063",
      "vidwan": "304676"
    }
  },
  {
    "id": "vitap-1245-cms",
    "name": "Dr. Ajay Dagar",
    "employeeId": "13.70418",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "105, AB-1",
    "email": "ajay.dagar@vitap.ac.in",
    "phone": "5832",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ajay_Dagar_70418_IMG_2615_SENSE_e68956490d.avif",
    "education": [
      "B.Tech in Electronics and Communication Engineering, UTPU Lucknow",
      "M.Tech in Digital Communication, IIITM Gwalior",
      "Ph.D. in Electrical Engineering, IIT Kanpur"
    ],
    "researchArea": "Personal Sound Reproduction, Audio Signal Processing, Multi-modal Information Retrieval, Audio-Visual Signal Processing in Mixed Reality, Artificial Intelligence and Machine Learning",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "website": "https://sites.google.com/view/ajaydagar",
      "researchGate": "GWM-7889-2022",
      "googleScholar": "MQBQzi4AAAAJ",
      "orcid": "0000-0001-7357-031X",
      "scopus": "55642177000"
    }
  },
  {
    "id": "vitap-1331-cms",
    "name": "Dr. Anupama A. P.",
    "employeeId": "13.7043",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "819 - O, CB",
    "email": "anupama.ap@vitap.ac.in",
    "phone": "5849",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Anupama_A_P_VISH_1447_11c0b036be.avif",
    "education": [
      "BA English Language and Literature, University of Kerala",
      "MA English Language and Literature, University of Kerala",
      "PhD in Film Studies, National Institute of Technology, Tiruchirappalli"
    ],
    "researchArea": "Film Studies, Spectatorship Studies, Spatial studies in film, Semiotics, Cyberpunk",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/anupama-a-p-a1a749108/",
      "researchGate": "https://www.researchgate.",
      "googleScholar": "https://scholar.google.com/citations?",
      "orcid": "https://orcid.org/0000",
      "scopus": "57218850526",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/301737"
    }
  },
  {
    "id": "vitap-1432-cms",
    "name": "Dr. Piu Kundu",
    "employeeId": "13.70449",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "104-G, CB",
    "email": "piu.kundu@vitap.ac.in",
    "phone": "5873",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Piu_Kundu_70449_IMG_2572_SAS_MAT_a0ff9f188a.avif",
    "education": [
      "The University of Burdwan",
      "National Institute of Technology Durgapur",
      "National Institute of Technology Durgapur"
    ],
    "researchArea": "Geophysics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Piu-Kundu?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=E93l9aUAAAAJ&hl=hi",
      "orcid": "https://orcid.org/0000-0001-9204-178X",
      "scopus": "57215898216",
      "vidwan": "https://vidwan.inflibnet.ac.in/myprofile"
    }
  },
  {
    "id": "vitap-1437-cms",
    "name": "Dr. Bibhab Bandhu Majumdar",
    "employeeId": "13.70454",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "622-L, CB",
    "email": "bibhabbandhu.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bibhab_Bandhu_Majumdar_70454_IMG_2530_SAS_CHY_5dc69c2adf.avif",
    "education": [
      "B.Sc. Chemistry (Honours), Presidency College, University of Calcutta",
      "M.Sc. Chemistry, IIT Bombay",
      "PhD, Ruhr University Bochum, Germany",
      "Postdoctoral research associate-I, SN Bose National Centre for Basic Sciences, Kolkata (2019-2020), Postdoctoral fellow: TIFR Hyderabad (2020-2022)"
    ],
    "researchArea": "Computational chemistry, molecular dynamics simulations, free energy calculations",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "orcid": "0000-0003-0269-5937",
      "scopus": "57202094865",
      "vidwan": "299914"
    }
  },
  {
    "id": "vitap-1338-cms",
    "name": "Dr. Ann Mary George",
    "employeeId": "13.70463",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "723-L, CB",
    "email": "annmary.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ann_Mary_George_70463_0228_025ea5a483.avif",
    "education": [
      "BA ENGLISH, St. Xavier's College, Gujarat University, Ahmedabad",
      "MA English, The English and Foreign Languages University (EFLU), Hyderabad",
      "PhD Film Studies and Visual Culture, The English and Foreign Languages University, Hyderabad"
    ],
    "researchArea": "Film Studies, Star Studies, Malayalam Cinema, Popular Culture, and Ecocriticism",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ann-mary-george-7b238576",
      "googleScholar": "https://scholar.google.com/citations?user=EwTRwgUAAAAJ&hl=en",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/301787"
    }
  },
  {
    "id": "vitap-1339-cms",
    "name": "Dr. Aby Abraham",
    "employeeId": "13.70464",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "723 - G, CB",
    "email": "a.abraham@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70464_Dr_Aby_Abraham_VISH_1368_9314a69153.avif",
    "education": [
      "BA English Langauge and Literature. CMS College Kotttayam, MG University",
      "MA English, The English and Foreign Languages University (EFLU), Hyderabad",
      "PhD in English and Comparative Literature, Central University of Kerala"
    ],
    "researchArea": "Visual Culture, Cultural Studies, Photography, Popular Culture, Literary Criticism",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-aby-abraham-222a0765"
    }
  },
  {
    "id": "vitap-1346-cms",
    "name": "Dr. Amar Ramesh Wayal",
    "employeeId": "13.70491",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "819 - P, CB",
    "email": "amar.w@vitap.ac.in",
    "phone": "5899",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Amar_Ramesh_Wayal_VISH_1439_0e3b2d11ee.avif",
    "education": [
      "B.A. (English) & Sant Gadge Baba Amaravati University, Amaravati, Maharashtra",
      "M.A. (English Literature) & Dr. Babasaheb Ambedkar Marathwada University, Aurangabad, Maharashtra",
      "Ph.D (Comparative Literature) & Central University of Gujarat, Gandhinagar",
      "1) M.Phil. (Comparative Literature) , Central University of Gujarat, Gandhinagar, Gujarat 2) Post-Graduate Course (Applied Research Studies), University of Lethbridge, Alberta, Canada"
    ],
    "researchArea": "North American Native Studies, American Indian Rhetoric, First Nations cultural Politics, Comparative Literature, Translation Studies, Television Studies, Posthuman Studies, and Alternative Humanities",
    "memberships": [
      "Film Circle Membership (National Film Archive of India, Ministry of Information and Broadcasting Government of India) 2024- Present"
    ],
    "projects": [
      "Anupama A. P. (PI), Amar Ramesh Wayal (Co-PI), & Raghavi R. K. (Co-PI). (2023). The Cyberpunk: Governance, Security, and Politics. Awarded by ICSSR New Delhi. Funding of 5 Lakh. Ongoing research."
    ],
    "patents": [
      "1. System, Method for Embedding Behavioral and Social Impact Messaging in Multimedia Content for Social Development (Indian Patent No. 202441100035 A)",
      "2. A System and Method Facilitating Improved Learning Experiences to Users (Indian Patent No. 202441047924 A)",
      "3. Multilingual Translation Memory, Translation Method, and Translation Programme (Indian Patent No. 202441042208 A)",
      "4. A Method for Using New Media Technologies to Enhance Teaching and Learning Processes (India Patent No. 202321017225)"
    ],
    "awards": [
      "Doctoral Fellowship, Indian Council of Social Science Research, New Delhi, 2017.",
      "Shastri Indo-Canadian Scholar, Shastri Indo-Canadian Institute, Canada, 2019"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-amar-wayal-94863b119/",
      "researchGate": "https://www.researchgate.net/profile/Amar-Wayal-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/scholar?hl=en&as_sdt=0%2C5&q=Amar+Wayal&oq=",
      "orcid": "0000-0003-1674-9545",
      "scopus": "57218750531",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/301734"
    }
  },
  {
    "id": "vitap-1470-cms",
    "name": "Dr. Mohd Abdul Muqeet Maaz",
    "employeeId": "13.70499",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "410, AB-1",
    "email": "muqeet.maaz@vitap.ac.in",
    "phone": "5418",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70499_Dr_Mohd_Abdul_Muqeet_Maaz_VSB_1168_27e5fe3ebe.avif",
    "education": [
      "B.Sc (Commercial Agriculture and Business Management), Prof. Jayashankar Telangana State Agricultural University",
      "MBA (Agribusiness), Aligarh Muslim University",
      "Ph.D (Business Management and Agricultural Economics), Aligarh Muslim University"
    ],
    "researchArea": "Consumer Behaviour, Marketing Management, Cross cultural Management, General Management, Strategic Management",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-mohd-abdul-muqeet-maaz-25601822b",
      "researchGate": "https://www.researchgate.net/profile/Mohd-Maaz",
      "googleScholar": "https://scholar.google.com/citations?user=g7jlAWcAAAAJ&hl=en&oi=ao",
      "orcid": "https://orcid.org/0000-0003-2151-8354",
      "scopus": "57266550200"
    }
  },
  {
    "id": "vitap-1296-cms",
    "name": "Dr. Sayyed Faizan Ali",
    "employeeId": "13.70501",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": null,
    "email": "faizan.ali@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/51_Dr_Sayyed_Faizan_Ali_SENSE_70501_48ef8d1bdb.avif",
    "education": [
      "B.Tech in Electronics & Instrumentation, Gautam Buddh Technical University",
      "M.Tech in Control & Instrumentation, Delhi Technological University, Delhi",
      "Ph.D. in Electronics & Instrumentation, Indian Institute of Technology (IIT) ISM Dhanbad"
    ],
    "researchArea": "Sensor Design, Sensor Optimization, MEMS, Signal Conditioning, Circuit Designing, Wireless Transmission SAW Devices and IoT Techniques, Artificial Neural Network, Machine Learning.",
    "memberships": [
      "IEEE, OSA SPIE"
    ],
    "projects": [],
    "patents": [
      "Method for real time monitoring of liquid level for wireless transmission system, 201931054793"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-sayyed-faizan-ali-136817212/",
      "researchGate": "https://www.researchgate.net/profile/Sayyed-Ali",
      "googleScholar": "9TD-g3gAAAAJ",
      "scopus": "57209273575"
    }
  },
  {
    "id": "vitap-1349-cms",
    "name": "Dr. Joseph Alugula",
    "employeeId": "13.70511",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "813 - F, CB",
    "email": "joseph.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Joseph_Alugula_VISH_0945_65017dd59a.avif",
    "education": [
      "BA (History, Economics and Politics), Andhra University",
      "MA (Political Science), University of Hyderabad",
      "PhD (Political Science), University of Hyderabad"
    ],
    "researchArea": "Political Theory, International Relations (Indo-Israel Relations), Public Policy, Ageing, Social Security",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-joseph-alugula-phd-a1058851/",
      "orcid": "0000-0002-6760-5675"
    }
  },
  {
    "id": "vitap-1447-cms",
    "name": "Dr. Ramesh A",
    "employeeId": "13.70512",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "813 - G, CB",
    "email": "ramesh.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ramesh_A_SAS_0957_a889c83ddd.avif",
    "education": [
      "B.Sc. Thiruvalluvar University",
      "M.Sc (Mathematics), Indian Institue of Technology Madras",
      "Ph.D. , Indian Institue of Technology Ropar",
      "PDF, McGill University Canada"
    ],
    "researchArea": "Mathematical Biology, Theoretical Ecology, Nonlinear Dynamics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "website": "https://sites.google.com/site/rameshaavk",
      "googleScholar": "https://sites.google.com/site/rameshaavk",
      "orcid": "https://orcid.org/0000-0001-9922-5602"
    }
  },
  {
    "id": "vitap-1228-cms",
    "name": "Dr. Pranav Anand Ojha",
    "employeeId": "13.7053",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "415-D, AB-2",
    "email": "pranavanand.o@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Pranav_Anand_Ojha_70530_IMG_2543_VSL_442e32d402.avif",
    "education": [
      "LLB (Hons.), Faculty of Law, BHU",
      "LLM (IPR), NLU Jodhpur"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1483-cms",
    "name": "Dr. Pradip.R.Patle",
    "employeeId": "13.70577",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "124-F, AB-2",
    "email": "pradip.patle@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pradip_R_Patle_SAS_0880_fab03717a4.avif",
    "education": [
      "BSc, RTM Nagpur University Nagpur",
      "MSc, RTM Nagpur University Nagpur",
      "PhD VNIT Nagpur"
    ],
    "researchArea": "Nonlinear Analysis and Fractional Differential Equations",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Pradip-Patle",
      "googleScholar": "VoSGT4QAAAAJ",
      "orcid": "0000-0002-9650-6107",
      "scopus": "57204216315",
      "vidwan": "300211"
    }
  },
  {
    "id": "vitap-1500-cms",
    "name": "Dr. Dibyendu Sekhar Mandal",
    "employeeId": "13.70609",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "202-B, AB-2",
    "email": "sekharmandal.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Dibyendu_Sekhar_Mandal_SAS_0787_3c06c9254b.avif",
    "education": [
      "B.Sc Mathematics, University of Calcutta",
      "M.Sc. in Applied Mathematics, University of Calcutta",
      "Ph.D. in Applied Mathematics, Indian Statistical Institute Kolkata",
      "Visiting Scientist (Indian Statistical Institute Kolkata)"
    ],
    "researchArea": "Mathematical Biology",
    "memberships": [
      "ISCA, CMS, IMS"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "University Grants Commission (UGC) Fellowship, India, 2014-2019.",
      "Travel grant from the Organizing committee of “NINTH WORKSHOP Dynamical Systems Applied to Biology and Natural Sciences” Dipartimento Di Matematica, Universita di Torino, Italy; 2018.",
      "Travel grant from the Organizing committee of “7th Mathematical Models in Ecology and Evolution (MMEE) conference”, Université de Lyon, France; 2019.",
      "CSIR (Council of Scientific and Industrial Research) provides full travel grant to attend international scientific events; 2019.",
      "NBHM (The National Board for Higher Mathematics) provides full travel assistance (Not availed) for attending “Summer School Data and Models in Ecology and Evolution, (DMEE)”, held in Orsay at Institut Pascal (University Paris-Saclay), France, from July 8-12; 2019."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dibyendu-sekhar-mandal-810322ab/",
      "website": "https://sites.google.com/view/dsmandal/home?authuser=0",
      "researchGate": "https://www.researchgate.net/profile/Dibyendu_Mandal3",
      "googleScholar": "https://scholar.google.co.in/citations?user=WksyY48AAAAJ&hl=en&oi=ao",
      "orcid": "0000-0003-4796-247X",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57194336811",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/435388"
    }
  },
  {
    "id": "vitap-1487-cms",
    "name": "Dr. Kottu Durga Prasad",
    "employeeId": "13.70614",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "124-L, AB-2",
    "email": "durgaorasad.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kottu_Durga_Prasad_SAS_0780_57c8cec7d6.avif",
    "education": [
      "B.Sc & Andhra University",
      "M.Sc (Mathematics), Andhra University",
      "Ph.D (Mathematics), VIT Vellore"
    ],
    "researchArea": "Nonlinear Dynamics",
    "memberships": [
      "Indian Mathematical Society"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "qvrqlYIAAAAJ",
      "orcid": "0000-0001-5065-8490",
      "scopus": "57199500404, 59491697200",
      "vidwan": "https://vitap.irins.org/profile/440063"
    }
  },
  {
    "id": "vitap-1469-cms",
    "name": "Dr. Satyendra Singh Chauhan",
    "employeeId": "13.70629",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "320-E, AB-2",
    "email": "satyendra.chauhan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70629_Dr_Satyendra_Singh_Chauhan_MAT_1211_ddb1b2146b.avif",
    "education": [
      "B.Sc. & Veer Bahadur Singh Purvanchal University Jaunpur Uttar Pradesh",
      "M.Sc. & University of Allahabad, Prayagraj, Uttar Pradesh",
      "Ph.D. & BITS Pilani, Pilani Campus, Rajasthan"
    ],
    "researchArea": "Fluid Dynamics (Blood Flow, Solute Dispersion Process, Heat and Mass Transfer, Homogenization Process, Environmental Dispersion in Wetland Flow, Creeping Flow, Electrokinetic Transport, Membrane Filtration Process, Dispersion of Gyrotactic Micro-Organisms, Peristaltic Transport, Flow in Anterior Chamber of Eye, Synovial Fluid Analysis, and Artificial Neural Network)",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "JRF (DST-SERB) & SRF (CSIR)"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Satyendra-Chauhan-3",
      "googleScholar": "https://scholar.google.co.in/citations?user=YdPwFQvJl2EC&hl=hi",
      "orcid": "0000-0001-9080-398X",
      "scopus": "57205503883",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/464999/NDY0OTk5"
    }
  },
  {
    "id": "vitap-1535-cms",
    "name": "Dr. Gokul Yenduri",
    "employeeId": "13.70634",
    "designation": "Assistant Professor Sr Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "619-H, CB",
    "email": "gokul.yenduri@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Gokul_Yenduri_70634_IMG_4973_SCOPE_504ea5823a.avif",
    "education": [
      "B.Tech (CSE) & ANU",
      "M.Tech (IT (Networking) ) & Vellore Institute of Technology, Vellore",
      "P.hD., & Vellore Institute of Technology, Vellore",
      "University of South Florida (Sarasota-Manatee Campus) (Pursuing)"
    ],
    "researchArea": "Inclusive Education, Metaverse, Federated Learning, Blockchain, Explainable AI, Healthcare",
    "memberships": [],
    "projects": [
      "Senior Research Fellow, completed (“DIVERSASIA – Embracing Diversity in Asia through the Adoption of Inclusive Open Practices” Project No: 618615-EPP-1-2020-1-UK-EPPKA2-CBHE-JP, co-funded by the Erasmus+ programme of the European Union."
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/gokul-yenduri-ll-074176136/",
      "researchGate": "https://www.researchgate.net/profile/Gokul-Yenduri",
      "googleScholar": "https://scholar.google.co.in/citations?user=4-hLI_gAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57223040078"
    }
  },
  {
    "id": "vitap-1438-cms",
    "name": "Dr. Suresh Garimella",
    "employeeId": "13.70637",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "224-G, AB-2",
    "email": "suresh.garimella@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Suresh_Garimella_VISH_1004_e645b57413.avif",
    "education": [
      "History, Economics, Political Science Institution: Andhra Pradesh Residential Degree College",
      "History, University of Hyderabad",
      "History, Jawaharlal Nehru University",
      "MPhil, University of Hyderabad"
    ],
    "researchArea": "Modern Indian History, Socio-Political History of Law",
    "memberships": [
      "Indian History Congress, South Indian History Congress"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https:/www.linkedin.com/in/suresh-garimella-145a82219"
    }
  },
  {
    "id": "vitap-1510-cms",
    "name": "Dr. Priyanka Singh",
    "employeeId": "13.70649",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "626 - J, CB",
    "email": "priyanka.singh@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Priyanka_Singh_SCOPE_0906_59bb0bf845.avif",
    "education": [
      "B.Tech, Solapur University",
      "M.Tech, Visweswaraiya Technical University(VTU)",
      "Ph.D, National Institute of Technology,Silchar,Assam"
    ],
    "researchArea": "Computer Security, Artificial Intelligence, Machine learning, Deep Learning, Malware Detection,",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=p-L62vMAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0001-5476-6501"
    }
  },
  {
    "id": "vitap-1513-cms",
    "name": "Dr. Shirin Naresh Patil",
    "employeeId": "13.7065",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "147, AB1",
    "email": "shirin.patil@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shirin_Naresh_Patil_70650_IMG_2315_SMEC_14078a61d2.avif",
    "education": [
      "B.E, Rashtrasant Tukdoji Maharaj Nagpur University",
      "M.Tech, IIT Madras",
      "Ph.D., IIT Madras",
      "Otto Von Guericke University, Magdeburg"
    ],
    "researchArea": "Sprays and Atomization, Droplets, Gas Turbine Injectors, Particle Image Velocimetry, Phase Doppler Particle Analyzer, Computational Fluid Dynamics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/shirin-patil-10423851",
      "googleScholar": "https://scholar.google.com/citations?user=EAQD1W0AAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57210801204"
    }
  },
  {
    "id": "vitap-1520-cms",
    "name": "Dr. Posham Uppamma",
    "employeeId": "13.70667",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "620-E, CB",
    "email": "uppamma.posham@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Posham_Uppamma_SCOPE_1821_7685b6bf2d.avif",
    "education": [
      "B.Tech-CSE & JNTU Hyderabad",
      "M.Tech-CSE & JNTU Hyderabad",
      "Ph.D- School of Computer Science Engineering and Information Systems, VIT University-Vellore"
    ],
    "researchArea": "Machine Learning, Deep Learning, Blockchain",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/uppamma-posham-26328a20b/?trk=eml-email_network_conversations_01-header-0-profile_glimmer",
      "researchGate": "https://www.researchgate.net/profile/Posham-Uppamma",
      "googleScholar": "https://scholar.google.co.in/citations?user=Ir1eD3kAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58099069300",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/541182"
    }
  },
  {
    "id": "vitap-1522-cms",
    "name": "Dr. Bensha C. Shaji",
    "employeeId": "13.70669",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "416-C, AB-2",
    "email": "bensha.shaji@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Bensha_C_Shaji_VSL_1921_55596a8fc2.avif",
    "education": [
      "BBA LL.B, Karnataka State Law University Hubbli",
      "LL.M Christ Deemed to be University Bangalore",
      "PhD in Taxation Law (Pursuing) Christ Deemed to be University Bangalore"
    ],
    "researchArea": "Taxation Law, Corporate and Commercial Law",
    "memberships": [
      "Bar Council of India, Volleyball Federation of India"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/bensha-c-shaji-aab2921a7/",
      "googleScholar": "https://scholar.google.co.in/citations?hl=en&view_op=list_works&gmla=AOAOcb0QUjaj2WMHofYVnwZFvUFtVMiMoLQnACikru9W5cvK0xrV5k0ReH9gw56LAdxe0zhJGUM2vR2IRrZDUg&user=YMK9p8cAAAAJ"
    }
  },
  {
    "id": "vitap-1523-cms",
    "name": "Dr. Farooq Ahmad Mir",
    "employeeId": "13.7067",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "225-A, AB-2",
    "email": "farooq.mir@vitap.ac.in",
    "phone": "5361",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Farooq_Ahmad_Mir_VISH_1856_3304d8bc19.avif",
    "education": [
      "B.Sc., B.Ed. (University of Kashmir)",
      "M.A. in Linguistics (University of Kashmir)",
      "Ph.D., (Aligarh Muslim University, Aligarh)",
      "Indian Institute of Tecnology Bombay"
    ],
    "researchArea": "Neuro-Cognitive Linguistics; English Language Teaching; Language Documentation; Sociolinguistics; Phonetics & Phonology (English and Languages in India); Linguistics Research methodology.",
    "memberships": [
      "1. Society for Endangered Languages. 2. Cognitive Linguistics"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/farooq-ahmad-mir-ph-d-527007222/?trk=public_profile_browsemap&originalSubdomain=in",
      "researchGate": "https://www.researchgate.net/profile/Farooq-Mir-3",
      "googleScholar": "https://scholar.google.com/citations?user=SfVrppoAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57864486600"
    }
  },
  {
    "id": "vitap-1536-cms",
    "name": "Dr. T Rama Thulasi",
    "employeeId": "13.7068",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "620-D, CB",
    "email": "ramathulasi.t@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/T_Rama_Thulasi_70680_IMG_4693_SCOPE_317554f0fc.avif",
    "education": [
      "Sri Venkateswara University (SVU), Tirupati",
      "JNTUA, Anantapuram"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1551-cms",
    "name": "Dr. Sanal Kumar T S",
    "employeeId": "13.70686",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "615 - L, CB",
    "email": null,
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Sanal_Kumar_T_S_70686_IMG_4701_SCOPE_044928b86d.avif",
    "education": [
      "Bsc CS, University of Calicut, Kerala.",
      "1.MCA, Govt. Engineering College, MG University, Kerala, 2. M.Tech CSE, PRIST University, Tanjore, Tamil Nadu.",
      "Phd, VIT, Vellore, Tamil Nadu."
    ],
    "researchArea": "ML in Education, Personalized Learning Models, Learning Classifier Systems.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sanal-kumar-t-s-6a153321a?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app",
      "researchGate": "https://www.researchgate.net/profile/Sanal-T-S-2",
      "googleScholar": "https://scholar.google.com/citations?user=0kHDn_0AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57202072964"
    }
  },
  {
    "id": "vitap-1553-cms",
    "name": "Dr. Shalini Ramanathan",
    "employeeId": "13.70688",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "723 - N, CB",
    "email": "shalini.ramanathan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shalini_70688_IMG_4939_SCOPE_9f9567a177.avif",
    "education": [
      "B.E. Bharathiar University",
      "M.E Anna University",
      "Ph.D. National Institute of Technology Tiruchirappalli"
    ],
    "researchArea": "Medical Imaging, Image Reconstruction",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/shaliniramnath/",
      "googleScholar": "https://scholar.google.com/citations?user=BQOgbmAAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57209289283"
    }
  },
  {
    "id": "vitap-1555-cms",
    "name": "Dr. Mohinder Singh. B",
    "employeeId": "13.7069",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "813 - I, CB",
    "email": "mohindersingh.b@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mohinder_Singh_IMG_6554_SCOPE_0b52d2d66d.avif",
    "education": [
      "MCA, JNTU Hyderabad",
      "M.Tech (CSE), JNTU Hyderabad",
      "Ph.D (CSE), VIT Vellore."
    ],
    "researchArea": "Data Security, Cyber Security",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=XWySjmYAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58480005500"
    }
  },
  {
    "id": "vitap-1557-cms",
    "name": "Dr. Kavikumar. R",
    "employeeId": "13.70692",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "310-B, AB1",
    "email": "kavikumar.r@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kavikumar_R_SASMAT_IMG_2149_1192680d5a.avif",
    "education": [
      "B.Sc. - Bharathidasan University, Tiruchirappalli",
      "M.Sc-Bharathiar University, Coimbatore",
      "PhD-Anna University, Chennai",
      "Post Doctoral Researcher- Chungbuk National University, South Korea"
    ],
    "researchArea": "Systems and Control Theory",
    "memberships": [],
    "projects": [
      "Design of event-triggered sample value controller in linear system using improved Looped function."
    ],
    "patents": [],
    "awards": [
      "Excellent Researcher Award: Hall of Fame in Chungbuk National University, South Korea, 2023.",
      "Grands: Received grants from ICIAM for registration, travel, and accommodation to attend ICIAM 2019 (Spain, July 15-19, 2019) and for registration to attend ICIAM 2023 (Japan, August 20-25, 2023)"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-kavikumar-ramasamy-958297112/?originalSubdomain=in",
      "researchGate": "https://www.researchgate.net/profile/Ramasamy-Kavikumar",
      "googleScholar": "https://scholar.google.co.in/citations?user=XQu7zvkAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201522142"
    }
  },
  {
    "id": "vitap-1560-cms",
    "name": "Dr. D. Paul Joseph",
    "employeeId": "13.70695",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "623-F, CB",
    "email": "pauljoseph.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_D_Paul_Joseph_SCOPE_IMG_2891_d6ded3b4da.avif",
    "education": [
      "B.Tech, JNTU-K",
      "M.Tech, Andhra University",
      "PhD, VIT Vellore"
    ],
    "researchArea": "Cyber Security, Digital Forensics, NLP, Machine Learning, Information Extraction",
    "memberships": [
      "IEEE, ACM"
    ],
    "projects": [],
    "patents": [
      "202441044454 - Secure Forensic Bk Hyper parameter tuned three-tier robust disk forensic system"
    ],
    "awards": [
      "Best Resarcher Award, VIT Vellore, 2017.",
      "MANF Award, UGC-MoMA, 2018"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/pauljosephd/",
      "researchGate": "https://www.researchgate.net/profile/D-Paul-Joseph",
      "googleScholar": "https://scholar.google.co.in/citations?user=BUWVtJ0AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57211626919",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/443277"
    }
  },
  {
    "id": "vitap-1562-cms",
    "name": "Dr. Adla Padma",
    "employeeId": "13.70697",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "723 - P, CB",
    "email": "padma.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Adla_Padma_SCOPE_IMG_2155_94a428f711.avif",
    "education": [
      "JNTUH",
      "JNTUH",
      "VIT University Vellore"
    ],
    "researchArea": "Blockchain, IoT, Machine Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://in.linkedin.com/in/padma-adla-1625bb204",
      "researchGate": "https://www.researchgate.net/profile/Adla-Padma-2/research",
      "googleScholar": "https://scholar.google.com/citations?user=UD8x3gcAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57216522650",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/601340"
    }
  },
  {
    "id": "vitap-1563-cms",
    "name": "Dr. Amgothu Shanthi",
    "employeeId": "13.70698",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "623-K, CB",
    "email": "shanthi.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Amgothu_Shanthi_SCOPE_IMG_2895_22c808ab44.avif",
    "education": [
      "JNTUH",
      "OU",
      "VIT- Vellore"
    ],
    "researchArea": "IoT, Artificial Intelligent, Deep learning, Soft Computing and Networking",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=3lR-_VEAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58388309600"
    }
  },
  {
    "id": "vitap-1567-cms",
    "name": "Dr. Shalini Subramani",
    "employeeId": "13.70704",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "204-D, CB",
    "email": "shalini.subramani@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shalini_Subramani_SCOPE_IMG_2135_b026e5a2fc.avif",
    "education": [
      "B.E (CSE), Affilated to Anna University",
      "M.E (CSE), Affilated to Anna University",
      "PhD(SCOPE), VIT University, Vellore"
    ],
    "researchArea": "Network Security",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57336667500"
    }
  },
  {
    "id": "vitap-1572-cms",
    "name": "Dr. K Aravind",
    "employeeId": "13.70706",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "723 - B, CB",
    "email": "aravind.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_K_Aravind_SCOPE_6bfaf408d8.avif",
    "education": [
      "Anna University",
      "Jawaharlal Nehru Technological University Anantapur",
      "VIT University Vellore"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [
      "1. Design No. : 381142-001andMACHINE LEARNING-BASED ROBOT FOR FACE MASK AND SANITIZER DISPENSING",
      "2. Design No. : 393730-001 and ARTIFICIAL INTELLIGENCE BASED HEALTHMONITORING WEARABLE DEVICE",
      "3. Design No. : 405336-001 and SMART REMOTE PATIENT MONITORING APPARATUS FOR DOCTORS"
    ],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1570-cms",
    "name": "Dr. Ngangbam Indrason",
    "employeeId": "13.70707",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "813 - L, CB",
    "email": "indrason.n@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ngangbam_Indrason_SCOPE_IMG_2126_98813f365a.avif",
    "education": [
      "B. Tech (Information Technology), Lovely Professional University, Punjab",
      "M. Tech (Information Technology), North-Eastern Hill University, Meghalaya",
      "Ph.D. (Information Technology), North-Eastern Hill University, Meghalaya"
    ],
    "researchArea": "Blockchain, Internet of Things, Software-Defined Networking, Network Security",
    "memberships": [],
    "projects": [],
    "patents": [
      "Application Number: 202331074589 Title: SDN-based IoT Oriented Blockchain enabled E-Voting System (Published on 18/10/2024)"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/indrason-ngangbam-154493129/",
      "researchGate": "https://www.researchgate.net/profile/Ngangbam-Indrason",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=rdXa3yQAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57218595961"
    }
  },
  {
    "id": "vitap-1571-cms",
    "name": "Dr. Madala Guru Brahmam",
    "employeeId": "13.70708",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "623-M, CB",
    "email": "gurubrahmam.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Madala_Guru_Brahmam_SCOPE_IMG_2746_13e4cf712f.avif",
    "education": [
      "BTech CSE, Affiliated to JNTUK",
      "MTech CSE, Affiliated to JNTUK",
      "VIT, Vellore"
    ],
    "researchArea": "Cloud, ML, DL, AI, Quantum Computing, Blockchain, IoT",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Madala-Brahmam/research",
      "googleScholar": "https://scholar.google.com/citations?user=_2ouAsUAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57951362000"
    }
  },
  {
    "id": "vitap-1576-cms",
    "name": "Dr. Renita R",
    "employeeId": "13.70711",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "204-G, CB",
    "email": "renita.r@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Renita_R_SCOPE_8341f6d6c0.avif",
    "education": [
      "BE-CSE, Anna University",
      "ME - CSE, Anna University",
      "PHD - VIT, Vellore"
    ],
    "researchArea": "Software Engineering, Artificial Intelligence",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1574-cms",
    "name": "Dr. Monalisa Sahu",
    "employeeId": "13.70712",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "626 - I, CB",
    "email": "monalisa.sahu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Monalisa_Sahu_70712_SCOPE_992010f587.avif",
    "education": [
      "B.Tech(IT), BPUT, Odisha",
      "M.Tech(CS), Berhampur University, Odisha",
      "PhD(CSE), GIETU, Odisha"
    ],
    "researchArea": "Network Security, Steganography, Water marking, Image processing",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Monalisa-Sahu-2",
      "googleScholar": "https://scholar.google.co.in/citations?user=gEKfK9EAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57193898779",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/625851"
    }
  },
  {
    "id": "vitap-1579-cms",
    "name": "Dr. Allapati Rajya Lakshmi",
    "employeeId": "13.70714",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "615 - M, CB",
    "email": "rajyalakshmi.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Allapati_Rajya_Lakshmi_SCOPE_3e4c0957c3.avif",
    "education": [
      "B.Sc & ANU, AP",
      "M.Tech (JNTUH), M.Sc(ANU, AP), MCA(IGNOU)",
      "Ph.D & VIT"
    ],
    "researchArea": "Deep learning with IoT",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?view_op=list_works&hl=en&user=PRG_xDkAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57549258800"
    }
  },
  {
    "id": "vitap-1580-cms",
    "name": "Dr. Jayashree Pradhan",
    "employeeId": "13.70715",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "157, AB-1",
    "email": "jayashree.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Jayashree_Pradhan_SENSE_IMG_7275_97a815a254.avif",
    "education": [
      "Btech, Silicon Institute Of Technology, BBSR",
      "PhD, National Institute of Technology Rourkela",
      "Post Doc, Indian Institute of Science Bangalore"
    ],
    "researchArea": "Optical wireless Communication, Visible Light Communication",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "SERB ITS- 2023 grant for foreign conference."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-jayashree-pradhan-46b79251/",
      "researchGate": "https://www.researchgate.net/profile/Jayashree-Pradhan-2",
      "googleScholar": "https://scholar.google.com/citations?user=-2RWyf8AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1584-cms",
    "name": "Dr. Ankur Pandey",
    "employeeId": "13.70719",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "424-C, AB-1",
    "email": "ankur.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ankur_Pandey_SENSE_IMG_7261_8d01a81bd9.avif",
    "education": [
      "I.E.T Lucknow",
      "MNNIT Allahabad",
      "NIT Jamshedpur"
    ],
    "researchArea": "Dielectric Properties, Biomaterials, Medical Implant, Biosensors",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "http://linkedin.com/in/ankur-pandey-1a319a2bb",
      "researchGate": "https://www.researchgate.net/profile/Ankur-Pandey-17",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=yRqmIasAAAAJ",
      "scopus": "https://www.scopus.com/feedback/author/reviewAuthorProfile.uri?authorIds=57946106000"
    }
  },
  {
    "id": "vitap-1587-cms",
    "name": "Dr. Gayathri Dhara",
    "employeeId": "13.70722",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "1013 - O, CB",
    "email": "gayathri.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Gayathri_Dhara_SCOPE_fa3bb4c548.avif",
    "education": [
      "B.Sc(MPC), Kakatiya University.",
      "MCA, (Andhra University); M.Tech, (JNTUK)",
      "Ph.D. in Computer Science and Engineering, SRM University-AP."
    ],
    "researchArea": "Visual Saliency, Computer Vision, Deep Learning",
    "memberships": [
      "ACM"
    ],
    "projects": [],
    "patents": [
      "1. A system and a method for enhancement of visual saliency of intended face in group photography. Patent published (Application number: 202441040020).",
      "2. A wearable device to assist visually impaired people in navigation and object interaction. Patent published (Application number: 202441048386).",
      "3. A system for Face Recognition in an Unconstrained Environment. Patent published (Application number: 202541020827)."
    ],
    "awards": [
      "Secured a Gold Medal on the 8th Research Day organized by SRM University-AP, Andhra Pradesh, in 2023."
    ],
    "links": {
      "googleScholar": "https://scholar.google.co.in/citations?user=tCUsNCEAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57810785300"
    }
  },
  {
    "id": "vitap-1596-cms",
    "name": "Dr. Maheshuni Sankush Krishna",
    "employeeId": "13.70731",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "170, AB-1",
    "email": "sankushkrishna.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Maheshuni_Sankush_Krishna_SENSE_058c518611.avif",
    "education": [
      "B.Tech, ACE Engineering College (Jawaharlal Nehru Technological University))",
      "M.Tech. National Institute of Technology Patna",
      "Ph.D. National Institute of Technology Patna"
    ],
    "researchArea": "2D Materials for Nanoelectronics Devices",
    "memberships": [],
    "projects": [],
    "patents": [
      "1.202231007237, Nanoscale Interconnects Using Tai- lored Edge Passivated ZnO Nanoribbons",
      "2. 202231043396, Nanointerconnects Based on Zigzag Stanene Nanoribbons (SnNRs) via Edge Functionalization",
      "3. 202331084957, Nanointerconnect Design Using Unsaturated Edged Antimonene Nanoribbons"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/maheshuni-sankush-329562268/",
      "researchGate": "https://www.researchgate.net/profile/Sankush-Krishna-Maheshuni?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=WlE_RaIAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57198116718"
    }
  },
  {
    "id": "vitap-1597-cms",
    "name": "Dr. Lakshminarayana Janjanam",
    "employeeId": "13.70732",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "167, AB-1",
    "email": "Lakshminarayana.j@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Lakshminarayana_Janjanam_SENSE_9dd14c8509.avif",
    "education": [
      "B. Tech (ECE) & J N T U K University",
      "M.Tech (VLSI & ES) & J N T U K University",
      "Ph.D (Signal Processing) & National Institute of Technology Raipur"
    ],
    "researchArea": "Signal Processing, Soft Computing Techniques, Kalman Filtering, Deep Learning Models",
    "memberships": [
      "IETE"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Received National Research Excellence Award from the Institute of Engineers, India",
      "MHRD Fellowship for Doctoral Study at National Institute of Technology Raipur, India",
      "Received Best Student Award for the School Topper in SSC"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/lakshminarayana-janjanam-916b96247/",
      "researchGate": "https://www.researchgate.net/scientific-contributions/Lakshminarayana-Janjanam-2183530975",
      "googleScholar": "https://scholar.google.com/citations?user=pC4dZrAAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201860276"
    }
  },
  {
    "id": "vitap-1599-cms",
    "name": "Dr. Battula Venkata Satish Babu",
    "employeeId": "13.70734",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "618 - F, CB",
    "email": "satishbabu.bv@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Battula_Venkata_Satish_Babu_SCOPE_bffbe534a0.avif",
    "education": [
      "B.Tech(CSE), Acharya Nagarjuna University,Guntur",
      "M.tech(CSE), Acharya Nagarjuna University,Guntur",
      "Ph.D(CSE), Jawaharlal Nehru Technological University Hyderabad"
    ],
    "researchArea": "Blockchain, Network and Data Security, Data Science, Digital Image processing, Cloud and Virtualization, IOT",
    "memberships": [
      "1) Institute of Scholars : INSC20203B4D 2)International Association of Engineers: 255832 3) The Society of Digital Information and Wireless Communications : 32358 4) The Indian Science Congress Association, Life Membership:L44215"
    ],
    "projects": [
      "Title: Low cost water monitoring System for Rural Communities Funding agency: SIDDHARTHA ACADEMY OF GENERAL & TECHNICAL EDUCATION, Vijayawada, 2023-24"
    ],
    "patents": [
      "1) Application Number: 202341021832 , Title:“ Innovative Video Sharing Platform with Keyword Based Timeline Marking and Keyword tracking” ,2023",
      "2)Application Number:202341088616 , Title: \"\"An Unified Data access Revocation Management Leveraging Blockchain and Auxiliary Trees\"\", 2024",
      "3)Application Number: 202341088625 , Title: \"\"Context-aware, Multi-granular and Block Chain Based Dynamic Data Protection Framework\"\", 2024",
      "4)Application Number: 202541036656 , Title: \"\"Low Cost Edge AI-Based Water Quality Monitoring System Using Random Forest Regression\"\", 2025"
    ],
    "awards": [
      "Received \"Award of Excellence\" and 5000/- thousand cash price from SAP India Pvt.Ltd ,IIT Bombay under ICT (MHRD) Program,2016 being one of the toppers in workshop “ICT and Blended learning” conducted overall India.",
      "Received “Best Paper Award” for the conference paper \"A Data Mining Based Model For Detection Of Deceitful Behaviour In Water Consumption\", International Conference On Artificial Intelligence And Its Emerging Areas, 2k21, Narasaraopeta Engineering College, Narasaraopet- 522 601.",
      "Qualified GATE 2022 & UGC NET(2026,2017,2018,2019,2023)",
      "Certified Ethereum Expert, Blockchain Council, 2022.",
      "IBM Blockchain Foundation Developer, 2020.",
      "Certified as a ProAct Digital Teacher from Loyola Institute of Business Management-(LIBA), 2020."
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Dr-Babu-14/research",
      "googleScholar": "https://scholar.google.com/citations?user=Eo6BCXAAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57216581188",
      "vidwan": "https://vidwan.inflibnet.ac.in//profile/96571"
    }
  },
  {
    "id": "vitap-1606-cms",
    "name": "Dr. Samuka Mohanty",
    "employeeId": "13.70741",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "618 - G, CB",
    "email": "samuka.mohanty@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Samuka_Mohanty_59d74ff5d6.avif",
    "education": [
      "BTech in CSE, BPUT, Odisha",
      "MTech in CSE, BPUT, Odisha",
      "PhD, SOA University, Odisha"
    ],
    "researchArea": "Machine Learning and Artificial Intelligence",
    "memberships": [
      "Life Member of IET and ISTE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1617-cms",
    "name": "Dr. Rajasekhar Boddu",
    "employeeId": "13.70753",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "621 - G, CB",
    "email": "rajasekhar.boddu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rajasekhar_Boddu_SCOPE_IMG_8131_77b58bd422.avif",
    "education": [
      "B.Tech, JNTU Hyderabad",
      "M.Tech, JNTU Hyderabad",
      "Ph.D, Acharya Nagarjuna University"
    ],
    "researchArea": "Machine Learning, Deep Learning, Image Processing",
    "memberships": [
      "ACM,CSTA,IAENG"
    ],
    "projects": [],
    "patents": [
      "1. UK Application Number: 6294154,Title: \"Wrist Band for School Children Security\"",
      "2. UK Application Number: 6292616,Title: \"AI Based Plant Extract Analysing Device to Identify Disease\"",
      "3.Germany Patent Number: 202022103985,Title: “Mobile Medical System and method based on block chain and 5G communication”",
      "4. Australia Patent Number: 2021100011,Title: “A Novel Method of Big Data Retrieval System using Machine Learning”",
      "5.Indian Publication Number: 202041053460,Title: “The Middleware in Internet of Things (IoT) for bridging heterogeneity between devices connected in network”",
      "6.Indian Publication Number: 202011035974,Title: “Hybridization with Deep Learning Techniques and Data Mining for Advanced Use of Industrial Sensor Networks”"
    ],
    "awards": [
      "Research Excellence Award from Gokaraju Rangaraju Institute of Engineering and Technology, Hyderabad in November 2024",
      "“Award of Excellence in Research-2022” in IJMTST Excellence Awards-2022 from International Journal for Modern Trends in Science and Technology",
      "“Shiksha Ratan Award-2022” from International Council for Education, Research and Training",
      "“VEDANT EDUCATOR EXCELLENCE AWARD 2020” from Vedant Foundation",
      "Best Faculty Award 2020-2021 from All India Eminent Faculty Council of Engineering, Management and Technology in Association with Engineering & Management College Teachers Development Association",
      "“INDIAN OVERSEAS PERFORMANCE EXCELLENT AWARD” in IARE –2019, from GISR Foundation",
      "“Young Researcher Award” in Vedant Academics Bangkok Awards – 2019 in Bangkok"
    ],
    "links": {
      "linkedin": "https://in.linkedin.com/in/dr-rajasekhar-boddu-906a489a",
      "researchGate": "https://www.researchgate.net/profile/Rajasekhar-Boddu",
      "googleScholar": "https://scholar.google.com/citations?user=wuimgP8AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57489395400",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/614111"
    }
  },
  {
    "id": "vitap-1633-cms",
    "name": "Dr. Ganji Tejasree",
    "employeeId": "13.70761",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "621 - N, CB",
    "email": "tejasree.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ganji_Tejasree_SCOPE_IMG_7267_1e21668a3b.avif",
    "education": [
      "Bachelors Of Engineering in Computer Science and Engineering & Chaitanya Bharathi Institute of Technology, Osmania University",
      "Master of Technology in Computer Science and Engineering, Vardhaman College of Engineering, JNTUH",
      "Doctor of Philosophy- Vellore Institute of Technology, Vellore"
    ],
    "researchArea": "Hyperspectral Imaging, Machine Learning, Deep Learning, Digital Image Processing",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-tejasree-ganji-8857841b7/",
      "googleScholar": "https://scholar.google.com/citations?user=EWdMueMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57930712200"
    }
  },
  {
    "id": "vitap-1622-cms",
    "name": "Dr. Nihar Ranjan Nayak",
    "employeeId": "13.70766",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "818 - G, CB",
    "email": "nihar.ranjan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Nihar_Ranjan_Nayak_SAS_IMG_8168_604fb52e77.avif",
    "education": [
      "B.Sc.(Information Science and Telecommunication), Ravenshaw University,Odisha",
      "M.Sc.(Computer Science), Pondicherry Central University, Pondicherry",
      "PHD(Computer Science & Engineering), Pondicherry Central University, Pondicherry"
    ],
    "researchArea": "Distributed System, Cloud Computing, Block Chain, Machine Learning, Artificial Intelligence, Fog Computing",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-nihar-ranjan-nayak-7877566b/",
      "googleScholar": "https://scholar.google.com/citations?user=rymK1xkAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57207953064",
      "vidwan": "https://vidwan.inflibnet.ac.in/myprofile"
    }
  },
  {
    "id": "vitap-1639-cms",
    "name": "Dr. Bileesh P Babu",
    "employeeId": "13.70774",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "816 - G, CB",
    "email": "bileeshbabu.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bileesh_P_Babu_SCOPE_IMG_8121_2b2e877e49.avif",
    "education": [
      "B. Tech in Computer Science and Engineering, Kerala University",
      "M. Tech in Computer Science and Engineering, Visvesvaraya Technological University",
      "PhD in Computer Science and Engineering"
    ],
    "researchArea": "Computer Vision, Machine Learning, Deep Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/bileesh-babu-82375072/",
      "researchGate": "https://www.researchgate.net/profile/Bileesh-Babu?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=qKrL_8wAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57914833100"
    }
  },
  {
    "id": "vitap-1640-cms",
    "name": "Dr. Dasari Sandeep",
    "employeeId": "13.70775",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "818 - J, CB",
    "email": "dasari.sandeep@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Dasari_Sandeep_SCOPE_IMG_8144_54ee0a9cad.avif",
    "education": [
      "B.Tech & JNTUA",
      "M.Tech (CS) & JNTUA",
      "Ph.D & VIT- Vellore"
    ],
    "researchArea": "Federated Learning, Machine Learning, Cyber Security, Big Data",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. Real Time Data Verification Device",
      "2. Cybersecurity Intrusion Detection: Evaluating Deep Learning Models with the CICDDoS2019 Dataset.",
      "3. Chest Worn Garment to Detect Brest Cancer"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-sandeep-dasari-2681102a1/",
      "researchGate": "https://www.researchgate.net/profile/Dasari-Sandeep/research",
      "googleScholar": "https://scholar.google.com/citations?user=RgWYGGkAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58285340300"
    }
  },
  {
    "id": "vitap-1653-cms",
    "name": "Dr. Shubhadeep Pal",
    "employeeId": "13.70789",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "329-A, AB-1",
    "email": "shubhadeep.pal@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shubhadeep_Pal_def4dfd2e1.avif",
    "education": [
      "BSc & Ramakrishna Mission Vidyamandira, Belur math",
      "MSc, Indian Institute of Technology Kanpur",
      "PhD & Tata Institute of Fundamental Science, Hyderabad, Weizmann Institute of Science, Catholic University of Louvain, Liege University",
      "Weizmann Institute of Science, Catholic University of Louvain, Liege University"
    ],
    "researchArea": "Material Science, Electrochemistry, Energy Storage Technology, Transport Physics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "K V Rao Scientific Society Young Scientist award winner",
      "CEFIPRA CEFIPRA-ESSON fellowship",
      "TIFR Hyderabad Best Innovative Poster Award",
      "Complex and Functional Materials (ICCFM 2018) Best Poster Award"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-shubhadeep-pal-28637089/",
      "googleScholar": "https://scholar.google.co.in/citations?user=4S9JuB4AAAAJ&hl=en&oi=ao",
      "scopus": "57189726969"
    }
  },
  {
    "id": "vitap-1655-cms",
    "name": "Dr. Saronath Halder",
    "employeeId": "13.70791",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "159, AB1",
    "email": "saronath.halder@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Saronath_Halder_fa7dcb772f.avif",
    "education": [
      "B.Sc., R. K. Mission, Narendrapur/ University of Calcutta",
      "M.Sc., IIT Madras",
      "Ph.D., Bose Institute/ University of Calcutta"
    ],
    "researchArea": "Quantum Information",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=5hNFk-MAAAAJ"
    }
  },
  {
    "id": "vitap-1656-cms",
    "name": "Dr. Putta Durga",
    "employeeId": "13.70792",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "817 - N, CB",
    "email": "durga.putta@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Putta_Durga_7619bf7153.avif",
    "education": [
      "B.Tech (CSE) & JNTUA",
      "M.Tech (CSE) & JNTUK",
      "Ph. D (CSE) & VIT-AP"
    ],
    "researchArea": "Artificial Intelligence, Natural Language Processing, Deep Learning",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. 438896-001 and An AI-Based Interactive Kiosk For Checking Healthcare Data",
      "2. 443944-001 and Artificial Intelligence-Based Cloud Data Security Detector",
      "3. 202541062268 and Smart Traffic Monitoring: Vision-Based Accident Detection and Analysis",
      "4. 202541038101 and Hybrid Sentiment Analysis: Integrating Text And Visual Data Using Ensemble Learning",
      "5. 202541037909 and Neural Network-Based AI System For Early Disease Prediction From Multimodal Medical Data",
      "6. 202541041548 and Secure Computing With Blockchain-Enabled Zero Knowledge Proof Identity",
      "7. 202541041552 and Quantum Assisted Data Structures For High Speed Computing Applications",
      "8. 202541041637 and Reinforcement Learning Driven AI For Dynamic Process Optimization In Smart Factories",
      "9. 202441075504 and Deep-Sentiment: An Effective Deep Sentiment Analysis Using a Decision-Based Recurrent Neural Network (D-RNN)",
      "10. 202441084338 and Diagnostic Precision With AI- Brain Tumor Detection In Healthcare",
      "11. 202441088614 and Early Diabetes Detection: A Machine Learning Approach",
      "12. 202441102453 and Cardio Fusion: A Novel Hybrid Approach For Predicting Cardiovascular Risk Using Machine Learning",
      "13. 202211045554 and Artificial intelligence and Deep Learning based Technique for Understanding the Various Thermoelectric Materials",
      "14. 202221046139 and Deep learning based automatic prevention and detection of brain tumor using image processing, data mining, and machine learning algorithms for smart healthcare systems",
      "15. 202231053304 and Artificial Intelligence and Deep Learning based Driverless Cars to reduce the road accident, Death Rate using Python"
    ],
    "awards": [
      "Young Researcher Award, INSC, an ISO 9001:2015 certified body under the Ministry of MSME & Corporate Affairs, Govt. of India, 2024"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Putta-Durga",
      "googleScholar": "https://scholar.google.com/citations?user=QUBD21oAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57982555600",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/261613"
    }
  },
  {
    "id": "vitap-1657-cms",
    "name": "Dr. Chattu Kannaiah",
    "employeeId": "13.70793",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "816 - B, CB",
    "email": "kannaiah.ch@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Chattu_Kannaiah_SCOPE_12a583d704.avif",
    "education": [
      "B.Tech (CSE) & JNTUH",
      "M.Tech (CSE) & JNTUH",
      "Ph.D (CSE) & VIT-AP"
    ],
    "researchArea": "Natural Language Processing, Machine Learning, Deep Learning",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. 202341037142 and Creating Corpora for Inadequate Resource Telugu Language to Analyze Sentiments Using Deep Learning.",
      "2. 2020102026 and System and Method for Enabling Sentiment Analysis to Evaluate Real-Time Events"
    ],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=y4l78LIAAAAJ",
      "scopus": "https://www.scopus.com/results/authorNamesList.uri?name=name&st1=Chattu&st2=Kannaiah&origin=searchauthorlookup"
    }
  },
  {
    "id": "vitap-1658-cms",
    "name": "Dr. Dasari Bosu Babu",
    "employeeId": "13.70794",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "104-B, CB",
    "email": "bosubabu.d@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Dasari_Bosu_Babu_SASCHY_992816ee16.avif",
    "education": [
      "Graduated from Andhra University",
      "Graduated from Pondicherry University",
      "Development of energy storage materials from CSIR-Central Electrochemical Research Institute, Developing next-generation battery technologies,the Karlsruhe Institute of Technology (KIT),",
      "Developing next-generation battery technologies,the Karlsruhe Institute of Technology (KIT),"
    ],
    "researchArea": "Design and development of advanced cathode and anode materials for high-performance lithium-ion, lithium-sulfur, and all-solid-state batteries, contributing to cutting-edge advancements in energy storage technologies.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/bosu-babu-dasari-5aa61223/",
      "googleScholar": "https://scholar.google.com/citations?user=DWYU12MAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1660-cms",
    "name": "Dr. Shailja Jain",
    "employeeId": "13.70796",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "626 - L, CB",
    "email": "shailja.jain@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shailja_Jain_SASCHY_c731a0778c.avif",
    "education": [
      "B.Sc. from Dr. Hari Singh Gour Central University",
      "M.Sc. from Dr. Hari Singh Gour Central University",
      "Ph.D. from CSIR-National Chemical Laboratory, Pune, The Hebrew University of Jerusalem, Israel and Alexander-Von-Humboldt Postdoctoral Fellow, University of Stuttgart, Germany.",
      "The Hebrew University of Jerusalem, Israel and Alexander-Von-Humboldt Postdoctoral Fellow, University of Stuttgart, Germany."
    ],
    "researchArea": "Chemical Bonding, Reaction Mechanisms, Catalysis, Main Group Chemistry, Stereoselectivity, Noncovalent Interactions, Electric Fields Effects",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Alexander-von-Humboldt fellowship for postdoctoral study (starting September 2023).",
      "Keerthi Sangoram Memorial Endowment Award for “Best Research Scholar” for 2020 at CSIR-NCL Pune, India (Feb 2021).",
      "Dr. Krishnan Award for “Best Published Research Paper” in Computational Sciences for 2020 at CSIR-NCL Pune, India (Feb 2021).",
      "Best Poster Award at the International Conference on Recent Trends in Catalysis (RTC 2020), NIT Calicut, India (Feb 2020).",
      "Best Poster Award at the International Conference Structural and Inorganic Chemistry (ICSIC-II), IISER Pune, India (March 2019).",
      "Best Poster Award at Science day, CSIR-NCL Pune, India (Feb 2018).",
      "CSIR-UGC-NET-Lectureship (Chemical Sciences) (All India Rank-21) (December 2017)",
      "DST-Inspire Fellowship (Junior Research Fellowship (JRF), and Senior Research Fellowship (SRF)), Awarded by Department of Science and Technology-Inspire Fellowship Scheme, India (January 2015).",
      "First Rank M.Sc. Chemistry, Dr. Harisingh Gour Central University Sagar, India (June 2014).",
      "First Rank B.Sc. Dr. Harisingh Gour Central University Sagar, India (June 2012)."
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/shailja-jain-ph-d-she-her-096734263",
      "researchGate": "https://www.researchgate.net/profile/Shailja-Jain-2",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=ndPiBSkAAAAJ",
      "orcid": "https://orcid.org/0000-0003-4588-9643"
    }
  },
  {
    "id": "vitap-1665-cms",
    "name": "Dr. Gangadhar Pamarthi",
    "employeeId": "13.70803",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "622-B, CB",
    "email": "gangadhar.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Gangadhar_Pamarthi_SASCHY_19b2fb4aed.avif",
    "education": [
      "B. Sc (Andhra Loyola College, Nagarjuna University)",
      "M. Sc (Organic Chemistry, Andhra University College of Science and Technology)",
      "CSIR - Indian Institute of of Chemical Technology, Hyderabad."
    ],
    "researchArea": "Total Synthesis, Assymmetric Synthesis, Development of Methodology, Computational Chemistry",
    "memberships": [
      "Association of Chemistry Teachers(ACT)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1670-cms",
    "name": "Dr. Manas Ranjan Panda",
    "employeeId": "13.70807",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "622-M, CB",
    "email": "manas.panda@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Manas_Ranjan_Panda_SASPHY_e38ee51e4c.avif",
    "education": [
      "Utkal University, Bhubaneswar",
      "Pondicherry University, Pondicherry",
      "1) IIT-B Monash Research Academy (A collaboration PhD between IIT Bombay, India & Monash University, Australia) , 2) Monash University",
      "Monash University"
    ],
    "researchArea": "Energy Storage Materials & Batteries",
    "memberships": [
      "1. Member of the American Chemical Society, 2024. 2. Member of Materials Research Society, 2019-2022. 3. Membor of the American Physical Society, 4. Member of Indian Association of Physics Teachers"
    ],
    "projects": [],
    "patents": [
      "1. M. R. Panda, S. Sau, S. Mitra, Spectroelectrochemical cell holding set-up for in-situ/operando synchrotron-based measurements. Indian patent, Grant No. 468128, 2023.",
      "2. M. R. Panda, A. Raj, S. Sau, D. P. Dutta, S. Mitra, Tamarindus indica seed derived carbon and its composite preparation method thereof for sodium-ion battery. Indian patent, Grant No. 478825, 2023.",
      "3. M. R. Panda, A. Raj, A. Kumar, A. Ghosh, Q. Bao, S. Mitra, Rechargeable sodium-ion batteries based on layered electrode materials and method of fabricating the same. Indian patent, Indian Patent Grant No. 381040, 2021.",
      "4. A. Raj, M. R. Panda, S. Mitra, D. P. Dutta, Electrochemical cell, method for synthesis of bio-derived carbon and preparation of electrode from bio-derived carbon. Indian patent, Grant No. 413867, 2022.",
      "5. A. Kumar, A. Ghosh, S. Mitra, M. R. Panda, Electrochemical cell including optical window made of transparent adhesive tape and method for manufacturing thereof. Indian patent, Grant No. 384463, 2021."
    ],
    "awards": [
      "String Bio Best Thesis Award 2021, IITB-Monash Research Academy, India, this Award recognizes outstanding doctoral research among PhD graduates in 2021.",
      "Anil K. and Bharati Bhatnagar Best Thesis Award 2021, Bhabha Atomic Research Centre (BARC), India, this Award recognizes exceptional doctoral research in Condensed Matter Physics nationwide for 2021.",
      "National Award for Research Excellence 2021, The Excellence in Nano Innovation Award from the Indian National Young Academy of Sciences (INYAS) for notable contributions to nanotechnology research across the nation in 2021.",
      "Tata Chemicals Best Journal Paper Award 2020, IITB-Monash Research Academy, India.",
      "Thermo Fisher Scientific Best Collaborations Award 2019, IITB-Monash Research Academy, India.",
      "Shortlisted for Gandhian Young Technological Innovation Awards, 2020 (GYTI 2020), Office of the President of India, Rashtrapati Bhavan, New Delhi, India.",
      "Best Poster Award 2017, The 62nd DAE Solid State Physics Symposium 2017, BARC, Mumbai, India.",
      "IITB, India & Monash University, Australia Graduate Fellowship, 2016–2020"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-manas-ranjan-panda-743b3049/",
      "researchGate": "https://www.researchgate.net/profile/Manas_Panda9?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=DbjoyvQAAAAJ&view_op=list_works&authuser=2&sortby=pubdate",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201687650"
    }
  },
  {
    "id": "vitap-1672-cms",
    "name": "Dr. Thangam Sivanantham",
    "employeeId": "13.70809",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "622-G, CB",
    "email": "thangam.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_THANGAM_SIVANANTHAM_SCOPE_995e08ebc2.avif",
    "education": [
      "B.E & M.K University, Madurai",
      "M.E & Anna University, Chennai",
      "Ph.D & VIT-AP University"
    ],
    "researchArea": "Cyber Security",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. IPR202341056255-System and Methods for Edge-Enabled Malicious Vehicle Detection.",
      "2. IPR202141009515-Design of Secured Smart Mobile Real-Time Health Monitoring System Using IOT Fog Computing.",
      "3. IPR202041050337-A Smart Walking System for The Elderly and Blind."
    ],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=M76VjQwAAAAJ",
      "scopus": "\"https://www.scopus.com/authid/detail.uri?authorId=59326481400 \""
    }
  },
  {
    "id": "vitap-1675-cms",
    "name": "Dr. Shaik Moinuddin Ahmed",
    "employeeId": "13.70812",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "622-J, CB",
    "email": "moinuddin.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shaik_Moinuddin_Ahmed_SCOPE_379bcf7c38.JPG",
    "education": [
      "B.Tech.(CSE), Andhra University",
      "M.Tech.(CST), Andhra University",
      "Ph.D.(CS), Maulana Azad National Urdu University (MANUU) A Central University"
    ],
    "researchArea": "OCR, Image Processing",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=79y4CpkAAAAJ&hl=en&authuser=1",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58414835400"
    }
  },
  {
    "id": "vitap-1677-cms",
    "name": "Dr. Mekathoti Vamsi Kiran",
    "employeeId": "13.70814",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "622-F, CB",
    "email": "vamsikiran.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70814_Dr_Mekathoti_Vamsi_Kiran_SCOPE_bb9e691bb0.avif",
    "education": [
      "CBIT, Osmania University, Hyderabad",
      "Sathyabama University, Chennai",
      "NIT-Trichy, India"
    ],
    "researchArea": "Wireless Body Area Networks, Artificial Intelligence",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-vamsi-kiran-mekathoti-ph-d-nit-trichy-india-152b1b6b/",
      "googleScholar": "https://scholar.google.com/citations?user=h5e2YdMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57217177381"
    }
  },
  {
    "id": "vitap-1678-cms",
    "name": "Dr. Venkata Sivanarayana Gayyi",
    "employeeId": "13.70815",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "619-E, CB",
    "email": "sivanarayana.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Venkata_Sivanarayana_Gayyi_SCOPE_8032011354.avif",
    "education": [
      "B.Tech(IT) and JNTU-Hyd",
      "M.Tech(IT) and Andhra University",
      "Ph.D(CSE) and GITAM (Deemed to be University)"
    ],
    "researchArea": "Medical Image Processing, Deep Learning, Cyber Security",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "linkedin.com/in/venkata-sivanarayana-323706270",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=82QVnK4AAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57219486357"
    }
  },
  {
    "id": "vitap-1679-cms",
    "name": "Dr. Madala Gargi",
    "employeeId": "13.70816",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "618 - B, CB",
    "email": "gargi.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Madala_Gargi_SCOPE_27433024ef.avif",
    "education": [
      "B.Tech., JNTU Hyderabad",
      "M.Tech., JNTU Kakinada",
      "PhD, VIT-AP University"
    ],
    "researchArea": "Medical Image Processing",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-gargi-madala-209ab02b7/",
      "googleScholar": "https://scholar.google.com/citations?user=bFEuJGYAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56492981600"
    }
  },
  {
    "id": "vitap-1687-cms",
    "name": "Dr. Lanka Divya",
    "employeeId": "13.70824",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "615 - E, CB",
    "email": "divya.lanka@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_LANKA_DIVYA_SCOPE_e61e4789e1.avif",
    "education": [
      "B.Tech, Andhra University",
      "M.Tech, JNTUK Kakinada",
      "Ph.D, Pondicherry University"
    ],
    "researchArea": null,
    "memberships": [
      "ISTE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1691-cms",
    "name": "Dr. N Md Jubair Basha",
    "employeeId": "13.70828",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "626 - F, CB",
    "email": "jubairbasha.md@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_N_MD_JUBAIR_BASHA_SCOPE_f0653e1099.avif",
    "education": [
      "B.Tech(Information Technology) & JNTU Hyderabad",
      "M.Tech(Information Technology) & JNTU Hyderabad",
      "Ph.D(CSE) & Bharathidasan University, Tiruchirapalli"
    ],
    "researchArea": "Software Engineering, Machine Learning, Artificial Intelligence, Emerging Technologies",
    "memberships": [
      "1. Fellow of Instituition of Engineers 2.Senior ACM Member 3. Life Member,Computer Society of India"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Ambassador of ACM",
      "Dr Sarvepalli RadhaKrishnan National Pratibha Award-2025"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&authuser=1&user=VxIYaDEAAAAJ",
      "scopus": "25646016100, 59432352700, 5516960100"
    }
  },
  {
    "id": "vitap-1693-cms",
    "name": "Dr. Kranthi Kumar Reddy Missal",
    "employeeId": "13.7083",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "111, AB-1",
    "email": "kranthi.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_KRANTHI_KUMAR_REDDY_MISSAL_SENSE_95efc88519.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1694-cms",
    "name": "Dr. Angel Shaji",
    "employeeId": "13.70831",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "415-A, AB-2",
    "email": "angel.shaji@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_ANGEL_SHAJI_VSL_f89a2744a5.avif",
    "education": [
      "VIT University, Chennai Campus",
      "Christ Deemed to be University, Bengaluru",
      "Christ Deemed to be University, Bengaluru"
    ],
    "researchArea": "Insolvency and Bankruptcy Law, Corporate and Commercial Law",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://in.linkedin.com/in/angel-shaji-695316106",
      "googleScholar": "https://scholar.google.com/citations?view_op=list_works&hl=en&user=5Xr66FcAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=59654783500"
    }
  },
  {
    "id": "vitap-1695-cms",
    "name": "Dr. K Durgesh",
    "employeeId": "13.70832",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "107, AB-1",
    "email": "durgesh.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_K_DURGESH_SENSE_69e47b2c07.avif",
    "education": [
      "B.Tech & JNTU-A",
      "M.Tech & Sri Venkateswara University, Tirupati",
      "Ph.D. & Indian Institute of Information Technology, Sri City."
    ],
    "researchArea": "Signal processing, Speech Processing, Statistical Modelling, and Statistical machine Learning.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1696-cms",
    "name": "Dr. Gosala Bethany",
    "employeeId": "13.70833",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "204-B, CB",
    "email": "bethany.gosala@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_GOSALA_BETHANY_SCOPE_850a38d074.avif",
    "education": [
      "B.Sc. (Mathematics, Physics, Computer Science), Osmania University",
      "M.Sc. (Maths with Computer Science), Osmania University",
      "Ph.D. (Maths with Computer Science), Banaras Hindu University"
    ],
    "researchArea": "Artificial Intelligence, Artificial Neural Network, Neuroimaging, EEG, BCI, Eye tracking, Social Robots",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Selected for “International Visiting Student Program” offered by the Institute of Eminence (IoE), Banaras Hindu University, to visit any top 500 QS-ranked institutes as a Visiting researcher for six months with full financial support.",
      "Winner of “Vandae Bharatam Kathatmak Video Pratiyogita”, conducted by Centre for Development of Advanced Computing (C-DAC), India. On the occasion of Indian independence, 15 August 2022.",
      "Awarded with Maulana Azad National Fellowship Junior Research Fellow (MANF-JRF) for June 2019.",
      "Qualified a National Level Exam, UGC NET/JRF June 2019 in Computer Science and Applications.",
      "Qualified Telangana State Eligibility Test (TS-SET-2019) for Assistant Professor/ Lecturer in the Subject Mathematical Sciences.",
      "Qualified Telangana State Eligibility Test (TS-SET-2018) for Assistant Professor/ Lecturer in the Subject Computer Science and Applications."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/bethany-gosala/",
      "researchGate": "https://www.researchgate.net/profile/Gosala-Bethany-2",
      "googleScholar": "https://scholar.google.com/citations?user=MHk-0FMAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57223794828"
    }
  },
  {
    "id": "vitap-1698-cms",
    "name": "Dr. Rakesh P S",
    "employeeId": "13.70835",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "415-J, AB-2",
    "email": "rakesh.ps@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rakesh_P_S_VSL_f232acf1e1.avif",
    "education": [
      "BBA., LL.B (Honours), Government Law College, Kozhikode, University of Calicut, Kerala",
      "LL.M. (Criminal Law), School of Legal Studies, Cochin University of Science and Technology, Kochi, Kerala",
      "Forensic Identification Using Biological Samples in Criminal Process: Legal Safeguards and Ethical Concerns, School of Legal Studies, Cochin University of Science and Technology, Kochi, Kerala"
    ],
    "researchArea": "Criminal Law, Forensic Evidence, Criminal Procedure, Jurisprudence, Constitutional Law, Medical Law",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Rakesh-P-S-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=4h6N2DgAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=59657083700&origin=resultslist"
    }
  },
  {
    "id": "vitap-1699-cms",
    "name": "Dr. Zeba Shamsi",
    "employeeId": "13.70836",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1017 - H, CB",
    "email": "shamsi.zeba@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Zeba_Shamsi_SCOPE_a64723763d.avif",
    "education": [
      "B.Tech in Computer Science and Engineering & Assam Don Bosco University",
      "M.Tech in Computer Science and Engineering & Al-Falah University",
      "PhD in Computer Science and engineering & NIT Silchar"
    ],
    "researchArea": "Cybersecurity, with emphasis on cryptography, image-based data security (encryption & steganography), and security analytics.",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. Patent Number: 202331076794, Indian Patent, \"\"Design and Implementation of Adaptive Cluster Approach in CRN for 5G Applications",
      "2. Patent Number: 44855-001, Indian Patent, \"\"AI- BASED FINGERPRINT DEVICE FOR CYBERCRIME DETECTION"
    ],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Zeba-Shamsi?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=UiNfIJAAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57193568625"
    }
  },
  {
    "id": "vitap-1708-cms",
    "name": "Dr. Priya Kumari",
    "employeeId": "13.7084",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "225-F, AB-2",
    "email": "priya.kumari@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_PRIYA_KUMARI_VSL_693a0713cc.avif",
    "education": [
      "B.A., LL.B. (Hons.), NUSRL, Ranchi",
      "LL.M., NLU, Jodhpur",
      "Ph.D. (Law), MNLU, Chhatrapati Sambhajinagar"
    ],
    "researchArea": "Climate Change Law, Business and Human Rights, IPR",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1706-cms",
    "name": "Dr. Mohd Irfan",
    "employeeId": "13.70845",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1017-D, CB",
    "email": "mohd.irfan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_MOHD_IRFAN_SCOPE_84ec81dd60.avif",
    "education": [
      "B.Sc.(Maths), Mahatma Gandhi Kashi Vidyapith, Varanasi",
      "M.Sc.(MCS), Jamia Millia Islamia, New Delhi",
      "University of Hyderabad, Hyderabad"
    ],
    "researchArea": "Applied Machine Learning, Computer Vision, Healthcare, Deep Learning, Image Enhancement",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/mohd-irfan925"
    }
  },
  {
    "id": "vitap-1711-cms",
    "name": "Dr. Y. Raghuvamsi",
    "employeeId": "13.70848",
    "designation": "Assistant Professor Senior Grade-1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "329-H, AB-1",
    "email": "raghuvamsi.yarlagadda@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_YARLAGADDA_RAGHUVAMSI_SENSE_0c425e4e54.avif",
    "education": [
      "B.Tech in EEE from JNTUK Kakinada",
      "M.Tech in Power Systems Engineering from JNTUK Kakinada",
      "PhD from NIT Andhra Pradesh"
    ],
    "researchArea": "Distribution System State Estimation, Deep learning, Optimization Techniques, IoT",
    "memberships": [
      "IEEE-93057532"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "linkedin.com/in/dr-yarlagadda-raghuvamsi-01210a25a",
      "researchGate": "https://www.researchgate.net/profile/Raghuvamsi-Yarlagadda/research",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=BhFb4F0AAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57561121000",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/216221"
    }
  },
  {
    "id": "vitap-1718-cms",
    "name": "Dr. Balaraju Ramesh",
    "employeeId": "13.70856",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "817 - A, CB",
    "email": "balaraju.ramesh@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_BALARAJU_RAMESH_SCOPE_1d7f65465b.avif",
    "education": [
      "B.Tech in CSE & JNTUH, Hyderabad",
      "M.Tech in CS & NITT, Tiruchirapalle",
      "PhD in CSE & VIT, Vellore"
    ],
    "researchArea": "Machine Learning, Deep Learning, IoT, Cloud Computing and Cyber Security",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/firststeps.FollowSuggestions.html",
      "googleScholar": "https://myaccount.google.com/?hl=en&pli=1",
      "scopus": "https://www.scopus.com/pages/search/authors?searchId=aed0e582-3702-4c30-b499-3e4c2bd6c25b"
    }
  },
  {
    "id": "vitap-1719-cms",
    "name": "Dr. Tirumanadham N S Koti Manikumar",
    "employeeId": "13.70857",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1017-G, CB",
    "email": "tirumanadham.koti@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_TIRUMANADHAM_N_S_KOTI_MANIKUMAR_SCOPE_8901dad203.avif",
    "education": [
      "B.Tech & JNTUK",
      "M.Tech & JNTUK",
      "PhD & Bharath Institute of Higher Education and Research, Post Doctorial Fellow & Newcastle University in Singapore (NUiS)",
      "Post Doctorial Fellow & Newcastle University in Singapore (NUiS)"
    ],
    "researchArea": "Machine Learning, E-Learning, Deep Learning, Computer Networks",
    "memberships": [
      "Senior Member, IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-koti-mani-kumar-thirumanadham-47b0aa87/",
      "researchGate": "https://www.researchgate.net/?_tp=eyJjb250ZXh0Ijp7ImZpcnN0UGFnZSI6ImxvZ2luIiwicGFnZSI6ImxvZ2luIn19",
      "googleScholar": "https://scholar.google.com/citations?user=NYnMRSgAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57657683000"
    }
  },
  {
    "id": "vitap-1720-cms",
    "name": "Dr. Ayesha Khatun",
    "employeeId": "13.70858",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "425-G, AB1",
    "email": "ayesha.khatun@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_AYESHA_KHATUN_VSB_dcb739e884.avif",
    "education": [
      "BA (Economics), Assam Central University, Silchar",
      "MBA, Dibrugarh University",
      "PhD, Assam Central University, Silchar"
    ],
    "researchArea": "Knowledge Management, SRHRM, Neurodiversity, AI in HRM, CSR, Social Entrepreneurship, Micromanagement, Higher Education administration, Hybrid work arrangement",
    "memberships": [],
    "projects": [
      "Evaluating the Jal Jeevan Mission's Impact on Water Accessibility and Quality: A Study of Leh Ladakh, ICSSR"
    ],
    "patents": [
      "Application No.202341049663 A, 1. Implementation of Machine Learning Approaches for Predicting Job Satisfaction and Employee Behavior in an Organization"
    ],
    "awards": [
      "Maulana Azad National Fellowship, Ministry of Minority Affairs, Govt. of India, 2014"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ayesha-khatun-99b28318a/",
      "researchGate": "https://www.researchgate.net/profile/Ayesha-Khatun",
      "googleScholar": "https://scholar.google.com/citations?user=iZSFHcUAAAAJ&hl=en",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0002-0932-0444",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57202977116"
    }
  },
  {
    "id": "vitap-1723-cms",
    "name": "Dr. Midde Venkata Siva",
    "employeeId": "13.70861",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "313-B, AB1",
    "email": "venkatasiva.midde@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_MIDDE_VENKATA_SIVA_SENSE_043df843d6.avif",
    "education": [
      "B.Tech in ECE, JNTU Anantapuramu",
      "M.Tech in Microelectronics and VLSI Design, NIT Calicut",
      "PhD NIT Calicut"
    ],
    "researchArea": "VLSI Architectures for image processing, AI/ML Hardware accelators, Hardware for CNN",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/mvsiva451/",
      "googleScholar": "https://scholar.google.com/citations?user=nFaRmZIAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57216688326"
    }
  },
  {
    "id": "vitap-1729-cms",
    "name": "Dr. Kalyani Abhyankar",
    "employeeId": "13.70864",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "225 E, AB2",
    "email": "kalyani.abhyankar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_KALYANI_ABHYANKAR_VSL_a57b2c75a5.avif",
    "education": [
      "BBA LLB(Hons), Christ University Bangalore",
      "LLM (Constitutional and Administrative Law), National Law University of Advanced Legal Studies, Kochin",
      "Phd in E-commerce and Consumer law ( NLIU Bhopal )"
    ],
    "researchArea": "Ecommerce and Consumer Law. AI and Dark Patterns, New Emerging Tech and Law, Health Law",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/kalyaniabhyankar/"
    }
  },
  {
    "id": "vitap-1732-cms",
    "name": "Dr. Siba Prasad Mishra",
    "employeeId": "13.70867",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "314 - A, AB-1",
    "email": "sibaprasad.mishra@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Siba_Prasad_Mishra_SENSE_9ff5f86df0.avif",
    "education": [
      "Btech, BPUT Rourkela",
      "Mtech, NIT Rourkela",
      "PhD, SVNIT Surat"
    ],
    "researchArea": "Signal processing, Speech signal processing, Machine learning and deep learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/siba-prasad-mishra-maa/",
      "googleScholar": "https://scholar.google.com/citations?user=DxP34SEAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1733-cms",
    "name": "Dr. Dibyadrasta Sahoo",
    "employeeId": "13.70868",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "314 - C, AB-1",
    "email": "dibyadrasta.sahoo@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Dibyadrasta_Sahoo_SENSE_37bc73b925.avif",
    "education": [
      "B.TECH & BPUT, Rourkela",
      "M.TECH & NIT Silchar",
      "PhD & IIT Roorkee"
    ],
    "researchArea": "Semiconductor Device/Memory, VLSI, AI/ML, Optimization",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=6AIKCrIAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1735-cms",
    "name": "Dr. Mattakoyya Aharonu",
    "employeeId": "13.7087",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1017 - L, CB",
    "email": "aharonu.mattakoyya@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Mattakoyya_Aharonu_SCOPE_c8804b6ca4.avif",
    "education": [
      "B.Tech. in Information Technology, JNTU Kakinada, Andhra Pradesh, India.",
      "M.Tech. in Computer Science and Engineering, JNTU Kakinada, Andhra Pradesh, India.",
      "Ph.D. in Computer Science and Engineering, Vellore Institute of Technology (VIT) , Vellore, Tamil Nadu, India."
    ],
    "researchArea": "Artificial Intelligence , Machine Learning ,Deep Learning , Computer Vision , Image Processing",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1737-cms",
    "name": "Dr. Mullapudi Siva",
    "employeeId": "13.70872",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "309 - A, AB-1",
    "email": "siva.mullapudi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_MULLAPUDI_SIVA_SENSE_df6279cab4.avif",
    "education": [
      "B.Tech, EEE, Acharya Nagarjuna University, Guntur",
      "M.Tech, Systems and Control, NIT Warangal",
      "Ph.D. , NIT Warangal"
    ],
    "researchArea": "Control Systems, Power electronics, Fuel Cell control, Renewable energy, Fractional Order Control, System Identification",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?view_op=search_authors&mauthors=siva+mullapudi&hl=en&oi=ao"
    }
  },
  {
    "id": "vitap-1738-cms",
    "name": "Dr. Sonia Das",
    "employeeId": "13.70873",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "309 - D, AB-1",
    "email": "sonia.das@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_SONIA_DAS_SENES_7566c6a383.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1739-cms",
    "name": "Dr. Madduluri Suneetha",
    "employeeId": "13.70874",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "309 - B, AB-1",
    "email": "madduluri.suneetha@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_MADDULURI_SUNEETHA_SENSE_79d2967ce1.avif",
    "education": [
      "B.Tech in ECE, JNTU Kakinada",
      "M.Tech in CESP, JNTU Kakinada",
      "Ph.D, NIT Warangal"
    ],
    "researchArea": "Biomedical Signal Processing, Biometrics, AI in Healthcare & Agricultural Applications",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. AI-Based Continuous Health Monitoring and Biometric Authentication Using",
      "2. Investigations On AI–Based Biometric Authentication Systems",
      "3. Smart Systems, Smart Capital: Engineering Innovation Meets Financial Strategy"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/suneetha-sivakrishna-082658226/",
      "researchGate": "https://www.researchgate.net/profile/Dr-Madduluri?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=AxlXXZEAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58541273500",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/710037"
    }
  },
  {
    "id": "vitap-1748-cms",
    "name": "Dr. Meera Patel",
    "employeeId": "13.70883",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "817 - F, CB",
    "email": "meera.patel@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_MEERA_PATEL_SENSE_14514a0095.avif",
    "education": [
      "Electronics and Communication Engineering, Dr. A.P.J. Abdul Kalam Technical University Lucknow, Uttar Pradesh",
      "M. Tech. (Control System), National Institute of Technology Kurukshetra, Haryana, India",
      "Ph.D. (Control and Automation), Indian Institute of Technology Delhi, India, Post Doctoral fellow (Control & Computing Group), Indian Institute of Technology Bombay, Maharashtra, India",
      "Post Doctoral fellow (Control & Computing Group), Indian Institute of Technology Bombay, Maharashtra, India"
    ],
    "researchArea": "Networked Descriptor Systems, Multi-agent system, Cooperative Control, Linear Systems",
    "memberships": [
      "IEEE Member, IEEE Control Systems Society Member, IEEE Young Professionals"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=gxpAFd8AAAAJ&hl=en&oi=sra",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58711248000"
    }
  },
  {
    "id": "vitap-1749-cms",
    "name": "Dr. Krishna Prasad Bera",
    "employeeId": "13.70884",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "623-P, CB",
    "email": "krishnaprasad.bera@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Krishna_Prasad_Bera_SAS_a4d6d70e97.avif",
    "education": [
      "B.Sc & M.Sc, University of Calcutta",
      "M.Tech, IIT Kharagpur",
      "PhD, National Taiwan University (NTU, Taiwan), Research Fellow at National University of Singapore (NUS) & Nanyang Technological University (NTU) of Singapore. C.V. Raman Post-doctoral Fellow at Indian Institute of Science Bangalore (IISc)",
      "Research Fellow at National University of Singapore (NUS) & Nanyang Technological University (NTU) of Singapore. C.V. Raman Post-doctoral Fellow at Indian Institute of Science Bangalore (IISc)"
    ],
    "researchArea": "Quantum Optical and Transport properties, 2D Materials, Nanoelectronics, Optoelectronics, Semiconductor Devices, Magneto-Optical Effects, and Multiferroics",
    "memberships": [
      "ACS (American Chemical Society)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=lHivL2gAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1750-cms",
    "name": "Dr. Mahendra Sahare",
    "employeeId": "13.70885",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "618-A, CB",
    "email": "mahendra.sahare@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Mahendra_Sahare_SCOPE_fd14414194.avif",
    "education": [
      "BE, Rajiv Gandhi Proudyogiki Vishwavidyalaya, Bhopal (MP)",
      "M Tech., Rajiv Gandhi Proudyogiki Vishwavidyalaya, Bhopal (MP)",
      "Ph. D, Rabindranath Tagore University, Bhopal (MP)"
    ],
    "researchArea": "Artificial Intelligence, Machine Learning, FANET, IoT, Theory of Computation",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. Remote Aquatic Environmental Monitoring using Internet of things.",
      "2. Adaptive fuzzy control for efficient congestion avoidance in FANET and IOT Environments.",
      "3. AI Based device for brain signal detection."
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-mahendra-sahare-46432158/",
      "researchGate": "https://www.researchgate.net/profile/Mahendra-Sahare",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=cH77lpIAAAAJ",
      "scopus": "https://www.scopus.com/pages/feedback/author/review-profile?authorIds=48761897700",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/645061"
    }
  },
  {
    "id": "vitap-1757-cms",
    "name": "Dr. Anshuman Choudhary",
    "employeeId": "13.70892",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "817-J, CB",
    "email": "anshuman.choudhary@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Anshuman_Choudhary_SENSE_d3b2095a39.avif",
    "education": [
      "West Bengal University of Technology",
      "Direct PhD",
      "Indian Institute of Technology kanpur, Indian Institute of Technology kanpur",
      "Indian Institute of Technology kanpur"
    ],
    "researchArea": "Frequency Selective Surfaces, Metamaterials, Nanocomposites, Optically Transparent Materials for EMI Shielding, and Microwave Absorption.",
    "memberships": [
      "Reviewer of IEEE Transaction on Microwave Theory and Techniques, Member APS-IEEE and MTTS-IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-anshuman-choudhary-369978166",
      "googleScholar": "https://scholar.google.com/citations?user=DhiRCJMAAAAJ&hl=en&oi=sra"
    }
  },
  {
    "id": "vitap-1760-cms",
    "name": "Dr. Nilanjan Roy",
    "employeeId": "13.70895",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "817-G, CB",
    "email": "nilanjan.roy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Nilanjan_Roy_SAS_e9885d92b6.avif",
    "education": [
      "B.Sc. in Physics (Hons.), Presidency College, University of Calcutta",
      "M.Sc. in Physics, IIT Kanpur & University of Kentucky",
      "Ph.D. in Physics, IISER Bhopal, IoE Postdoctoral Fellow, IISc Bangalore; Postdoctoral Research Fellow, NTU Singapore; Postdoctoral Research Associate, NISER Bhubaneswar",
      "IoE Postdoctoral Fellow, IISc Bangalore; Postdoctoral Research Fellow, NTU Singapore; Postdoctoral Research Associate, NISER Bhubaneswar"
    ],
    "researchArea": "Quantum many-body physics, quantum information, quantum technologies, computational algorithms",
    "memberships": [
      "Early-Career Member of American Physical Society"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Max-Steckler Fellowship, University of Kentucky, 2011",
      "Junior Research Fellowship, CSIR & UGC, India, 2015"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Nilanjan-Roy-2",
      "googleScholar": "https://scholar.google.com/citations?user=NZiikpcAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57201216879"
    }
  },
  {
    "id": "vitap-1761-cms",
    "name": "Dr. Kuntal Chakraborty",
    "employeeId": "13.70896",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "812-A, CB",
    "email": "kuntal.chakraborty@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kuntal_Chakraborty_SENSE_4e737ae1df.avif",
    "education": [
      "B.Tech (AEIE) - MAKAUT, West Bengal",
      "M.Tech (VLSI Design and Microelectronics Technology) - Jadavpur University, Kolkata, West Bengal",
      "Ph.D (VLSI Design)- National Institute of Technology Arunachal Pradesh"
    ],
    "researchArea": "VLSI Circuit, Time to Digital Converter, Smart Temperature Sensor",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=bpBf3i0AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58889564300"
    }
  },
  {
    "id": "vitap-1762-cms",
    "name": "Dr. Shaik Wasim Akram",
    "employeeId": "13.70898",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "812-C, CB",
    "email": "wasim.shaik@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_SHAIK_WASIM_AKRAM_SCOPE_01366f68e4.avif",
    "education": [
      "B.Tech, JNTU Kakinada",
      "M.Tech, JNTU Kakinada",
      "Ph.D, JNTU Anantapur"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=bZGgTnsAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57211278563"
    }
  },
  {
    "id": "vitap-1767-cms",
    "name": "Dr. Rajesh Velpula",
    "employeeId": "13.70903",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "819-F, CB",
    "email": "rajesh.velpula@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rajesh_Velpula_SENSE_d3be2fdeb3.avif",
    "education": [
      "B.Tech - Electrical and Electronics Engineering & Acharya Nagarjuna University",
      "M. Tech - Power Systems & Jawaharlal Nehru Technological University Kakinada",
      "Ph.D. & National Institute of Technology Tiruchirappalli"
    ],
    "researchArea": "Power System Protection, Numerical Relaying, Transmission Line Protection and Protection of Power Systems with Inverter-Based Resources (IBRs).",
    "memberships": [
      "Indian Society for Technical Education (ISTE)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-rajesh-velpula-4179a8156/",
      "researchGate": "https://www.researchgate.net/profile/Rajesh-Velpula-3?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=5G0fYsoAAAAJ&view_op=list_works&sortby=pubdate",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57696503300",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/723890"
    }
  },
  {
    "id": "vitap-1768-cms",
    "name": "Dr. Pichhika Hari Chandana",
    "employeeId": "13.70904",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "819-G, CB",
    "email": "harichandana.pichhika@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_PICHHIKA_HARI_CHANDANA_9b1e4ea880.avif",
    "education": [
      "B.Tech & JNTU-A",
      "M.Tech & Sri Venkateswara University, Tirupati",
      "Ph.D. & Indian Institute of Information Technology, Sri City."
    ],
    "researchArea": "Image Processing, Computer Vision, Deep Learning, Precision Agriculture, Unmanned Aerial Vehicles (UAVs)",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Awarded 2nd Place for innovation in Digital Agriculture at the National Horticulture Fair 2024, held at ICAR-IIHR, Bengaluru."
    ],
    "links": {}
  },
  {
    "id": "vitap-1769-cms",
    "name": "Dr. Patan Mushiya Katoon",
    "employeeId": "13.70905",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "819-B, CB",
    "email": "mushiyakatoon.patan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Patan_Mushiya_Katoon_SCOPE_4d938d053a.avif",
    "education": [
      "B.Sc, M.Sc & ANU University",
      "M.Tech (CSE) & CSJM University",
      "Ph.D VIT-AP UNIVERSITY"
    ],
    "researchArea": "Blockchain Technology , Healthcare",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/scholar?hl=en&as_sdt=0%2C5&q=PATAN+MUSHIYA+KATOON&btnG=",
      "scopus": "https://www.scopus.com/pages/search/authors?firstName=PATAN&lastName=katoon"
    }
  },
  {
    "id": "vitap-1772-cms",
    "name": "Dr. Praveen Tiwari",
    "employeeId": "13.70908",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "819 - H, CB",
    "email": "praveen.tiwari@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Praveen_Tiwari_SENSE_cea1fdf34c.avif",
    "education": [
      "BE RGPV Bhopal",
      "ME CSVTU Bhilai",
      "PhD IIT Guwahati"
    ],
    "researchArea": "Renewable Energy System, Smart Grid & Community Microgrid, DNN-based Load Forecasting, Grid Simulation & Validation",
    "memberships": [
      "IEEE, ISTE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-praveen-tiwari-aaa19611/",
      "googleScholar": "https://scholar.google.com/citations?user=bk8A5ekAAAAJ&hl=en&authuser=1"
    }
  },
  {
    "id": "vitap-1774-cms",
    "name": "Dr. Lolugu Govindarao",
    "employeeId": "13.70911",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "207-B, AB2",
    "email": "govindarao.lolugu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Lolugu_Govindarao_SASMAT_0a38986f62.avif",
    "education": [
      "B.Sc, Andhra University",
      "M. Sc(Mathematics), Pondicherry",
      "Ph. D, NIT Rourkela"
    ],
    "researchArea": "Numerical Methods for Singularly perturbed delay partial differential equations",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/lolugu-govindarao-31381761/",
      "researchGate": "https://www.researchgate.net/profile/Lolugu-Govindarao-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=xjAXz34AAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57205026803"
    }
  },
  {
    "id": "vitap-1779-cms",
    "name": "Dr. Krishnendu K",
    "employeeId": "13.70916",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "813-A, CB",
    "email": "krishnendu.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Krishnendu_K_SENSE_80d201f5a0.avif",
    "education": [
      "B.Tech. - Electronics and Communication Engineering, Mahatma Gandhi University, Kerala",
      "M.E. - Applied Electronics, Karunya University, Tamil Nadu",
      "Ph.D. - Electronics and Communication Engineering, IIT Roorkee"
    ],
    "researchArea": "Industrial Signal Processing, Sensor Time-Series Analysis, Spectro-temporal Localization, Time Frequency Analysis, Machinery Condition Monitoring, Predictive Maintenance",
    "memberships": [
      "IEEE"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/kkrishnendu/",
      "googleScholar": "https://scholar.google.com/citations?user=AYZ0_PMAAAAJ&hl",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=59535766500"
    }
  },
  {
    "id": "vitap-1786-cms",
    "name": "Dr. Mudit Mishra",
    "employeeId": "13.70924",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Mechanical Engineering (SMEC)",
    "subDepartment": null,
    "office": "160, AB-1",
    "email": "mudit.mishra@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Mudit_Mishra_SMEC_18117d9034.avif",
    "education": [
      "B.Tech, UPTU",
      "M.Tech, IIT (ISM) Dhanbad",
      "Ph.D., IIT (BHU) Varanasi"
    ],
    "researchArea": "Metamaterials, Wave Propagation, Lattice Structures, Functionally Graded material, Dynamic Stiffness Method, Finite Element Method",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=aMp22a0AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1793-cms",
    "name": "Dr. Mamilla Sreenivasulu",
    "employeeId": "13.70933",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1013 - I, CB",
    "email": "sreenivasulu.mamilla@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Mamilla_Sreenivasulu_SENSE_0e41d2e3db.png",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1794-cms",
    "name": "Dr. Pothi Reddy Krishna Mohan Reddy",
    "employeeId": "13.70935",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1013-M, CB",
    "email": "krishnamohan.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pothi_Reddy_Krishna_Mohan_Reddy_SENSE_932709fa08.avif",
    "education": [
      "B.Tech, JNTU Anantapur",
      "M.Tech, National Institute of Technology Nagaland",
      "PhD & National Institute of Technology Andhra Pradesh"
    ],
    "researchArea": "Energy management, Microgrids, Optimization, Demand response",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/krishna-mohan-reddy-b76802243/",
      "researchGate": "https://www.researchgate.net/profile/Krishna-Mohan-Reddy-Pothireddy?",
      "googleScholar": "https://scholar.google.com/citations?user=OJGAinoAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57391472500"
    }
  },
  {
    "id": "vitap-1796-cms",
    "name": "Dr. Koyyana Srinivasa Rao",
    "employeeId": "13.70937",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1013 - N, CB",
    "email": "srinivasarao.koyyana@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Koyyana_Srinivasa_Rao_SENSE_37c73a788f.avif",
    "education": [
      "B.Tech&Jawaharlal Nehru Technological University (JNTU), Kakinada",
      "M.Tech & Jawaharlal Nehru Technological University (JNTU), Kakinada",
      "Ph.D. & National Institute of Technology (NIT), Warangal."
    ],
    "researchArea": "Power Quality, Grid-Connected Inverters Supported by Renewable Energy Sources, Multilevel Converters, Control of DC-DC converters",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. Application No. 201941054849 and Title: Smart Wind Farm Management System",
      "2. Application No. 202041012418 and Title: Artifical Intelligence Based Smart Motorized Bicycle"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-k-srinivasa-rao-579337238/",
      "googleScholar": "https://scholar.google.com/citations?user=FKmNErYAAAAJ&hl=en&oi=ao"
    }
  },
  {
    "id": "vitap-1797-cms",
    "name": "Dr. Potharaju Ramesh",
    "employeeId": "13.70938",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1013 - L, CB",
    "email": "ramesh.potharaju@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Potharaju_Ramesh_SENSE_cce0d60352.avif",
    "education": [
      "B.Tech (ECE)- JNTU Hyderabad",
      "M.Tech (VLSI System Design)- JNTU Hyderabad",
      "Ph.D. (Microelectronics & VLSI)- NIT Silchar"
    ],
    "researchArea": "Microelectronics & VLSI- Tunnel FET",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?%20user=ojrDOWcAAAAJ&hl=en&user=ojrDOWcAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57221100210"
    }
  },
  {
    "id": "vitap-1799-cms",
    "name": "Dr. Buddepu Santhosh Kumar",
    "employeeId": "13.70941",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1016-L, CB",
    "email": "santhoshkumar.buddepu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Buddepu_Santhosh_Kumar_SENSE_75a5d728e9.avif",
    "education": [
      "B.Tech & JNTU Kakinada",
      "M Tech & JNTU KAKINADA",
      "PhD & NIT ROURKELA"
    ],
    "researchArea": "Ground Penetrating Radar (GPR) Signal Processing and Subsurface Imaging; Clutter and Noise Suppression; Subsurface Object Detection and Classification; Deep Learning for GPR Data Analysis; Machine Learning and Explainable Artificial Intelligence; Radar Image Interpretation.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-santhosh-kumar-buddepu-73a97277/?isSelfProfile=true",
      "googleScholar": "https://scholar.google.com/citations?user=hF-ujQsAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57214152610"
    }
  },
  {
    "id": "vitap-1800-cms",
    "name": "Dr. V V L Divakar Allavarapu",
    "employeeId": "13.70942",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1017-F, CB",
    "email": "divakar.allavarapu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_V_V_L_Divakar_Allavarapu_SCOPE_92db77a7d3.avif",
    "education": [
      "B.TEch (CSE), JNTU Hyderabad",
      "M.Tech (Artificial Intelligence), University of Hyderabad",
      "P.hD JNTU Kakinada"
    ],
    "researchArea": "Blockchain, Business Analytics, FinTech, Artificial Intelligence, and Machine Learning",
    "memberships": [
      "CSI"
    ],
    "projects": [],
    "patents": [
      "1. System and Method for Multiple Group Session Key Agreement Based on Blockchain Smart Contract Centric Computing (Published -2020) (202041031039 A)",
      "2. System and Method for Dynamic Group Key Agreement Based on Blockchain Smart Contract Centric Computing (Published -2020 and Grant-2025) (202041020444 A)"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/v-v-l-divakar-allavarapu-9619ab62/",
      "googleScholar": "https://scholar.google.com/citations?user=jp5WkI8AAAAJ&hl",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57220077766"
    }
  },
  {
    "id": "vitap-1803-cms",
    "name": "Dr. Pradeep Kumar Jena",
    "employeeId": "13.70945",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1016-P, CB",
    "email": "pradeepkumar.jena@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pradeep_Kumar_Jena_SCOPE_be5516f747.avif",
    "education": [
      "Berhampur University, Berhampur, Odisha",
      "Berhampur University, Berhampur, Odisha",
      "Biju Patnaik University Of Technology, Rourkela, Odisha"
    ],
    "researchArea": "Computer Vision, CBIR, Deep Learning, Image and Video Data Processing",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=Js4S7BwAAAAJ&hl=en&oi=ao"
    }
  },
  {
    "id": "vitap-1804-cms",
    "name": "Dr. Charulata Palai",
    "employeeId": "13.70946",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1016 -O, CB",
    "email": "charulata.palai@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Charulata_Palai_SCOPE_d456ffc168.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1808-cms",
    "name": "Dr. Karumanchi Beulah Sujan",
    "employeeId": "13.7095",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1016-C, CB",
    "email": "beulahsujan.karumanchi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Karumanchi_Beulah_Sujan_SENSE_01be393eab.avif",
    "education": [
      "B.Tech, Acharya Nagarjuna University",
      "M.Tech, Pondicherry Central University",
      "P.hD., NIT Andhra Pradesh"
    ],
    "researchArea": "Wireless Communication-Heterogeneous Cognitive Radio Networking",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/scholar?hl=en&as_sdt=0%2C5&q=beulah+sujan&btnG=",
      "scopus": "https://www.scopus.com/pages/search/authors?searchId=50033cee-6568-4e9c-92c3-ec27f1a399c6"
    }
  },
  {
    "id": "vitap-1810-cms",
    "name": "Dr. Surla Govindu",
    "employeeId": "13.70952",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1016-D, CB",
    "email": "govindu.surla@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Surla_Govindu_SCOPE_bbdc9f135c.avif",
    "education": [
      "B.Tech (Computer Science & Engineering) & JNTU-Kakinada",
      "M.Tech(Computer Science & Engineering) & JNTU-Kakinada",
      "Ph.D. (Computer Science & Engineering) & Pondicherry University"
    ],
    "researchArea": "Quantum Cryptography, Machine Learning, Deep Learning, Cryptography, Data Science",
    "memberships": [
      "ACM"
    ],
    "projects": [],
    "patents": [
      "A Novel Hybrid Quantum Resistant Cryptographic System for Enhancing the Security in Wireless Body Sensor Networks"
    ],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-govindu-surla-b68b3325a",
      "researchGate": "https://www.researchgate.net/profile/Surla-Govindu?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=wgtnYH8AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1811-cms",
    "name": "Dr. Immadi Murali Krishna",
    "employeeId": "13.70953",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "1016 - F, CB",
    "email": "muralikrishna.immad@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Immadi_Murali_Krishna_SCOPE_e65f35e5b7.avif",
    "education": [
      "B.SC(CS),ANU",
      "M.SC(CS),AU and M.Tech(CSE),JNTUH",
      "Ph.D(CSE),JNTUK"
    ],
    "researchArea": "Machine Learning, Deep Learning, AI, Visual Cryptography and IOT",
    "memberships": [
      "IE,IAENG,INTERNET SOCIETY, ICSES"
    ],
    "projects": [],
    "patents": [
      "1. Patent No.: 202621028089 Title: AI and Machine Learning-Based Automated Meeting Minute Generation System,",
      "2. Patent No.: 202541028887 Title: CN-GRAM FEATURE SELECTION BASED LSTM MODEL FOR FAKE NEWS DETECTION,",
      "3. Patent No: 202541041561 A, Title: SMART HEALTHCARE MONITORING SYSTEM USING IOT AND MACHINE LEARNING,",
      "4. Patent No.: 202041031170, Title: Image Hashing Search Engine with VP-Trees and OpenCV"
    ],
    "awards": [
      "Young Teacher in Computer Science – ITAP Award, 2022, Certificate of Excellence, 2017–2018: Received a Certificate of Excellence for valuable contribution during the academic year 2017–2018 at Potti Sri Ramulu Chalavadi Mallikarjuna Rao College of Engineering and Technology, Vijayawada."
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-i-murali-krishna-91275a229",
      "researchGate": "https://www.researchgate.net/profile/Dr-Krishna-6?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=KSwh_ckAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=60722287300",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/470976"
    }
  },
  {
    "id": "vitap-1814-cms",
    "name": "Dr. Naresh Boda",
    "employeeId": "13.70956",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1016-J, CB",
    "email": "naresh.boda@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Naresh_Boda_SENSE_8fbea93bdb.avif",
    "education": [
      "B Tech, JNTU Hyderabad",
      "M Tech, JNTU Hyderabad",
      "Ph.D. Motilal Nehru National Institute of Technology Allahabad, Prayagraj"
    ],
    "researchArea": "\"Power System, Energy Market, Pricing Mechanism, and Power System Economics\"",
    "memberships": [
      "IEEE, IAENG"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/naresh-boda-4731b7351",
      "researchGate": "https://www.researchgate.net/profile/Naresh-Boda?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=dQbJ31MAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58846859700"
    }
  },
  {
    "id": "vitap-1819-cms",
    "name": "Dr. R.Sai Prasad Goud",
    "employeeId": "13.70961",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1017-O, CB",
    "email": "saiprasadgoud.r@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_R_Sai_Prasad_Goud_SENSE_adc22e7d5b.avif",
    "education": [
      "B.Tech in Electronica and Communication Engineering, JNTU Hyderabad",
      "M.E. in Embedded Systems and VLSI design, Osmania University",
      "Ph.D., in Electronics Science, BITS Pilani, Hyderabad Camous",
      "BITS Pilani, Hyderabad Camous"
    ],
    "researchArea": "Semiconductor Device Fabrication, Printed and Flexible Sensors, Advanced Semiconductor Memory Technologies, Radiation detection and Radiation reliability studies, Synthesis and Characterization of Electronic Materials for various applications.",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. Title: Perovskite-LIG-based Resistive device for Ionizing Radiation Detection, Authors: Arindam Kushagra, R. Sai Prasad Goud, Bavana Harshitha, Sanket Goel, V Ramgopal Rao. Application No: 202611046898 filed in Apr-26.",
      "2. Title: Flexible Two-Terminal Resistive Radiation Device, Authors: Arindam Kushagra, R. Sai Prasad Goud, Bavana Harshitha, Sanket Goel, V Ramgopal Rao. Application No: 202511109623 filed in Nov-25.",
      "3. Title: Organic Field-Effect Transistor (OFET) Device and a Method For Fabricating Thereof, Authors: Arindam Kushagra, R. Sai Prasad Goud, N Praneeth, Sanket Goel, V Ramgopal Rao. Application No: 202511063610 filed in Jul-25."
    ],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/sai-prasad-goud-574492107",
      "researchGate": "https://www.researchgate.net/profile/R_Sai_Prasad_Goud/research",
      "googleScholar": "https://scholar.google.com/citations?user=ocISz-0AAAAJ&hl=en&authuser=1",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57479733600"
    }
  },
  {
    "id": "vitap-1824-cms",
    "name": "Dr. Yathirajula Ramesh Babu",
    "employeeId": "13.70964",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1017 - A, CB",
    "email": "yathirajula.rameshbabu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Yathirajula_Ramesh_Babu_SENSE_85f7a2409e.avif",
    "education": [
      "B.E & Andhra University",
      "M.Tech & JNTU Kakinada",
      "PhD & IIT Guwahati"
    ],
    "researchArea": "Fabrication of Nano Scale LEDs and Sensors, VLSI and Opto-Electronics, AI and ML",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Best Teacher Award in 2026"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=dTEVLWEAAAAJ&hl=en&oi=ao"
    }
  },
  {
    "id": "vitap-1822-cms",
    "name": "Dr. Bhavna Thawani",
    "employeeId": "13.70965",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "168, AB-1",
    "email": "bhavana.thawani@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bhavana_Thawani_VSB_613030b628.avif",
    "education": [
      "Delhi university",
      "Masters of Business Administration from Bhartiya Vidya Bhavna",
      "Doctor of Philosophy from Birla Institute of Management & Technology"
    ],
    "researchArea": "Sustainability Reporting--Finance and Accounting",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "ICAI International Best Research Paper Award"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/bhavna-thawani-9210a2b1",
      "researchGate": "https://www.researchgate.net/profile/Bhavna-Thawani-2",
      "googleScholar": "https://scholar.google.com/scholar?hl=en&as_sdt=0%2C5&q=Bhavna+Thawani&oq=Bhav"
    }
  },
  {
    "id": "vitap-1823-cms",
    "name": "Dr. Syed Rizwana",
    "employeeId": "13.70966",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": null,
    "email": "syed.rizwana@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Syed_Rizwana_SCOPE_ed7f9108fc.avif",
    "education": [
      "B.Tech & JNTU KAKINADA",
      "M.Tech &JNTU KAKINADA",
      "PhD & NIT MIZORAM"
    ],
    "researchArea": "Deep Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1321-cms",
    "name": "Dr. Shalini Thakur",
    "employeeId": "14.70118",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "320-D, AB-2",
    "email": "shalini.thakur@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shalini_Thakur_70118_IMG_2581_SAS_MAT_71bfe1332b.avif",
    "education": [
      "B.Sc., T.M.B.U. Bhagalpur University",
      "M.Sc., T.M.B.U. Bhagalpur University",
      "PhD, IIT(ISM) Dhanbad, Visiting Scientist ISI Kolkata",
      "Visiting Scientist ISI Kolkata"
    ],
    "researchArea": "Nonlinear Optimization Problems, Generalized Convexity, Optimality& duality",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Shalini-Jha-2?ev=hdr_xpr"
    }
  },
  {
    "id": "vitap-1225-cms",
    "name": "Ms. CH. Amrita Gulshan",
    "employeeId": "14.70148",
    "designation": "Assistant Professor Grade-2",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "416-B, AB-2",
    "email": "amrita.gulshan@vitap.ac.in",
    "phone": "5473",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_CH_Amrita_Gulshan_70148_IMG_2558_VSL_ec28e66b99.avif",
    "education": [
      "MS Ramaiah College of Law, Karnataka State Law University",
      "Andhra University",
      "WBNUJS"
    ],
    "researchArea": "International Law, Space Law",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/amrita-gulshan"
    }
  },
  {
    "id": "vitap-1323-cms",
    "name": "Dr. Chandan Kumar Thakur",
    "employeeId": "14.70153",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "320-F. AB-2",
    "email": "chandan.thakur@vitap.ac.in",
    "phone": "5866",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Chandan_Kumar_Thakur_70153_IMG_2532_SAS_3fcea634b1.avif",
    "education": [
      "B. Sc. and Veer Bahadur Singh Purvanchal University, Jaunpur, UP, India",
      "M.Sc., Banaras Hindu University, Varanasi, India.",
      "Ph.D., Indian Institute of Technology (Indian School of Mines) Dhanbad, India"
    ],
    "researchArea": "Solute Transport Modeling, Contaminant Hydrology, Groundwater Hydrology, Analytical and Numerical Approach.",
    "memberships": [
      "Society of Industrial Applied Mathematics ISM, Society of Applied Mathematics (SAM) Student Chapter, Indian mathematical Society"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Fellowship awarded (2012) by Rehabilitation council of India under Minister of Human Resource Development."
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Chandan-Thakur-6",
      "googleScholar": "https://scholar.google.co.in/citations?user=zJEtQI8AAAAJ&hl=en&oi=ao"
    }
  },
  {
    "id": "vitap-1332-cms",
    "name": "Dr. Manisha Maity",
    "employeeId": "14.70198",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "307-F, AB-2",
    "email": "manisha.m@vitap.ac.in",
    "phone": "5846",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Manisha_Maity_SAS_0928_524b5c9174.avif",
    "education": [
      "B.Sc (Maths Hons.) Ravenshaw University, Cuttack, Odisha",
      "M.Sc (Maths and Computing), IIT (ISM) Dhanbad",
      "PhD (Maths and Computing), IIT (ISM) Dhanbad"
    ],
    "researchArea": "Differential Equations and Theoretical Seismology",
    "memberships": [
      "ISTAM, ISCA, IMS, SAM"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Manisha-Maity",
      "googleScholar": "https://scholar.google.com/citations?user=kwrR3R4AAAAJ&hl=en&oi=ao",
      "orcid": "0000-0001-7134-6197",
      "scopus": "57193838357",
      "vidwan": "365234"
    }
  },
  {
    "id": "vitap-1272-cms",
    "name": "Dr. Renuprasad Hemkiran Patki",
    "employeeId": "14.70222",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "325-D, AB-2",
    "email": "renuprasad.patki@vitap.ac.in",
    "phone": "5810",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Renuprasad_Hemkiran_Patki_70222_IMG_2546_VISH_8216c74ed8.avif",
    "education": [
      "B.A. Savitribai Phule Pune University",
      "M.A. German Studies, Savitribai Phule Pune University",
      "Ph.D. Savitribai Phule Pune University"
    ],
    "researchArea": "Modern German Poetry, Contemporary German Love Poetry, History of German Literature, German as a Foreign Language (DaF)",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/renuprasad-patki-98308568/",
      "orcid": "0000-0002-8698-2847"
    }
  },
  {
    "id": "vitap-1279-cms",
    "name": "Dr. Balasingh V",
    "employeeId": "14.70361",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "723 -F, CB",
    "email": "balasingh.v@vitap.ac.in",
    "phone": "5984",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Balasingh_V_VISH_1952_d4d316f546.JPG",
    "education": [
      "B.A. English manonmaniam sundaranar university, tamilnadu",
      "M.A. English manonmaniam sundaranar university, tamilnadu",
      "Ph.D. in English ( Postcolonial Literature), IIT ROORKEE"
    ],
    "researchArea": "Postcolonial literature, diaspora literature, british literature, literary theory and criticism.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1283-cms",
    "name": "Dr. Anindita Shome",
    "employeeId": "14.7037",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "125-K, AB-2",
    "email": "anindita.shome@vitap.ac.in",
    "phone": "5990",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Anindita_Shome_VISH_1426_396ef2ad9c.avif",
    "education": [
      "B.A. English Hons, University of Calcutta",
      "M.A. English Literature, EFLU Hyderabad",
      "Ph.D. in Indian Diaspora Studies, HCU"
    ],
    "researchArea": "Diaspora studies, South Asian literatures, Migration studies",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-anindita-shome-6a64bb65",
      "researchGate": "https://www.researchgate.net/profile/Anindita-Shome",
      "googleScholar": "https://scholar.google.com/citations?user=HpG7eFkAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-8238-4946",
      "scopus": "57217006366"
    }
  },
  {
    "id": "vitap-1290-cms",
    "name": "Dr. Shubhra Ghoshal",
    "employeeId": "14.70376",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "103-E, CB",
    "email": "shubhra.ghoshal@vitap.ac.in",
    "phone": "5096",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shubhra_Ghoshal_VISH_1543_cac9b5f421.avif",
    "education": [
      "B.A. English Hons., Vinoba Bhave University, Hazaribagh",
      "M.A. English, Vinoba Bhave University, Hazaribagh",
      "Ph.D in English, IIT (ISM), Dhanbad"
    ],
    "researchArea": "Theatre Studies, Critical Theories, Indian Literature",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/shubhra-ghoshal-39b168155/",
      "googleScholar": "https://scholar.google.com/citations?user=bufw3U8AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1298-cms",
    "name": "Dr. Dheeraj Kumar",
    "employeeId": "14.70379",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "723 - E, CB",
    "email": "dheeraj.kumar@vitap.ac.in",
    "phone": "5909",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70379_Dr_Dheeraj_Kumar_VISH_1351_2bd99316d2.avif",
    "education": [
      "BA (Hons.) French, The EFL University, Hyderabad",
      "MA in French, The EFL University, Hyderabad",
      "PhD in French, The EFL University, Hyderabad"
    ],
    "researchArea": "French and Francophone Literature",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1400-cms",
    "name": "Dr. Kotnana Ganesh",
    "employeeId": "14.70385",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "128-H, CB",
    "email": "ganesh.kotnana@vitap.ac.in",
    "phone": "5904",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kotnana_Ganesh_SASPHY_8f4b491c16.avif",
    "education": [
      "BSc, Andhra University",
      "MSc, Andhra University",
      "PhD, Indian Institute of Technology Hyderabad",
      "Uppsala University (2018-2020), Gachon University (2024-2026)"
    ],
    "researchArea": "Condensed Matter Physics - Functional Materials",
    "memberships": [
      "Magnetic Society of India (MSI)"
    ],
    "projects": [
      "Tuning the optical and magnetic properties of RFeO3 compounds for multifunctional applications, VIT-AP University"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ganesh-kotnana-30b1b7145/",
      "researchGate": "https://www.researchgate.net/profile/Ganesh-Kotnana",
      "googleScholar": "https://scholar.google.co.in/citations?user=s3vTRA0AAAAJ",
      "orcid": "0000-0003-1861-4580",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57189893950",
      "vidwan": "https://vitap.irins.org/profile/257310"
    }
  },
  {
    "id": "vitap-1302-cms",
    "name": "Dr. Arpana Venu",
    "employeeId": "14.70408",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "307-C, AB-2",
    "email": "arpana.venu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70408_Dr_Arpana_Venu_VISH_1301_12f04334fc.avif",
    "education": [
      "BA English Language & Literature, Bharathiar University",
      "MA English Language &Literature, Sree Sankaracharya University of Sanskrit",
      "PhD English, Amrita Viswa Vidyapeetham, Kochi Campus"
    ],
    "researchArea": "Travel Writing, South-Asian Travel Writing, Translation Studies, Queer Studies, Film Studies",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/arpana-venu/"
    }
  },
  {
    "id": "vitap-1227-cms",
    "name": "Mr. Avin Tiwari",
    "employeeId": "14.70413",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "415-C, AB-2",
    "email": "avin.tiwari@vitap.ac.in",
    "phone": "5827",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70413_Mr_Avin_Tiwari_VSL_1389_1b2625015b.avif",
    "education": [
      "University of Delhi",
      "University of North Bengal",
      "Indian Institute of Technology Kharagpur"
    ],
    "researchArea": "Corporate Law",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://in.linkedin.com/in/avin-tiwari-307715249",
      "researchGate": "https://www.researchgate.net/profile/At-Tt-3",
      "googleScholar": "https://scholar.google.com/citations?user=U-CgLHkAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57217833512"
    }
  },
  {
    "id": "vitap-1426-cms",
    "name": "Dr. Arun Kumar Yadav",
    "employeeId": "14.70441",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "320-C, AB-2",
    "email": "arun.yadav@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Arun_Kumar_Yadav_SAS_0882_cc6feb0927.avif",
    "education": [
      "B.Sc. Dr. R M L Avadh Uiniversity Faizabad",
      "M.Sc. Banaras Hindu University Varanasi",
      "Ph.D. Indian Institute of Technology(ISM) Dhanbad"
    ],
    "researchArea": "Orbital Mechanics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-arun-yadav-047986113/",
      "researchGate": "https://www.researchgate.net/profile/Arun-Yadav-35",
      "googleScholar": "https://scholar.google.com/citations?user=VtlkNG8AAAAJ&hl=en",
      "vidwan": "https://vidwan.inflibnet.ac.in/myprofile"
    }
  },
  {
    "id": "vitap-1467-cms",
    "name": "Dr. U M Gopal Krishna",
    "employeeId": "14.70481",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "410 , AB-1",
    "email": "gopalkrishna.um@vitap.ac.in",
    "phone": "5892",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_U_M_Gopal_Krishna_70481_0454_c701dc12eb.avif",
    "education": [
      "Srikrishnadevaraya University, Anathapuramu.",
      "Srikrishnadevaraya University, Anathapuramu.",
      "(Ph.D Fianance) Jawaharlal Nehru Technological University Anantapuram"
    ],
    "researchArea": "Financial Accounting, Financial Mangement, Investment Analysis and Portfolio Management, Financial Markets, Business Analytics, Data Analysis using SPSS, Tableau",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-u-m-gopal-krishna-50aa3b123/",
      "googleScholar": "https://scholar.google.com/citations?user=QHyfSE4AAAAJ&hl=en",
      "orcid": "0000-0002-2536-3962",
      "scopus": "57210730801"
    }
  },
  {
    "id": "vitap-1342-cms",
    "name": "Dr. Karishma Bisht",
    "employeeId": "14.7049",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "124-I, AB-2",
    "email": "karishma.b@vitap.ac.in",
    "phone": "5613",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Karishma_Bisht_70490_IMG_2643_VISH_20e82a5f6a.avif",
    "education": [
      "B.Sc FAD - Army Institute of Fashion and Design, Bangalore. Masters - Isabella Thoburn College, Lucknow",
      "Gurukula Kangri University, Haridwar"
    ],
    "researchArea": "Literature and Psychology, Indian Aesthetics, Literary Theory, World Literature, Disablity Studies.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-karishma-bisht-6303b35b",
      "orcid": "0000-0003-0458-9791"
    }
  },
  {
    "id": "vitap-1444-cms",
    "name": "Dr. Vasili B V Nagarjuna",
    "employeeId": "14.70508",
    "designation": "Assistant professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "207 - H, AB-2",
    "email": "nagarjuna.vasili@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vasili_B_V_Nagarjuna_SAS_0777_f8dbf4cc9b.avif",
    "education": [
      "B.Sc (Statistics) and Acharya Nagarjuna University",
      "M.Sc (Statistics) & Sri Venkateswara University",
      "Ph.D.(Statistics)& Pondicherry University"
    ],
    "researchArea": "Distribution Theory, Statistical Quality Control, Statistical Inference, Operations Research and Applied Statistics.",
    "memberships": [
      "ISPS- Life member, SSCA- Life member"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Indian Society for Probability and Statistics- Young Statistician,2019",
      "Prof. Jayaraman Sethu Raman Gold Medal, 2019."
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Vasili-B-V-Nagarjuna-2",
      "googleScholar": "https://scholar.google.com/citations?user=A4hyd70AAAAJ&hl=en&oi=sra",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58055902800",
      "vidwan": "https://vitap.irins.org/profile/301699"
    }
  },
  {
    "id": "vitap-1454-cms",
    "name": "Dr. K. Panduranga",
    "employeeId": "14.7052",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "819 - K, CB",
    "email": "panduranga.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_K_Panduranga_SAS_0892_378adffc47.avif",
    "education": [
      "BSC, Andhra University",
      "MSC Applied Mathematics, NIT-Warangal",
      "Mathematics, BITS-Pilani"
    ],
    "researchArea": "Coastal Hydrodynamics, Boundary Element Analysis, and Machine Learning",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Kottala-Panduranga",
      "googleScholar": "https://scholar.google.com/citations?view_op=list_works&hl=en&hl=en&user=isyDp9UAAAAJ",
      "orcid": "0000-0002-3928-8385",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57216299518",
      "vidwan": "354905"
    }
  },
  {
    "id": "vitap-1463-cms",
    "name": "Dr.Santanu Nandi",
    "employeeId": "14.70534",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "623-E, CB",
    "email": "santanu.nandi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Santanu_Nandi_SAS_0988_f46baac9db.avif",
    "education": [
      "B.Sc, Mathematics, Calcutta University",
      "M.Sc. TIFR, Bangalore",
      "Ph.D. Graduate Center, CUNY, USA"
    ],
    "researchArea": "Complex Dynamical System, Fractals",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "http://www.linkedin.com/in/santanu-nandi-089445116"
    }
  },
  {
    "id": "vitap-1230-cms",
    "name": "Ms. Kirtika Sahu",
    "employeeId": "14.70536",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "415-B, AB-2",
    "email": "kirtika.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70536_Ms_Kirtika_Sahu_VSL_1397_6f1674d9ec.avif",
    "education": [
      "B.A.LL.B. (Hons.), Dr. RMLNLU, Lucknow",
      "LL.M., Dr. RMLNLU, Lucknow",
      "CSJM University, Kanpur",
      "Constitutional law"
    ],
    "researchArea": "Constitutional & Administrative Law, Cyber Law",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1468-cms",
    "name": "Dr. Gokulnath",
    "employeeId": "14.70554",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "125-N, AB-2",
    "email": "gokulnath@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Gokulnath_SAS_1006_f24e70eeaf.avif",
    "education": [
      "M.Sc. (Integrated) Mathematics & Pondicherry University",
      "M.Sc. (Integrated) Mathematics & Pondicherry University",
      "Ph. D. Mathematics & Pondicherry University"
    ],
    "researchArea": "Graph Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Lectureship (NET), CSIR-UGC and 2015",
      "Springer Best Student Paper Presentation Award, 5th Annual International Conference on Algorithms and Discrete Applied Mathematics in IIT, Khragpur and 2019"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Gokulnath-M",
      "googleScholar": "http://scholar.google.co.in/citations?user=lRGXFbcAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57200652638",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/365266"
    }
  },
  {
    "id": "vitap-1360-cms",
    "name": "Dr. Neethu P Antony",
    "employeeId": "14.70555",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "125-A1, AB-2",
    "email": "neethup.antony@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Neethu_P_Antony_VISH_1471_221a3e41ae.avif",
    "education": [
      "BA English Language& Literature-University of Kerala",
      "MA English Language & Literature- Mahatma Gandhi University",
      "PhD in English- Mahatma Gandhi University"
    ],
    "researchArea": "Indian Literature, Modern Indian Drama, Gender Studies, SubalternResistance Studies, Communication Studies",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "linkedin.com/in/neethu-p-antony-812010194",
      "googleScholar": "https://scholar.google.com/citations?user=aMGiytEAAAAJ&hl=en&authuser=1",
      "orcid": "https://orcid.org/0000-0001-5394-4978",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/355973"
    }
  },
  {
    "id": "vitap-1377-cms",
    "name": "Dr. Amrita Purakayastha",
    "employeeId": "14.7056",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "124-M, AB-2",
    "email": "amrita.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Amrita_Purakayastha_70560_IMG_4862_VISH_4e546738b9.avif",
    "education": [
      "Triple majors in Economics, Psychology and Sociology, Bangalore University",
      "M.Sc., Bharathiar University",
      "Ph.D. (Economics) from Bharathiar University"
    ],
    "researchArea": "Economics of Human Resources/ Health Economics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Awarded with Gold Medal for securing first rank in Bharathiar University.",
      "Awarded with ICSSR fellowship during Ph.D."
    ],
    "links": {}
  },
  {
    "id": "vitap-1382-cms",
    "name": "Dr. Naveen Kumar Ranjan",
    "employeeId": "14.70561",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "202-C, AB-2",
    "email": "naveen.ranjan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Naveen_Kumar_Ranjan_VISH_3ee2ba7d99.avif",
    "education": [
      "B.A (Hons.)/ Jawaharlal Nehru University (JNU), New Delhi",
      "M.A/ Jawaharlal Nehru University (JNU), New Delhi",
      "Ph.D./ Jawaharlal Nehru University (JNU), New Delhi"
    ],
    "researchArea": "Korean Language Education, Error Analysis, Psychology of Language Learning, Language Learning Strategies, ICT in Language Learning etc.",
    "memberships": [
      "The International Network for Korean Language and Culture (국제한국언어문화학회)"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "‘KLTTP Scholarship Award’ for outstanding performance during the ‘JNU Korean Language Teacher’s Training Program’ organized by Jawaharlal Nehru University, KCCI, Embassy of Republic of Korea in 2022.",
      "‘Sinhan Bank Dream Foundation Award’ for Outstanding performance during M.A program, 2014, Sinhan Bank, New Delhi Branch."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-naveen-k-ranjan-80855694?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app",
      "googleScholar": "https://scholar.google.com/citations?user=3J5ITy8AAAAJ&hl=en",
      "orcid": "https://orcid.org/0009-0009-7982-964X",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/372741"
    }
  },
  {
    "id": "vitap-1240-cms",
    "name": "Ms. Malavika Ganta",
    "employeeId": "14.70566",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "415-I, AB-2",
    "email": "malavika.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70566_Ms_Malavika_Ganta_VSL_1166_788f49cf84.avif",
    "education": [
      "BA, LL.B from the Damodaram Sanjivayya National Law University (DSNLU)",
      "Master Degree in Law LL.M., from Jain University (JGI) Banglore"
    ],
    "researchArea": "Constitutional law, Administrative law, Jurisprudence, Human Rights and Medical Laws",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1472-cms",
    "name": "Dr. Vanacharla Pujitha",
    "employeeId": "14.70569",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "723 - A, CB",
    "email": "pujitha.v@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vanacharla_Pujitha_70569_IMG_2588_SAS_MAT_768ceaef5c.avif",
    "education": [
      "B.Sc.(M.P.C), Acharya Nagarjuna University",
      "M.Sc. Applied Mathematics, NIT Warangal",
      "Ph.D. Mathematics, NIT Warangal"
    ],
    "researchArea": "Biomechanics, CFD, Lubrication, Mathematical modelling, Newtonian/Non-Newtonian fluids",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://l1nk.dev/4hdAc",
      "orcid": "https://orcid.org/0009-0006-9347-8477",
      "scopus": "57205188724",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/445341"
    }
  },
  {
    "id": "vitap-1480-cms",
    "name": "Dr. G.Siva",
    "employeeId": "14.70572",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "225-M, AB-2",
    "email": "siva.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_G_Siva_SAS_0731_be91d02a25.avif",
    "education": [
      "B.Sc. MSCs, Sri Venkateswara University",
      "M.Sc. Statistics, Sri Venkateswara University",
      "Ph.D. Statistics, Pondicherry Central University"
    ],
    "researchArea": "Biostatistics - Classification Techniques and Sampling Theory",
    "memberships": [
      "ISPS-Indian Society for Probability and Statistics; SSCA - Society of Statistics and Computer Applications"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "ISPS Young Statistician Award (Prof. Jayaraman Sethuraman Godl Medal), Indian Society for Probability and Statistics, 2021",
      "Prof. Pagadala Balasiddamuni Gold medal, Sri Venkateswara University, 2023",
      "Prof. M. P. Sastry Gold medal, Sri Venkateswara University, 2023",
      "Prof. C.R. Rao Cash Prize, Sri Venkateswara University, 2023"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-siva-g-5169b7205/",
      "researchGate": "https://www.researchgate.net/profile/Siva-G-2",
      "googleScholar": "https://scholar.google.com/citations?user=jAwWxA0AAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0001-8624-7052",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57831261900",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/338851"
    }
  },
  {
    "id": "vitap-1391-cms",
    "name": "Dr. Linet Thomas",
    "employeeId": "14.70578",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "224-H, AB-2",
    "email": "linet.thomas@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70578_Dr_Linet_Thomas_VISH_1353_47717e6656.avif",
    "education": [
      "Bachelor of Arts, Calicut University",
      "Master of Arts, EFL University",
      "Doctor of Philosophy in Comparative Literature and India Studies, EFL University"
    ],
    "researchArea": "Comparative Literature, Malayalam Literatures in Translation, Gabriel GarcÃ­a MÃ¡rquez, Political Modernist Fictions of Kerala, Latin American Fictions",
    "memberships": [
      "CLAI - Comparative Literature Association of India"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=-VSznRgAAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0003-0057-0516",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/418219/NDE4MjE5"
    }
  },
  {
    "id": "vitap-1488-cms",
    "name": "Dr. Prashant Patel",
    "employeeId": "14.70587",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G23-G, AB-2",
    "email": "prashant.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70587_Dr_Prashant_Patel_SAS_1065_93fd75b131.avif",
    "education": [
      "BSc, CSJMU Kanpur",
      "M.Sc., Visvesvaraya National Institute of Technology (VNIT), Nagpur",
      "PhD, University of Johannesburg",
      "Postdoctoral Research Fellow, University of Johannesburg"
    ],
    "researchArea": "Functional Analysis, Fixed Point Theory",
    "memberships": [
      "1. Life Member of Indian Mathematical Society, 2. Member of South African Mathematical Society"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "CSIR-JRF",
      "CSIR-NET",
      "GATE",
      "IIT-JAM",
      "GES-4IR (University of Johannesburg)",
      "URC-FRC (University of Johannesburg)"
    ],
    "links": {
      "linkedin": "https://in.linkedin.com/in/gundimedavenugopal",
      "researchGate": "https://www.researchgate.net/profile/Prashant-Patel-12?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.co.in/citations?user=IAR23x0AAAAJ&hl=en",
      "orcid": "0000-0003-0438-4366",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57206880694",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/420025"
    }
  },
  {
    "id": "vitap-1496-cms",
    "name": "Dr. Nimai Sarkar",
    "employeeId": "14.70593",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "307-G, AB-2",
    "email": "nimai.s@vitap.ac.in",
    "phone": "5814",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Nimai_Sarkar_SAS_1861_0af1224d5b.avif",
    "education": [
      "BSc-Math, ABN Seal College (North Bengal University)",
      "MSc in Applied Mathematics, Indian Institute of Engineering Science & Technology (IIEST) Shibpur",
      "PhD, National Institute of Technology (NIT) Silchar"
    ],
    "researchArea": "Qualitative study on Integral and Integro differential Equations, FPT",
    "memberships": [
      "AAM"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Inspire award (2012) by DST, Govt. of India, NET (AIR 27) Conducted by CSIR, 2019; GATE 2019, 2020"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=B7RYoXIAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57216811960",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/439676/NDM5Njc2"
    }
  },
  {
    "id": "vitap-1404-cms",
    "name": "Dr. Ashraf Pulikkamath",
    "employeeId": "14.70594",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "225-J, AB-2",
    "email": "ashraf.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ashraf_Pulikkamath_VISH_1431_dffb24173a.avif",
    "education": [
      "BBM, Bharathiar University",
      "MA Econometrics, University of Madras",
      "PhD, University of Madras"
    ],
    "researchArea": "Gender Economics, Gender Budget, Fiscal Policy, Development Economics, Development Studies",
    "memberships": [
      "(1) World Economics Association, UK (2) Development Studies Association, UK (3) Kerala Economic Association, India (4) Indian Association of Women Studies, India (5) Indian Commerce Association, India"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "JAPAN-EAST ASIA NETWORK OF EXCHANGE FOR STUDENTS AND YOUTHS (2016) FELLOWSHIP – 2017, Ministry of Foreign Affairs, Government of Japan, Tokyo, 2017"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/ashrafpulikkamath/",
      "googleScholar": "0000-0003-0292-9529",
      "orcid": "0000-0003-0292-9529",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/407844"
    }
  },
  {
    "id": "vitap-1414-cms",
    "name": "Dr. Ritu Varghese",
    "employeeId": "14.70597",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "207 - F, AB-2",
    "email": "ritu.v@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ritu_Varghese_70597_IMG_4711_VISH_2f6255bfc7.avif",
    "education": [
      "B.A. Honours in English Literature, University Maharani's College, University of Rajasthan (Rajasthan)",
      "M.A. in English, University of Rajasthan (Rajasthan)",
      "Ph.D., National Institute of Technology Rourkela, Odisha"
    ],
    "researchArea": "English Literature, Religion and Theology, Cultural Studies, Hindu Studies, Bhakti Literature, Modern Indian Historiography",
    "memberships": [
      "1. Indian Network for Memory Studies, IIT Madras, India 2. Religion in Society Research Network, University of Illinois"
    ],
    "projects": [
      "1. Research Assistant (November 2019–October 2020), Project titled “Restoring the Sacred in Public Spheres” sponsored by Indian Council of Social Science Research (ICSSR), New Delhi, India.",
      "2. Research Investigator (February–March 2016), National Project on “Governance and Management of Higher Education in India” conducted by the Centre for Policy Research in Higher Education (CPRHE), National University of Education, Planning and Administration (NUEPA), funded by Ministry of Human Resource Development, New Delhi, India."
    ],
    "patents": [],
    "awards": [
      "Isaac Sequeira Memorial (ISM) Award for Best Paper Presented by a Young Scholar (27-29 September 2024) the 25th International Melus MELOW conference held at Kathmandu University, Nepal.",
      "Dr. S.B. Mathur Memorial Gold Medal (2013–14) awarded for securing the highest aggregate marks in English Literature (Honours) by University Maharani’s College, University of Rajasthan, Jaipur.",
      "Certificate of Merit (2011) awarded for outstanding academic performance and for being among the top 0.1 percent of successful candidates in Political Science of All India Senior School Certificate Examination 2011, Central Board of Secondary Education, New Delhi, India.",
      "Gargi Puraskar (2009) awarded for meritorious academic performance in matriculation by Balika Shiksha Foundation, Jaipur (Rajasthan) accompanied with scholarship sponsored by the Government of Rajasthan."
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/ritu-varghese08",
      "googleScholar": "https://scholar.google.com/citations?user=pem-lGQAAAAJ&hl=en&authuser=4",
      "orcid": "https://orcid.org/0000-0001-7124-6161",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57490464900",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/407795"
    }
  },
  {
    "id": "vitap-1499-cms",
    "name": "Dr. Anshul Gopal",
    "employeeId": "14.70606",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": null,
    "email": "anshul.gopal@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Anshul_Gopal_70606_0244_f3742e31b5.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1462-cms",
    "name": "Dr. Rajashree Naik",
    "employeeId": "14.70612",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "225-G, AB-2",
    "email": "rajashree.naik@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rajashree_Naik_SAS_Chem_1942_1d88309d58.avif",
    "education": [
      "B.Sc., Sambalpur University",
      "M.Sc, Central University of Rajasthan",
      "Ph.D, Central University of Rajasthan"
    ],
    "researchArea": "Environmental Chemistry, Remote Sensing and Geographic Information System, Climate Change, Sustainable Development Goals",
    "memberships": [
      "British Ecological Society, Society of Wetland Scientists, International Society of Limnology"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Training and Travel Grant 2020 award by British Ecological Society",
      "Received Student Registration Grant 2021 by Ecological Society of America",
      "Received Wetzel Award 2022 by International Society of Limnology, Germany"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-rajashree-naik-93ab3a142/",
      "researchGate": "https://www.researchgate.net/profile/Rajashree-Naik-2?ev=hdr_xprf",
      "googleScholar": "http://tinyurl.com/4bn62w97",
      "orcid": "0000-0002-8303-0015",
      "scopus": "57223346198",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/430490"
    }
  },
  {
    "id": "vitap-1501-cms",
    "name": "Dr. Prakash S",
    "employeeId": "14.70613",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "124-D, AB-2",
    "email": "prakash.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70613_Dr_Prakash_S_MAT_1283_93045c8d7b.avif",
    "education": [
      "B.Sc. Mathematics, Bharathiar University",
      "M.Sc., Mathematics, Pondicherry University",
      "Ph.D., Mathematics., Pondicherry University"
    ],
    "researchArea": "Hydrodynamic Stability",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57222530423",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/445953"
    }
  },
  {
    "id": "vitap-1490-cms",
    "name": "Dr. Senthamizhselvi A",
    "employeeId": "14.7062",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "329-G, AB-1",
    "email": "senthamizhselvi.a@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Senthamizhselvi_A_VSB_0998_ad1b622247.avif",
    "education": [
      "BBA(Auxilium College- Thiruvalluvar University)",
      "MBA (Finance&Marketing) Velammal Institute of Technology, Chennai(Anna University)",
      "Ph.D- Behavioural Finance (Vellore Institute of Technology- Vellore)"
    ],
    "researchArea": "Finance, Investment Management, Financial Markets, Financial Management, Managerial Economics and Business Research Methods.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-senthamizhselvi -a-0417676b/",
      "orcid": "https://orcid.org/0000-0002-6008-124X"
    }
  },
  {
    "id": "vitap-1493-cms",
    "name": "Dr. Umer Mushtaq Lone",
    "employeeId": "14.70636",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "425-B, AB-1",
    "email": "umermushtaq.lone@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Umer_Mushtaq_Lone_VSB_0769_9d40d45f26.avif",
    "education": [
      "BBA (Bachelor of Business Administration) from University of Kashmir",
      "MFC (Master of Finance and Control) from University of Kashmir; M.Com and PGDIBOs from IGNOU",
      "Ph.D. from University of Kashmir"
    ],
    "researchArea": "Accounting, Corporate Finance, Investment Management, Financial Markets and Financial Risk Management",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/umer-mushtaq-lone-ba726529/",
      "researchGate": "https://www.researchgate.net/profile/Umer-Lone",
      "googleScholar": "https://scholar.google.com/citations?user=g-3ntRgAAAAJ&hl=en",
      "orcid": "0000-0002-0400-5189",
      "scopus": "AAZ-7121-2021"
    }
  },
  {
    "id": "vitap-1502-cms",
    "name": "Dr. Soumik Sarkar",
    "employeeId": "14.70644",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "224-D, AB-2",
    "email": "soumik.sarkar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Soumik_Sarkar_VISH_1435_c7d309c549.avif",
    "education": [
      "B.Sc (Hons.) in Economics, Asutosh College, University of Calcutta",
      "M.Sc in Economics, University of Calcutta",
      "PhD in Economics, University of Calcutta"
    ],
    "researchArea": "Macroeconomics, Development Economics, Globalization, Political Economy, History of Economic Ideas, International Trade",
    "memberships": [
      "Life Member, Indian Political Economy Association"
    ],
    "projects": [
      "“The Dream of Owning a Home- How does PM Awas Yojana (Urban) Change the Quality of Life of the Needy?”, sponsored by Indian Council of Social Science Research (ICSSR), September 2023- March 2024"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/soumik-sarkar-7b623462/",
      "researchGate": "https://www.researchgate.net/profile/Soumik-Sarkar-6",
      "googleScholar": "https://scholar.google.com/citations?view_op=list_works&hl=en&user=ArMwR3QAAAAJ&gmla=AKKJWFfjVii-EixXh6wKxDpIbpx0ph_dE9qqu3202Joe4eIyC66DP3xuMAtJBhcHKseNaE7YSmev3t4LdgrxTBX6htxFXVbAhoHQLTQGgy5iGSIoAA",
      "orcid": "https://orcid.org/0000-0002-2613-5291",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57225937265",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/286265"
    }
  },
  {
    "id": "vitap-1518-cms",
    "name": "Dr. Mo Faheem",
    "employeeId": "14.70658",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "125-M, AB-2",
    "email": "faheem.mo@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Mo_Faheem_f6c706e8a7.avif",
    "education": [
      "B.Sc., Chaudhary Charan Singh University Meerut",
      "M.Sc., Jamia Millia Islamia New Delhi",
      "Ph.D., Jamia Millia Islamia New Delhi",
      "Research Associate, Indian Institute of Technology Indore"
    ],
    "researchArea": "Numerical Analysis, Wavelets, Mathematical Biology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Gold Model (M.Sc.), Jamia Millia Islamia, 2018",
      "INSPIRE-SHE (Scholarship for Higher Education), DST-Govt. of India, 2014"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/m-faheem-sayyed-b747b1316/",
      "researchGate": "https://www.researchgate.net/profile/Mo-Faheem",
      "googleScholar": "https://scholar.google.com/citations?user=zD84e9gAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57220454984"
    }
  },
  {
    "id": "vitap-1530-cms",
    "name": "Dr. S. V. Gomathi",
    "employeeId": "14.70663",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "325-C, AB-2",
    "email": "gomathi.sv@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_S_V_Gomathi_SAS_1858_4e714dcab7.avif",
    "education": [
      "Bsc (Maths)& University of Madras",
      "Msc(Maths) & Thiruvalluvar Universiti",
      "Ph.D(Maths) & VIT(Vellore Campus)"
    ],
    "researchArea": "Operation Research",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Gomathi-S-V",
      "googleScholar": "https://scholar.google.com/citations?user=ju5MiPAAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57216550474",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/544007"
    }
  },
  {
    "id": "vitap-1533-cms",
    "name": "Mr. Sidhant Gupta",
    "employeeId": "14.70664",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "415-F, AB-2",
    "email": "sidhant.gupta@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Sidhant_Gupta_VSL_1927_b0fb395696.avif",
    "education": [
      "LL.B.- Panjab University, Chandigarh",
      "LL.M.- Corporate & Business Law- Gujarat National Law University, Gandhinagar",
      "Ph.D.- Himachal Pradesh National Law University, Shimla"
    ],
    "researchArea": "1. Animal Welfare Legislations in India and across globe, 2. Arbitration, Conciliation and Mediation Laws, 3. Emerging Technologies and its use case in Legal field, 4. Indian Contract Act, Special Contract Law and Advanced Contracts- Evolving Jurisprudence in Contract Laws, 5. Insolvency and Bankruptcy Code",
    "memberships": [
      "1. Indian National Association of Legal Professionals (INLAP), 2. People for Animals, India (PFA)"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/sidhant11233/"
    }
  },
  {
    "id": "vitap-1532-cms",
    "name": "Dr. Amrendra Singh Gill",
    "employeeId": "14.70665",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "325-F, AB-2",
    "email": "amrendra.gill@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Amrendra_Singh_Gill_SAS_MAT_1897_887f4b7bbb.avif",
    "education": [
      "BSc.(H) Mathematics, Delhi University",
      "MSc. Mathematics, Delhi University",
      "Ph.D. IIT Ropar",
      "HRI Prayagraj"
    ],
    "researchArea": "Knot Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Amrendra-Gill/publications",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=tdNZ_40AAAAJ&view_op=list_works&authuser=1&sortby=pubdate",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57205729080"
    }
  },
  {
    "id": "vitap-1558-cms",
    "name": "Dr. Narendra Kumar",
    "employeeId": "14.70693",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "310-A, AB-1",
    "email": "narendrakumar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Narendra_Kumar_SAS_7aca0995ac.avif",
    "education": [
      "B.Sc. & University of Lucknow, Lucknow",
      "M.Sc. & Banaras Hindu University, Varanasi",
      "Ph.D. & Indian Institute of Technology (ISM), Dhanbad",
      "Post Doctoral Fellow & Indian Institute Of Science, Bangalore"
    ],
    "researchArea": "Algebraic Coding Theory, DNA Data Based Storage",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Young Researcher Award, Institute of Scholars, 2022"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-narendra-kumar-verma-781b17140/",
      "researchGate": "https://www.researchgate.net/profile/Narendra-Kumar-20?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=6hYcBlgAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57225849890"
    }
  },
  {
    "id": "vitap-1564-cms",
    "name": "Dr. Subhankar Sil",
    "employeeId": "14.70701",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "109, AB-1",
    "email": "subhankar.sil@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Subhankar_Sil_SASMAT_IMG_2151_76edea2d48.avif",
    "education": [
      "B.Sc. Mathematics, Vivekananda Mahavidyalaya under The University of Burdwan",
      "M.Sc. Mathematics, Indian Institute of Technology Kharagpur, Kharagpur, India",
      "Ph.D. Mathematics, Indian Institute of Technology Kharagpur, Kharagpur, India",
      "Institute Postdoctoral Fellow, Department of Mathematics, Indian Institute of Technology Madras; Postdoctoral Fellow, Department of Mathematics, University of British Columbia, Vancouver, Canada"
    ],
    "researchArea": "Symmetry analysis of Differential Equations, Conservation laws, Nonlinear PDEs, Nonlocal symmetry analysis",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/subhankar-sil-a274b5118",
      "researchGate": "https://www.researchgate.net/profile/Subhankar-Sil-3",
      "googleScholar": "https://scholar.google.co.in/citations?user=bSGa25EAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57217195379"
    }
  },
  {
    "id": "vitap-1614-cms",
    "name": "Dr. Swatilekha Sen",
    "employeeId": "14.7075",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "622 - D, CB",
    "email": "swatilekha.sen@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Swatilekha_Sen_VISH_IMG_8156_071220b333.avif",
    "education": [
      "B.A (Hons) in Geography, The University of Burdwan",
      "M.A in Geography, The University of Burdwan",
      "Ph.D in Geography, The University of Burdwan"
    ],
    "researchArea": "Environmental Humanities, Urban studies, Gender issues, Livelihood studies",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1627-cms",
    "name": "Dr. Vivek Shukla",
    "employeeId": "14.70755",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": null,
    "email": "vivek.shukla@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vivek_Shukla_SAS_IMG_8192_7482593b82.avif",
    "education": [
      "B.Sc.- Dr. R.M.L. Avadh University, Ayodhya, India",
      "M.Sc. - University of Allahabad, Prayagraj, India",
      "Ph.D. - Banaras Hindu University, Varanasi, India, Post-Doc.- Korea Institute of Science and Technology, South Korea",
      "Post-Doc.- Korea Institute of Science and Technology, South Korea"
    ],
    "researchArea": "Materials for Sustainable Technologies, Nanomaterials, Hydrogen Storage, Hydrogen Production, CO2 Capture and Storage",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-vivek-shukla-a1157479/",
      "researchGate": "https://www.researchgate.net/profile/Vivek-Shukla?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=Kx9Ww0MAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1629-cms",
    "name": "Dr. Koteswara Rao Gorantla",
    "employeeId": "14.70757",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "103 - D, CB",
    "email": "koteswarao.gorantla@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Koteswara_Rao_Gorantla_SAS_IMG_8194_97b25debb2.avif",
    "education": [
      "B. Sc (Maths, Physics, Chemistry) -Acharaya Nagarjuna University",
      "M.Sc (Analytical Chemistry) NIT Warangal",
      "Ph.D. (Computational Chemistry) IIT Hyderabad , Research Associate - Michigan Technological University",
      "Research Associate - Michigan Technological University"
    ],
    "researchArea": "Computational Chemistry - Ab initio molecular dynamics, QM/MM, DFT and Metadynamics for understanding the catalytic mechanistic process of inorganic complexes and metalloenzymes",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/koteswararao-gorantla-57809a22b/",
      "googleScholar": "https://scholar.google.com/citations?user=vOD_oMAAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57202754224"
    }
  },
  {
    "id": "vitap-1630-cms",
    "name": "Dr. Abhik Digar",
    "employeeId": "14.70758",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "618 - K , CB",
    "email": "abhik.digar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Abhik_Digar_SAS_IMG_8178_6c3d3b8956.avif",
    "education": [
      "B.Sc., The University of Burdwan",
      "Indian Institute of Technology Hyderabad",
      "1) Ph. D., Indian Institute of Technology Ropar, 2) Visiting Scientist, Indian Statistical Institute, Bangalore center, 3) Post Doctoral Fellow, Indian Institute of Technology Kanpur",
      "(1) Visiting Scientist, Indian Statistical Institute, Bangalore center (2) Post Doctoral Fellow, Indian Institute of Technology Kanpur"
    ],
    "researchArea": "Functional Analysis, Optimization, Fixed Point Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=xwHYOUwAAAAJ&hl=en&oi=ao"
    }
  },
  {
    "id": "vitap-1634-cms",
    "name": "Dr. Saikat Roy",
    "employeeId": "14.70769",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "818 - B, Central Block",
    "email": "saikat.roy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Saikat_Roy_SASMAT_IMG_8177_6b8c1b83b1.avif",
    "education": [
      "B.Sc, University of Calcutta",
      "M.Sc, University of Calcutta",
      "National Institute of Technology Durgapur, IIT Bombay, TUS Tokyo, IISC Bangalore",
      "IIT Bombay, TUS Tokyo, IISC Bangalore"
    ],
    "researchArea": "Banach space Geometry, Operator Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Saikat-Roy-10/research",
      "googleScholar": "https://scholar.google.com/citations?user=2lvmPB8AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57216459312"
    }
  },
  {
    "id": "vitap-1636-cms",
    "name": "Dr. Jyotirmoy Roy",
    "employeeId": "14.70771",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "818 - D, CB",
    "email": "jyotirmoy.roy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Jyotirmoy_Roy_SASMAT_IMG_8173_b5943c4ebd.avif",
    "education": [
      "University of Calcutta",
      "Indian Institute of Engineering Science and Technology, Shibpur",
      "Indian Institute of Engineering Science and Technology, Shibpur, Indian Institute of Technology Kanpur",
      "Indian Institute of Technology Kanpur"
    ],
    "researchArea": "Dynamical Systems, Mathematical Ecology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Inspire Fellowship"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=LNS4fZ8AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1638-cms",
    "name": "Dr. Srabani Chakraborty",
    "employeeId": "14.70773",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "207- D, AB-2",
    "email": "srabani.chakraborty@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Srabani_Chakraborty_VISH_IMG_8195_84ae052c65.avif",
    "education": [
      "Jadavapur University (2010)",
      "Jadavpur University (2012)",
      "Jawaharlal Nehru University (2022)"
    ],
    "researchArea": "Early Medieval India",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "scopus": "DOI:10.1177/23484489211041139"
    }
  },
  {
    "id": "vitap-1644-cms",
    "name": "Dr. Santi Ranjan Das",
    "employeeId": "14.70779",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "619-G, CB",
    "email": "santiranjan.das@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Santi_Ranjan_Das_SASMAT_IMG_8175_6b41f8a3a9.avif",
    "education": [
      "B.Sc Honours (Haldia Government College)",
      "M.Sc Mathematics (IIT Madras)",
      "Ph.D Mathematics (IIT Madras), Postdoc (NISER Bhubaneswar)",
      "Postdoc (NISER Bhubaneswar)"
    ],
    "researchArea": "Harmonic Analysis",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/feed/?trk=guest_homepage-basic_google-one-tap-submit",
      "researchGate": "https://www.researchgate.net/profile/Santi-Das?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=KMWMPRUAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57220984602"
    }
  },
  {
    "id": "vitap-1683-cms",
    "name": "Dr. Sowndarrajan P T",
    "employeeId": "14.70819",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "424-H, AB-1",
    "email": "sowndarrajan.pt@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sowndarrajan_P_T_SASMAT_7ab86b3763.avif",
    "education": [
      "B.Sc. (Mathematics), Bharathiar University",
      "M.Sc. (Mathematics), Bharathiar University",
      "P.hD. (Mathematics), National Institute of Technology Goa"
    ],
    "researchArea": "Mathematical Biology, Dynamical Systems, Partial Differential Equations",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "linkedin.com/in/sowndarrajan-p-t-phd",
      "researchGate": "https://www.researchgate.net/profile/Sowndarrajan-P-T?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=m3C0LHsAAAAJ"
    }
  },
  {
    "id": "vitap-1715-cms",
    "name": "Dr. Soumyadeep Chakraborty",
    "employeeId": "14.70852",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "124-A1, AB-2",
    "email": "soumyadeep.chakraborty@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_SOUMYADEEP_CHAKRABORTY_VISH_7cc4520a3c.avif",
    "education": [
      "B.A. (English Honours), Vidyasagar University",
      "M.A. in English, Vidyasagar University",
      "Ph.D., Bankura University"
    ],
    "researchArea": "Children's Literature, Popular Literature and Culture & Environmental Humanities",
    "memberships": [
      "1. Life member of the Shakespeare Society of India 2. Life Member and the Executive Council Member (ECM) of the Southern Region of West Bengal of the Ecosophical Foundation for the Study of Literature and Environment (EFSLE) 3. Member of the Association of Anglophone Postcolonial Studies (GAPS) 4. Member of the Association for Children's Literature in South Asia (ACLiSA) 5. Member of the Midnapore Film Society (Affiliated to the Federation of Film Societies of Eastern India)"
    ],
    "projects": [
      "ICSSR-Major Research Project on PVTGs, Indian Council of Social Science Research (New Delhi, Delhi, IN)"
    ],
    "patents": [],
    "awards": [
      "GAPS Research Grant, The Association for Anglophone Postcolonial Studies (GAPS), Germany, 2024",
      "Bursary Award for Research Excellence, The School of Arts, English and Languages, Queen’s University, Belfast, Ireland, the UK, 2019"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/soumyadeep-chakraborty-7719b040a/",
      "researchGate": "https://www.researchgate.net/profile/Soumyadeep-Chakraborty-7",
      "googleScholar": "https://scholar.google.com/citations?hl=en&authuser=2&user=SJ6T5xIAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=60145196200",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/705906"
    }
  },
  {
    "id": "vitap-1721-cms",
    "name": "Dr. Maneesh P",
    "employeeId": "14.70859",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "124-J, AB2",
    "email": "maneesh.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_MANEESH_P_VISH_7169814ebf.avif",
    "education": [
      "BA Economics- Kannur University, Kerala",
      "MA Applied Economics- Kannur University, Kerala; M.Phil in Economics - The Gandhigram Rural Institute-Deemed to be University, Tamil Nadu",
      "Ph.D in Economics - Madurai Kamaraj University, Tamil Nadu"
    ],
    "researchArea": "Refugee Studies, Livelihood Studies, Rural Transformation, Digital Society and Technology Adoption, Development Policy and Governance",
    "memberships": [],
    "projects": [
      "Integration of Digital Technologies for Transforming Rural Occupational and Livelihood Diversification Strategies in South India, Indian Council of Social Science Research (ICSSR)"
    ],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/maneesh-p-1b2a27148/",
      "researchGate": "https://www.researchgate.net/profile/Maneesh-p?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=fOokynIAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57225922276",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/391524"
    }
  },
  {
    "id": "vitap-1766-cms",
    "name": "Dr. Rohit Verma",
    "employeeId": "14.70902",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "812-H, CB",
    "email": "rohit.verma@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Rohit_Verma_SASMAT_4f7928f43a.avif",
    "education": [
      "BSc. , Ch. Charan Singh University Meerut",
      "M.Sc. Mathematics and Scientific Computing, National Institute of Technology Allahabad",
      "PhD in Mathematics, National Institute of Technology Surat, Mathematics, Indian Institute of Technology Guwahati",
      "Mathematics, Indian Institute of Technology Guwahati"
    ],
    "researchArea": "Computational Mathematics and Numerical Simulations",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Young Researcher Award in ICPS-2021 Conference.",
      "Full Financial Assistance by Hong kong Baptist University, Hong Kong for Article presentation in the conference Modern Kernel Methods and Applications.",
      "Institute Postdoctoral research Fellowship (IPDF) by IIT Guwahati.",
      "Financial Assistance from Science and Enginnering Research Board (SERB), Department of Science & Technology (DST) under the International Travel Grant Scheme for Article presentation in ICNAAM conference, Heraklion, Crete, Greece. (File no: ITS/2022/001981).",
      "Qualified CSIR-JRF(NET)(Mathematical Sciences), June 2022. 6. Qualified CSIR-NET(Mathematical Sciences), June 2017"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-rohit-verma-857216101/",
      "researchGate": "https://www.researchgate.net/profile/Rohit-Verma-13?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=UbpWvZIAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/pages/authors/57205488734",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/503945"
    }
  },
  {
    "id": "vitap-1783-cms",
    "name": "Dr. Abdul Mohsin",
    "employeeId": "14.70921",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "623-H, CB",
    "email": "abdul.mohsin@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Abdul_Mohsin_VISH_05719bf5e1.avif",
    "education": [
      "B.A, University of Kashmir",
      "M.A. Political Science, Aligarh Muslim University",
      "Ph.D. in Political Science, Aligarh Muslim University, Postdoctoral Research Fellow, Institute of Eminence (IoE), University of Hyderabad",
      "Postdoctoral Research Fellow, Institute of Eminence (IoE), University of Hyderabad"
    ],
    "researchArea": "Digital Governance, Welfare Politics, Social Policy, and State–Society Relations",
    "memberships": [
      "UNESCO Inclusive Policy Lab"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "International Conference Grant (₹1,00,000), Institute of Eminence, University of Hyderabad, 2024.",
      "Maulana Azad National Fellowship (MANF JRF), Ministry of Minority Affairs, Government of India, 2019.",
      "Institute of Eminence Postdoctoral Fellowship, University of Hyderabad, 2023."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/abdul-mohsin-62b3b8311/",
      "researchGate": "https://www.researchgate.net/profile/Abdul-Mohsin-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=fHtP_tAAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57949897100"
    }
  },
  {
    "id": "vitap-1790-cms",
    "name": "Dr. Bihalan Bhattacharya",
    "employeeId": "14.70926",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "1013-B, CB",
    "email": "bihalan.bhattacharya@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bihalan_Bhattacharya_SASMAT_2d9956a78b.avif",
    "education": [
      "B.Sc. (Hons.) in Mathematics , St. Xavier's College (Autonomous) under University of Calcutta",
      "M.Sc. in Mathematics and Computing, Indian School of Mines",
      "Ph.D. in Applied Mathematics, S. N. Bose National Centre for Basic Sciences (University of Calcutta), International Institute of Information Technology (IIIT), Hyderabad; Nicolaus Copernicus University in Torun, Poland; Indian Institute of Science Education and Research (IISER), Berhampur",
      "International Institute of Information Technology (IIIT), Hyderabad; Nicolaus Copernicus University in Torun, Poland; Indian Institute of Science Education and Research (IISER), Berhampur"
    ],
    "researchArea": "Mathematical Foundations of Quantum Science and Technology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Grant for Researchers from Abroad at the Faculty of Physics",
      "University Centre of Excellence \"Dynamics, Mathematical Analysis and Artificial Intelligence\"",
      "Nicolaus Copernicus University in Torun, Poland"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=8RvwBSoAAAAJ&view_op=list_works"
    }
  },
  {
    "id": "vitap-1813-cms",
    "name": "Dr. Divya Singh",
    "employeeId": "14.70955",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "1016-I, CB",
    "email": "divya.singh@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Divya_Singh_SASCHY_7c5ffada1a.avif",
    "education": [
      "B.Sc (Hons.) Chemistry; Banaras Hindu University",
      "M.Sc Chemistry; Banaras Hindu University",
      "PhD; Indian Institute of Science Education and Research (IISER) Pune, Post Doctoral Research Fellow; Tel Aviv University Israel",
      "Post Doctoral Research Fellow; Tel Aviv University Israel"
    ],
    "researchArea": "Theoretical Physical Chemistry; Chemical Physics; Non-Equilibrium Statistical Mechanics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=Uc1qbucAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1820-cms",
    "name": "Dr. Sarasija Das",
    "employeeId": "14.70962",
    "designation": "Assistant Professor Grade 2",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Chemistry",
    "office": "1017-I, CB",
    "email": "sarasija.das@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sarasija_Das_SASCHE_92cd70181e.avif",
    "education": [
      "BSc (Honours in Chemistry), University of North Bengal",
      "MS, IISER Kolkata",
      "1. Ph.D, IISER Kolkata, 2. Postdoctoral Scholar, The Ohio State University, USA 3. Project Scientist I, IISc Bangalore, India",
      "(1) Postdoctoral Scholar, The Ohio State University, USA (2) Project Scientist I, IISc Bangalore, India"
    ],
    "researchArea": "Functional Organic Materials",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=87dXaWMAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1261-cms",
    "name": "Dr. Pragya Sengupta",
    "employeeId": "15.70086",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "620-J, CB",
    "email": "sengupta.pragya@vitap.ac.in",
    "phone": "5697",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pragya_Sengupta_70086_IMG_4882_VISH_aca9e4d604.avif",
    "education": [
      "BA (English), NEHU",
      "MA (English), University of Hyderabad",
      "PhD (Translation Studies), Univerity of Hyderabad"
    ],
    "researchArea": "Translation Studies, Comparative Literature",
    "memberships": [
      "IASS, CLAI"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1281-cms",
    "name": "Dr. Mahi S Thavarathu",
    "employeeId": "15.70368",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": null,
    "email": "mahi.thavarathu@vitap.ac.in",
    "phone": "5987",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Mahi_S_Thavarathu_IMG_6604_VISH_c5b37235d5.avif",
    "education": [
      "BA English, University Of Kerala",
      "MA English, JNU",
      "Ph.D. in English , CES, JNU"
    ],
    "researchArea": "Immigrant Narratives, Ecological Humanities, Contemporary Irish Literature",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1294-cms",
    "name": "Dr. Neelima Adapa",
    "employeeId": "15.70377",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "723 - D, CB",
    "email": "neelima.adapa@vitap.ac.in",
    "phone": "5997",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Neelima_Adapa_IMG_9411_VISH_5341f03d0b.avif",
    "education": [
      "B.A, Andhra University",
      "M.A in English (Language and Literature), Andhra University",
      "PhD in English, Maulana Azad National Urdu University"
    ],
    "researchArea": "Language Variation & Phonetic Analysis of Stuttering",
    "memberships": [
      "ELTAI- English Language Teachers Association of India, ID no. A010250003"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Faculty Award, VITAP University, 2023"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-neelima-adapa-45020561",
      "researchGate": "https://www.researchgate.net/profile/Neelima-Adapa?ev=prf_overview",
      "googleScholar": "https://scholar.google.com/citations?user=ULoqiB8AAAAJ&hl=en",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/259175"
    }
  },
  {
    "id": "vitap-1380-cms",
    "name": "Dr. Archana Tiwari",
    "employeeId": "15.70424",
    "designation": "Assistant Professor Grade I",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "128-D, CB",
    "email": "archana.tiwari@vitap.ac.in",
    "phone": "5838",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Archana_Tiwari_SAS_0848_ac41f1756a.avif",
    "education": [
      "B.Sc Gangadhar Meher (Autonomous) College",
      "M.Sc -NIT Rourkela",
      "Ph.D -NIT Rourkela"
    ],
    "researchArea": "Mathematical Control Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/archana-tiwari-8423b4b4/",
      "researchGate": "https://www.researchgate.net/profile/Archana-Tiwari-11",
      "orcid": "0000-0003-2080-1262",
      "scopus": "57196244346",
      "vidwan": "267307"
    }
  },
  {
    "id": "vitap-1235-cms",
    "name": "Ms. Kshama Pandey",
    "employeeId": "15.70537",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "415-E, AB-2",
    "email": "kshama.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Kshama_Pandey_VSL_0052f4effc.avif",
    "education": [
      "Faculty of Law, Banaras Hindu University",
      "National Law Institute University",
      "Presidency University, Bangalore"
    ],
    "researchArea": "Criminal Law, Constitutional Law, Property Law, Alternative Dispute Resolution, Administrative law.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1466-cms",
    "name": "Dr. Shobhit Kumar Srivastava",
    "employeeId": "15.70552",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "325-G, AB-2",
    "email": "shobhit.srivastava@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70552_Dr_Shobhit_Kumar_Srivastav_SAS_1072_8cf39fc509.avif",
    "education": [
      "B.Sc, DDU Gorakhpur University, Gorakhpur, U.P.",
      "M.Sc, DDU Gorakhpur University, Gorakhpur, U.P.",
      "Ph.D, IIT(BHU) Varanasi, U.P."
    ],
    "researchArea": "Gas Dynamics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=RO5TBJMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57213822487",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/365242"
    }
  },
  {
    "id": "vitap-1491-cms",
    "name": "Dr. Sonali Kaushik",
    "employeeId": "15.70589",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "G24-A, AB-2",
    "email": "sonali.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70589_Dr_Sonali_Kaushik_MAT_1275_39a5481a80.avif",
    "education": [
      "B.Sc (H) Mathematics, Kirori Mal College, University of Delhi",
      "M.Sc in Pure Mathematics, Jamia Millia Islamia",
      "Ph.D., Birla Institute of Technology and Science Pilani, Pilani Campus"
    ],
    "researchArea": "Theoretical, numerical, and semi-analytical analysis of partial integro differential equations and infinite system of ODE's",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Sonali-Kaushik-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=SmcRqZkAAAAJ&hl=en",
      "orcid": "0000-0003-4628-0928",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57468428300",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/445955"
    }
  },
  {
    "id": "vitap-1495-cms",
    "name": "Dr. Chiranjeev Kumar Shahu",
    "employeeId": "15.7059",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "812 -G, CB",
    "email": "chiranjeev.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Chiranjeev_Kumar_Shahu_7059_0652_f72debb72f.avif",
    "education": [
      "B.Sc. CSJM University",
      "M.Sc. University of Allahabad",
      "PhD IIT Madras"
    ],
    "researchArea": "Differential Equations, Magnetization Dynamics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "linkedin.com/in/chiranjeev-kumar-shahu-644a9a184",
      "researchGate": "https://www.researchgate.net/profile/Chiranjeev-Shahu",
      "googleScholar": "https://scholar.google.com/citations?user=6g6yeDgAAAAJ&hl=en",
      "vidwan": "396133"
    }
  },
  {
    "id": "vitap-1419-cms",
    "name": "Dr. Tanmoy Das",
    "employeeId": "15.706",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "224-E, AB-2",
    "email": "tanmoy.das@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70600_Dr_Tanmoy_Das_VISH_1247_2637fd6dda.avif",
    "education": [
      "B.Sc. Computer Science - Cotton College, Gauhati University",
      "M.A. Development Studies - IIT Guwahati",
      "PhD - Jawaharlal Nehru University, New Delhi"
    ],
    "researchArea": "State, Governance and Development; State and Civil Society; Everyday state and Development; Peace and Conflict Studies; Political Anthropology; Political Sociology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/tanmoy-das-6b978622/",
      "researchGate": "https://www.researchgate.net/profile/Tanmoy-Das-7",
      "googleScholar": "https://scholar.google.com/citations?user=mPWbUJoAAAAJ&hl=en",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0002-6240-6781",
      "scopus": "57894595600",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/407430"
    }
  },
  {
    "id": "vitap-1430-cms",
    "name": "Dr. Pragnya Parimita Chayani",
    "employeeId": "15.70622",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "813 - J, CB",
    "email": "pragnyaparimita.ch@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pragnya_Parimita_Chayani_70622_IMG_4705_vish_ce84c30258.avif",
    "education": [
      "B.A (English), Utkal University",
      "M.A.(English), Ravenshaw University",
      "Indian Institute of Technology Dharwad, Karnataka"
    ],
    "researchArea": "Energy Humanities, Gender and Anthropocene, Neo-Extractivism, Ecocriticism, Migration and Diaspora Studies",
    "memberships": [
      "1. Member of Karnataka University, Dharwadâ€™s Literary Association (Since 2018) 2. Member of Petrocultures Research Group, University of Alberta, Canada (Since April 2023)"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "James Roach Fellowship, offered by Osmania University Centerfor International Programmes, Hyderabad (06th August 2019 – 06th September 2019)"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/pragnya-chayani-7b7273287/",
      "researchGate": "https://www.researchgate.net/profile/Pragnya-Chayani",
      "orcid": "https://orcid.org/0009-0005-1293-6839?lang=en",
      "vidwan": "https://vidwan.inflibnet.ac.in/myprofile#personal_information_panel :~:text=Profile%20URL%3A%20https%3A//vidwan.inflibnet.ac.in/ profile/447109"
    }
  },
  {
    "id": "vitap-1433-cms",
    "name": "Dr. Jabeen Yasmeen",
    "employeeId": "15.70623",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "813 - P, CB",
    "email": "jabeen.yasmeen@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Jabeen_Yasmeen_70623_IMG_2607_VISH_ef01354dc0.avif",
    "education": [
      "B.A. (Honours), Dibrugarh University.",
      "M.A. in English Literature, Jamia Millia Islamia",
      "PhD, Indian Institute of Technology Bombay,",
      "Institute Post Doctoral Fellow, Indian Institute of Technology Bombay"
    ],
    "researchArea": "Trauma narratives, Oral Narratives, Literature on Citizenship and Identity, Partition Studies, Food and Trauma Narratives, Literature from Northeast India.",
    "memberships": [
      "IACLALS, Indian Network for Memory Studies"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/447114"
    }
  },
  {
    "id": "vitap-1471-cms",
    "name": "Dr. Subhasis Panda",
    "employeeId": "15.70626",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "818 - O, CB",
    "email": "subhasis.panda@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/70626_Dr_Subhasis_Panda_MAT_1312_fb50792c7e.avif",
    "education": [
      "BSc, Utkal University",
      "MSc, University of Hyderabad",
      "PhD, Indian Institute of Technology Madras",
      "Indian Institute of Technology Kanpur"
    ],
    "researchArea": "Algebraic Number Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/446152"
    }
  },
  {
    "id": "vitap-1515-cms",
    "name": "Dr. Pema Choden Bhutia",
    "employeeId": "15.70654",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "124-H, AB-2",
    "email": "pemachoden.bhutia@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pema_Choden_Bhutia_VISH_0839_9833ae15d0.avif",
    "education": [
      "BA , Sri Sathya Sai Institute of Higher Learning, Anantapur Campus, Andhra Pradesh",
      "M.A. Economics, University of Madras, Chepauk, Chennai",
      "PhD. in Economics , Madras Institute of Development Studies, Chennai"
    ],
    "researchArea": "Tourism, Ecotourism, Environmental Valuation Techniques, Environmental Economics and Gender Issues.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "ICSSR Fellow",
      "M & EA Institutional Fund",
      "Government Scholarship",
      "GRDS Young Research Award"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Pema-Bhutia",
      "googleScholar": "https://scholar.google.com/citations?user=9tw1ICUAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=59132102600",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/528193/NTI4MTkz"
    }
  },
  {
    "id": "vitap-1524-cms",
    "name": "Ms. Nidhi Nair",
    "employeeId": "15.70668",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Law (VSL)",
    "subDepartment": null,
    "office": "415-H, AB-2",
    "email": "nidhi.nair@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Nidhi_Nair_70668_IMG_2534_VSL_515057149b.avif",
    "education": [
      "BA LLB (Guru Gobind Singh Indraprastha University)",
      "LLM (Kurukshetra University)",
      "Ph.D(Law) National Law Institute University, Bhopal"
    ],
    "researchArea": "Insolvency Laws",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1521-cms",
    "name": "Dr. Riya",
    "employeeId": "15.70671",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "819 - N, CB",
    "email": "riya@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Riya_SAS_1854_86e34e62ae.avif",
    "education": [
      "B.Sc. & Chaudhary Charan Singh University, Meerut, Uttar Pradesh",
      "M.Sc. & Chaudhary Charan Singh University, Meerut, Uttar Pradesh",
      "Ph.D. & Indian Institute of Information Technology, Design and Manufacturing, Jabalpur, Madhya Pradesh"
    ],
    "researchArea": "Decomposition of an Image into Structure and Texture Components, Image Enhancement, Image Denoising",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-riya-ruhela-a26743194/",
      "researchGate": "https://www.researchgate.net/profile/Riya-Ruhela-2",
      "googleScholar": "https://scholar.google.com/citations?user=SqywrBAAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57221098855"
    }
  },
  {
    "id": "vitap-1543-cms",
    "name": "Dr. Sane Umesh Reddy",
    "employeeId": "15.70674",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "813 - M, CB",
    "email": "saneumesh.r@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sane_Umesh_Reddy_70674_0655_ca3e1d9147.avif",
    "education": [
      "B.Sc., Sri Krishnadevaraya University",
      "M.Sc. Mathematics, Sri Venkateswara University",
      "Ph.D. in Spectral Graph Theory, IIT Bhubaneswar"
    ],
    "researchArea": "Spectral Graph Theory",
    "memberships": [
      "ILAS"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "CSIR-UGC NET (JRF), CSIR-UGC, 2017"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=Me5ahUEAAAAJ&hl=en",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/513021"
    }
  },
  {
    "id": "vitap-1546-cms",
    "name": "Dr. SK Ashadul Rahaman",
    "employeeId": "15.70675",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "125-J, AB2",
    "email": "ashadulrahaman.sk@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_SK_Ashadul_Rahaman_70675_0636_46b808a894.avif",
    "education": [
      "B.Sc. (Hons.), Aligarh Muslim University",
      "M.Sc., Aligarh Muslim University",
      "Ph.D., Aligarh Muslim University"
    ],
    "researchArea": "Summability Theory, Fuzzy Theory.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Scholarship award funded by AMU Alumni Association Toronto, Canada.",
      "Prof. Mohd Ozair Memorial Scholarship.",
      "University merit financial award.",
      "Türkiye Burslari international scholarship for a Ph.D. program.",
      "CSIR-JRF.",
      "UGC-NET.",
      "IIT-GATE"
    ],
    "links": {
      "linkedin": "linkedin.com/in/sk-ashadul-rahaman",
      "researchGate": "https://www.researchgate.net/profile/Sk-A-Rahaman",
      "googleScholar": "https://scholar.google.com/citations?user=xT48mk8AAAAJ&hl=en",
      "orcid": "https://orcid.org/my-orcid?orcid=0000-0002-4813-6965"
    }
  },
  {
    "id": "vitap-1539-cms",
    "name": "Dr. Vishnu V",
    "employeeId": "15.70677",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "813 - K, CB",
    "email": "vishnu.v@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vishnu_V_70677_IMG_5207_SENSE_a0aa28b017.avif",
    "education": [
      "BA English. MG University, Kottayam",
      "MA English (Cultural Studies). The English and Foreign Languages University, Hyderabad",
      "PhD in Film Studies. The English and Foreign Languages University, Hyderabad"
    ],
    "researchArea": "Film Studies, Cultural Studies, Popular Culture, Genre Studies, Science Fiction",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/554045/NTU0MDQ1"
    }
  },
  {
    "id": "vitap-1548-cms",
    "name": "Dr. Anindita Roy",
    "employeeId": "15.70682",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "819 - L, CB",
    "email": "anindita.roy@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Anindita_Roy_70682_IMG_4947_VISH_27fbfcb694.avif",
    "education": [
      "Graduation in Science, University of Calcutta",
      "Master in Spanish, Jawaharlal Nehru University",
      "PhD (Spanish) Jawaharlal Nehru University"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1549-cms",
    "name": "Dr. Ganesh M",
    "employeeId": "15.70684",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "202-D, AB-2",
    "email": "ganesh.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ganesh_M_70684_IMG_2686_VISH_5195b2b0cb.avif",
    "education": [
      "Biotechnology, Sri Venkateswara University",
      "Anthropology, University of Hyderabad",
      "Anthropology, University of Hyderabad"
    ],
    "researchArea": "Archaeological Anthropology, Prehistory and Heritage studies",
    "memberships": [
      "ISPQS, ISCA"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ganesh-m-7b690324/"
    }
  },
  {
    "id": "vitap-1552-cms",
    "name": "Dr. Srirupa Poddar",
    "employeeId": "15.70687",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "204-H, CB",
    "email": "srirupa.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Srirupa_Poddar_VISH_43e2e53359.avif",
    "education": [
      "B.A (English Honours), RamaKrishna Sarada Mission Vivekananda Vidya Bhavan, West Bengal State University",
      "MA (Applied Linguistics), University of Hyderabad. MPhil (Applied Linguistics), University of Hyderabad",
      "PhD (English Language Studies), University of Hyderabad"
    ],
    "researchArea": "English Language Teaching, Language Policy, Multilingualism, Business Communication & Soft Skills, and Documentation of Endangered Languages",
    "memberships": [
      "1. Member of Asian Association for Language Assessment (AALA) 2. Member of English Language Teachers Association of India (ELTAI) Member ID: E22M00637"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Received SS25 Early Career & Global South Researcher Grant (Online) to present my research paper virtually at the Sociolinguistics Symposium (SS) 25, to be held at Curtin University, Perth, Australia, from 24-27 June 2024"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/srirupa-poddar-02828973/"
    }
  },
  {
    "id": "vitap-1566-cms",
    "name": "Dr. Jyotsna Sharma",
    "employeeId": "15.70703",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "128-B, CB",
    "email": "jyotsna.sharma@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Jyotsna_Sharma_SASMAT_3184916674.avif",
    "education": [
      "Punjabi University",
      "Punjabi University",
      "Indian Institute of Technology Delhi"
    ],
    "researchArea": "Number Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1568-cms",
    "name": "Dr. Ronali Madhusmita Sahoo",
    "employeeId": "15.70705",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "124-E, AB-2",
    "email": "ronali.sahoo@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Ronali_Madhusmita_Sahoo_SASMAT_IMG_2169_dc6046c1a2.avif",
    "education": [
      "BSc in Computer Science, Dhenkanal Autonomous College (Dhenkanal)",
      "MCA, Veer Surendra Sai University of Technology (Burla)",
      "Ph.D., Veer Surendra Sai University of Technology (Burla)"
    ],
    "researchArea": "Multiprocessor Scheduling, ML/DL, Evolutionary Algorithms,",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=XValy9kAAAAJ",
      "scopus": "https://www-scopus-com.vitaplibrary.remotexs.in/authid/detail.uri?authorId=57215605681"
    }
  },
  {
    "id": "vitap-1573-cms",
    "name": "Dr. K Kinjari",
    "employeeId": "15.7071",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "224-C, AB-2",
    "email": "kinjari.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_K_Kinjari_VISH_IMG_7317_741cbf9c9c.avif",
    "education": [
      "B.Sc. Psychology, Patrician College Arts and Science (Affiliated to University of Madras)",
      "M.Sc. Counseling Psychology, Chettinad Academy of Research and Education",
      "Ph.D. Counseling Psychology, Chettinad Academy of Research and Education"
    ],
    "researchArea": "Applied Cognitive Psychology, Counseling Psychology, Social Psychology, Educational Psychology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/kinjarik/",
      "researchGate": "https://www.researchgate.net/profile/Kinjari-Kancharla",
      "googleScholar": "https://scholar.google.com/citations?user=yu6gct4AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57653544100",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/625707"
    }
  },
  {
    "id": "vitap-1610-cms",
    "name": "Dr. Krishna Nair J",
    "employeeId": "15.70748",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "307-E, AB-2",
    "email": "krishnanair.j@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Krishna_Nair_J_VISH_5fdfae7b8f.avif",
    "education": [
      "BA in Economics, Mahatma Gandhi University",
      "MA in Economics, Central University of Rajasthan",
      "PhD in Economics, Indian Institute of Technology Kharagpur"
    ],
    "researchArea": "Public Economics, Public Policy, Development Economics, Political Economy, Gender",
    "memberships": [
      "IPPA"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=idhORFIAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1616-cms",
    "name": "Dr. Akshay Kumar",
    "employeeId": "15.70752",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "204-C, CB",
    "email": "akshay.kumar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Akshay_Kumar_SAS_IMG_8146_016fd7f28e.avif",
    "education": [
      "B.Sc., University of Rajasthan, Jaipur",
      "M.Sc., IIT Madras",
      "Ph.D., MNIT JAIPUR (NIT JAIPUR), Post Doctoral Researcher, IIT MADRAS",
      "Post Doctoral Researcher, IIT MADRAS"
    ],
    "researchArea": "Functional Analysis and it's application to Function Spaces",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/me?trk=p_mwlite_feed-secondary_nav",
      "researchGate": "https://www.researchgate.net/profile/Akshay-Kumar-60?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=Dhdx_iUAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1626-cms",
    "name": "Dr. Raja Solanki",
    "employeeId": "15.70754",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "621 - H, CB",
    "email": "raja.solanki@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Raja_Solanki_SAS_IMG_8136_afe6ec3d60.avif",
    "education": [
      "B.Sc from Devi Ahilya University, Indore",
      "M.Sc (Mathematics) from Devi Ahilya University, Indore",
      "Ph.D from BITS-Pilani, Hyderabad."
    ],
    "researchArea": "Cosmology and Bayesian Modelling",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Best Paper Award from the Tensor Society, India in the year 2024."
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/raja-solanki-5b80a5240",
      "researchGate": "https://www.researchgate.net/profile/Raja-Solanki?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=YGo5lpAAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57222142773"
    }
  },
  {
    "id": "vitap-1628-cms",
    "name": "Dr. Talha Umar",
    "employeeId": "15.70756",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "621 - K, CB",
    "email": "talha.umar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Talha_Umar_SAS_IMG_8140_18e54f08cb.avif",
    "education": [
      "B.Sc, Aligarh Muslim University",
      "M.C.A. Aligarh Muslim University"
    ],
    "researchArea": "Cryptography, Encryption, Data Security",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/talha-umar-148a46a7/",
      "researchGate": "https://www.researchgate.net/profile/Talha-Umar-2",
      "googleScholar": "https://scholar.google.com/citations?user=RTXYOg4AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58489555200"
    }
  },
  {
    "id": "vitap-1632-cms",
    "name": "Dr. Himanshu Verma",
    "employeeId": "15.7076",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "621 - O, CB",
    "email": "himanshu.verma@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Himanshu_Verma_SAS_IMG_8142_289555c7ad.avif",
    "education": [
      "B.A., Chaudhary Devi Lal University, Haryana",
      "M.Sc., Guru Jambheshwar University of Science & Technology, Haryana",
      "Ph.D., Birla Institute of Technology and Science, Pilani , Pilani Campus, Rajasthan"
    ],
    "researchArea": "Crustal Structure, Fault Kinematics and Seismicity Statistics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "CSIR-UGC NET/JRF, 2018, 2019"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Himanshu-Verma-42?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=iQcmvL8AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57772927400",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/625716/NjI1NzE2"
    }
  },
  {
    "id": "vitap-1620-cms",
    "name": "Dr. Prachi Jain",
    "employeeId": "15.70764",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Physics",
    "office": "618 - P, CB",
    "email": "prachi.jain@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_PRACHI_JAIN_SAS_IMG_8118_388d7d16b6.avif",
    "education": [
      "B.Sc. (Physics Hons) , Delhi University",
      "M.Sc. (Physics) , Central University of Punjab",
      "Ph.D. (Physics), Netaji Subhas University of Technology"
    ],
    "researchArea": "Water Splitting, Hydrogen Production, Hydroelectric Cells, Energy Storage Devices, Energy Conversion, Multiferroics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "6 Commendable Research Awards(NSUT, 2025)"
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-prachi-jain-174006203",
      "researchGate": "https://www.researchgate.net/profile/Prachi-Jain-74",
      "googleScholar": "https://scholar.google.com/citations?user=0ZuU35MAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1621-cms",
    "name": "Dr. Parul Saini",
    "employeeId": "15.70765",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "818 - I, CB",
    "email": "parul.saini@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Parul_Saini_SAS_IMG_8162_5456c37587.avif",
    "education": [
      "Bachelor's of Art, Mathematics, Maharishi Dayanand University Rohtak, Haryana",
      "Master in Science, Mathematics, Maharishi Dayanand University Rohtak, Haryana",
      "Doctor of Philosophy in Mathematics, PDPM, Indian Institute of Information Technology, Design and Manufacturing Jabalpur, MP"
    ],
    "researchArea": "Numerical methods, Application of Spectral Methods in differential equations and noise corrupted signals",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1623-cms",
    "name": "Dr. Reddimala Naresh",
    "employeeId": "15.70767",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "818 - E, CB",
    "email": "naresh.reddimalla@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Reddimala_Naresh_SAS_IMG_8154_5ceb7944d8.avif",
    "education": [
      "B.Sc, Kakatiya University",
      "M.Sc (Mathematics), Mahatma Gandhi University",
      "P.hD (Mathamtics), NIT Warangal"
    ],
    "researchArea": "Meteorology, tides, Numerical modeling",
    "memberships": [
      "APTSMS"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "UGC-URH scholarship, UGC, 2017; DST- INSPIRE Fellowship, DST, 2020"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Naresh_Reddimalla?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=5BZQjcoAAAAJ&view_op=list_works&authuser=2&gmla=AH8HC4yUwQi1ZaAPqBkHKLJ5h_cq_599hFz-c3gtbRgqLpjX-7xd_s2Dx17tQ7pfcewOFeIMhO4gr9e9luG3JD6p",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57961506900"
    }
  },
  {
    "id": "vitap-1624-cms",
    "name": "Dr. Ansumalini Panda",
    "employeeId": "15.70768",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "329-J , AB-1",
    "email": "ansumalini.panda@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ansumalini_Panda_VSB_IMG_7259_3852db1286.avif",
    "education": [
      "FM University",
      "Utkal University",
      "NIT Rourkela"
    ],
    "researchArea": "Human Resource Management, Work-life Balance ,employee commitment, Psychological Empowerment, Employee Retention",
    "memberships": [],
    "projects": [],
    "patents": [
      "1.Title of Invention - System For Assessment of Work-Life balance and Method There of Application No - 202221005050A Date of Filling Application - 31/01/2022 Publication Date - 25/02/2022",
      "2. Title of Invention- Method For Determining Viability of a Business Application No-202221028250A Publication Date: 15/07/2022",
      "3. Title of Invention - : COLLABORATIVE INFORMATION SHARING SYSTEM AND METHOD THERE OF Application No - 202221028252 A Date of Filling Application - 17/05/2022 Publication Date - 15/07/2022",
      "4. Title: System and Method for AI driven dynamic pricing to reduce food waste in Retail Environments Application No-202541059251A Publication Date: 4/07/2025\""
    ],
    "awards": [
      "Conference- International conference on innovations in business, trade & commerce Paper Title- An empirical investigation of customer characteristics on retail format selection - a mediating role of store image. Date-11-12th March 2022 Publication: journal of Indian Business Research, emerald publication (Scopus with ABDC).",
      "2. Conference- International conference on circular economy- redefining the world and driving towards sustainability\". Paper title- Aligning industry 4.0 with sustainable performance: mediating role of circular economy capabilities and supply chain resilience. Date-18-19 May,2022 University-department of economics, MIT World Peace University partnership with Helwan university, Catholic university and the Climate Reality Project. Publication: Management of Environmental Quality, Emerald Publication (SCI and Scopus).NIL"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ansu-malini-848a5a61/",
      "googleScholar": "https://scholar.google.com/citations?user=mWimXekAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57196464695"
    }
  },
  {
    "id": "vitap-1637-cms",
    "name": "Dr. Santanu Dey",
    "employeeId": "15.70772",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "818 - A, CB",
    "email": "santanu.dey@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Santanu_Dey_SASMAT_IMG_8169_f331374145.avif",
    "education": [
      "B.Sc. (Honours), Vidyasagar University",
      "M.Sc., Vidyasagar University",
      "Ph.D., Indian Institute of Technology (ISM) Dhanbad"
    ],
    "researchArea": "Classification Problems, Multivariate Statistics, Statistical Inference, Directional Statistics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "JOINT CSIR-UGC NET (2019)",
      "GATE (2018, 2019)"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/santanu-dey-0b6938218/",
      "researchGate": "https://www.researchgate.net/profile/Santanu-Dey-5?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=8-NJa-YAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57658738900",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/638544/NjM4NTQ0"
    }
  },
  {
    "id": "vitap-1642-cms",
    "name": "Dr. Monika Srivastava",
    "employeeId": "15.70777",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "225-D, AB-2",
    "email": "monika.srivastava@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Monika_Srivastava_VISH_IMG_7319_b26de78222.avif",
    "education": [
      "B.A Psychology ( Patna Women's College)",
      "M.A Psychology (Central University of South Bihar)",
      "PhD Psychology (Indian Institute of Technology, Bhilai)"
    ],
    "researchArea": "Positive Psychology, Clinical Psychology and Statistics in Psychology",
    "memberships": [
      "Member of American Psychological Association, Member of International Positive Psychology Association"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=SyWCuyUAAAAJ&hl=en&oi=sra"
    }
  },
  {
    "id": "vitap-1645-cms",
    "name": "Dr. Keerthi Jain Kushal Jain",
    "employeeId": "15.7078",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "425-A, AB-1",
    "email": "keerthijain.Kj@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Keerthi_Jain_Kushal_Jain_VSB_IMG_8126_e9a530dd7a.avif",
    "education": [
      "B.Tech - EEE Dr MGR University",
      "MBA -Sacred Heart College",
      "PhD Marketing and Technology Management"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/k-keerthi-jain",
      "googleScholar": "https://scholar.google.com/citations?user=Rm9F-TEAAAAJ&hl=e",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57140838100"
    }
  },
  {
    "id": "vitap-1646-cms",
    "name": "Dr. Banoth Veeranna",
    "employeeId": "15.70781",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "207 - G, AB-2",
    "email": "banoth.veeranna@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Banoth_Veeranna_SASMAT_IMG_8158_07161ece96.avif",
    "education": [
      "B.Sc. Statistics - Kavitha Memorial Degree College, Khammam (KU-Warangal)",
      "M.Sc. Statistics - Kakatiya University, Warangal",
      "Ph.D. Statistics - University of Hyderabad, Hyderabad, Post Doctoral Fellow - Statistics - Banaras Hindu University, Varanasi",
      "Post Doctoral Fellow - Statistics - Banaras Hindu University, Varanasi"
    ],
    "researchArea": "Statistical Inference, Bayesian Inference, Distribution Theory, Probability and Statistics",
    "memberships": [
      "Life Membership in Indian Society for Probability and Statistics (ISPS)"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "National Fellowship Scheme For Higher Education of ST Students (NFST) - Ministry of Tribal Affairs - 2018-2022.",
      "PROF. A.M. MATHAI BEST Ph.D. THESIS AWARD – ISF - 2024. 3. Prof. Jacob Sundara raja Best Paper Presentation Award - 2024"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-banoth-veeranna-6301b5103/",
      "researchGate": "https://www.researchgate.net/profile/Banoth-Veeranna?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=4bAVcXcAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57952262200&origin=recordpage"
    }
  },
  {
    "id": "vitap-1647-cms",
    "name": "Dr. Debgopal Sahoo",
    "employeeId": "15.70782",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "818 - K, CB",
    "email": "debgopal.sahoo@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Debgopal_Sahoo_SASMAT_IMG_8181_55f0755226.avif",
    "education": [
      "B.Sc. in Mathematics, University of Calcutta",
      "M.Sc. in Applied Mathematics, IIEST Shibpur",
      "PhD, IIEST Shibpur"
    ],
    "researchArea": "Nonlinear Dynamics, Mathematical Biology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Debgopal-Sahoo",
      "googleScholar": "https://scholar.google.com/citations?user=3AVK3ZgAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1648-cms",
    "name": "Dr. Vadithe Rakesh Naik",
    "employeeId": "15.70783",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "328-F, AB-1",
    "email": "rakeshnaik.v@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Vadithe_Rakesh_Naik_VSB_IMG_8152_ececc7943b.avif",
    "education": [
      "Rayalaseema University",
      "University of Hyderabad",
      "Maulaua Azad National Institute of Technology (MANIT) - Bhopal"
    ],
    "researchArea": "HR Analytics; Green HRM; Blockchain Adoption in HR",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Runnerup in best research paper in Indian Management Research Conference (IMRC)-2024 conduted by IIM Ahmedabad. Paper titled \"Role of Technology enablers for implementation of HR analytics in Indian IT sector: A mediation analysis\"."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/rakesh-naik-vadithe-b0039322b/",
      "researchGate": "https://www.researchgate.net/profile/Rakesh-Vadithe?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=V5_wcwIAAAAJ&hl=en&oi=ao",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58956059900"
    }
  },
  {
    "id": "vitap-1649-cms",
    "name": "Dr. Suman Das",
    "employeeId": "15.70785",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "326 F - AB1",
    "email": "suman.das@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Suman_Das_VSB_IMG_7253_740fbf8bb0.avif",
    "education": [
      "B.Com (Accounting & Finance) , North Eastern Hill University",
      "M.Com(Accounting & Finance) , North Eastern Hill University",
      "North Eastern Hill University"
    ],
    "researchArea": "Accounting and Finance",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Best Paper Award for presenting paper titled “Bank Market Power and Risk: Comparative Analysis of India and Bangladesh” inInternational Seminar on Accounting, Finance, Business, and Social Sciences (ISAFBS’2023), Organised by Assam University, Silchar, in Collaboration with Alabama A&M University, USA",
      "Best Paper Award for presenting paper titled “Decoding Market Power: Insights from Listed Commercial Banks in India” International Seminar on Business and Sustainability Organized by the Department of Commerce in collaboration with BIZZ-BUILDER & IQAC, St. Edmund’s College, Shillong on 26th April 2024"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Suman-Das-63?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=kecdOxgAAAAJ&hl=en",
      "vidwan": "https://vidwan.inflibnet.ac.in/myprofile"
    }
  },
  {
    "id": "vitap-1650-cms",
    "name": "Dr. Vinay Kumar",
    "employeeId": "15.70786",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "618 -N, CB",
    "email": "vinay.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vinay_Kumar_SASMAT_IMG_7255_06006e3d9b.avif",
    "education": [
      "B.Sc., CSJM University, Kanpur",
      "M.Tech., IIT Madras",
      "Ph.D., IIT Madras"
    ],
    "researchArea": "Stochastic and Mathematical Modeling, Queueing Systems, and Optimization",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/vnyshakya/",
      "researchGate": "https://www.researchgate.net/profile/Vinay-Kumar-51",
      "googleScholar": "https://scholar.google.com/citations?user=TPSZf-0AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1661-cms",
    "name": "Dr. Sreenish S",
    "employeeId": "15.70798",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "125-H, AB-2",
    "email": "sreenish.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sreenish_S_VISH_2978e47baf.avif",
    "education": [
      "BA History, University of Kerala",
      "MA Philosophy, University of Kerala",
      "PhD Philosophy, University of Hyderabad"
    ],
    "researchArea": "Philosophy of Mind, Philosophy of Perception",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1663-cms",
    "name": "Dr. Abhilash Chand",
    "employeeId": "15.708",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "626 - B, CB",
    "email": "abhilash.chand@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Abhilash_Chand_SASMAT_3e1246ce1c.avif",
    "education": [
      "B.Sc. (Mathematics), Stewart Science College, Cuttack",
      "M.Sc. (Mathematics), Ravenshaw University, Cuttack",
      "Ph.D., National Institute of Technology, Rourkela"
    ],
    "researchArea": "Finite element discontinuous Galerkin methods, Applied Mathematics, Mathematical Physics, Computational Mathematics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "JOINT CSIR-UGC NET JRF (2019), GATE (2019,2020)"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-abhilash-chand-1651ba22/",
      "researchGate": "https://www.researchgate.net/profile/Abhilash-Chand",
      "googleScholar": "https://scholar.google.co.in/citations?user=zq1FBboAAAAJ&hl=en",
      "scopus": "http://www.scopus.com/inward/authorDetails.url?authorID=57893230100&partnerID=MN8TOARS",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/667736"
    }
  },
  {
    "id": "vitap-1664-cms",
    "name": "Dr. Arpita Devi",
    "employeeId": "15.70804",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "622-C, Central Block",
    "email": "arpita.devi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Arpita_Devi_SASMAT_ff40ff136b.avif",
    "education": [
      "BSc in Mathematics (Honours), Cotton University, Guwahati",
      "MSc in Mathematics, Central University of Punjab, Bathinda",
      "PhD, National Institute of Technology Silchar"
    ],
    "researchArea": "Nonlinear Dynamics, Mathematical Epidemiology, Population Biology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-arpita-devi-60990b18b/",
      "researchGate": "https://www.researchgate.net/profile/Arpita-Devi-2/research",
      "googleScholar": "https://scholar.google.com/citations?user=EmEuqa8AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58835444100",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/667547"
    }
  },
  {
    "id": "vitap-1671-cms",
    "name": "Dr. Ritesh Ranjan",
    "employeeId": "15.70808",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "622-E, CB",
    "email": "ritesh.ranjan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Ritesh_Ranjan_VISH_105db8a25c.avif",
    "education": [
      "B.A (Hons) French, Banaras Hindu University",
      "MA (French), Pondicherry University",
      "PhD (French), Banaras Hindu University"
    ],
    "researchArea": "French and Francophone literature, French literature & Culture, Franco Moroccan literature ,Maghreb literature, French Translation & Interpretation",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/ritesh-ranjan-042150111/"
    }
  },
  {
    "id": "vitap-1674-cms",
    "name": "Dr. Komal",
    "employeeId": "15.70811",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "622-I, CB",
    "email": "komal@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_KOMAL_SAS_e9b32cf71f.avif",
    "education": [
      "B.Sc., Maharshi Dayanand University, Rohtak, Haryana",
      "M.Sc. (Mathematics), Guru Jambheshwar University of Science & Technology, Hisar, Haryana",
      "Ph.D. (Mathematics), Birla Institute of Technology and Science, Pilani , Pilani Campus, Rajasthan"
    ],
    "researchArea": "Mathematical Modeling, Fractional Differential Equation, Crime Dynamics, Unemployment, Epidemiology, Dynamical System",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "CSIR-UGC NET/JRF, 2018",
      "Best Paper Presentation 2nd International Conference on Applied Mathematics in Science and Engineering (AMSE-2022)"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-komal-bansal-148144185/",
      "researchGate": "https://www.researchgate.net/profile/Komal-Bansal-3?ev=hdr_xprf&_tp=eyJjb250ZXh0Ijp7ImZpcnN0UGFnZSI6ImhvbWUiLCJwYWdlIjoiaG9tZSIsInBvc2l0aW9uIjoiZ2xvYmFsSGVhZGVyIn19",
      "googleScholar": "https://scholar.google.com/citations?user=JMdTYYMAAAAJ&hl=en&authuser=1",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=56209154000",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/521258"
    }
  },
  {
    "id": "vitap-1676-cms",
    "name": "Dr. Manisha Bhadran",
    "employeeId": "15.70813",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "622-K, CB",
    "email": "manisha.bhadran@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Manisha_Bhadran_VISH_ce41a29bb7.avif",
    "education": [
      "B.A. English — M.G. University, Kottayam",
      "M.A. English Literature — The English and Foreign Languages University, Hyderabad",
      "Ph.D. English — University of Hyderabad"
    ],
    "researchArea": "Women's Studies, Human Rights and Literature, South Asian and West Asian Studies, Law and Literature",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=DwHSKSQAAAAJ",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=59702347100"
    }
  },
  {
    "id": "vitap-1684-cms",
    "name": "Dr. Muneeswaran R",
    "employeeId": "15.70818",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "424-B, AB-1",
    "email": "muneeswaran.r@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Muneeswaran_SASPHY_75426bb69b.avif",
    "education": [
      "B.Sc, Mathematics & Ayya Nadar Janaki Ammal College, Sivakasi",
      "M.Sc, Mathematics & Central University of Kerala",
      "PhD, Number Theory & IISER, Thiruvananthapuram"
    ],
    "researchArea": "Number Theory, Coding Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/muneeswaran-r-a407721a0?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BfQcIKnRCRDye7w%2FqYAjwPg%3D%3D",
      "googleScholar": "https://scholar.google.com/citations?hl=en&view_op=list_works&gmla=AElLoL37Vj82AZpBcLmo7PeRgsY5TP-czH0EBwFkOkt4XulgWISQ5fwVA19_qF6tB52pGnFnMEEFh5VC6BWv6w&user=Pgd3erEAAAAJ"
    }
  },
  {
    "id": "vitap-1682-cms",
    "name": "Dr. Udita Banerjee",
    "employeeId": "15.7082",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "224-B, AB-1",
    "email": "udita.banerjee@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Udita_Banerjee_VISH_dac052c088.avif",
    "education": [
      "B.A. (Hons) in English | The University of Burdwan",
      "M.A. | M.Phil. | The University of Burdwan",
      "Ph.D. | IIT Gandhinagar"
    ],
    "researchArea": "Partition Literature(s), Affect Studies, Object Oriented Ontology, Border & Migration Studies",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1688-cms",
    "name": "Dr. Nishi Gupta",
    "employeeId": "15.70825",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "818 - C, CB",
    "email": "nishi.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_NISHI_GUPTA_SAS_aeb4b022c4.avif",
    "education": [
      "B.Sc, CSJM University Kanpur, U.P.",
      "M.Sc., CSJM University Kanpur, U.P.",
      "Ph.D, National Institute of Technology Silchar, Assam",
      "IPDF, Indioan Institute of Technology Guwahati, Assam"
    ],
    "researchArea": "Partial Differential EquationPartial Differential Equation",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Best Paper Award, ICAMCI, NIT Agartala-2020"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=odyXZQgAAAAJ&hl=en&oi=sra",
      "scopus": "57209931664"
    }
  },
  {
    "id": "vitap-1689-cms",
    "name": "Dr. Inzamul Sarkar",
    "employeeId": "15.70826",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "225-I, AB-2",
    "email": "inzamul.sarkar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_INZAMUL_SARKAR_VISH_1b4e5f984f.avif",
    "education": [
      "BA (Hons.) in Linguistics, Aligarh Muslim University",
      "MA in Linguistics, Aligarh Muslim University",
      "PhD in Linguistics, Aligarh Muslim University"
    ],
    "researchArea": "Sociolinguistic Ethnography, Translanguaging, English Language Education and Humour Studies.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-inzamul-sarkar-a8aa4b22a/",
      "researchGate": "https://www.researchgate.net/profile/Inzamul-Sarkar?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=scT6odQAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57470756300"
    }
  },
  {
    "id": "vitap-1709-cms",
    "name": "Dr. Varna Venugopal",
    "employeeId": "15.70841",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "329-E, AB-1",
    "email": "varna.venugopal@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Varna_Venugopal_VISH_3dce71cc6f.avif",
    "education": [
      "BA in English Language and Literature, University of Calicut",
      "MA in English, University of Hyderabad",
      "PhD in English, Indian Institute of Technology Madras (IIT Madras)"
    ],
    "researchArea": "Environmental Humanities, Phytocriticism, Indian Writing in English",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Charles Wallace Visiting Fellowship at IAS, Durham University , 2026",
      "Institute Research Award, IIT Madras, 2024 Awarded by the Office of the Dean of Academic Research to PhD scholars demonstrating outstanding publications, strong academic performance, and excellence in research communication."
    ],
    "links": {}
  },
  {
    "id": "vitap-1713-cms",
    "name": "Dr. Aishwarya Dhawan",
    "employeeId": "15.7085",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "225 H, AB-2",
    "email": "aishwarya.dhawan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_AISHWARYA_DHAWAN_VISH_62dd9a4e9a.avif",
    "education": [
      "Bachelor of Arts (Economics), St. Xavier's College, Ranchi University",
      "Master of Arts (Economics), Banaras Hindu University",
      "PhD (Economics), IIT Bombay"
    ],
    "researchArea": "Environmental Economics, Water Resource Management, Applied Econometrics, Geospatial Analysis",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1714-cms",
    "name": "Dr. Krishna Priya B",
    "employeeId": "15.70851",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "125-A, AB-2",
    "email": "krishna.priya@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_KRISHNA_PRIYA_B_VISH_eaf7f14fc5.avif",
    "education": [
      "BSc. Psychology- M.O.P Vaishnav College for Women, Chennai (Affiliated to University of Madras)",
      "MSc. Counselling Psychology- University of Madras",
      "PhD. Psychology- Vellore Institute of Technology, Vellore"
    ],
    "researchArea": "Counselling & Health Psychology, Psychoneuroimmunology, Social Psychology, Caregiving Research & Advocacy.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Four Raman Research Award — Awarded by Vellore Institute of Technology for Publications in Scopus-Indexed and Impact Factor Journals (2023, 2024).",
      "Best Presentation Award — October 2023, 5th International Conference on Innovative Strategies and Advancements in Academics and Research: Navigating Global Scenarios.",
      "Best Presentation Award — October 2022, 4th International Conference on Developing New India through Science, Social Science, Humanities, and Research.",
      "Best Alumni Award for Academic Excellence — 2022, Department of Counselling Psychology, University of Madras.",
      "University First Rank Holder — 2022, Department of Counselling Psychology, University of Madras.",
      "Madras University Merit Fellowship — 2022, Department of Counselling Psychology, University of Madras.",
      "Best Paper Award — March 2021, International e-conference organized by Dr. MGR Janaki College for Women.",
      "Prof. Deepak Bhat Award for best paper presentation — February 2021, 56th National & 25th International Conference organized by Indian Academy of Applied Psychology (IAAP).",
      "Member-Alumni Representative for Board of Studies for Psychology Program- 2020, Department of Social Sciences, MOP Vaishnav College for Women.",
      "A.S Radhika Memorial Award for the best outgoing student, BSc Psychology — 2019, Department of Psychology, MOP Vaishnav College for Women.",
      "Shri VV Sabha Endowment Prize for securing 1st rank in BSc Psychology— 2019, Department of Psychology, MOP Vaishnav College for Women.",
      "Second position in the Intramural exhibition, Chinmay club — 2016 Department of Psychology, M.O.P Vaishnav College for Women.",
      "Top 2% on Stress Management Certification Course — 2016 National Programme on Technology Enhanced Learning."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-krishna-priya-balachandran-15286b165?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app",
      "googleScholar": "https://scholar.google.com/citations?user=Cg49GOIAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58393614700",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/665375"
    }
  },
  {
    "id": "vitap-1717-cms",
    "name": "Dr. Aysha Thasleema K S",
    "employeeId": "15.70855",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "225 A1, AB-2",
    "email": "aysha.thasleema@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_AYSHA_THASLEEMA_K_S_VISH_7af5d92121.avif",
    "education": [
      "BSc. Psychology, University of Calicut",
      "MSc. Applied Psychology, Pondicherry University",
      "PhD in Psychology, University of Hyderabad"
    ],
    "researchArea": "Child and adolescent health, Well-being research, Health risk behaviours",
    "memberships": [
      "Member of Indian Association of Health Psychologists"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Prof. AS Dash Medal for the best PhD thesis from Centre for Psychology, University of Hyderabad in 2025",
      "Best paper award for presentation titled Association between Self-Efficacy and Wellbeing of Adolescents: Mediating role of Psychosocial Support at the International Conference jointly organized by Association of Health Psychologists, Bhaktivedanta Research Center, Stockholm University, and Sri Padmavati Mahila Visvavidyalayam on December 2022"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Aysha-Thasleema?ev=hdr_xprf"
    }
  },
  {
    "id": "vitap-1731-cms",
    "name": "Dr. Uzma Azam",
    "employeeId": "15.70866",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "224-F2, AB2",
    "email": "uzma.azam@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_UZMA_AZAM_VISH_3d9addb935.avif",
    "education": [
      "B.A , ALIGARH MUSLIM UNIVERSITY",
      "M.A, ALIGARH MUSLIM UNIVERSITY",
      "PHD, ALIGARH MUSLIM UNIVERSITY"
    ],
    "researchArea": "Environmental Psychology",
    "memberships": [
      "AMERICAN PSYCHOLOGICAL ASSOCIATION"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/uzma-a-31491a13b",
      "researchGate": "https://www.researchgate.net/profile/Uzma-Azam",
      "googleScholar": "https://scholar.google.com/citations?user=q4zewgYAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1740-cms",
    "name": "Dr. Velmala Sharath Kumar",
    "employeeId": "15.70875",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "621-A, CB",
    "email": "sharathkumar.velmala@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Velmala_Sharath_Kumar_VISH_1e6eee9eaf.avif",
    "education": [
      "B. Pharmacy, Kakatiya University, Warangal",
      "MA German, English and Foreign Languages University , Hyderabad",
      "PhD German, Jawaharlal Nehru University, New Delhi"
    ],
    "researchArea": "German Literature, DaF",
    "memberships": [
      "Goethe Society of India (GSI)"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Baden-Württemberg-Stipendium for University Students Universität Konstanz - 2022",
      "IPIW – International Promovieren in Wuppertal Bergische Universität Wuppertal - 2017",
      "Junior Research Fellowship (JRF) awarded by UGC, India - 2018"
    ],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=ikkbMqAAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1758-cms",
    "name": "Dr. Devarapalli Suman",
    "employeeId": "15.70893",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "165, AB-1",
    "email": "suman.devarapalli@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Devarapalli_Suman_VSB_86039f9409.avif",
    "education": [
      "B. Com General (Acharya Nagarjuna University, Guntur)",
      "MBA (Finance and Marketing) (Acharya Nagarjuna University, Guntur)",
      "SRM University, AP, Amaravathi"
    ],
    "researchArea": "Integrated Reporting, Corporate Governance, Sustainability, CSR, and Corporate Finance",
    "memberships": [
      "(i) INSC membership Life (ID: 20247YRA97) (ii) Commerce and Management Association of India (CMAI) CMA/25/0844"
    ],
    "projects": [],
    "patents": [],
    "awards": [
      "Received “INSC Young Research Award -2024\""
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-devarapalli-suman-51007637",
      "researchGate": "https://www.researchgate.net/profile/Devarapalli-Suman?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?authuser=2&user=4EE7zoQAAAAJ"
    }
  },
  {
    "id": "vitap-1759-cms",
    "name": "Dr. Sinjini Chakraborty",
    "employeeId": "15.70894",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "813-N, CB",
    "email": "sinjini.chakraborty@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sinjini_Chakraborty_VISH_27550b9f3f.avif",
    "education": [
      "B.A. (Hons.) in English ; Asutosh College, Calcutta University)",
      "M.A. in English (Linguistics) ; The English and Foreign Languages University, Hyderabad",
      "PhD in Linguistics & Phonetics. ; The English and Foreign Languages University, Hyderabad"
    ],
    "researchArea": "Articulatory & Acoustic Phonetics, Forensic Phonetics, Sociophonetics, Dialect Studies, Speech Perception",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-sinjini-chakraborty-44b59b14b",
      "researchGate": "https://www.researchgate.net/profile/Sinjini-Chakraborty-2"
    }
  },
  {
    "id": "vitap-1764-cms",
    "name": "Dr. Parveen",
    "employeeId": "15.709",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "812-I, CB",
    "email": "parveen@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Parveen_SASMAT_cab6f53ad7.avif",
    "education": [
      "B.A., CDLU Sirsa",
      "M.Sc Mathematics, MDU Rohtak",
      "Ph.D Mathematics, BITS Pilani, Institute Post Doctoral Fellow, IIT Guwahati",
      "Institute Post Doctoral Fellow, IIT Guwahati"
    ],
    "researchArea": "Algebraic Graph Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-parveen-1874b030b/",
      "researchGate": "https://www.researchgate.net/profile/Parveen-Bishnoi-2",
      "googleScholar": "https://scholar.google.com/citations?user=LF_vQ6QAAAAJ&hl=en&authuser=2",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57254434400"
    }
  },
  {
    "id": "vitap-1765-cms",
    "name": "Dr. Moumita Ghosh",
    "employeeId": "15.70901",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "812 - O, CB",
    "email": "moumita.ghosh@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Moumita_Ghosh_SASMAT_282a9480f1.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1773-cms",
    "name": "Dr. Reetika Chawla",
    "employeeId": "15.70909",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "819 - I, CB",
    "email": "reetika.chawla@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Reetika_Chawla_SASMAT_6ee507c01d.avif",
    "education": [],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1775-cms",
    "name": "Dr. Muhammed Navas K A",
    "employeeId": "15.70912",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "207 - E, AB-2",
    "email": "muhammed.navas@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Muhammed_Navas_K_A_VISH_fef3f12920.avif",
    "education": [
      "BA Economics, University of Calicut, Kerala",
      "MA Economics and M.Phil Economics, University of Madras, Tamil Nadu",
      "PhD Economics, University of Madras, Chennai, Tamil Nadu"
    ],
    "researchArea": "Agricultural Development, Labour and Employment Studies, Gender and Development, Rural Livelihoods, Development Policy and Governance.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-muhammed-navas-ka-64b677362"
    }
  },
  {
    "id": "vitap-1776-cms",
    "name": "Dr. Charu Waliyan",
    "employeeId": "15.70913",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "723-H, CB",
    "email": "charu.waliyan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Charu_Waliyan_VISH_dfef592b1b.avif",
    "education": [
      "Dr. Bhimrao Ambedkar University",
      "Banaras Hindu University",
      "Banaras Hindu University"
    ],
    "researchArea": "Youth language, social media communication, intercultural communication,",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1777-cms",
    "name": "Dr. Kavya R Nair",
    "employeeId": "15.70914",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "207-C, AB-2",
    "email": "kavya.nair@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kavya_R_Nair_SASMAT_ba298d4a0a.avif",
    "education": [
      "BSc Mathematics- Sacred Hearts College, Thevara, Kerala",
      "MSc Mathematics- Cochin University of Science and Technology",
      "PhD- National Institute of Technology Calicut"
    ],
    "researchArea": "Graph Theory, Fuzzy Graph Theory",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "CSIR- JRF in Mathematical Sciences (2019)"
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/kavya-r-nair-48218a320",
      "researchGate": "https://www.researchgate.net/profile/Kavya-Nair-8?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=ZWAKg5oAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1780-cms",
    "name": "Dr. Angana Das",
    "employeeId": "15.70918",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "813 - O, CB",
    "email": "angana.das@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Angana_Das_VISH_c4e4072ec4.avif",
    "education": [
      "B.A in Comparative Literature, Jadavpur University",
      "M.A. in Comparative Literature, Jadavpur University",
      "PhD in English, Department of Humanities and Social Sciences, IIT Kanpur"
    ],
    "researchArea": "Literatures of Africa, Postcolonial Studies, Feminist Theory and Literary Criticism",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1781-cms",
    "name": "Dr. Arunava Acharya",
    "employeeId": "15.70919",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "621-F, CB",
    "email": "arunava.acharya@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Arunava_Acharya_VISH_c01a84ab2c.avif",
    "education": [
      "BA (Honours), University of Calcutta",
      "MA, University of Delhi",
      "PhD, IIT Roorkee"
    ],
    "researchArea": "1.Post-Truth Studies, 2.Historiography and Historical Fiction, 3.Cultural Studies, 4.Media, Technology, and Society, 5.Speculative Fiction, 6.Political Aesthetics, 7.Public Humanities",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Arunava-Acharya",
      "googleScholar": "https://scholar.google.com/citations?user=zQMDYIoAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1782-cms",
    "name": "Dr. Sharanya Ghosh",
    "employeeId": "15.7092",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "621-I, CB",
    "email": "sharanya.ghosh@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sharanya_Ghosh_VISH_21fa4e2a4a.avif",
    "education": [
      "B.A., University of Calcutta",
      "M.A., Presidency University Kolkata",
      "PhD, Indian Institute of Technology Jodhpur, Postdoctoral Research Fellow, FLAME University Pune",
      "Postdoctoral Research Fellow, FLAME University Pune"
    ],
    "researchArea": "Digital Humanities, Digital Pedagogy, Cognitive Literary Studies",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Research Visit Fellowship awarded by ICSSR for visit to Johannes Gutenberg University Mainz, Germany;",
      "Paul Fortier Prize, awarded by the Alliance of the Digital Humanities Organzations, Graz, Austria"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Sharanya-Ghosh-2?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=xBwYfu0AAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1784-cms",
    "name": "Dr. Ajmal S Rasaq",
    "employeeId": "15.70922",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "307-H, AB-2",
    "email": "ajmal.rasaq@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Ajmal_S_Rasaq_VISH_af4f68c2ec.avif",
    "education": [
      "BA Political Science, Mahatma Gandhi University, Kottayam, Kerala",
      "MA Political Science, University of Hyderabad",
      "PhD Humanities & Social Sciences, Indian Institute of Technology, Guwahati"
    ],
    "researchArea": "Political Geography, Political Ecology, Geographies of Caste and Capital",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Earth Scholarship, Scottish Graduate School for Arts & Humanities, British Council Scotland, 2023"
    ],
    "links": {}
  },
  {
    "id": "vitap-1785-cms",
    "name": "Dr. Sarath Sasikumar",
    "employeeId": "15.70923",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "817-H, CB",
    "email": "sarath.sasikumar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Sarath_Sasikumar_VISH_12fc8da622.avif",
    "education": [
      "Bachelor of Arts in Political Science, University of Calicut",
      "Master of Arts in Political Science, University of Hyderabad",
      "Doctor of Philosophy in Political Science, Centre for Political Studies, Jawaharlal Nehru University"
    ],
    "researchArea": "Political Sociology, Political Theory, Identity Politics, Marxism, and Kerala Politics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "researchGate": "https://www.researchgate.net/profile/Sarath-Sasikumar-3?ev=hdr_xprf",
      "scopus": "https://www.scopus.com/pages/authors/57222121734"
    }
  },
  {
    "id": "vitap-1787-cms",
    "name": "Dr. Arghya Chakraborty",
    "employeeId": "15.70925",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "1013 - A, CB",
    "email": "arghya.chakraborty@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Arghya_Chakraborty_VISH_6c90b6e049.avif",
    "education": [
      "B.A. (Hons), West Bengal State University",
      "M.A. (Gold Medalist), Maharaja Sayajirao University of Baroda",
      "Ph.D. (English), Maharaja Sayajirao University of Baroda"
    ],
    "researchArea": "English Poetry, American Literature, Latin American Literature, Drama and Performance, Cultural Studies, and English Language Teaching",
    "memberships": [
      "ELT@I and British Council"
    ],
    "projects": [],
    "patents": [
      "Design 455947-001, English Literature Skill Teaching Device"
    ],
    "awards": [
      "Awarded with Shakespeare Society Prof. V.Y. Kantak Gold Medal in the year 2019"
    ],
    "links": {
      "researchGate": "https://www.researchgate.net/publication/333809314"
    }
  },
  {
    "id": "vitap-1791-cms",
    "name": "Dr. Purnendu Bikash Debnath",
    "employeeId": "15.70927",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "1013-C, CB",
    "email": "purnendu.debnath@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Purnendu_Bikash_Debnath_VISH_9e0eab8db9.avif",
    "education": [
      "BA English, The English and Foreign Languages University",
      "MA Linguistics, University of Delhi",
      "P.HD Linguistics and Phonetics, The English and Foreign Languages University"
    ],
    "researchArea": "Phonetics, Morphology, Syntax, ELT",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1807-cms",
    "name": "Dr. Halavath Rajesh",
    "employeeId": "15.70949",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "1016-B, CB",
    "email": "rajesh.halavath@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Halavath_Rajesh_VISH_750c4debfe.avif",
    "education": [
      "BA(Spanish)-The English and foreign language University-Hyderabad",
      "MA(Spanish)-The English and foreign language University-Hyderabad",
      "Ph.D.(Spanish)-The English and foreign language University-Hyderabad"
    ],
    "researchArea": "Environmental literature, comparative study of Latin American and Indian literature",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1816-cms",
    "name": "Dr. Supratik Deb",
    "employeeId": "15.70958",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "171, AB-1",
    "email": "supratik.deb@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Supratik_Deb_VSB_43eb0b03f6.avif",
    "education": [
      "BTech, NIT Durgapur",
      "MBA, ABV-IIITM Gwalior",
      "PhD, IIT Kharagpur"
    ],
    "researchArea": "Corporate Finance, Capital Structure Theory, Corporate Debt, Corporate Governance, Security Analysis and Portfolio Management",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1825-cms",
    "name": "Dr. Ramesh Kumar Mahtha",
    "employeeId": "15.70967",
    "designation": "Assistant Professor Grade 1",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "1013-D, CB",
    "email": "rameshkumar.mahtha@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ramesh_Kumar_Mahtha_70fdb1c105.avif",
    "education": [
      "B.A. in English Literature, SKMU",
      "M.A. in English Literature, BHU",
      "PhD in English, School of Humanities and Social Sciences, IIT Indore, Postdoctoral RA in Digital Humanities and Social Sciences at JPN National Centre of Excellence in the Humanities, IIT Indore",
      "Postdoctoral RA in Digital Humanities and Social Sciences at JPN National Centre of Excellence in the Humanities, IIT Indore"
    ],
    "researchArea": "Indian Postcolonial Studies, Postcolonial Literature & Theory, Identity and Violence Studies, Digital Humanities",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-ramesh-kumar-mahtha-3a92b423a",
      "researchGate": "https://www.researchgate.net/profile/Ramesh-Kumar-Mahtha?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?user=EDhf_j8AAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=59348269200"
    }
  },
  {
    "id": "vitap-1263-cms",
    "name": "Ms. Kanaka Himabindu P.",
    "employeeId": "16.70185",
    "designation": "Assistant Professor",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "202-D1, AB-2",
    "email": "kanaka.himabindu@vitap.ac.in",
    "phone": "5400",
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Kanaka_Himabindu_P_70185_VISH_8ee2586be4.avif",
    "education": [
      "Integrated Master of Arts, University of Hyderabad",
      "Master of Philosophy, Indian Institute of Technology Hyderabad",
      "Doctor of Philosophy, Indian Institute of Technology Hyderabad"
    ],
    "researchArea": "Socio-Cultural Anthropology - Urban Studies, Sustainability, Smart Cities, Medical Anthropology, Tribal Studies",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "Awarded Best Synopsis in BASAS (British Association of South Asian Studies) international conference held at Durham, UK and awarded a price money of 1000 pounds.",
      "Invited Student Panelist for a symposium on 21st November 2017, \"Discuss Cultivation of Global Human Resource of Japan Through Foreign Perspectives\" held at Tokyo, Japan.",
      "Acquired Academic Excellence Award for the year 2014-15 in M.Phil. at Indian Institute of Technology Hyderabad.",
      "Secured Gold Medal for being the Topper of Integrated Master’s in Anthropology from University of Hyderabad, Hyderabad.",
      "Received medal for being the topper of the college in intermediate (M.E.C) from V.S.L. Jr. College, Kakinada."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/kanaka-himabindu-pottumuthu-733ab742/",
      "researchGate": "https://www.researchgate.net/profile/Kanaka-Pottumuthu?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=V3yuoVYAAAAJ",
      "orcid": "0000-0002-6608-9277",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58633379600",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/258739"
    }
  },
  {
    "id": "vitap-1601-cms",
    "name": "Mr. Jayanta Pratihar",
    "employeeId": "16.70736",
    "designation": "Assistant Professor",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "816 - F, CB",
    "email": "jayanta.pratihar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Jayanta_Pratihar_SCOPE_54e087c19f.avif",
    "education": [
      "B. Sc. in Mathematics Honours, Calcutta University (West Bengal)",
      "M. Sc. & M. Tech. in Computer Science & Engineering, Maulana Abul Kalam Azad University of Technology (West Bengal)"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1741-cms",
    "name": "Mr. Gowtham Polumati",
    "employeeId": "16.70876",
    "designation": "Assistant Professor",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "621-B, CB",
    "email": "gowtham.polumati@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Gowtham_Polumati_SENSE_ce3dc0a23e.avif",
    "education": [
      "BITS Pilani Hyderabad Campus",
      "JNTUH",
      "JNTUH"
    ],
    "researchArea": "Nano Scale Semiconductor Devices and Optoelectronics",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=CovvfPkAAAAJ"
    }
  },
  {
    "id": "vitap-1763-cms",
    "name": "Ms. Sruthi Sasidharan",
    "employeeId": "16.70899",
    "designation": "Assistant Professor",
    "department": "School of Social Science and Humanities (VISH)",
    "subDepartment": null,
    "office": "723 - C, CB",
    "email": "sruthi.sasidharan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Sruthi_Sasidharan_VISH_cc3097ffb6.avif",
    "education": [
      "BA English Language and Literature, Kannur University",
      "MA English and Comparative Literature, Central University of Kerala"
    ],
    "researchArea": "Comparative Literature, Caste studies, Phenomenology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1771-cms",
    "name": "Ms. Harapriya Kar",
    "employeeId": "16.70907",
    "designation": "Assistant Professor",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "819-C, CB",
    "email": "harapriya.kar@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Harapriya_Kar_SCOPE_1516d1eab9.avif",
    "education": [
      "B.Tech Biju pattanaik university Rourkela",
      "M.Tech Pondicherry University",
      "PhD Vellore Institute of Technology Vellore"
    ],
    "researchArea": "Advanced Deep learning Model Analysis, Assistive Technology, Computer Vision, IOT Automation| Robotics| Sign Language Interpretation| Quantum Communication",
    "memberships": [
      "IEEE, ACM"
    ],
    "projects": [
      "Rescue Robo Sign-Bot: Real-Time Emergency Communication Assistant for Hearing-Impaired Individuals"
    ],
    "patents": [
      "1. App. 202541085594 (Filed: 15 Sep 2025; Published: 03 Oct 2025), title{A Wearable Robotic Ring System (RUSCBot) for Facilitating Communication for Persons with Speech, Hearing, or Visual Impairments.} Inventors: Harapriya Kar, Viswanathan P. Applicant: VIT.",
      "2. App.No.202641025046 (Filed: 03 march 2026; Published: 23 march 2026), title{A multilingual sign language interpretation system configured for real-time deployment on an IOT-enabled robotic or assistive communication platform.}, Inventors: Harapriya Kar, Viswanathan P. Applicant: VIT.",
      "3. App. No. 202641073778 (Filed: 14 June 2026; Published: 26 June 2026), title{REINFORCEMENT-THRESHOLD CONTROLLED SPATIOTEMPORAL GESTURE INTERPRETATION SYSTEM USING ADAPTIVE MEMORY ENGINE.}, Inventors: Harapriya Kar, Viswanathan P. Applicant: VIT",
      "4. App. No. 202641081007 (Filed: 01 July 2026; Published: 03 july 2026, title{System and Method for Multilingual Sign Interpretation and Assistive Communication Using Coordinated Spatiotemporal Processing.}, Inventors: Harapriya Kar, Viswanathan P. Applicant: VIT"
    ],
    "awards": [
      "{APJ Abdul Kalam Award} --- Received for academic and research excellence, with a cash prize of INR~15,000.",
      "{Raman Research Award} --- Recognised for outstanding research contribution, with a cash prize of INR~10,000.",
      "{Raman Research Award} --- Recognised for outstanding research contribution, with a cash prize of INR~15,000.",
      "{Wearable Device Development Grant} --- Received components and product development fund INR 20000 from IIC and EDC to develop a wearable assistive device for the hearing and visually impaired community.",
      "{Topper of the Batch} (2019--2020) --- Radhakrishna Institute of Technology, Bhubaneswar.",
      "{IIT Mumbai Certification} --- Certified by the Spoken Tutorial Project, IIT Mumbai, in C and Java.",
      "{IIT Bhubaneswar Certification} --- Certified and received cash INR 3000 by IIT bhubaneswar, Hackathon, in AR and VR.",
      "{Hackathon on Augmented Reality} --- Participated in Conclave and Hackathon at IIT Bhubaneswar."
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/harapriya-kar-0955a7184/",
      "researchGate": "https://www.researchgate.net/profile/Harapriya-Kar-4?ev=hdr_xprf",
      "googleScholar": "https://scholar.google.com/scholar?hl=en&as_sdt=0%2C5&authuser=1&q=Harapriya+kar&oq=",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58951576500",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/319398"
    }
  },
  {
    "id": "vitap-1792-cms",
    "name": "Dr. Bandi Narasimha Rao",
    "employeeId": "16.70932",
    "designation": "Assistant Professor",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1013-H, CB",
    "email": "narasimharao.bandi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bandi_Narasimha_Rao_SENSE_ab5042962f.avif",
    "education": [
      "B.Tech,JNTU Kakinada",
      "M.Tech,NIT Warangal",
      "Phd, NIT Warangal"
    ],
    "researchArea": "Wireless Communications",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=6AytmqoAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1795-cms",
    "name": "Mr. Lavati Hemanth Krishna",
    "employeeId": "16.70936",
    "designation": "Assistant Professor",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "618-I, CB",
    "email": "hemanthkrishna.lavati@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Lavati_Hemanth_Krishna_SENSE_534a92e961.avif",
    "education": [
      "B.Tech, JNTU-Kakinada",
      "M.Tech, JNTU-Kakinada",
      "Ph.D Indian Institute of Technology Mandi"
    ],
    "researchArea": "Low Power VLSI Design, Approximate Computing, Hardware Accelerators, Multi-valued Logic and Emerging Nano Devices",
    "memberships": [
      "IEEE"
    ],
    "projects": [
      "Design of a Ternary Matrix Product Cell with Applications to Emerging Device Technologies (SERB/348) — Principal Investigator: Dr. B. Srinivasu; Project Associate: L. Hemanth Krishna"
    ],
    "patents": [],
    "awards": [
      "Student/Research Fellowship Award – IEEE Computer Society Annual Symposium on VLSI (ISVLSI), 2026.",
      "Student/Research Fellowship Award – International Conference on VLSI Design (VLSID), 2026."
    ],
    "links": {
      "linkedin": "https://in.linkedin.com/in/hemanth-krishna-4bb087189",
      "researchGate": "https://www.researchgate.net/profile/Mr-L-Hemanth-Krishna",
      "googleScholar": "https://scholar.google.com/citations?user=SQHfd_0AAAAJ&hl=en",
      "orcid": "https://orcid.org/0000-0002-7737-6685",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57451900100"
    }
  },
  {
    "id": "vitap-1801-cms",
    "name": "Mr. Vangapandu Dhanunjaya Naidu",
    "employeeId": "16.70943",
    "designation": "Assistant Professor",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1016-G, CB",
    "email": "dhanunjayanaidu.vangapandu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Vangapandu_Dhanunjaya_Naidu_SENSE_54ca678739.avif",
    "education": [
      "B.Tech Electrical and Electronics & Acharya nagarjuna university",
      "M.Tech Electrical Power Systems & Savitribhai Phule Pune University",
      "High Voltage Engineering (Thesis Submitted) & NIT Warangal"
    ],
    "researchArea": "High voltage AC/DC systems, Nano dielectrics, Condition monitoring of power apparatus and Polymeric insulation.",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dhanunjaya-naidu-v-30a325287/",
      "googleScholar": "https://scholar.google.com/citations?user=qg-lTpoAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1818-cms",
    "name": "Mr. Kumar Vaibhav Tejan",
    "employeeId": "16.7096",
    "designation": "Assistant Professor",
    "department": "School of Electronics Engineering (SENSE)",
    "subDepartment": null,
    "office": "1017 - N, CB",
    "email": "kumarvaibhav.tejan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Kumar_Vaibhav_Tejan_SENSE_fa36ebab08.avif",
    "education": [
      "B.Tech & AKTU, Lucknow",
      "M.Tech & IIT Mandi",
      "Ph.D. & IIT Mandi"
    ],
    "researchArea": "Power electronics and drives, electrical machines control and design of electrical machines, conditioning monitoring control of PMSM & EV stability control for In-wheel motor",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/kumar-vaibhav-tejan-212b40190/"
    }
  },
  {
    "id": "vitap-1826-cms",
    "name": "Ms. Dharani Sabari Samudrala",
    "employeeId": "16.70968",
    "designation": "Assistant Professor",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": null,
    "office": "819-H, CB",
    "email": "dharanisabari.samudrala@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dharani_Sabari_Samudrala_c49ba04f55.avif",
    "education": [
      "GITAM College & Andhra University",
      "SRM UNIVERSITY-AP",
      "SRM UNIVERSITY-AP"
    ],
    "researchArea": "Deep Learning, Machine Learning, 5G Communications, Artificial Intelligence, Wireless Communication.",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. 202541016042 and A System and Method for Predicting Network Traffic in Next-Generation Cellular Networks",
      "2. 202541014367 and A System and Method for Predicting Cellular Network Traffic",
      "3. 202541128949 and A System and Method for Real-Time Cellular Traffic Prediction with Spatio-Temporal Based Network Optimization",
      "4. 202541124710 and Traffic Management System and Method for Real-Time Traffic Congestion Prediction and Dynamically Optimize Vehicle Routing"
    ],
    "awards": [],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dharani-sabari-samudrala-7b797824b/",
      "googleScholar": "https://scholar.google.com/citations?hl=en&user=ZEchKjYAAAAJ"
    }
  },
  {
    "id": "vitap-1545-cms",
    "name": "Mr. Gundimeda Venugopal",
    "employeeId": "17.70797",
    "designation": "Professor of Practice",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "618 -O, CB",
    "email": "venugopal.g@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Gundimeda_Venugopal_IMG_6586_SCOPE_096d01a61b.avif",
    "education": [
      "EEE, Jawaharlal Nehru Technological University",
      "MTech Computer Science, Jawaharlal Nehru University, New Delhi"
    ],
    "researchArea": "Natural Language Processing, Computer Vision, Machine Learning, Deep Learning",
    "memberships": [],
    "projects": [],
    "patents": [
      "1. 10660576 System and method for detecting retinopathy (Granted 26 May 2020)",
      "2. 10846571, SYSTEM AND METHOD FOR RECOGNIZING LOGOS (Granted, 24 Nov 2020)",
      "3. 10949702, System and a method for semantic level image retrieval (Granted,16 Mar,2021)",
      "4. 11087153, TRAFFIC LIGHT RECOGNITION SYSTEM AND METHOD(Granted, 10 Aug 2021)",
      "5. 11132577, A System and a Method for Efficient Image Recognition(Granted, 28 Sep 2021)",
      "6. 20180150562, System and Method for Automatically Extracting and Analyzing Data (Filed, 21 Jul 2017)"
    ],
    "awards": [
      "Cognizant Innovation Awards 2016, Cognizant Jun 2017 ( Runner-Up in Cognizant Digital Business Digital Category )",
      "Cognizant Innovation award 2010, Cognizant (First Place for Innovation Concepts Category)",
      "eGovernance Architecture Committee Member - Government of India (2005)",
      "Best paper Award ( International conference on Artificial Intelligence and Cognitive computing), 2018",
      "JNU fellowship",
      "National Merit Scholarship holder"
    ],
    "links": {
      "linkedin": "https://in.linkedin.com/in/gundimedavenugopal",
      "researchGate": "https://www.researchgate.net/profile/Venugopal-Gundimeda-2/research",
      "googleScholar": "https://scholar.google.com/citations?user=BiEix3oAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-1335-cms",
    "name": "Dr. Nadiminti Nagamani",
    "employeeId": "19.70211",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Advanced Science (SAS)",
    "subDepartment": "Maths",
    "office": "325-B, AB-2",
    "email": "nagamani.n@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Nadiminti_Nagamani_SAS_1490_d59bc120a3.avif",
    "education": [
      "Andhra University",
      "Andhra University",
      "NIT Rourkela"
    ],
    "researchArea": "Statistical Inference",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1724-cms",
    "name": "Sudhir Shenoy S",
    "employeeId": "11111",
    "designation": "Adjunct Faculty",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "Sudhir & Vikas Chartered Accountants , Mangalore",
    "email": "secretary.vsb@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/CA_Sudhir_Shenoy_S_4c7fcb6ae9.avif",
    "education": [],
    "researchArea": "Chattered Accountant",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1725-cms",
    "name": "Dr. Bhanu Prakash Reddy Varla",
    "employeeId": "11112",
    "designation": "Adjunct Faculty",
    "department": "School of Business (VSB)",
    "subDepartment": null,
    "office": "– Plural Technology Pvt Ltd, EdifyPath, Angel Investor -Graylogic-Urbankisaan- Beenfield, Startup Mentor, Post Doctorate – Birla Institute (BIMTECH), TedX Speaker",
    "email": "secretary1.vsb@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Bhanu_Prakash_Reddy_Varla_ca9d312585.avif",
    "education": [],
    "researchArea": "IITB | IIMB | Partner & Director",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1577-cms",
    "name": "Ms. Yarlagadda Siva Reshma",
    "employeeId": "70709",
    "designation": "Assistant Professor Junior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "619-O, CB",
    "email": "sivareshma.y@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Yarlagadda_Siva_Reshma_SCOPE_358652a00f.avif",
    "education": [
      "B.Tech-Computer Science and Engineering,JNTUK",
      "M.Tech-Computer Science and Engineering with Specialization in Artificial Intelligence and Machine Learning,VIT,Chennai"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1581-cms",
    "name": "Mr. Kandru Lakshmi Sai Praneeth",
    "employeeId": "70716",
    "designation": "Assistant Professor Junior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "619-B, CB",
    "email": "saipraneeth.kl@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Kandru_Lakshmi_Sai_Praneeth_SCOPE_7db458ab0c.avif",
    "education": [
      "B.Tech-JNTUK",
      "M.Tech-Gitam university"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1589-cms",
    "name": "Mr. Madugula Kiran Kumar",
    "employeeId": "70724",
    "designation": "Assistant Professor Junior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DAIML",
    "office": "618 -J, CB",
    "email": "kirankumar.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Madugula_Kiran_Kumar_SCOPE_9b251552a5.avif",
    "education": [
      "ANU",
      "AU"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1591-cms",
    "name": "Ms. Pechetti Mounika",
    "employeeId": "70726",
    "designation": "Assistant Professor Junior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DSSE",
    "office": "619-D, CB",
    "email": "mounika.p@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Pechetti_Mounika_SCOPE_d931a04f52.avif",
    "education": [
      "B.Tech , JNTUK",
      "M.Tech, JNTUK"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1593-cms",
    "name": "Mr. Burla Nagaraju",
    "employeeId": "70728",
    "designation": "Assistant Professor Junior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DNS",
    "office": "623-J, CB",
    "email": "nagaraju.burla@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Mr_Burla_Nagaraju_SCOPE_253ae69fe6.avif",
    "education": [
      "B.Tech & JNTU-Kakinada",
      "M.Tech & JNTU-Kakinada"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [
      "1.Application No.202141005229 A & Title of The Invention : An Iot Based Healthcare System to Find Medical Emergency and Initiate Expert Care",
      "2.Application No.202341076765 A & Title of the invention : Method and System for Dynamic Resource Allocation and Load Balancing for Energy-Efficient Iot Networks"
    ],
    "awards": [],
    "links": {
      "googleScholar": "https://scholar.google.com/citations?user=MMMamQMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=58905753700",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/352360"
    }
  },
  {
    "id": "vitap-1598-cms",
    "name": "Ms. Mannepuli Srujana",
    "employeeId": "70733",
    "designation": "Assistant Professor Junior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "619-C, CB",
    "email": "srujana.m@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Mannepuli_Srujana_SCOPE_24bfb4c050.avif",
    "education": [
      "B.Tech JNTUK",
      "M.Tech & Acharya Nagarjuna University"
    ],
    "researchArea": null,
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1603-cms",
    "name": "Ms. Paidipogu Sowjanya",
    "employeeId": "70738",
    "designation": "Assistant Professor Junior",
    "department": "School of Computer Science and Engineering (SCOPE)",
    "subDepartment": "DDSE",
    "office": "128-I, CB",
    "email": "sowjanya.paidipogu@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Ms_Paidipogu_Sowjanya_SCOPE_e1dc871315.avif",
    "education": [
      "BTECH & JNTUA",
      "MTECH & JNTUA"
    ],
    "researchArea": null,
    "memberships": [
      "ACM"
    ],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {}
  },
  {
    "id": "vitap-1-sbst",
    "name": "Dr. Jayasankari Senthilganesh",
    "employeeId": "13.70897",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Bio Sciences and Technology (SBST)",
    "subDepartment": null,
    "office": "812-B,CB",
    "email": "jayasankari.s@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_JAYASANKARI_SBST_8983078619.avif",
    "education": [
      "M.tech (integrated), SASTRA Deemed University",
      "M.tech (integrated), SASTRA Deemed University",
      "Ph.D, SASTRA Deemed University"
    ],
    "researchArea": "Mycology, Candidiasis, ex vivo studies",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [],
    "links": {
      "linkedin": "www.linkedin.com/in/dr-jayasankari-senthilganesh-76527a157",
      "googleScholar": "https://scholar.google.com/citations?user=qlhFVAMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=57215589253"
    }
  },
  {
    "id": "vitap-2-sbst",
    "name": "Dr. Mood Rajitha",
    "employeeId": "13.70917",
    "designation": "Assistant Professor Senior Grade 1",
    "department": "School of Bio Sciences and Technology (SBST)",
    "subDepartment": null,
    "office": "1017-K, CB",
    "email": "rajitha.mood@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Mood_Rajitha_SBST_2e06d2bf30.avif",
    "education": [
      "Integrated MSc Systems Biology, University of Hyderabad",
      "Integrated MSc Systems Biology, University of Hyderabad",
      "Ph.D. Biotechnology, National Institute of Animal Biotechnology"
    ],
    "researchArea": "Molecular biology, Host–Parasite Interactions, Vector Biology, Natural Product Research",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "CSIR-NET (JRF-LS) — Life Sciences, AIR 158th rank (2017)"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-rajitha-mood-110210127/",
      "googleScholar": "https://scholar.google.com/citations?user=61W5xLYAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-3-sbst",
    "name": "Dr. Pranjal Kumar",
    "employeeId": "12.70910",
    "designation": "Assistant Professor Senior Grade 2",
    "department": "School of Bio Sciences and Technology (SBST)",
    "subDepartment": null,
    "office": "819-J, CB",
    "email": "pranjal.k@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Pranjal_Kumar_SBST_1edb90ed25.avif",
    "education": [
      "B.Sc. (Biotechnology), Pt. Ravishankar Shukla University, Raipur (CG)",
      "M.Sc. (Biotechnology)- RTM Nagpur University; M.Tech. (Medical Biotechnology)- IIT Hyderabad; M.A.Ed. (Pursuing)- Birmingham City University, United Kingdom",
      "Ph.D. (Molecular Cancer Biology) - IIT Dharwad"
    ],
    "researchArea": "Cancer Biology and Molecular Oncology; Long Non-coding RNAs (lncRNAs) and Non-coding RNA Biology; Traditional Medicine and Integrative Oncology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "CSIR-UGC NET (Life Sciences)",
      "CSIR-UGC NET & JRF (Life Sciences)",
      "ASRB NET (Agricultural Biotechnology)",
      "ASRB NET (Animal Biotechnology)",
      "UGC-NET (Environmental Sciences, Twice)",
      "DBT-JRF (BET - Category I)",
      "ICMR-JRF (Life Sciences)",
      "GATE-BT (AIR-31)",
      "TIFR-JGEEBILS"
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/drpranjalk",
      "googleScholar": "https://scholar.google.com",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/487549"
    }
  },
  {
    "id": "vitap-4-sbst",
    "name": "Dr. Kotapati Kasi Viswanath",
    "employeeId": "9.70928",
    "designation": "Associate Professor Senior",
    "department": "School of Bio Sciences and Technology (SBST)",
    "subDepartment": null,
    "office": "1013-P, CB",
    "email": "kasiviswanath.kotapati@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Kotapati_Kasi_Viswanath_SBST_d158d7d222.avif",
    "education": [
      "Biotechnology & Sri Venkateswara University, Tirupati",
      "Biochemistry & Sri Venkateswara University, Tirupati",
      "Bioinformatics & Pondicherry University"
    ],
    "researchArea": "Plant Biotechnology, Plant Virology, Biochemistry, Bioinformatics, Nanotechnology",
    "memberships": [],
    "projects": [],
    "patents": [],
    "awards": [
      "MOST-Taiwan Fellowship-2018",
      "Associate Fellow-APAS-2022",
      "Qualified AP-SET-2016"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/dr-kasi-viswanath-kotapati-8326116a/",
      "googleScholar": "https://scholar.google.com/citations?user=pKLqUd4AAAAJ&hl=en",
      "vidwan": "https://vidwan.inflibnet.ac.in/profile/487549"
    }
  },
  {
    "id": "vitap-5-sbst",
    "name": "Dr. Vikas Sharma",
    "employeeId": "11.70929",
    "designation": "Associate Professor Grade 1",
    "department": "School of Bio Sciences and Technology (SBST)",
    "subDepartment": null,
    "office": "1013-E, CB",
    "email": "vikas.sharma@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vikas_Sharma_SBST_db0b0bf33e.avif",
    "education": [
      "B.Tech. (Biotechnology), Kurukshetra University",
      "M.Tech. (Biotechnology), Kurukshetra University",
      "PhD (Biotechnology), National Institute of Technology Raipur, Pohang University of Science & Technology (POSTECH), South Korea (QS WUR #106), 2022-2026"
    ],
    "researchArea": "Bioprocess Engineering, AI-assisted Integrated Bio-manufacturing Systems, Microfluidic Technology, Development of Biochips",
    "memberships": [],
    "projects": [],
    "patents": [
      "Microfluidic Reaction Device and mRNA Synthesis Method (PCT/KR2024/014779; WIPO No. WO2025071355A1)"
    ],
    "awards": [
      "MSCA Postdoctoral Fellowship Seal of Excellence (European Commission 2025)",
      "SERB-National Postdoctoral Fellowship (2022) - Awarded (Not availed)",
      "GATE Qualified (2015 & 2022)"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/vikas-sharma-bioscience",
      "googleScholar": "https://scholar.google.com/citations?user=aI5rV0QAAAAJ&hl=en"
    }
  },
  {
    "id": "vitap-6-sbst",
    "name": "Dr. Shraddha Chauhan",
    "employeeId": "11.70930",
    "designation": "Associate Professor Grade 1",
    "department": "School of Bio Sciences and Technology (SBST)",
    "subDepartment": null,
    "office": "1013-F, CB",
    "email": "shraddha.chauhan@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Shraddha_Chauhan_SBST_9cfc3c8c79.avif",
    "education": [
      "B.Tech (Biotechnology), Gautam Buddh Technical University",
      "M.Tech (Biotechnology), Rajiv Gandhi Proudyogiki Vishwavidyalaya (RGPV)",
      "PhD (Biotechnology), National Institute of Technology Raipur , Research Assistant Professor (POSTECH, South Korea), Postdoctoral Researcher (POSTECH, South Korea), IPDF (IISER Bhopal (2022-2023)"
    ],
    "researchArea": "Molecular diagnostics, Electrochemical and Microfluidic Biosensors, Synthetic biology, Epigenetics",
    "memberships": [],
    "projects": [],
    "patents": [
      "2026: Cys-Gly-Cu Laccase mimicking Nanozyme ( Application number (KR): 10-2026-0072778)",
      "2025: Electrochemical aptasensor for TB Ag85B (Application number (KR): 10-2025-0041739)",
      "2023: Laccase based electrochemical sensor for arsenic (Application number (IN): 202321007040)"
    ],
    "awards": [
      "Research Professor Award (POSTECH, South Korea) 2025-2026",
      "Postdoctoral Fellowship (POSTECH, South Korea) 2023-2025",
      "IPDF IISER Bhopal 2022-2023",
      "Young Scientist Award 2019",
      "MHRD Doctoral Fellowship 2016-2021"
    ],
    "links": {
      "linkedin": "https://www.linkedin.com/in/shraddha-chauhan-4177b6225?trk=contact-info",
      "googleScholar": "https://scholar.google.com/citations?user=O8vcNusAAAAJ&hl=en&oi=ao"
    }
  },
  {
    "id": "vitap-7-sbst",
    "name": "Dr. Vishal Tripathi",
    "employeeId": "11.70939",
    "designation": "Associate Professor Grade 1",
    "department": "School of Bio Sciences and Technology (SBST)",
    "subDepartment": null,
    "office": "1013-K, CB",
    "email": "vishal.tripathi@vitap.ac.in",
    "phone": null,
    "photoUrl": "https://vitap-backend.s3.ap-south-1.amazonaws.com/Dr_Vishal_Tripathi_SBST_f5e3c5b97e.avif",
    "education": [
      "B.Sc. (Botany, Chemistry, Zoology) DDU Gorakhpur University",
      "M.Sc. (Plant Biotechnology) Banaras Hindu University",
      "Ph.D. (Plant Biotechnology) Banaras Hindu University, Post Doc Berlin-Brandenburg Institute of Advanced Biodiversity Research (BBIB), Freie Universität Berlin"
    ],
    "researchArea": "Environmental Biotechnology; Plant–Microbe Interactions; Bioremediation; Soil and Plant Health; Sustainable Agriculture",
    "memberships": [],
    "projects": [
      "Sustainable Utilisation of Invasive Plant Biomass for Bioactive Component Recovery and Biochar Generation: A Unique Solution for Improving Rural Livelihoods in Uttarakhand — National Mission on Himalayan Studies (NMHS), Ministry of Environment, Forest and Climate Change, Government of India — Co-Principal Investigator"
    ],
    "patents": [
      "202411091817 A — A TERAHERTZ-BASED DETECTION SYSTEM AND METHOD THEREOF"
    ],
    "awards": [
      "Green Talent Award — Federal Ministry of Education and Research (BMBF), Germany — 2018",
      "AU-CBT Research Excellence Award — Biotech Research Society of India (BRSI) — 2016",
      "Louis Pasteur Young Scientist Award — Association of Microbiologists of India (AMI) & Lovely Professional University, Jalandhar, Punjab — 2023",
      "Best Oral Presentation Award for “Microplastic Pollution in Terrestrial Ecosystem” — International Symposium on Sustainable Urban Environment, Sustainability Cluster, UPES, Dehradun — 2022",
      "Travel Award — Food and Agriculture Organization (FAO) of the United Nations, to attend the Global Soil Symposium on Soil Pollution (GSOP18), FAO Headquarters, Rome, Italy — 2018",
      "Best Presentation Award for “How Does Warming Affect Lindane Dissipation and Microbial Activity in Soil” — International Conference on Pesticide Behaviour in Soil, Air and Water, University of York, UK — 2017",
      "Travel Bursary Award — Bayer AG, to attend the International Conference on Pesticide Behaviour in Soil, Air and Water, University of York, UK — 2017"
    ],
    "links": {
      "linkedin": "www.linkedin.com/in/vishal-tripathi-941bb330",
      "googleScholar": "https://scholar.google.com/citations?user=mJZHBPMAAAAJ&hl=en",
      "scopus": "https://www.scopus.com/authid/detail.uri?authorId=55694653100"
    }
  }
];
