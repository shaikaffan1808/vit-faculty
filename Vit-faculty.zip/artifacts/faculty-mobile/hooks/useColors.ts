import { useColorScheme } from 'react-native';
import colors from '@/constants/colors';

export function useColors(override?: 'light' | 'dark') {
  const systemScheme = useColorScheme();
  const scheme = override ?? (systemScheme === 'dark' ? 'dark' : 'light');
  const palette = scheme === 'dark' ? colors.dark : colors.light;
  return { ...palette, radius: colors.radius };
}
