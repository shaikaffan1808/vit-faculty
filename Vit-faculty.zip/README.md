# Vit faculty

Vit faculty is a searchable VIT-AP University faculty directory available as a
responsive website, installable PWA, and Expo mobile app.

This workspace contains three ways to use the directory:

- A responsive web directory that runs locally in VS Code.
- An installable, offline-capable progressive web app (PWA).
- A native iOS and Android app built with Expo.

The faculty records and campus background are bundled with the apps. Search and
faculty profile details do not need a live server or a website URL. Profile
photos are hosted by VIT-AP; photos already cached on a device may remain
available offline, and missing photos fall back to initials.

## Requirements

- Node.js 20 LTS or newer
- pnpm 10
- VS Code (optional; the commands also work in a terminal)

From the project root, install the dependencies once:

```sh
corepack enable
pnpm install
```

## Run the website locally

```sh
pnpm dev:web
```

Open `http://localhost:5173`. The local dev server does not require
platform-specific environment variables. It refreshes the bundled faculty
snapshot when the official source is available and keeps the saved snapshot
when it is not.

To open the development site on a phone, connect the phone and computer to the
same Wi-Fi network, then open the **Network** URL printed by Vite (for example,
`http://192.168.1.20:5173`). Do not use `localhost` on the phone; that refers to
the phone itself. If the URL does not load, allow Node.js through the computer's
firewall for private networks.

## Install and use the PWA offline

1. Start the website and open it once in a browser.
2. Use the browser's **Install app** or **Add to Home Screen** action.
3. Open the installed app. After its first successful load, the app shell,
   bundled faculty data, campus image, and icons are cached for offline use.

The PWA is configured to update itself when a newer build is available. It
does not need a separate app-store link.

## Run the native app

```sh
pnpm dev:mobile
```

Use the Expo QR code with Expo Go, or launch an available simulator from the
Expo terminal. The native app includes the faculty data and campus photo in its
bundle and keeps the Day/Night preference on the device.

To create a local native build, use a computer with the relevant platform tools:

```sh
pnpm --filter @workspace/faculty-mobile android
pnpm --filter @workspace/faculty-mobile ios
```

Android builds require Android Studio and its SDK. iOS builds require macOS and
Xcode.

## Refresh the bundled faculty data

When online, run:

```sh
pnpm refresh:faculty
```

This updates the web and native snapshots together. The web app also runs this
refresh before development and production builds. If VIT-AP's public source is
temporarily unavailable, the existing snapshot is retained; if there is no
snapshot yet, the command reports an error instead of silently creating an
empty directory.

## Build the web PWA

```sh
pnpm build:web
```

The production site, web manifest, and service worker are written to
`artifacts/search-directory/dist/public/`.

## Publish the website

The `vit-faculty` GitHub Pages workflow builds and publishes the PWA whenever
changes are pushed to the `main` branch. In the repository settings, enable
GitHub Pages with **GitHub Actions** as the deployment source.

The public website address is:
`https://<your-github-account>.github.io/vit-faculty/`
